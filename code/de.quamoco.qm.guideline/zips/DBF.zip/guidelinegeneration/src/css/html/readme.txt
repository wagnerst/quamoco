This file is necessary as long as the folder does not contain another file due to eclipse bug #33171

https://bugs.eclipse.org/bugs/show_bug.cgi?id=33171
/*--------------------------------------------------------------------------+
$Id: Unit.java 30402 2010-10-07 09:16:26Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/**
 * Base class for units.
 * <p>
 * We have observed that in large code bases, the number of different units
 * after normalization is significantly smaller than the total number of units.
 * We exploit this observation in order to reduce the memory footprint of the
 * units by pooling unit content strings. This way, each unit content string is
 * only kept in memory once, independent of how often it occurs in the source
 * code. For pooling, we use Java's {@link String#intern()} facility in the
 * constructor {@link Unit}.
 * <p>
 * <b>Note:</b> The implementation of {@link #hashCode()} and
 * {@link #equals(Object)} are crucial for the detection algorithm.
 * 
 * @author Florian Deissenboeck
 * @author $Author: juergens $
 * @author Elmar Juergens
 * @version $Rev: 30402 $
 * @levd.rating GREEN Hash: C30A13EE825E29C47EF0F050A4785B96
 */
public abstract class Unit {

	/** String pool used to reuse equal content strings for units */
	public static final WeakHashMap<String, WeakReference<String>> stringPool = new WeakHashMap<String, WeakReference<String>>();

	// ALERT: we are not thread-safe here! No synchronization.
	private static String intern(String s) {
		WeakReference<String> ref = stringPool.get(s);
		if (ref != null) {
			String result = ref.get();
			if (result != null) {
				return result;
			}
		}

		ref = new WeakReference<String>(s);
		stringPool.put(s, ref);
		return s;
	}

	/** The position in the file */
	private final int startLineInFile;

	/** The uniform path of the element this unit stems from. */
	private final String elementUniformPath;

	/** The number of lines covered by this unit */
	private final int coveredLines;

	/** The number of lines covered by this unit */
	private final int indexInFile;

	/** The content of this unit. */
	private final String content;

	/** The content of this unit without normalization */
	private final String unnormalizedContent;

	/** Create a new unit with identical normalized and unnormalized content */
	protected Unit(int startLineInFile, String elementUniformPath, String content,
			int coveredLines, int indexInFile) {
		this(startLineInFile, elementUniformPath, content, content, coveredLines, indexInFile);
	}

	/** Create new unit */
	protected Unit(int startLineInFile, String elementUniformPath, String content,
			String unnormalizedContent, int coveredLines, int indexInFile) {
		this.startLineInFile = startLineInFile;
		this.elementUniformPath = elementUniformPath;
		this.content = intern(content);
		this.unnormalizedContent = intern(unnormalizedContent);
		this.coveredLines = coveredLines;
		this.indexInFile = indexInFile;
	}

	/** Uniform path of the element this unit stems from. */
	public String getElementUniformPath() {
		return elementUniformPath;
	}

	/** Gets the line number of the start of the unit in the source file. */
	public int getStartLineInFile() {
		return startLineInFile;
	}

	/** Gets the index of the unit in the source file */
	public int getIndexInFile() {
		return indexInFile;
	}

	/** Returns the number of lines this unit covers in the source file */
	public int getCoveredLines() {
		return coveredLines;
	}

	/** Textual content of the unit. */
	public String getContent() {
		return content;
	}

	/** Unnormalized textual content of this unit */
	public String getUnnormalizedContent() {
		return unnormalizedContent;
	}

	/**
	 * The hash code of a unit object is identical to the hash code of its
	 * content string.
	 * 
	 * @see #getContent()
	 */
	@Override
	public int hashCode() {
		return content.hashCode();
	}

	/** Two unit objects are equal if there content strings are equal. */
	@Override
	public boolean equals(Object other) {
		// contrary to the myths on the net this is not slower than catching
		// the class cast exception
		if (!(other instanceof Unit)) {
			return false;
		}

		// Since the content string is interned, we can perform reference
		// comparison instead of calling equals()
		return content.equals(((Unit) other).content);
	}

	/** Default implementation returns false. Override for synthetic units */
	public boolean isSynthetic() {
		return false;
	}
}
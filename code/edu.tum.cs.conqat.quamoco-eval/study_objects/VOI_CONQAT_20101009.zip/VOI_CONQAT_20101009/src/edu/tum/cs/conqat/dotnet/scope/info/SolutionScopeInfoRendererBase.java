/*--------------------------------------------------------------------------+
$Id: SolutionScopeInfoRendererBase.java 29928 2010-08-26 12:36:16Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.info;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATFieldParameter;
import edu.tum.cs.conqat.dotnet.scope.SolutionScopeInfo;

/**
 * Base class for processors that render {@link SolutionScopeInfo}s.
 * 
 * @author ladmin
 * @author $Author: juergens $
 * @version $Rev: 29928 $
 * @levd.rating YELLOW Hash: A9E9167AA34C1EB80506755FC36E3C59
 */
public abstract class SolutionScopeInfoRendererBase extends ConQATProcessorBase {

	/** Key under which value is stored */
	protected static final String VALUE = "Value";

	/** Flag that determines whether sorting gets disabled */
	private final boolean disableSorting;

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = ConQATParamDoc.INPUT_NAME, attribute = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_DESC)
	public SolutionScopeInfo input;

	/** Constructor */
	public SolutionScopeInfoRendererBase(boolean disableSorting) {
		this.disableSorting = disableSorting;
	}

	/** {@inheritDoc} */
	@Override
	public ListNode process() {
		ListNode root = createRoot();

		render(root, input);

		return root;
	}

	/** Create and configure root node */
	private ListNode createRoot() {
		ListNode root = new ListNode();

		root.setValue(NodeConstants.HIDE_ROOT, true);

		NodeUtils.addToDisplayList(root, getKeys());

		if (disableSorting) {
			root.setValue(NodeConstants.COMPARATOR, null);
		}

		return root;
	}

	/** Template method that deriving classes override to add their keys */
	protected String[] getKeys() {
		return new String[] {};
	}

	/**
	 * Template method that deriving classes override to perform actual
	 * rendering
	 */
	protected abstract void render(ListNode root, SolutionScopeInfo info);

	/** Adds a node with specified name and value and adds it to the root */
	protected void appendNameValueNode(ListNode root, String name, Object value) {
		ListNode node = new ListNode(name);
		root.addChild(node);
		node.setValue(VALUE, value);
	}

}

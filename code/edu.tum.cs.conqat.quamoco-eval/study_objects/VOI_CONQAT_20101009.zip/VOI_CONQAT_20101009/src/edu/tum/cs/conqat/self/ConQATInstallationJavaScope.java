/*--------------------------------------------------------------------------+
$Id: ConQATInstallationJavaScope.java 30446 2010-10-07 13:25:06Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.self;

import java.io.File;

import edu.tum.cs.commons.filesystem.FileExtensionFilter;
import edu.tum.cs.conqat.bundle.BundleInfo;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.self.scope.ConQATBundleNode;
import edu.tum.cs.conqat.self.scope.ConQATInstallationRoot;

/**
 * A scope that acts like the JavaScope but uses the ConQATInstallationRoot as
 * input.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 30446 $
 * @levd.rating GREEN Hash: 07C98B4773BF352594766AA62F8BFD03
 */
@AConQATProcessor(description = "This processor creates a JavaRootElement from the "
		+ "given ConQATInstallationRoot including ConQAT and all its bundles.")
public class ConQATInstallationJavaScope extends ConQATProcessorBase {

	/** {@inheritDoc} */
	@Override
	public Object process() throws ConQATException {
		return null;
	}

	// FIXME (BH): reinclude
	
//	/** The ConQAT installation to look at. */
//	private ConQATInstallationRoot conqatRoot;
//
//	/** Whether to include tests. */
//	private boolean includeTests = false;
//
//	/** Set the ConQAT installation. */
//	@AConQATParameter(name = "conqat", minOccurrences = 1, maxOccurrences = 1, description = ""
//			+ "The ConQAT installation being used as source for Java files and byte code.")
//	public void setConQATDirectory(
//			@AConQATAttribute(name = "root", description = "Reference to the generating processor.")
//			ConQATInstallationRoot conqatRoot) {
//		this.conqatRoot = conqatRoot;
//	}
//
//	/** Set whether to include tests */
//	@AConQATParameter(name = "test-src", minOccurrences = 0, maxOccurrences = 1, description = ""
//			+ "Decide whether to also include the test sources. Default is false.")
//	public void setIncludeTests(
//			@AConQATAttribute(name = "include", description = "True or false.")
//			boolean include) {
//		includeTests = include;
//	}
//
//	/** {@inheritDoc} */
//	public IJavaRootElement process() throws ConQATException {
//		JavaScope javaScope = new JavaScope();
//		javaScope.init(getProcessorInfo());
//
//		addConQAT(javaScope);
//		addBundles(javaScope);
//
//		return javaScope.process();
//	}
//
//	/** Adds the ConQAT directory. */
//	private void addConQAT(JavaScope javaScope) {
//		String srcDir = new File(conqatRoot.getConQATDirectory(), "src")
//				.getPath();
//		getLogger().info("Added source code directory " + srcDir);
//		javaScope.addSourceDirectory(srcDir, false);
//
//		String buildDir = new File(conqatRoot.getConQATDirectory(), "build")
//				.getPath();
//		getLogger().info("Added byte code directory " + buildDir);
//		javaScope.addByteCodeDirectory(buildDir, false);
//
//		if (includeTests) {
//			String testsrcDir = new File(conqatRoot.getConQATDirectory(),
//					"test-src").getPath();
//			getLogger().info("Added source code directory " + testsrcDir);
//			javaScope.addSourceDirectory(testsrcDir, false);
//		}
//
//		for (File lib : new File(conqatRoot.getConQATDirectory(), "lib")
//				.listFiles(new FileExtensionFilter("jar"))) {
//			getLogger().info("Added class path element " + lib.getPath());
//			javaScope.addClasspathElement(lib.getPath());
//		}
//	}
//
//	/** Adds all bundle directories. */
//	private void addBundles(JavaScope javaScope) {
//		for (ConQATBundleNode bundleNode : conqatRoot.getChildren()) {
//			BundleInfo bi = bundleNode.getBundleInfo();
//			File srcDir = new File(bi.getLocation(), "src");
//			File testsrcDir = new File(bi.getLocation(), "test-src");
//			File classesDir = bi.getClassesDirectory();
//
//			if (srcDir.isDirectory()) {
//				getLogger().info(
//						"Added source code directory " + srcDir.getPath());
//				javaScope.addSourceDirectory(srcDir.getPath(), false);
//			}
//			if (classesDir.isDirectory()) {
//				getLogger().info(
//						"Added byte code directory " + classesDir.getPath());
//				javaScope.addByteCodeDirectory(classesDir.getPath(), false);
//			}
//			if (includeTests && testsrcDir.isDirectory()) {
//				getLogger().info(
//						"Added source code directory " + testsrcDir.getPath());
//				javaScope.addSourceDirectory(testsrcDir.getPath(), false);
//			}
//			for (File lib : bi.getLibraries()) {
//				getLogger().info("Added class path element " + lib.getPath());
//				javaScope.addClasspathElement(lib.getPath());
//			}
//		}
//	}
}
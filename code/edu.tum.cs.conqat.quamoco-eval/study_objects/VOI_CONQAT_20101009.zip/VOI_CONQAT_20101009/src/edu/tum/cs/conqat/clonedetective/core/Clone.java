/*--------------------------------------------------------------------------+
$Id: Clone.java 30457 2010-10-07 14:27:48Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import static edu.tum.cs.commons.string.StringUtils.CR;
import static edu.tum.cs.commons.string.StringUtils.TWO_SPACES;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.filesystem.CanonicalFile;

/**
 * Class that represents cloned code regions.
 * 
 * @author Florian Deissenboeck
 * @author Elmar Juergens
 * @author $Author: heineman $
 * @version $Rev: 30457 $
 * @levd.rating YELLOW Hash: A6BB5B3F59ED0A7784695D8AF9DDC347
 */
public class Clone extends KeyValueStoreBase {

	/** {@link CloneClass} this clone belongs to */
	private CloneClass cloneClass;

	/** Location of the element that contains the clone */
	private String location;

	/** Uniform path of the element that contains the clone */
	private final String uniformPath;

	/** Fingerprint of clone */
	private final String fingerprint;

	/** Birth timestamp */
	private Date birth;

	/** Death timestamp */
	private Date death;

	/** Timestamp fingerprint was last modified */
	private Date fingerprintLastModified;

	/** Position of the first line of the clone in its file */
	private final int startLineInFile;

	/** Length of clone in input file */
	private final int lengthInFile;

	/** Position of the first unit of the clone in its file */
	private final int startUnitIndexInFile;

	/** Length of the clone in units */
	private final int lengthInUnits;

	/** Map that contains the gap types in the clone. */
	private Map<Integer, EEditOperation> gaps;

	/** Delta size in units */
	protected int deltaInUnits;

	/** Creates a clone with a delta in units of 0 */
	public Clone(long id, CloneClass cloneClass, String location,
			String uniformPath, int startLineInFile, int lengthInFile,
			int startUnitIndexInFile, int lengthInUnits, String fingerprint) {
		this(id, cloneClass, location, uniformPath, startLineInFile,
				lengthInFile, startUnitIndexInFile, lengthInUnits, fingerprint,
				0);
	}

	/** Constructor */
	public Clone(long id, CloneClass cloneClass, String location,
			String uniformPath, int startLineInFile, int lengthInFile,
			int startUnitIndexInFile, int lengthInUnits, String fingerprint,
			int deltaInUnits) {
		super(id);

		CCSMAssert.isNotNull(location);
		CCSMAssert.isNotNull(uniformPath);

		this.cloneClass = cloneClass;

		// We use the Java string pool here for because:
		// - during clone detection, many clones can be created
		// - all fingerprints of non-gapped clones in same clone class are equal
		// (but created as different instances)
		this.fingerprint = fingerprint.intern();

		this.location = location;
		this.uniformPath = uniformPath;
		this.startLineInFile = startLineInFile;
		this.lengthInFile = lengthInFile;
		this.startUnitIndexInFile = startUnitIndexInFile;
		this.lengthInUnits = lengthInUnits;
		this.deltaInUnits = deltaInUnits;

		CCSMPre.isTrue(lengthInFile >= 0,
				"Original length must not be negative: " + this);

		cloneClass.add(this);
	}

	/**
	 * Two clones are considered equal, if they describe the same region of code
	 * in the same file with the same gaps.
	 */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Clone)) {
			return false;
		}

		Clone other = (Clone) obj;

		// compare files
		if (!getUniformPath().equals(other.getUniformPath())) {
			return false;
		}

		// compare start lines
		if (getStartLineInFile() != other.getStartLineInFile()) {
			return false;
		}

		// compare length
		if (getLengthInFile() != other.getLengthInFile()) {
			return false;
		}

		// compare gaps
		if (gapCount() != other.gapCount()) {
			return false;
		}
		for (int gapPosition : getGapPositions()) {
			if (!getGapTypeAt(gapPosition).equals(
					other.getGapTypeAt(gapPosition))) {
				return false;
			}
		}

		// if code reaches here, clones are equal
		return true;
	}

	/**
	 * Returns the hash code based on the file, the start and length. Gap
	 * information is ignored.
	 */
	@Override
	public int hashCode() {
		return (getUniformPath().hashCode() * 13 + getStartLineInFile()) * 17
				+ getLengthInFile();
	}

	/** {@link CloneClass} this clone belongs to */
	public CloneClass getCloneClass() {
		return cloneClass;
	}

	/** Get file that contains this clone */
	@Deprecated
	public CanonicalFile getFile() {
		try {
			return new CanonicalFile(location);
		} catch (IOException e) {
			throw new AssertionError("Cannot create canonical file for: "
					+ location);
		}
	}

	/**
	 * Fingerprint of clone. A clone fingerprint characterizes the piece of
	 * cloned code after normalization. All ungapped clones inside a single
	 * clone class have the same fingerprint.
	 */
	public String getFingerprint() {
		return fingerprint;
	}

	/** Position of the first line of the clone in its file */
	public int getStartLineInFile() {
		return startLineInFile;
	}

	/** Length of the clone in lines in its file. */
	public int getLengthInFile() {
		return lengthInFile;
	}

	/** Position of the first unit of the clone in its file */
	public int getStartUnitIndexInFile() {
		return startUnitIndexInFile;
	}

	/** Length of the clone in units. */
	public int getLengthInUnits() {
		return lengthInUnits;
	}

	/** Position of the last line of the clone in its file */
	public int getLastLineInFile() {
		return getStartLineInFile() + getLengthInFile() - 1;
	}

	/** Position of the last unit of the clone in its file */
	public int getLastUnitInFile() {
		return getStartUnitIndexInFile() + getLengthInUnits() - 1;
	}

	/** Edit distance to first clone in clone class */
	public int getDeltaInUnits() {
		return deltaInUnits;
	}

	/** Returns location. TODO (LH) needs better javadoc */
	public String getLocation() {
		return location;
	}

	/** Returns uniformPath. TODO (LH) needs better javadoc */
	public String getUniformPath() {
		return uniformPath;
	}

	/**
	 * Gets the gap type at a line offset. Returns {@link EEditOperation#NONE}
	 * if the clone does not contain a gap at that position
	 */
	public EEditOperation getGapTypeAt(int lineOffset) {
		if (gaps == null) {
			return EEditOperation.NONE;
		}

		EEditOperation gapType = gaps.get(lineOffset);
		if (gapType == null) {
			return EEditOperation.NONE;
		}
		return gapType;
	}

	/** Returns birth timestamp. */
	public Date getBirth() {
		return birth;
	}

	/** Returns death timestamp. */
	public Date getDeath() {
		return death;
	}

	/** Determines whether the clone contains gaps */
	public boolean containsGaps() {
		if (gaps == null) {
			return false;
		}

		return gaps.size() > 0;
	}

	/** Return number of gaps, or 0, if clone has no gaps */
	public int gapCount() {
		if (gaps == null) {
			return 0;
		}

		return gaps.size();
	}

	/**
	 * Returns a list of the gap positions, or empty list, if clone has no gaps.
	 */
	public UnmodifiableList<Integer> getGapPositions() {
		if (gaps == null) {
			return CollectionUtils.emptyList();
		}

		return CollectionUtils.asSortedUnmodifiableList(gaps.keySet());
	}

	/**
	 * Adds a gap position.
	 * 
	 * @param lineOffset
	 *            Position of the gap as line number offset from the start of
	 *            the clone.
	 * @param gapType
	 *            Type of the gap
	 */
	public void addGap(int lineOffset, EEditOperation gapType) {
		if (gaps == null) {
			gaps = new HashMap<Integer, EEditOperation>(0);
		}

		gaps.put(lineOffset, gapType);
	}

	/** Set delta size in units */
	public void setDeltaInUnits(int deltaInUnits) {
		this.deltaInUnits = deltaInUnits;
	}

	/** String representation of the essential clone data. */
	@Override
	public String toString() {
		String indent = TWO_SPACES;

		String result = "Clone [" + CR;
		result += indent + "lengthInFile=" + getLengthInFile() + CR;
		result += indent + "startLineInFile=" + getStartLineInFile() + CR;
		result += indent + "file=" + getLocation() + CR;
		result += "]" + CR;

		return result;
	}

	/**
	 * Sets the file. This method is used in CloneInspector if a user decides to
	 * relocate his source files.
	 */
	@Deprecated
	public void setFile(CanonicalFile file) {
		this.location = file.getAbsolutePath();
	}

	/** Set birth */
	public void setBirth(Date birth) {
		this.birth = birth;
	}

	/** Set birth */
	public void setDeath(Date death) {
		this.death = death;
	}

	/** Set timestamp fingerprint was last modified */
	public void setFingerprintLastModified(Date timestamp) {
		fingerprintLastModified = timestamp;
	}

	/** Get timestamp fingerprint was last modified */
	public Date getFingerprintLastModified() {
		return fingerprintLastModified;
	}

	/** Sets the clone class. Only called from CloneClass. */
	/* package */void setCloneClass(CloneClass cloneClass) {
		this.cloneClass = cloneClass;
	}

}
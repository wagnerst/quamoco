/*--------------------------------------------------------------------------+
$Id: ProjectFileParser9_10.java 28773 2010-06-24 14:48:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.project;

import java.io.File;

import edu.tum.cs.commons.xml.IXMLElementProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Parser for VS.NET 2005 and VS.NET 2008 project files.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 28773 $
 * @levd.rating GREEN Hash: AE3D418B13723176634451247556737D
 */
/* package */class ProjectFileParser9_10 extends ProjectFileParser {

	/** Constructor */
	public ProjectFileParser9_10(IConQATLogger logger) {
		super(logger);
	}

	/** {@inheritDoc} */
	@Override
	protected ProjectFileReader9_10 createReader(File projectFile) {
		return new ProjectFileReader9_10(projectFile);
	}

	/** Xml reader that performs actual XML processing. */
	private class ProjectFileReader9_10 extends ProjectFileReaderBase {

		/** Creates a ProjectFileReader9_10 for a project file */
		public ProjectFileReader9_10(File projectFile) {
			super(projectFile);
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createProcessor() {
			return new ItemGroupProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createAssemblyNameProcessor() {
			return new AssemblyNameProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createRelativeAssemblyPathProcessor() {
			return new PropertyGroupProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createOutputTypeProcessor() {
			return new OutputTypeProcessor();
		}

		/** Processor for ItemGroup elements */
		private class ItemGroupProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.ItemGroup;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				processChildElements(new CompileProcessor());
			}
		}

		/** Processor for PropertyGroup elements */
		private class PropertyGroupProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.PropertyGroup;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {

				// check if the current PropertyGroup is the one used in the
				// build configuration
				String condition = getStringAttribute(EProjectFileXmlAttribute.Condition);

				// check if we are in the default PropertyGroup
				if (condition == null || condition.equals("")) {

					// find the name and type of the assembly
					processChildElements(new OutputTypeProcessor());
					processChildElements(new AssemblyNameProcessor());

					// the arguments defined here are used if the used build
					// configuration does not override them
					processChildElements(new OutputPathProcessor());
				} else {

					// we are not interested in conditions other than "=="
					String conditionSeparator = "==";
					if (!condition.contains(conditionSeparator)) {
						return;
					}

					String[] expressionParts = condition
							.split(conditionSeparator);
					String currentConfiguration = expressionParts[1].trim();

					// check if the propertyGroup is the one for the used
					// configuration and platform
					String config = "'" + configuration.getName() + "|"
							+ configuration.getPlatform() + "'";
					if (currentConfiguration.equals(config)) {
						processChildElements(new OutputPathProcessor());
					}
				}
			}
		}

		/** Processor for OutputPath elements */
		private class OutputPathProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.OutputPath;
			}

			/** {@inheritDoc} */
			public void process() {
				outputPath = getText();
			}
		}

		/** Processor for ExecutableGroup elements */
		private class AssemblyNameProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.AssemblyName;
			}

			/** {@inheritDoc} */
			public void process() {
				assemblyName = getText();
			}
		}

		/** Processor for ExecutableGroup elements */
		private class OutputTypeProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.OutputType;
			}

			/** {@inheritDoc} */
			public void process() {
				outputType = getText();
			}
		}

		/** Processor for Compile elements */
		private class CompileProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.Compile;
			}

			/** {@inheritDoc} */
			public void process() {
				relativeSourceFilenames
						.add(getStringAttribute(EProjectFileXmlAttribute.Include));
			}
		}
	}
}
/*--------------------------------------------------------------------------+
$Id: SolutionScopeInfoExtractor.java 29931 2010-08-26 13:03:41Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.info;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATFieldParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.scope.SolutionScopeInfo;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * {@ConQAT.Doc}
 * 
 * @author ladmin
 * @author $Author: juergens $
 * @version $Rev: 29931 $
 * @levd.rating YELLOW Hash: C304FE0528B7D64F488949D6D10733EF
 */
@AConQATProcessor(description = "Extracts a SolutionScopeInfo object from a scope.")
public class SolutionScopeInfoExtractor extends ConQATProcessorBase {

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = ConQATParamDoc.INPUT_NAME, attribute = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_DESC)
	public IFileSystemElement input;

	/** {@inheritDoc} */
	@Override
	public SolutionScopeInfo process() throws ConQATException {
		return SolutionScopeInfo.getOrFail(input);
	}

}

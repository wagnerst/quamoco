/*--------------------------------------------------------------------------+
$Id: CloneIndexStoreAdapterFactory.java 29795 2010-08-19 09:38:28Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index.store.adapt;

import edu.tum.cs.conqat.clonedetective.index.store.ICloneIndexStore;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.core.IShutdownHook;
import edu.tum.cs.conqat.database.store.base.StorageConsumerProcessorBase;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29795 $
 * @levd.rating GREEN Hash: 7BE1C795C48790D2427DDA30D1E1DF86
 */
@AConQATProcessor(description = "Factory for a clone index store that uses the ConQAT storage back-end. "
		+ "Closing the store is performed on shutdown.")
public class CloneIndexStoreAdapterFactory extends StorageConsumerProcessorBase {

	/** {@inheritDoc} */
	@Override
	public ICloneIndexStore process() throws ConQATException {
		CloneIndexStoreAdapter cloneStore = new CloneIndexStoreAdapter(
				getStore());
		closeStoreOnExit(cloneStore);
		return cloneStore;
	}

	/** Makes sure the store is closed during shutdown (register hook). */
	private void closeStoreOnExit(final CloneIndexStoreAdapter cloneStore) {
		getProcessorInfo().registerShutdownHook(new IShutdownHook() {
			@Override
			public void performShutdown() throws ConQATException {
				cloneStore.close();
			}
		}, false);
	}
}

/*--------------------------------------------------------------------------+
$Id: SimulinkModelElement.java 30490 2010-10-07 17:20:05Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.scope;

import java.nio.charset.Charset;

import org.conqat.resource.IContentAccessor;
import org.conqat.resource.text.TextElement;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.simulink.model.SimulinkModel;

/**
 * Basic implementation for {@link ISimulinkElement}.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30490 $
 * @levd.rating GREEN Hash: FECBC7AF46BB4BE9E83995338297C7B7
 */
public class SimulinkModelElement extends TextElement implements
		ISimulinkElement {

	/** The encapsulated model. */
	private final SimulinkModel model;

	/** Constructor. */
	protected SimulinkModelElement(IContentAccessor accessor, Charset encoding,
			SimulinkModel model) {
		super(accessor, encoding);
		this.model = model;
	}

	/** Copy constructor. */
	protected SimulinkModelElement(SimulinkModelElement element)
			throws DeepCloneException {
		super(element);
		model = element.model.deepClone();
	}

	/** Returns <code>null</code>. Must override this to fulfill interface. */
	@Override
	public ISimulinkElement[] getChildren() {
		return null;
	}

	/** {@inheritDoc} */
	@Override
	public SimulinkModelElement deepClone() throws DeepCloneException {
		return new SimulinkModelElement(this);
	}

	/** {@inheritDoc} */
	@Override
	public SimulinkModel getModel() {
		return model;
	}
}
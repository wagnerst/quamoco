/*--------------------------------------------------------------------------+
$Id: IlaAssembliesXmlReader.java 28666 2010-06-23 14:06:16Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.ila.xml;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.commons.xml.IXMLElementProcessor;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.dotnet.ila.ILImporterProcessorBase;

/**
 * Reads members from Intermediate Language Analyzer XML files into a
 * representation that can be used to draw dependency graphs between the
 * assemblies.
 * 
 * @author Elmar Juergens
 * @author $Author: heineman $
 * 
 * @version $Revision: 28666 $
 * @levd.rating GREEN Hash: 4347A8DE75BC415E11A87578C781DFF2
 */
public class IlaAssembliesXmlReader extends IlaXmlReaderBase {

	/**
	 * Constructor
	 * 
	 * @param file
	 *            IL-XML file that gets parsed
	 * @param root
	 *            Root under which the nodes representing types found during
	 *            parse are attached
	 * @param ignorePatterns
	 *            List of patterns for members that are ignored during import.
	 * @param includePatterns
	 *            If not null, only members matching one of these patterns are
	 *            included.
	 */
	public IlaAssembliesXmlReader(File file, ListNode root,
			PatternList ignorePatterns, PatternList includePatterns) {
		super(file, root, ignorePatterns, includePatterns);
	}

	/** {@inheritDoc} */
	@Override
	protected void doParse() {
		String assemblyName = getStringAttribute(EIlaXmlAttribute.Name);
		ListNode assemblyNode = new ListNode(assemblyName);
		root.addChild(assemblyNode);
		assemblyNode.setValue(ILImporterProcessorBase.ASSEMBLY_NAME,
				assemblyName);

		List<String> dependencies = createDependenciesList();
		assemblyNode.setValue(ILImporterProcessorBase.DEPENDENCIES,
				dependencies);

		logDependencies(dependencies, assemblyName);
	}

	/** Parse list of all dependencies of an assembly */
	private List<String> createDependenciesList() {
		XmlDependsReader processor = new XmlDependsReader();
		processChildElements(processor);

		List<String> dependencies = new ArrayList<String>();
		for (String targetDependency : processor.getTargetDependencies()) {
			dependencies.add(targetDependency);
		}

		return dependencies;
	}

	/** Processor for &lt;TypeElement&gt; nodes */
	private class XmlDependsReader implements
			IXMLElementProcessor<EIlaXmlElement, NeverThrownRuntimeException> {

		/** List of target dependencies */
		private final List<String> targetDependencies = new ArrayList<String>();

		/** {@inheritDoc} */
		public void process() {
			String targetAssemblyString = getStringAttribute(EIlaXmlAttribute.Assembly);
			CCSMAssert.isTrue(targetAssemblyString.contains(","),
					"TargetAssemblyString format unexpected: \""
							+ targetAssemblyString + "\"");
			String targetAssemblyName = targetAssemblyString.substring(0,
					targetAssemblyString.indexOf(','));

			addDependency(targetAssemblyName, targetDependencies);
		}

		/** {@inheritDoc} */
		public EIlaXmlElement getTargetElement() {
			return EIlaXmlElement.Depends;
		}

		/** Get list of assembly names on which this assembly depends */
		public List<String> getTargetDependencies() {
			return CollectionUtils.asUnmodifiable(targetDependencies);
		}

	}

}
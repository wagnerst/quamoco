/*--------------------------------------------------------------------------+
$Id: DatabaseConnectionCloser.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database;

import java.sql.Connection;
import java.sql.SQLException;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Explicitly closes a database connection. This processor can be used, if the
 * connection does not close automatically. Although in theory, all connection
 * objects get closed upon being garbage collected, this does not always seem to
 * work in practice.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 604BF79DE0BB2F67629DAE0B5F11B196
 */
@AConQATProcessor(description = "Closes a database connection.")
public class DatabaseConnectionCloser extends ConQATProcessorBase {

	/** Connection that gets closed */
	private Connection connection;

	/** ConQAT Parameter */
	@AConQATParameter(name = "connection", description = "Connection that gets closed", minOccurrences = 1, maxOccurrences = 1)
	public void setConnection(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) Connection connection) {
		this.connection = connection;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.PREDECESSOR_NAME, description = ConQATParamDoc.PREDECESSOR_NAME_DESC)
	public void addPredecessor(
			@SuppressWarnings("unused") @AConQATAttribute(name = ConQATParamDoc.PREDECESSOR_REF_NAME, description = ConQATParamDoc.PREDECESSOR_REF_DESC) Object predecessor) {
		// do nothing
	}

	/** {@inheritDoc} */
	public Object process() {
		// close connection
		try {
			connection.close();
		} catch (SQLException e) {
			getLogger().warn(e.getMessage());
		}

		// nothing to return, this is a sink!
		return null;
	}

}
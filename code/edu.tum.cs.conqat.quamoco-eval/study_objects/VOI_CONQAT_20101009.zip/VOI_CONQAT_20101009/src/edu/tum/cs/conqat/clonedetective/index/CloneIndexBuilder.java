/*--------------------------------------------------------------------------+
$Id: CloneIndexBuilder.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import org.conqat.sourcecode.resource.ITokenElement;
import org.conqat.sourcecode.resource.ITokenResource;
import org.conqat.sourcecode.resource.TokenElementProcessorBase;

import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.detection.UnitProcessorBase;
import edu.tum.cs.conqat.clonedetective.index.store.ICloneIndexStore;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IUnitProvider;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.database.store.StorageException;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.filesystem.traversal.ElementTraversalUtils;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.ELanguage;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: juergens $
 * @version $Rev: 30460 $
 * @levd.rating GREEN Hash: 6BA7E3F21B0B0B1DED36E5EEABE45C12
 */
@AConQATProcessor(description = "Processor for constructing a clone index, which is a datastructure "
		+ "for performing fast clone lookup. "
		+ "This processor also calculates and annotates the unit size of the files.")
public class CloneIndexBuilder extends
		TokenElementProcessorBase {

	/** Default chunk length used for the constructed index. */
	protected final static int DEFAULT_CHUNK_LENGTH = 5;

	/** Frequency of logging in number of processed files between log messages. */
	protected final static int LOGGING_FREQUENCY = 100;

	/** The store. */
	private ICloneIndexStore store;
	
	/** The index */
	private CloneIndex index;
	
	/** Counter that keeps track of processed files */
	private int fileCount = 0;

	/** Normalizations used. */
	private final Map<ELanguage, IUnitProvider<ITokenResource, Unit>> normalizations = new EnumMap<ELanguage, IUnitProvider<ITokenResource, Unit>>(
			ELanguage.class);

	/** The chunk length used for the index. */
	private int chunkLength = DEFAULT_CHUNK_LENGTH;

	// TODO (EJ) initialize to count of all elements in resource hierarchy
	private String elementsCount;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "store", description = "The clone index store used to access and persist the clone index.", minOccurrences = 1, maxOccurrences = 1)
	public void setStore(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) ICloneIndexStore store) {
		this.store = store;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "chunk", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Allows to set the chunk length used. A higher chunk length improves performance, "
			+ "but the chunk length also marks the minimal clone length being detectable. "
			+ "If this is not used, a default chunk length of "
			+ DEFAULT_CHUNK_LENGTH + " is used.")
	public void setChunkLength(
			@AConQATAttribute(name = "length", description = "The chunk length used for the index (must be positive).") int chunkLength)
			throws ConQATException {
		if (chunkLength <= 0) {
			throw new ConQATException("Chunk index must be positive!");
		}
		this.chunkLength = chunkLength;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "normalization", description = "Sets the normalization used for a given language.", minOccurrences = 1)
	public void setNormalization(
			@AConQATAttribute(name = "language", description = "The language for which the normalization applies.") ELanguage language,
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IUnitProvider<ITokenResource, Unit> normalization)
			throws ConQATException {

		if (normalizations.put(language, normalization) != null) {
			throw new ConQATException(
					"Duplicate normalization applied for language " + language);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(ITokenResource root) throws ConQATException {
		setOptions();
		index = new CloneIndex(store, getLogger());
	}
	
	/** {@inheritDoc} */
	@Override
	protected void processElement(ITokenElement element) throws ConQATException {
		int units = index.insertFile(element);
		element.setValue(UnitProcessorBase.UNITS_KEY, units);

		if (++fileCount % LOGGING_FREQUENCY == 0) {
			getLogger().info(
					"Completed " + fileCount + " elements of "
							+ elementsCount + " ["
							+ index.getPerformanceInfo() + "]");
		}
	}

	
	/** {@inheritDoc} */
	@Override
	protected void finish(ITokenResource root)  {
		getLogger().info("Overall performance: " + index.getPerformanceInfo());
	}

	/** Sets the options used for the store. */
	private void setOptions() throws StorageException {
		for (ELanguage language : normalizations.keySet()) {
			PersistedOptions.setNormalization(store, language, normalizations
					.get(language));
		}
		PersistedOptions.setChunkLength(store, chunkLength);
	}

	
}

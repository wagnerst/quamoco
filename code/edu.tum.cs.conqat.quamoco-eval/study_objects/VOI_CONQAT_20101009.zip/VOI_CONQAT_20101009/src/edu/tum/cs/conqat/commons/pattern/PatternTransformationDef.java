/*--------------------------------------------------------------------------+
$Id: PatternTransformationDef.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.pattern;

import java.util.regex.PatternSyntaxException;

import edu.tum.cs.commons.string.RegexReplacement;
import edu.tum.cs.conqat.commons.CommonUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Processor used for defining a pattern transformation list.
 * 
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 8CE6334B7F82983C71067E81CE7D78AD
 */
@AConQATProcessor(description = "Defines a pattern transformation list.")
public class PatternTransformationDef extends ConQATProcessorBase {

	/** Underlying pattern transformation list. */
	private final PatternTransformationList patternTransformationList = new PatternTransformationList();

	/** Insert a new pattern. */
	@AConQATParameter(name = "pattern", description = "Definition of a pattern.")
	public void addPattern(
			@AConQATAttribute(name = "regex", description = ConQATParamDoc.REGEX_PATTERN_DESC) String regex,
			@AConQATAttribute(name = "replacement", description = ""
					+ "The replacement string.") String replacement)
			throws ConQATException {
		try {
			patternTransformationList.add(new RegexReplacement(regex,
					replacement));
		} catch (PatternSyntaxException e) {
			throw CommonUtils.wrapPatternSyntaxException(e);
		}
	}

	/** Insert a new pattern transformation list. */
	@AConQATParameter(name = "pattern-transformation-list", description = ""
			+ "Takes all entries of a pattern transformation list.")
	public void addPatternList(
			@AConQATAttribute(name = "list", description = "The referenced pattern transformation list.") PatternTransformationList list) {
		patternTransformationList.addAll(list);
	}

	/** Does not really process anything, but just returns the created list. */
	public PatternTransformationList process() {
		return patternTransformationList;
	}
}
/*--------------------------------------------------------------------------+
$Id: SimulinkBlockUsageAnalyzer.java 30489 2010-10-07 16:54:18Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.simulink.scope.ISimulinkResource;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * This processor creates a counter set for the distribution of block types
 * through the models.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30489 $
 * @levd.rating GREEN Hash: C7F30DC170B758EC961CB67C0996F564
 */
@AConQATProcessor(description = "This processor creates a counter set for the "
		+ "distribution of block types through the models.")
public class SimulinkBlockUsageAnalyzer extends ConQATProcessorBase implements
		INodeVisitor<ISimulinkResource, NeverThrownRuntimeException> {

	/** Root of the simulink tree. */
	private ISimulinkResource root;

	/** Created result. */
	private final CounterSet<String> result = new CounterSet<String>();

	/** Set the root element to work on. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) ISimulinkResource root) {
		this.root = root;
	}

	/** {@inheritDoc} */
	public CounterSet<String> process() {
		TraversalUtils.visitAllDepthFirst(this, root);
		return result;
	}

	/** {@inheritDoc} */
	public void visit(ISimulinkResource node) {
		if (node instanceof SimulinkModelElement) {
			traverseBlock(((SimulinkModelElement) node).getModel());
		}
	}

	/** Performs traversal of blocks. */
	private void traverseBlock(SimulinkBlock block) {
		for (SimulinkBlock child : block.getSubBlocks()) {
			traverseBlock(child);
		}
		result.inc(block.getResolvedType());
	}
}
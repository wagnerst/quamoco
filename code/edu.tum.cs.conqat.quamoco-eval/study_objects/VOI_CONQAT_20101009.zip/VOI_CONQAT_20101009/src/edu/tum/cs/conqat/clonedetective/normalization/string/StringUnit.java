/*--------------------------------------------------------------------------+
$Id: StringUnit.java 30402 2010-10-07 09:16:26Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.string;

import org.conqat.resource.IElement;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.clonedetective.core.Unit;

/**
 * Unit-implementation based on strings. Used by line and word normalization.
 * 
 * @author Rainer Spitzhirn
 * @author Elmar Juergens
 * @author Julian Much
 * @author $Author: juergens $
 * 
 * @version $Revision: 30402 $
 * @levd.rating GREEN Hash: 7FEB146D662402CF1C9F7798FEEBCEA7
 */
public class StringUnit extends Unit {

	/**
	 * Create new string unit object.
	 * 
	 * @param content
	 *            The string this unit represents
	 * @param elementUniformPath
	 *            The uniform path of the element string stems from.
	 * @param startLineInFile
	 *            The position within the file.
	 */
	public StringUnit(String content, String elementUniformPath, int startLineInFile,
			int indexInFile) {
		super(startLineInFile, elementUniformPath, content, 1, indexInFile);
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return "\"" + getContent() + "\" (Element:" + getStartLineInFile()
				+ "[" + getElementUniformPath() + "]";
	}

}
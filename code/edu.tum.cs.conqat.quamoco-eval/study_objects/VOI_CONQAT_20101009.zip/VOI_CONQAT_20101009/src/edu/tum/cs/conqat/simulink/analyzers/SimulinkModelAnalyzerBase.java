/*--------------------------------------------------------------------------+
$Id: SimulinkModelAnalyzerBase.java 30489 2010-10-07 16:54:18Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.simulink.scope.ISimulinkResource;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;

/**
 * Base class for processors that analyze Simulink models.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30489 $
 * @levd.rating GREEN Hash: 29AD7281AC24BAF8BDC1D72D555D7F7E
 */
public abstract class SimulinkModelAnalyzerBase extends
		NodeTraversingProcessorBase<ISimulinkResource> {

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** Visits all blocks if this is a {@link SimulinkModelElement}. */
	public void visit(ISimulinkResource node) throws ConQATException {
		if (node instanceof SimulinkModelElement) {
			SimulinkModelElement modelNode = (SimulinkModelElement) node;
			setUpModel(modelNode);
			analyzeModel(modelNode);
			finishModel(modelNode);
		}
	}

	/**
	 * Factory method called before traversing the blocks of the given model
	 * node. Default implementation does nothing.
	 */
	@SuppressWarnings("unused")
	protected void setUpModel(SimulinkModelElement modelNode)
			throws ConQATException {
		// nothing
	}

	/**
	 * Factory method called after traversing the blocks of the given model
	 * node. Default implementation does nothing.
	 */
	@SuppressWarnings("unused")
	protected void finishModel(SimulinkModelElement modelNode)
			throws ConQATException {
		// nothing
	}

	/** Override method to implement model analysis. */
	protected abstract void analyzeModel(SimulinkModelElement modelNode)
			throws ConQATException;

}
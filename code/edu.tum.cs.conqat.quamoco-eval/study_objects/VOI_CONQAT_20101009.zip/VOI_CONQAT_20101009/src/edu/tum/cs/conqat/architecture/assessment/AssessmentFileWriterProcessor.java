/*--------------------------------------------------------------------------+
$Id: AssessmentFileWriterProcessor.java 28462 2010-06-22 05:59:16Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.assessment;

import java.io.File;
import java.io.IOException;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.architecture.scope.ArchitectureDefinition;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: heineman $
 * @version $Rev: 28462 $
 * @levd.rating GREEN Hash: 7918DB1A661FA8CAD0000133D07FE592
 */
@AConQATProcessor(description = "Writes an assessed architecture to a file.")
public class AssessmentFileWriterProcessor extends ConQATProcessorBase {

	/** File that gets written */
	private File targetFile;

	/** Assessed {@link ArchitectureDefinition} that gets written to the file */
	private ArchitectureDefinition input;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "output", minOccurrences = 1, maxOccurrences = 1, description = "Name of the output directory")
	public void setOutputDirectory(
			@AConQATAttribute(name = "dir", description = "Name of the output directory") String outputDir,
			@AConQATAttribute(name = "filename", description = "Name of the file that gets written") String reportName) {
		targetFile = new File(outputDir, reportName);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setInput(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) ArchitectureDefinition input) {
		this.input = input;
	}

	/** {@inheritDoc} */
	@Override
	public File process() throws ConQATException {
		try {
			FileSystemUtils.ensureParentDirectoryExists(targetFile);
			AssessmentFileWriter writer = new AssessmentFileWriter(targetFile,
					input, getLogger());
			writer.writeArchitecture();
			writer.close();
		} catch (IOException e) {
			throw new ConQATException("Could not write file", e);
		}

		return targetFile;
	}
}
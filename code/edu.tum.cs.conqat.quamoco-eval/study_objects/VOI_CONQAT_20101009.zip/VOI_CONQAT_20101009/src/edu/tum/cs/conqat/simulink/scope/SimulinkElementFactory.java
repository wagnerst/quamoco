/*--------------------------------------------------------------------------+
$Id: SimulinkElementFactory.java 30490 2010-10-07 17:20:05Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.scope;

import java.io.StringReader;

import org.conqat.resource.IContentAccessor;
import org.conqat.resource.text.TextElement;
import org.conqat.resource.text.TextElementFactory;

import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.simulink.builder.SimulinkModelBuilder;
import edu.tum.cs.simulink.builder.SimulinkModelBuildingException;
import edu.tum.cs.simulink.model.SimulinkModel;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30490 $
 * @levd.rating GREEN Hash: D72EB15F11BF37E18772C86B8B21A617
 */
@AConQATProcessor(description = "Factory for token elements.")
public class SimulinkElementFactory extends TextElementFactory {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws ConQATException
	 *             if the model could not be built
	 */
	@Override
	public ISimulinkElement create(IContentAccessor accessor)
			throws ConQATException {
		try {
			SimulinkModel model = buildModel(accessor);
			return new SimulinkModelElement(accessor, encoding, model);
		} catch (SimulinkModelBuildingException ex) {
			throw new ConQATException("Could not build model for "
					+ accessor.getLocation() + ": " + ex.getMessage(), ex);
		}
	}

	/** Build Simulink model. */
	private SimulinkModel buildModel(IContentAccessor accessor)
			throws ConQATException, SimulinkModelBuildingException {
		String content = new TextElement(accessor, encoding)
				.getRawTextContent();
		SimulinkModelBuilder modelBuilder = new SimulinkModelBuilder(
				new StringReader(content), getLogger());
		return modelBuilder.buildModel();
	}
}

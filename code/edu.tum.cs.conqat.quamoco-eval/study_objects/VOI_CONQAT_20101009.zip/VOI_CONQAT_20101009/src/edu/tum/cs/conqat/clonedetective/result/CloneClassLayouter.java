/*--------------------------------------------------------------------------+
$Id: CloneClassLayouter.java 30315 2010-10-05 12:11:21Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import static edu.tum.cs.commons.html.EHTMLAttribute.CLASS;

import java.io.IOException;
import java.util.List;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.html.CSSDeclarationBlock;
import edu.tum.cs.commons.html.EHTMLElement;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.EEditOperation;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.html_presentation.CSSMananger;
import edu.tum.cs.conqat.html_presentation.util.LayouterBase;
import edu.tum.cs.scanner.ELanguage;
import edu.tum.cs.scanner.ILenientScanner;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.ScannerFactory;
import edu.tum.cs.scanner.ScannerUtils;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 30315 $
 * @levd.rating YELLOW Hash: 69234DEB5FFEC62704EEFFF84CAE3981
 */
@AConQATProcessor(description = "Writes syntax-highlighted clone output")
public class CloneClassLayouter extends LayouterBase {

	/** Default value for {@link #maxCloneCount} */
	private static final int DEFAULT_MAX_CLONE_COUNT = 500;

	/** Clone detection result from which clone classes are taken */
	private CloneDetectionResultElement result;

	/** Number that determines after how many clones the result is truncated. */
	private int maxCloneCount = DEFAULT_MAX_CLONE_COUNT;

	/** ConQAT Parameter */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) CloneDetectionResultElement result) {
		this.result = result;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "max", description = "Maximal number of clones that gets included. All clones exceeding this number are truncated", minOccurrences = 0, maxOccurrences = 1)
	public void setMaxCloneCount(
			@AConQATAttribute(name = "clones", description = "Use "
					+ CloneUtils.UNLIMITED
					+ " to include all clones. Default is "
					+ DEFAULT_MAX_CLONE_COUNT + ".") int maxCloneCount) {
		this.maxCloneCount = maxCloneCount;
	}

	/** {@inheritDoc} */
	@Override
	protected String getIconName() {
		return "clonedetective.png";
	}

	/** {@inheritDoc} */
	@Override
	protected void layoutPage() throws ConQATException {
		List<CloneClass> cloneClasses = CloneUtils.cloneClassesForFirstNClones(
				result.getList(), maxCloneCount);

		for (CloneClass cloneClass : cloneClasses) {
			layoutCloneClass(cloneClass);
			writer.addClosedElement(EHTMLElement.HR);
		}
	}

	/** Render a single {@link CloneClass} */
	private void layoutCloneClass(CloneClass cloneClass) throws ConQATException {
		// write header
		writer.openElement(EHTMLElement.H2);
		writer.addText("Clone class: " + cloneClass.getId() + " ("
				+ cloneClass.getClones().size() + " clones)");
		writer.closeElement(EHTMLElement.H2);

		for (Clone clone : cloneClass.getClones()) {
			layoutClone(clone);
			writer.addClosedElement(EHTMLElement.HR);
		}
	}

	/** Render a single {@link Clone} */
	private void layoutClone(Clone clone) throws ConQATException {
		writer.openElement(EHTMLElement.H3);
		writer.addText(clone.getFile() + " lines " + clone.getStartLineInFile()
				+ "-" + clone.getLastLineInFile());
		writer.closeElement(EHTMLElement.H3);

		layoutCloneCode(clone);
	}

	/** Render the cloned code of a single clone */
	private void layoutCloneCode(Clone clone) throws ConQATException {
		writer.openElement(EHTMLElement.PRE);

		String clonedCode = edu.tum.cs.conqat.clonedetective.corelocal.CloneUtils.getCloneContent(clone);
		List<IToken> tokens = getClonedTokens(clone.getFile(), clonedCode);

		IToken lastToken = null;
		boolean markerOpened = false;
		for (IToken token : tokens) {
			markerOpened = writeWhitespace(lastToken, token, clonedCode,
					markerOpened);
			markerOpened = setGapMarkers(clone, token, markerOpened);
			writeToken(token);
			lastToken = token;
		}
		if (markerOpened) {
			writer.closeElement(EHTMLElement.SPAN);
		}

		writer.closeElement(EHTMLElement.PRE);
	}

	/** Retrieve cloned tokens */
	private List<IToken> getClonedTokens(CanonicalFile file, String clonedCode)
			throws ConQATException {
		ILenientScanner scanner = ScannerFactory.newLenientScanner(
				ELanguage.JAVA, clonedCode, file.getCanonicalPath());
		try {
			return ScannerUtils.readTokens(scanner);
		} catch (IOException e) {
			throw new ConQATException("Problems reading file: " + file, e);
		}
	}

	/** Write marker that start gap regions in the code */
	private boolean setGapMarkers(Clone clone, IToken token,
			boolean pendingMarker) {
		int currentLineNumber = token.getLineNumber();

		if (!pendingMarker) {
			EEditOperation gapType = clone.getGapTypeAt(currentLineNumber);
			if (gapType != EEditOperation.NONE) {
				Object type = null;
				switch (gapType) {
				case INSERT:
					type = CSSMananger.GAP_ADDED;
					break;
				case CHANGE:
					type = CSSMananger.GAP_CHANGED;
					break;
				case DELETE:
					type = CSSMananger.GAP_REMOVED;
					break;
				default:
					CCSMAssert.fail("Not implemented");
				}

				writer.openElement(EHTMLElement.SPAN, CLASS, type);
				return true;
			}
		}

		return pendingMarker;
	}

	/**
	 * Render whitespace between tokens and close pending gap region marker if
	 * whitespace contains a newline
	 */
	private boolean writeWhitespace(IToken lastToken, IToken token,
			String clonedText, boolean pendingMarker) {
		int fromOffset = 0;
		if (lastToken != null) {
			fromOffset = lastToken.getOffset() + lastToken.getText().length();
		}
		int toOffset = token.getOffset();
		String whitespace = clonedText.substring(fromOffset, toOffset);

		if (pendingMarker && whitespace.contains(StringUtils.CR)) {
			// we add empty text to set writer into text mode. Else, it adds a
			// newline and indentation, which we don't want here.
			writer.addText(StringUtils.EMPTY_STRING);
			writer.closeElement(EHTMLElement.SPAN);
			pendingMarker = false;
		}

		writer.addText(whitespace);

		return pendingMarker;
	}

	/** Render token */
	private void writeToken(IToken token) {
		CSSDeclarationBlock style = getTokenStyle(token);
		writer.addClosedTextElement(EHTMLElement.SPAN, token.getText(), CLASS,
				style);
	}

	/** Determine CSS style for token */
	private CSSDeclarationBlock getTokenStyle(IToken token) {
		switch (token.getType().getTokenClass()) {
		case COMMENT:
			return CSSMananger.COMMENT;
		case KEYWORD:
			return CSSMananger.KEYWORD;
		case LITERAL:
			return CSSMananger.LITERAL;
		default:
			return CSSMananger.SMALL_FONT;
		}
	}
}
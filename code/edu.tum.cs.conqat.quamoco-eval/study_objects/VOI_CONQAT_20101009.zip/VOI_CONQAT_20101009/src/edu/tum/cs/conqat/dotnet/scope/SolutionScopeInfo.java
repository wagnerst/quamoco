/*--------------------------------------------------------------------------+
$Id$
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope;

import java.util.Set;

import edu.tum.cs.commons.clone.IDeepCloneable;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.TwoDimHashMap;
import edu.tum.cs.commons.collections.UnmodifiableSet;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.scope.info.EContainment;
import edu.tum.cs.conqat.dotnet.scope.info.EFileType;

/**
 * Collects statistics about which files are included and excluded in a scope.
 * 
 * The implementation of {@link #deepClone()} relies on the fact that the class
 * is immutable from outside this package. If you add methods that change its
 * state either make them package visible (or smaller) or reconsider
 * implementing deep cloning.
 * 
 * @author ladmin
 * @author $Author$
 * @version $Rev$
 * @levd.rating YELLOW Hash: 87D38DFE33D77E5E44F8CBFEC6155F10
 */
public class SolutionScopeInfo implements IDeepCloneable {

	/** Key under which info is stored */
	public static String KEY = "SolutionScopeInfo";

	/** Keeps track of included and excluded files */
	TwoDimHashMap<EContainment, EFileType, Set<CanonicalFile>> files = new TwoDimHashMap<EContainment, EFileType, Set<CanonicalFile>>();

	/** Keeps track of included and excluded files */
	TwoDimHashMap<EContainment, EFileType, Set<String>> patterns = new TwoDimHashMap<EContainment, EFileType, Set<String>>();

	/** Path of root node */
	private String rootPath;

	/**
	 * Retrieves the {@link SolutionScopeInfo} object from a ConQAT root node.
	 * If no one exists, it gets created and stored in the root node.
	 */
	public static SolutionScopeInfo getOrCreate(IConQATNode root)
			throws ConQATException {
		if (root.getValue(KEY) == null) {
			SolutionScopeInfo info = new SolutionScopeInfo();
			root.setValue(KEY, info);
		}

		return get(root);
	}

	/**
	 * Retrieves the {@link SolutionScopeInfo} object from a ConQAT root node.
	 * Fails if no info is stored at node. Use this method if a lack of the info
	 * object indicates a ConQAT configuration error.
	 * 
	 * @throws ConQATException
	 *             if no {@link SolutionScopeInfo} is stored at the node.
	 */
	public static SolutionScopeInfo getOrFail(IConQATNode root)
			throws ConQATException {
		SolutionScopeInfo info = get(root);

		if (info == null) {
			throw new ConQATException("No SolutionScopeInfo stored at node "
					+ root);
		}

		return info;
	}

	/**
	 * @return {@link SolutionScopeInfo} object from a ConQAT root node or
	 *         <code>null</code>, if none is stored.
	 */
	public static SolutionScopeInfo get(IConQATNode root)
			throws ConQATException {
		SolutionScopeInfo info = NodeUtils.getValue(root, KEY,
				SolutionScopeInfo.class);
		return info;
	}

	/** Set path to root of scope */
	/* package */void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	/**
	 * Returns the file set for a containment and a file type. If it does not
	 * exist, it gets created.
	 */
	private Set<CanonicalFile> fileSet(EContainment containment,
			EFileType fileType) {
		return SolutionScopeInfoAnnotator.getOrCreateSet(containment, fileType,
				files);
	}

	/**
	 * Returns the file set for a containment and a file type. If it does not
	 * exist, it gets created.
	 */
	private Set<String> patternSet(EContainment containment, EFileType fileType) {
		return SolutionScopeInfoAnnotator.getOrCreateSet(containment, fileType,
				patterns);
	}

	/** Adds a pattern */
	/* package */void addFile(EContainment containment, EFileType fileType,
			CanonicalFile file) {
		fileSet(containment, fileType).add(file);
	}

	/** Adds a pattern */
	/* package */void addPattern(EContainment containment, EFileType fileType,
			String pattern) {
		patternSet(containment, fileType).add(pattern);
	}

	/** @return set of corresponding patterns */
	public UnmodifiableSet<String> getPattern(EContainment containment,
			EFileType fileType) {
		return CollectionUtils
				.asUnmodifiable(patternSet(containment, fileType));
	}

	/** @return path of root node */
	public String getRootPath() {
		return rootPath;
	}

	/** @return set of corresponding files */
	public UnmodifiableSet<CanonicalFile> getFiles(EContainment containment,
			EFileType fileType) {
		return CollectionUtils.asUnmodifiable(fileSet(containment, fileType));
	}

	// TODO (EJ) Dear reviewer: I would like to discuss deep cloning of this
	// with you ;)
	/** {@inheritDoc} */
	@Override
	public IDeepCloneable deepClone() {
		// SolutionScopeInfo is immutable from outside this package, so we don't
		// clone but return this
		return this;
	}

	/** Adds all information from the {@link SolutionScopeInfo} */
	public void addAll(SolutionScopeInfo info) {
		this.files.putAll(info.files);
		this.patterns.putAll(info.patterns);
	}

}

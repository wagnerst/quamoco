/*--------------------------------------------------------------------------+
$Id: IPersistingEntity.java 29797 2010-08-19 09:38:31Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database.store;

/**
 * Interface for all entities dealing with persistence and thus need to be
 * closed on shut down.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29797 $
 * @levd.rating GREEN Hash: 0DDA77934879271BF46477BCF18D59F0
 */
public interface IPersistingEntity {

	/** Closes this entity. */
	void close() throws StorageException;
}

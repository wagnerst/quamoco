/*--------------------------------------------------------------------------+
$Id: IElementProvider.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import org.conqat.resource.text.ITextElement;
import org.conqat.resource.text.ITextResource;

import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IProvider;

/**
 * Interface for {@link ITextResource} providing components.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 30460 $
 * @levd.rating GREEN Hash: FBD117807F17A3C60DC960F64CDB0722
 */
public interface IElementProvider<R extends ITextResource, E extends ITextElement> extends
		IProvider<R, E, NeverThrownRuntimeException> {
	// Nothing to do
}
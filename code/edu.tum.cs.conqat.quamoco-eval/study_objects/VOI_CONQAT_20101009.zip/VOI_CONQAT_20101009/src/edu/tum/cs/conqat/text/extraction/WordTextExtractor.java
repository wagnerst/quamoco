/*--------------------------------------------------------------------------+
$Id: WordTextExtractor.java 30382 2010-10-06 14:00:11Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.extraction;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hwpf.extractor.WordExtractor;
import org.conqat.resource.IElement;
import org.conqat.resource.IResource;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * TODO (FD): Rename to MSWordTextExtractor TODO (FD): This should be
 * implemented as a special text element that transparently converts word files.
 * 
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * @version $Rev: 30382 $
 * @levd.rating RED Hash: 79871F83E48790839A8F14BEEE0D8B0C
 */
@AConQATProcessor(description = "Extracts text from word documents."
		+ "For each file in the input scope, an equally named file with suffix '.txt' "
		+ "is created that contains the extracted text.")
public class WordTextExtractor extends NodeTraversingProcessorBase<IResource> {

	/** If set to true, each a newline is inserted after each dot. */
	private boolean wrapAtDot = false;

	/** If set to true, each a newline is inserted after each whitespace block. */
	private boolean wrapAtWhitespace = false;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "wrap-at-dot", description = "If set to true, each a newline is inserted after each dot", minOccurrences = 0, maxOccurrences = 1)
	public void setWrapAtDot(
			@AConQATAttribute(name = "value", description = "Default is false") boolean wrapAtDot) {
		this.wrapAtDot = wrapAtDot;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "wrap-at-whitespace", description = "If set to true, each a newline is inserted after each whitespace block.", minOccurrences = 0, maxOccurrences = 1)
	public void setWrapAtWhitespace(
			@AConQATAttribute(name = "value", description = "Default is false") boolean wrapAtWhitespace) {
		this.wrapAtWhitespace = wrapAtWhitespace;
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** {@inheritDoc} */
	public void visit(IResource node) throws ConQATException {
		if (!(node instanceof IElement)) {
			return;
		}

		IElement element = (IElement) node;

		InputStream in = null;
		try {

			getLogger().info(
					"Extracting text from resource: " + element.getLocation());

			in = new ByteArrayInputStream(element.getContent());
			String text = extractText(in);

			if (wrapAtDot) {
				text = text.replaceAll("[.]", "." + StringUtils.CR);
			}

			if (wrapAtWhitespace) {
				text = text.replaceAll("\\s+", StringUtils.CR);
			}

			// TODO (FD): This is a bad hack!!!
			File targetFile = new File(element.getLocation() + ".txt");
			FileSystemUtils.writeFile(targetFile, text);
		} catch (IOException e) {
			getLogger().warn(
			"Problems extracting word text: " + element.getLocation(), e);
		} finally {
			FileSystemUtils.close(in, getLogger());
		}

	}

	/** Extract text from word file */
	private String extractText(InputStream in) throws IOException {
		WordExtractor extractor = new WordExtractor(in);
		String[] pars = extractor.getParagraphText();
		return StringUtils.concat(pars, StringUtils.CR);
	}

}
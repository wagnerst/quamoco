/*--------------------------------------------------------------------------+
$Id: EAssessmentType.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.format;

/**
 * Assessment result for edges in an architecture graph.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 6BE920E18D2BB5B110F659B1A36305B0
 */
public enum EAssessmentType {

	/** Dependencies underlying this edge are valid w.r.t. policies */
	VALID,

	/** Dependencies underlying this edge are invalid w.r.t. policies */
	INVALID,

	/** No dependencies underly this edge. It is unnecessary. */
	UNNECESSARY,
}
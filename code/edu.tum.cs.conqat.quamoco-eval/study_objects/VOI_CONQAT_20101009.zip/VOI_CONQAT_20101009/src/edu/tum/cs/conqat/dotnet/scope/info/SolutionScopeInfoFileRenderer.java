/*--------------------------------------------------------------------------+
$Id: SolutionScopeInfoFileRenderer.java 29913 2010-08-25 16:10:06Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.info;

import java.util.Set;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.core.AConQATFieldParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.dotnet.scope.SolutionScopeInfo;

/**
 * {@ConQAT.Doc}
 * 
 * @author ladmin
 * @author $Author: juergens $
 * @version $Rev: 29913 $
 * @levd.rating YELLOW Hash: 1C940176B55032BC22E142F2FB154587
 */
@AConQATProcessor(description = "Extracts a SolutionScopeInfo object from a scope and creates a conqat node structure "
		+ "from it that can be rendered into a table.")
public class SolutionScopeInfoFileRenderer extends
		SolutionScopeInfoRendererBase {

	/** Constructor */
	public SolutionScopeInfoFileRenderer() {
		super(false);
	}

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "containment", attribute = "value", description = "Set containment of files to be rendered")
	public EContainment containment;

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "file", attribute = "type", description = "Select file type to be rendered")
	public EFileType fileType;

	/** {@inheritDoc} */
	@Override
	protected void render(ListNode root, SolutionScopeInfo info) {
		Set<CanonicalFile> files = info.getFiles(containment, fileType);
		for (CanonicalFile file : files) {
			ListNode fileNode = new ListNode(file.getCanonicalPath());
			root.addChild(fileNode);
		}
	}

}

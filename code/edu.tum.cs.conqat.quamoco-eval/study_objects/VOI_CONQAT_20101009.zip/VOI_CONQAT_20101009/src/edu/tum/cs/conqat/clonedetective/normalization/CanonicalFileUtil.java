/*--------------------------------------------------------------------------+
$Id: CanonicalFileUtil.java 30315 2010-10-05 12:11:21Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization;

import java.io.IOException;

import edu.tum.cs.commons.filesystem.CanonicalFile;

/**
 * Utility class that creates a CanonicalFile. Useful until CR#3232 is complete.
 * 
 * @author ladmin
 * @author $Author: juergens $
 * @version $Rev: 30315 $
 * @levd.rating RED Hash: F9AA1DA306F571A22B5616204636E0D8
 */
public class CanonicalFileUtil {

	/** Create {@link CanonicalFileUtil} and wrap {@link IOException} into {@link AssertionError} */
	public static CanonicalFile canonicalFile(String path) {
		try {
			return new CanonicalFile(path);
		} catch (IOException e) {
			throw new AssertionError("Could not create CanonicalFile for :'" + path + "'");
		}
	}
	
}

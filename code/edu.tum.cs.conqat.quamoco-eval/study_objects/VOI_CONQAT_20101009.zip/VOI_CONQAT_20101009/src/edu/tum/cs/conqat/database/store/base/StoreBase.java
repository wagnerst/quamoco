/*--------------------------------------------------------------------------+
$Id: StoreBase.java 29044 2010-07-05 07:10:15Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database.store.base;

import java.util.Arrays;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.conqat.database.store.IKeyValueCallback;
import edu.tum.cs.conqat.database.store.IStore;
import edu.tum.cs.conqat.database.store.StorageException;

/**
 * Base class which contains utility methods for implementing stores.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29044 $
 * @levd.rating GREEN Hash: BF707AE444CCD071A5F1DAE553281BC0
 */
public abstract class StoreBase implements IStore {

	/**
	 * {@inheritDoc}
	 * <p>
	 * This implementation maps prefix queries to range queries. For this, the
	 * prefix is used as the begin key, and a suitable end key is calculated.
	 */
	@Override
	public void scan(byte[] prefix, IKeyValueCallback callback)
			throws StorageException {
		CCSMPre.isNotNull(prefix);

		// The goal of the following lines is the creation of a key that can act
		// as an end key, i.e. is larger than any key with the given prefix, but
		// small enough to skip all other keys. This is done by incrementing the
		// last (lowest) byte in the prefix key. If this last byte is 0xff, then
		// the overflow has to be propagated. In our case, instead of setting
		// overflown bytes to 0, we have to cut them off. This is performed in
		// the next lines, by finding the last non-0xff, incrementing it and
		// removing everything behind it.

		int lastIndex = prefix.length - 1;
		while (lastIndex >= 0 && prefix[lastIndex] == (byte) 0xFF) {
			--lastIndex;
		}

		byte[] end = null;
		if (lastIndex >= 0) {
			end = Arrays.copyOfRange(prefix, 0, lastIndex + 1);
			end[lastIndex] += 1;
		}
		// else: if haven't found an index, we can use null, as we anyway
		// including everything from the prefix to the end.

		scan(prefix, end, callback);
	}
}

/*--------------------------------------------------------------------------+
$Id: CloneAnnotatorBase.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.List;

import org.conqat.resource.text.ITextElement;
import org.conqat.resource.util.ResourceTraversalUtils;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for processors that annotate the file tree with clone-related
 * information.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 30460 $
 * @levd.rating GREEN Hash: 0543F2AFDEC0E503C8BBC358F110F06D
 */
public abstract class CloneAnnotatorBase extends
		ConQATPipelineProcessorBase<CloneDetectionResultElement> {

	/** Maps from canonical files to a list of clones found in the element */
	private final HashedListMap<String, Clone> fileToClones = new HashedListMap<String, Clone>();

	/**
	 * Performs annotation.
	 * <p>
	 * {@inheritDoc}
	 */
	@Override
	protected void processInput(CloneDetectionResultElement input)
			throws ConQATException {
		NodeUtils.addToDisplayList(input.getRoot(), getKeys());
		CloneUtils.initFileMapping(input.getList(), fileToClones);
		List<ITextElement> elements = ResourceTraversalUtils
				.listTextElements(input.getRoot());
		for (ITextElement element : elements) {
			visit(element);
		}

		checkLeftOverClones();
	}

	/**
	 * Template method that allows deriving classes to add Keys to the root
	 * node's display list
	 */
	protected String[] getKeys() {
		return new String[] {};
	}

	/** Perform annotation on an element */
	public void visit(ITextElement element) throws ConQATException {
		List<Clone> clonesList = fileToClones.getList(element.getUniformPath());
		if (clonesList == null) {
			clonesList = CollectionUtils.emptyList();
		}

		annotateClones(element, CollectionUtils.asUnmodifiable(clonesList));
		fileToClones.removeList(element.getUniformPath());
	}

	/**
	 * Template method that deriving classes implement to perform their
	 * annotation.
	 * 
	 * @param element
	 *            Element to which clones are annotated
	 * @param clonesList
	 *            List of clones for this element, or empty list, if no clones
	 *            are present in this element
	 * 
	 */
	protected abstract void annotateClones(ITextElement element,
			UnmodifiableList<Clone> clonesList) throws ConQATException;

	/**
	 * Check if any clones are left, for which no corresponding element has been
	 * found and generate warning messages accordingly. (This could happen, if
	 * the elements have been removed from the file tree after clone detection.)
	 */
	protected void checkLeftOverClones() {
		for (String file : fileToClones.getKeys()) {
			getLogger().warn(
					"No file system element found for file '" + file + "'");
		}
	}

}
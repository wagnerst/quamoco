/*--------------------------------------------------------------------------+
$Id: MemoryStoreBase.java 29795 2010-08-19 09:38:28Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index.store.mem;

import java.io.Serializable;
import java.util.HashMap;

import edu.tum.cs.conqat.clonedetective.index.store.ICloneIndexStore;

/**
 * Base class for clone index stores residing in memory. This class deals with
 * options handling and provides an empty close operation.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29795 $
 * @levd.rating GREEN Hash: 500CBBA37759C199EE5A6236BAB7B248
 */
public abstract class MemoryStoreBase implements ICloneIndexStore {

	/** Map for storing options. */
	protected final HashMap<String, Serializable> options = new HashMap<String, Serializable>();

	/** {@inheritDoc} */
	@Override
	public Serializable getOption(String key) {
		return options.get(key);
	}

	/** {@inheritDoc} */
	@Override
	public void setOption(String key, Serializable value) {
		options.put(key, value);
	}

	/** {@inheritDoc} */
	@Override
	public void close() {
		// does nothing
	}
}

/*--------------------------------------------------------------------------+
$Id: RootValuesProcessor.java 28410 2010-06-18 09:32:59Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.statistics;

import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.util.ConQATInputProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 28410 $
 * @levd.rating GREEN Hash: 43B6E1249B7C72036CEF6B6071D7F7DB
 */
@AConQATProcessor(description = "Creates a KeyedData object from the keys and values stored in the "
		+ "display list of the root node. This KeyedData object can e.g. be used to create a pie chart.")
public class RootValuesProcessor extends ConQATInputProcessorBase<IConQATNode> {

	/** {@inheritDoc} */
	public KeyedData<String> process() throws ConQATException {
		KeyedData<String> result = new KeyedData<String>();

		for (String key : NodeUtils.getDisplayList(input)) {
			Object value = input.getValue(key);
			try {
				Double numericValue = Double.parseDouble(value.toString());
				result.add(key, numericValue);
			} catch (NumberFormatException e) {
				throw new ConQATException("Cannot convert value" + value
						+ " stored in key " + key + " into a number: ", e);
			}
		}

		return result;
	}
}
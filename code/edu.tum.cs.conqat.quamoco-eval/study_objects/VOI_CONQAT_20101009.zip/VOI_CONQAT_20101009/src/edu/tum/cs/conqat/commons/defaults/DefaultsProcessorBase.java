/*--------------------------------------------------------------------------+
$Id: DefaultsProcessorBase.java 28780 2010-06-24 14:59:55Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.defaults;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for defaults processors.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 28780 $
 * @levd.rating GREEN Hash: 2170DC287D91BD430ED5FD3FA849EC98
 */
public class DefaultsProcessorBase<T> extends ConQATProcessorBase {

	/** Documentation string. */
	public static final String DOC = "This processor allows to define default values. "
			+ "If the actual value is not set, the default value is returned, otherwise the "
			+ "actual value is returned.";

	/** The value to use if no actual value is set. */
	private T defaultValue;

	/** The actual value. */
	private T actualValue;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "default", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Default value. If actual value is not set, this will be used.")
	public void setDefaultValue(
			@AConQATAttribute(name = "value", description = "Value") T value)
			throws ConQATException {
		if (value == null) {
			throw new ConQATException(
					"null value for default value not supported.");
		}
		defaultValue = value;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "actual", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "If set, this value will be used.")
	public void setActualValue(
			@AConQATAttribute(name = "value", description = "Value") T value)
			throws ConQATException {
		if (value == null) {
			throw new ConQATException(
					"null value for actual value not supported.");
		}
		actualValue = value;
	}

	/** {@inheritDoc} */
	@Override
	public T process() {
		if (actualValue == null) {
			return defaultValue;
		}
		return actualValue;
	}

}
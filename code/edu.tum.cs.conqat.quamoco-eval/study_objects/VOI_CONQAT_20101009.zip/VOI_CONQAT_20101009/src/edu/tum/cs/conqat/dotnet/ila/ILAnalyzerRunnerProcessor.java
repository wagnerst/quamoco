/*--------------------------------------------------------------------------+
$Id: ILAnalyzerRunnerProcessor.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.ila;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.io.ProcessUtils;
import edu.tum.cs.commons.io.ProcessUtils.ExecutionResult;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.BundleContext;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 26282 $
 * @levd.rating GREEN Hash: C20DB6CF984604629A5934F5558AD6E8
 */
@AConQATProcessor(description = ""
		+ "Runs the Intermediate Language Analyzer (ILA) on a bunch of assemblies. The"
		+ "ILA extracts the dependencies between the types in the assemblies and writes"
		+ "them to XML files, one per analyzed assembly. The name of the resulting XML"
		+ "file <assembly-name>.xml: Analysis of the file application.dll creates and"
		+ "XML file application.dll.xml."
		+ "This processor is typically be executed before a processor that performs an"
		+ "architectural analysis."
		+ "The assemblies that are to be analyzed can be specified individually. "
		+ "Alternatively, the processor can be given a file system scope and then "
		+ "simply processes all contained files.")
public class ILAnalyzerRunnerProcessor extends ConQATProcessorBase {

	/** List of all the assemblies that are to be analyzed */
	private final List<File> assemblies = new ArrayList<File>();

	/** Path to the ILA executable in the resource folder of this bundle */
	private final String ilaPath = BundleContext.getInstance()
			.getResourceManager().getAbsoluteResourcePath("ILAnalyzer.exe");

	/** Folder into which XML gets written */
	private File xmlTargetFolder;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "assembly", description = "Fully qualified name of the assembly that gets analysed", minOccurrences = 0, maxOccurrences = -1)
	public void addAssembly(
			@AConQATAttribute(name = "name", description = "Fully qualified name of the assembly that gets analysed") String filename) {
		assemblies.add(new File(filename));
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = "File system scope that contains assemblies that get analyzed", minOccurrences = 0, maxOccurrences = 1)
	public void setInput(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "All files that are contained in the scope are analyzed. Make sure it only contains assemblies.") IFileSystemElement root) {
		for (IFileSystemElement element : TraversalUtils
				.listLeavesDepthFirst(root)) {
			if (element.getFile().isFile()) {
				assemblies.add(element.getFile());
			}
		}
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "xml", description = "Folder the analysis result xml files are written to", minOccurrences = 1, maxOccurrences = 1)
	public void setXmlTargetFolder(
			@AConQATAttribute(name = "folder", description = "Folder the analysis result xml files are written to") String targetFolder) {
		xmlTargetFolder = new File(targetFolder);
	}

	/** Run ILAnalyzer on all assemblies. */
	public Object process() throws ConQATException {
		// abort if no assembly can be found
		if (assemblies.size() == 0) {
			throw new ConQATException(
					"No assembly found. Cannot run on empty input.");
		}

		// abort if target folder does not exist and cannot be created
		try {
			FileSystemUtils.ensureDirectoryExists(xmlTargetFolder);
		} catch (IOException e) {
			throw new ConQATException(e);
		}

		// determine whether we use mono
		boolean useMono = useMono();

		// process all assemblies, continuing if one fails.
		for (File assembly : assemblies) {
			try {
				executeIlAnalyzer(assembly, useMono);
			} catch (IOException e) {
				getLogger().error(
						"Could not analyze IL file: " + assembly + ": "
								+ e.getMessage());
			}
		}

		// This processor doesn't return anything
		return null;
	}

	/**
	 * Determines whether to use mono. If ILAnalyzer can be executed directly,
	 * <code>false</code> is returned. If it can only be executed using mono,
	 * <code>true</code> is returned. If it can neither be executed with, nor
	 * without Mono, a {@link ConQATException} is thrown.
	 */
	private boolean useMono() throws ConQATException {
		try {
			ExecutionResult result = ProcessUtils.execute(new String[] {
					ilaPath, "-h" });
			if (result.getReturnCode() == 0) {
				getLogger().info(".NET Framework found.");
				return false;
			}
		} catch (IOException e) {
			ExecutionResult result;
			try {
				result = ProcessUtils.execute(new String[] { "mono", ilaPath,
						"-h" });
				if (result.getReturnCode() == 0) {
					getLogger().info("Using Mono.");
					return true;
				}
			} catch (IOException ioex) {
				// ignore, since we throw an exception anyway
			}
		}

		throw new ConQATException(
				"Cannot execute ILAnalyzer. Maybe no .NET framework is installed?");
	}

	/** Runs the ILAnalyzer on the assembly file */
	private void executeIlAnalyzer(File assembly, boolean useMono)
			throws IOException, ConQATException {
		// start ILA
		String[] commandLineArgs = createCommandLineArguments(assembly, useMono);
		getLogger().debug(
				"ILAnalyzer command line: "
						+ StringUtils.concat(commandLineArgs, " "));
		ExecutionResult result = ProcessUtils.execute(commandLineArgs);

		if (!StringUtils.isEmpty(result.getStdout())) {
			getLogger().info(result.getStdout());
		}

		if (!StringUtils.isEmpty(result.getStderr())) {
			getLogger().warn(result.getStderr());
		}

		if (result.getReturnCode() != 0) {
			throw new ConQATException(result.getStderr());
		}
	}

	/** Creates the command line arguments for the ILA */
	private String[] createCommandLineArguments(File assembly, boolean useMono) {
		List<String> commandLineArgs = new ArrayList<String>();

		String inPath = assembly.getAbsolutePath();

		String outPath = new File(xmlTargetFolder, assembly.getName() + ".xml")
				.getAbsolutePath();

		if (useMono) {
			commandLineArgs.add("mono");
		}
		commandLineArgs.add(ilaPath);
		commandLineArgs.add("-in");
		commandLineArgs.add(inPath);
		commandLineArgs.add("-out");
		commandLineArgs.add(outPath);

		return commandLineArgs.toArray(new String[] {});
	}

}
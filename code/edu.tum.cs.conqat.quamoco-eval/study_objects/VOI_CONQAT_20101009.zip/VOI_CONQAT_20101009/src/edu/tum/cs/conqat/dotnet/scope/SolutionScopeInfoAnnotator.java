/*--------------------------------------------------------------------------+
$Id: SolutionScopeInfoAnnotator.java 29932 2010-08-26 13:08:43Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope;

import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.commons.collections.TwoDimHashMap;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATFieldParameter;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.dotnet.scope.info.EContainment;
import edu.tum.cs.conqat.dotnet.scope.info.EFileType;

/**
 * {@ConQAT.Doc}
 * 
 * @author ladmin
 * @author $Author: juergens $
 * @version $Rev: 29932 $
 * @levd.rating YELLOW Hash: C766D127846F4971786D2FD2999E47A2
 */
@AConQATProcessor(description = "Adds information to a SolutionScopeInfo object.")
public class SolutionScopeInfoAnnotator extends
		ConQATPipelineProcessorBase<SolutionScopeInfo> {

	/** Keep track of added patterns */
	private final TwoDimHashMap<EContainment, EFileType, Set<String>> patterns = new TwoDimHashMap<EContainment, EFileType, Set<String>>();

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "info", attribute = "ref", description = "Adds all information contained in this info object to the input info object", optional = true)
	public SolutionScopeInfo addInfo;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "annotate", description = "Annotate patterns", minOccurrences = 0, maxOccurrences = -1)
	public void addPattern(
			@AConQATAttribute(name = "pattern", description = "Pattern that gets annotated") String pattern,
			@AConQATAttribute(name = "containment", description = "Containment type of pattern") EContainment containment,
			@AConQATAttribute(name = "filetype", description = "File type of pattern") EFileType fileType) {
		getOrCreateSet(containment, fileType, patterns).add(pattern);
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(SolutionScopeInfo info) {
		for (EContainment containment : patterns.getFirstKeys()) {
			for (EFileType fileType : patterns.getSecondKeys(containment)) {
				for (String pattern : patterns.getValue(containment, fileType)) {
					info.addPattern(containment, fileType, pattern);
				}
			}
		}

		if (addInfo != null) {
			info.addAll(addInfo);
		}
	}

	// TODO (EJ) Dear reviwer: Should we move this utility method into
	// TwoDimHashmap?
	/**
	 * Gets or creates the corresponding set from the corresponding
	 * {@link TwoDimHashMap}
	 */
	public static <T> Set<T> getOrCreateSet(EContainment containment,
			EFileType fileType,
			TwoDimHashMap<EContainment, EFileType, Set<T>> container) {
		Set<T> set = container.getValue(containment, fileType);
		if (set == null) {
			set = new HashSet<T>();
			container.putValue(containment, fileType, set);
		}
		return set;
	}

}

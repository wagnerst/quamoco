/*--------------------------------------------------------------------------+
$Id: ILImporterProcessorBase.java 28733 2010-06-24 11:52:44Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.ila;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.ila.xml.IlaXmlReaderBase;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for processors that imports dependencies from ILA Xml files.
 * 
 * @see ILAnalyzerRunnerProcessor
 * 
 * @author Elmar Juergens
 * @author $Author: heineman $
 * 
 * @version $Revision: 28733 $
 * @levd.rating GREEN Hash: 72E67FC60C654499823934D7E502A12A
 */
public abstract class ILImporterProcessorBase extends ConQATProcessorBase
		implements INodeVisitor<IFileSystemElement, ConQATException> {

	/** Key under which the dependencies are stored */
	@AConQATKey(description = "Key under which the dependencies are stored", type = "java.util.List<String>")
	public static final String DEPENDENCIES = "Dependency List";

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Key under which assembly name is stored.", type = "java.lang.String")
	public static final String ASSEMBLY_NAME = "AssemblyName";

	/**
	 * Root of the directory tree that contains the XML files containing IL
	 * information that serve as input for this processor.
	 */
	private IFileSystemElement root;

	/** Root of the result tree containing dependency information */
	protected ListNode outputRoot;

	/** Dependencies that match the ignore pattern are thrown away. */
	protected PatternList ignorePatterns = new PatternList();

	/**
	 * If this pattern list is set, only dependencies that match one of these
	 * patterns are included. (Mainly useful for debugging purposes to
	 * temporarily reduce the amount dependencies.)
	 */
	protected PatternList includePatterns = null;

	/** Set that stores all dependencies that have been imported */
	protected final Set<String> allDependencies = new HashSet<String>();

	/** If this string is set, all dependencies are written to this file */
	private String dependenciesFilename;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = "File system tree that contains ILA XML files.", minOccurrences = 1, maxOccurrences = 1)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IFileSystemElement root) {
		this.root = root;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "ignore", description = "Dependencies that match the ignore patterns are thrown away", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnorePatterns(
			@AConQATAttribute(name = "patterns", description = "Regular expressions") PatternList ignorePatterns) {
		this.ignorePatterns = ignorePatterns;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "include", description = ""
			+ "If this pattern list is set, only dependencies matching one of the patterns are included.", minOccurrences = 0, maxOccurrences = 1)
	public void setIncludePatterns(
			@AConQATAttribute(name = "patterns", description = "Regular expressions") PatternList includePatterns) {
		this.includePatterns = includePatterns;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.PREDECESSOR_NAME, description = ConQATParamDoc.PREDECESSOR_NAME_DESC)
	public void addPredecessor(
			@SuppressWarnings("unused") @AConQATAttribute(name = ConQATParamDoc.PREDECESSOR_REF_NAME, description = ConQATParamDoc.PREDECESSOR_REF_DESC) Object predecessor) {
		// do nothing, since this only informs the driver to execute this method
		// later.
	}

	/**
	 * {@ConQAT.Doc}
	 * 
	 * This debugging code is in the code, since we sometimes needed it in the
	 * field, where no IDE for debugging is available.
	 */
	@AConQATParameter(name = "debug-dependencies", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "If this filename is set, all imported dependencies are written to this file in alphabetical order. Useful for debugging purposes.")
	public void setDependenciesFilename(
			@AConQATAttribute(name = "filename", description = "Name of dependencies file.") String dependenciesFilename) {
		this.dependenciesFilename = dependenciesFilename;
	}

	/** Read dependencies from all IL-XML files */
	public ListNode process() throws ConQATException {
		outputRoot = new ListNode();
		TraversalUtils.visitLeavesDepthFirst(this, root);

		NodeUtils.addToDisplayList(outputRoot, DEPENDENCIES);
		NodeUtils.addToDisplayList(outputRoot, getKeys());

		if (isWriteDependenciesFile()) {
			writeDependenciesFile();
		}

		return outputRoot;
	}

	/**
	 * Read dependencies from a single IL-XML file
	 */
	public void visit(IFileSystemElement element) {
		if (element.getFile().isFile()) {
			IlaXmlReaderBase xmlReader = createXmlReader(element);

			try {
				xmlReader.parse();
			} catch (ConQATException ex) {
				String message = "Could not parse file: " + element.getFile();
				getLogger().error(message, ex);
				return;
			}

			if (isWriteDependenciesFile()) {
				allDependencies.addAll(xmlReader.getAllDependencies());
			}

		}
	}

	/** Create actual XML reader */
	protected abstract IlaXmlReaderBase createXmlReader(
			IFileSystemElement element);

	/** Default implementation returns empty key list. Subclasses can override. */
	protected String[] getKeys() {
		return new String[] {};
	}

	/** Determines whether to write a dependencies file */
	protected boolean isWriteDependenciesFile() {
		return dependenciesFilename != null;
	}

	/**
	 * Writes the sorted list of all imported dependencies into the file named
	 * {@link #dependenciesFilename}
	 */
	private void writeDependenciesFile() throws ConQATException {
		String content = StringUtils.concat(CollectionUtils
				.sort(allDependencies), StringUtils.CR);
		try {
			FileSystemUtils.writeFile(new File(dependenciesFilename), content);
		} catch (IOException e) {
			throw new ConQATException("Could not write dependencies file", e);
		}
	}

}
/*--------------------------------------------------------------------------+
$Id: SolutionScopeInfoPatternRenderer.java 29929 2010-08-26 12:37:24Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.info;

import java.util.Set;

import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.dotnet.scope.SolutionScopeInfo;

/**
 * {@ConQAT.Doc}
 * 
 * @author ladmin
 * @author $Author: juergens $
 * @version $Rev: 29929 $
 * @levd.rating YELLOW Hash: 93EA80F30CF143F02B047E7529D5EB2A
 */
@AConQATProcessor(description = "Renders the patterns from the SolutionScopeInfo.")
public class SolutionScopeInfoPatternRenderer extends
		SolutionScopeInfoRendererBase {

	/** Constructor */
	public SolutionScopeInfoPatternRenderer() {
		super(true);
	}

	/** {@inheritDoc} */
	@Override
	protected void render(ListNode root, SolutionScopeInfo info) {
		renderPattern(root, info, EContainment.INCLUDED, EFileType.SOLUTION);
		renderPattern(root, info, EContainment.EXCLUDED, EFileType.SOLUTION);
		renderPattern(root, info, EContainment.INCLUDED, EFileType.PROJECT);
		renderPattern(root, info, EContainment.EXCLUDED, EFileType.PROJECT);
		renderPattern(root, info, EContainment.INCLUDED, EFileType.SOURCE);
		renderPattern(root, info, EContainment.EXCLUDED, EFileType.SOURCE);
	}

	/** Render pattern */
	private void renderPattern(ListNode root, SolutionScopeInfo info,
			EContainment containment, EFileType fileType) {
		String name = containment.name().toLowerCase() + " "
				+ fileType.name().toLowerCase() + " patterns";
		Set<String> patterns = info.getPattern(containment, fileType);
		if (!patterns.isEmpty()) {
			appendNameValueNode(root, name, patterns);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected String[] getKeys() {
		return new String[] { VALUE };
	}

}

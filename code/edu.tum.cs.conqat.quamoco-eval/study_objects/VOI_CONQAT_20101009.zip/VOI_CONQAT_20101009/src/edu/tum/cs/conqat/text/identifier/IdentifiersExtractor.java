/*--------------------------------------------------------------------------+
$Id: IdentifiersExtractor.java 30496 2010-10-07 21:23:56Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import java.util.HashSet;
import java.util.Set;

import org.conqat.sourcecode.resource.ITokenElement;
import org.conqat.sourcecode.resource.ITokenResource;
import org.conqat.sourcecode.resource.TokenElementUtils;

import edu.tum.cs.conqat.commons.util.ConQATInputProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.scanner.ETokenType;
import edu.tum.cs.scanner.IToken;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30496 $
 * @levd.rating YELLOW Hash: 73674E73ED2E3F0F3D3745C2F27A57D2
 */
@AConQATProcessor(description = "This processor extracts the set of "
		+ "identifiers from a source code tree.")
public class IdentifiersExtractor extends
		ConQATInputProcessorBase<ITokenResource> {

	/** Set of identifiers. */
	private final HashSet<String> identifiers = new HashSet<String>();

	/** {@inheritDoc} */
	public Set<String> process() throws ConQATException {
		for (ITokenElement element : TokenElementUtils.listTokenElements(input)) {
			processElement(element);
		}
		return identifiers;
	}

	/** Process a single source element. */
	private void processElement(ITokenElement element) throws ConQATException {
		for (IToken token : element.getTokens(getLogger())) {
			if (token.getType() == ETokenType.IDENTIFIER) {
				identifiers.add(token.getText());
			}
		}
	}
}
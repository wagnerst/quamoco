/*--------------------------------------------------------------------------+
$Id: CloneLocAnnotator.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.List;

import org.conqat.resource.text.ITextElement;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.region.Region;
import edu.tum.cs.commons.region.RegionSet;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Annotates an element with the number of LOC that are part of at least one
 * clone.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 30460 $
 * @levd.rating GREEN Hash: B050FC0D87E25130FD2353BDE7653ED7
 */
@AConQATProcessor(description = "Computes the number of lines of code of a class that are part of at "
		+ "least one clone.")
public class CloneLocAnnotator extends CloneAnnotatorBase {

	/** Key which is used to store the Clone LoC value. */
	@AConQATKey(description = "Key that stores clone LoC value", type = "java.lang.Double")
	public final static String CLONE_LOC_KEY = "Clone LoC";

	/** Makes CLONE_LOC_KEY visible */
	@Override
	protected String[] getKeys() {
		return new String[] { CLONE_LOC_KEY };
	}

	/** Annotates CloneLoc metric at element */
	@Override
	protected void annotateClones(ITextElement element,
			UnmodifiableList<Clone> clonesList) {
		element.setValue(CLONE_LOC_KEY, calcCloneLoc(clonesList));
	}

	/**
	 * Computes the lines of code of an element that are covered by at least one
	 * clone. This corresponds to the non-overlapping sum of the length of the
	 * clones annotated to this class.
	 */
	private int calcCloneLoc(List<Clone> clones) {
		RegionSet regions = new RegionSet("clones");

		for (Clone clone : clones) {
			Region region = new Region(clone.getStartLineInFile(), clone
					.getStartLineInFile()
					+ clone.getLengthInFile() - 1, "clone");
			regions.add(region);
		}

		return regions.getPositionCount();
	}

}
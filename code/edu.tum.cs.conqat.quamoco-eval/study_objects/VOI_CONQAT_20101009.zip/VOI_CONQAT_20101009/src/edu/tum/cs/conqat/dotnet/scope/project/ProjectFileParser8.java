/*--------------------------------------------------------------------------+
$Id: ProjectFileParser8.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.project;

import java.io.File;

import edu.tum.cs.commons.xml.IXMLElementProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * ProjectFileReader8 for VS.NET 2003 project files.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: E948393C5BA8AD4A626D1AB6F8851464
 */
/* package */class ProjectFileParser8 extends ProjectFileParser {

	/** Constructor */
	public ProjectFileParser8(IConQATLogger logger) {
		super(logger);
	}

	/** {@inheritDoc} */
	@Override
	protected ProjectFileReader8 createReader(File projectFile) {
		return new ProjectFileReader8(projectFile);
	}

	/** Xml reader that performs actual XML processing. */
	private class ProjectFileReader8 extends ProjectFileReaderBase {

		/** Creates a ProjectFileReader8 for a project file */
		public ProjectFileReader8(File projectFile) {
			super(projectFile);
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createProcessor() {
			return new IncludeProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createAssemblyNameProcessor() {
			return new AssemblyProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createOutputTypeProcessor() {
			// No outputTypeProcessor needed in VS2003 projects because both
			// AssemblyName and OutputType
			// are an attribute of Settings. These are extracted by the
			// AssemblyProcessor.
			return null;
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createRelativeAssemblyPathProcessor() {
			return new ConfigProcessor();
		}

		/** Processor for AssemblyName elements */
		private class AssemblyProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.Settings;
			}

			/** {@inheritDoc} */
			public void process() {
				assemblyName = getStringAttribute(EProjectFileXmlAttribute.AssemblyName);
				outputType = getStringAttribute(EProjectFileXmlAttribute.OutputType);
			}
		}

		/** Processor for Config elements */
		private class ConfigProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.Config;
			}

			/** {@inheritDoc} */
			public void process() {
				if (configuration.getName().equals(
						getStringAttribute(EProjectFileXmlAttribute.Name))) {
					outputPath = getStringAttribute(EProjectFileXmlAttribute.OutputPath);
				}
			}
		}

		/** Processor for Include elements */
		private class IncludeProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.Include;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				processChildElements(new FileProcessor());
			}
		}

		/** Processor for File elements */
		private class FileProcessor implements
				IXMLElementProcessor<EProjectFileXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectFileXmlElement getTargetElement() {
				return EProjectFileXmlElement.File;
			}

			/** {@inheritDoc} */
			public void process() {
				String relativeSourceFilename = getStringAttribute(EProjectFileXmlAttribute.RelPath);
				String buildAction = getStringAttribute(EProjectFileXmlAttribute.BuildAction);
				if (buildAction != null && buildAction.equals("Compile")) {
					relativeSourceFilenames.add(relativeSourceFilename);
				}
			}

		}

	}

}
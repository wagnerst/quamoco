/*--------------------------------------------------------------------------+
$Id: ElementProviderFactoryBase.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import java.util.ArrayList;
import java.util.List;

import org.conqat.resource.text.ITextElement;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.filesystem.regions.RegionMarkerStrategyBase;

/**
 * Base class for element provider factories.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 30460 $
 * @levd.rating YELLOW Hash: 01A945C95210C379F130DB2386C3AD45
 */
public abstract class ElementProviderFactoryBase<Element extends ITextElement>
		extends ConQATProcessorBase {

	/** List of strategies that get evaluated */
	protected final List<RegionMarkerStrategyBase<Element>> strategies = new ArrayList<RegionMarkerStrategyBase<Element>>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "region-marker", description = "Add region-marker strategy", minOccurrences = 0)
	public void addAnnotationStrategy(
			@AConQATAttribute(name = "strategy", description = ConQATParamDoc.INPUT_REF_NAME) RegionMarkerStrategyBase<Element> strategy) {
		this.strategies.add(strategy);
	}

}
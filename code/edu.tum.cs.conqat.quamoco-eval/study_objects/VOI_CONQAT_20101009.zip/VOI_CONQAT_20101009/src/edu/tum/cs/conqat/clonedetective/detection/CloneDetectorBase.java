/*--------------------------------------------------------------------------+
$Id: CloneDetectorBase.java 30402 2010-10-07 09:16:26Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.conqat.resource.IElement;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.digest.Digester;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionStatistics;
import edu.tum.cs.conqat.clonedetective.core.ECloneDetectionStatistic;
import edu.tum.cs.conqat.clonedetective.core.IDatabaseSpace;
import edu.tum.cs.conqat.clonedetective.core.IdProvider;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.core.constraint.CardinalityConstraint;
import edu.tum.cs.conqat.clonedetective.core.constraint.ConstraintList;
import edu.tum.cs.conqat.clonedetective.core.constraint.ICloneClassConstraint;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.clonedetective.detection.suffixtree.ICloneReporter;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for clone detection processors.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 30402 $
 * @levd.rating YELLOW Hash: 5555672F9B83325DF56491568C7F2464
 */
public abstract class CloneDetectorBase extends UnitProcessorBase {

	/** Key used for storing detection statistics */
	public static final String DETECTION_STATS = "Detection Statistics";

	/**
	 * Number of units that a clone must at least comprise. If it has less, it
	 * gets filtered out.
	 */
	protected int minLength;

	/** Stores clone detection statistics */
	private CloneDetectionStatistics statistics;

	/** List of constraints that all detected clone classes must satisfy */
	private final ConstraintList constraints = new ConstraintList();

	/** Database space used for tracing */
	private IDatabaseSpace dbSpace;

	/** Timestamp at which detection started */
	private Date systemDate;

	/** {@link IdProvider} used to create Ids for clone classes and clones */
	protected IdProvider idProvider;

	/** List of units retrieved from the units provider */
	protected List<Unit> units = new ArrayList<Unit>();

	/** Sets the unit list */
	@AConQATParameter(name = "clonelength", description = "Minimal length of Clone", minOccurrences = 1, maxOccurrences = 1)
	public void setMinLength(
			@AConQATAttribute(name = "min", description = "Minimal length of Clone") int minLength) {
		this.minLength = minLength;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "constraint", minOccurrences = 0, maxOccurrences = -1, description = ""
			+ "Adds a constraint that each detected clone class must satisfy")
	public void addConstraint(
			@AConQATAttribute(name = "type", description = "Clone classes that do not match the constraint are filtered") ICloneClassConstraint constraint) {
		constraints.add(constraint);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "database", description = "Database connection for clone tracing.", minOccurrences = 0, maxOccurrences = 1)
	public void setDbSpace(
			@AConQATAttribute(name = "space", description = "If not set, no tracing is performed. If set, storeUnits is also set to true.") IDatabaseSpace dbSpace) {
		this.dbSpace = dbSpace;
		if (dbSpace != null) {
			storeUnits = true;
		}
	}

	/** {@ConQAT.Doc} */
	@Override
	@AConQATParameter(name = "store", description = "Flag that determines whether units are stored in clones.", minOccurrences = 0, maxOccurrences = 1)
	public void setStoreUnits(
			@AConQATAttribute(name = "units", description = "Increases memory requirements. Default is false. Automatically set if a database space is set.") boolean storeUnits) {
		if (dbSpace != null && !storeUnits) {
			getLogger().warn(
					"Cannot set store-units to false, since dbSpace is set");
		} else {
			this.storeUnits = storeUnits;
		}
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "system", minOccurrences = 0, maxOccurrences = 1, description = "Date denoting the system version on which clone detection is performed.")
	public void setSystemDate(
			@AConQATAttribute(name = "date", description = "If not set, system date is set to now") Date systemDate) {
		this.systemDate = systemDate;
	}

	/** Constructor */
	public CloneDetectorBase() {
		// only detect clone classes of cardinality 2 or greater.
		// (clone classes can have cardinality of 1, if all contained clones
		// are considered equal by the set that stores a clone classes'
		// clones. this can happen if clones only differ
		// in start and end units that are located on the same lines.)
		CardinalityConstraint constraint = new CardinalityConstraint();
		constraint.setCardinality(2, CardinalityConstraint.INFINITY);
		constraints.add(constraint);
	}

	/** Calls template method to perform clone detection in deriving class */
	public CloneDetectionResultElement process() throws ConQATException {
		// initialize id provider
		idProvider = initIdProvider();

		// create detection statistics object
		statistics = new CloneDetectionStatistics();
		input.setValue(DETECTION_STATS, statistics);

		drainUnits(units);
		Unit.stringPool.clear();

		// check if any units were found
		if (units.size() == 0) {
			throw new CloneDetectionException(
					"Empty input encountered! Clone detection aborted.");
		}

		List<CloneClass> cloneClasses = detectClones();

		collectStatistics(cloneClasses);

		// create detection result parameter object
		return new CloneDetectionResultElement(getSystemDate(), input,
				cloneClasses, createUnitsMap());
	}

	/**
	 * If the database connection is set, we use a GlobalIdProvider, else a
	 * standard {@link IdProvider}.
	 */
	private IdProvider initIdProvider() {
		if (dbSpace == null) {
			return new IdProvider();
		}

		return dbSpace.getIdProvider();
	}

	/**
	 * Stores number of processed units and number of found clones in detection
	 * statistics object
	 */
	private void collectStatistics(List<CloneClass> cloneClasses) {
		int unitCount = units.size();
		int cloneCount = CloneUtils.countClones(cloneClasses);

		getLogger().info("# Units: " + unitCount);
		getLogger().info("# Clones: " + cloneCount);

		statistics.setStatistic(ECloneDetectionStatistic.PROCESSED_UNIT_COUNT,
				unitCount);
		statistics.setStatistic(ECloneDetectionStatistic.CLONE_COUNT,
				cloneCount);
	}

	/**
	 * Template method that deriving classes override to implement their clone
	 * detection
	 */
	protected abstract List<CloneClass> detectClones() throws ConQATException;

	/** Returns timestamp at which detection started */
	protected Date getSystemDate() {
		if (systemDate == null) {
			// if not set, set to now
			systemDate = new Date();
		}
		return systemDate;
	}

	/** Create map from elements to units on which detection was performed */
	private Map<String, Unit[]> createUnitsMap() {
		HashedListMap<String, Unit> unitsPerElement = new HashedListMap<String, Unit>();
		for (Unit unit : units) {
			String elementId = unit.getElementUniformPath();
			// skip synthetic units, since they are not contained in the files
			if (!unit.isSynthetic()) {
				unitsPerElement.add(elementId, unit);
			}
		}

		return unitsPerElement.listsToArrays(Unit.class);
	}

	/**
	 * Receives found clones found during clone detection and packages them into
	 * clone classes.
	 * <p>
	 * Since this class accesses the units list of the clone detector, it is
	 * internal.
	 */
	protected class CloneConsumer implements ICloneReporter {

		/** List in which the created clone classes are stored */
		private final List<CloneClass> cloneClasses;

		/**
		 * Creates a ICloneConsumer that writes the {@link CloneClass}es it
		 * creates into the given list
		 */
		public CloneConsumer(List<CloneClass> cloneClasses) {
			this.cloneClasses = cloneClasses;
		}

		/** {@link CloneClass} currently being filled */
		protected CloneClass currentCloneClass;

		/** Start new clone class */
		public void startCloneClass(int normalizedLength) {
			currentCloneClass = new CloneClass(normalizedLength, idProvider
					.provideId());
		}

		/** Adds a clone to the current {@link CloneClass} */
		public Clone addClone(int globalPosition, int length) {
			// compute length of clone in lines
			Unit firstUnit = units.get(globalPosition);
			Unit lastUnit = units.get(globalPosition + length - 1);
			List<Unit> cloneUnits = units.subList(globalPosition,
					globalPosition + length);

			IElement element = resolveElement(firstUnit.getElementUniformPath());
			int startLineInFile = firstUnit.getStartLineInFile();
			int lengthInFile = lastUnit.getStartLineInFile()
					- firstUnit.getStartLineInFile()
					+ lastUnit.getCoveredLines();

			int startUnitIndexInFile = firstUnit.getIndexInFile();
			int endUnitIndexInFile = lastUnit.getIndexInFile();
			int lengthInUnits = endUnitIndexInFile - startUnitIndexInFile + 1;
			CCSMAssert.isTrue(lengthInUnits >= 0, "Negative length in units!");
			String fingerprint = createFingerprint(globalPosition, length);

			Clone clone = new Clone(idProvider.provideId(), currentCloneClass,
					element.getLocation(), element.getUniformPath(),
					startLineInFile, lengthInFile, startUnitIndexInFile,
					lengthInUnits, fingerprint);
			clone.setBirth(getSystemDate());

			if (storeUnits) {
				CloneUtils.setUnits(clone, cloneUnits);
			}

			currentCloneClass.add(clone);

			return clone;
		}

		/** Determine element for unit */
		private IElement resolveElement(String elementUniformPath) {
			// TODO (EJ) Implement
			return null;
		}

		/** Create fingerprint for current clone */
		protected String createFingerprint(int globalPosition, int length) {
			StringBuilder fingerprintBase = new StringBuilder();
			for (int pos = globalPosition; pos < globalPosition + length; pos++) {
				fingerprintBase.append(units.get(pos).getContent());
			}
			return Digester.createMD5Digest(fingerprintBase.toString());
		}

		/** Check constraints */
		public boolean completeCloneClass() throws ConQATException {
			boolean constraintsSatisfied = constraints
					.allSatisfied(currentCloneClass);

			if (constraintsSatisfied) {
				cloneClasses.add(currentCloneClass);
			}

			return constraintsSatisfied;
		}
	}

}
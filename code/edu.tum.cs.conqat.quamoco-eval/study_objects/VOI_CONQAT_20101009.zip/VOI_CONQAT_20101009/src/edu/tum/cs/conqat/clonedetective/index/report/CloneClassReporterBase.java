/*--------------------------------------------------------------------------+
$Id: CloneClassReporterBase.java 28787 2010-06-24 15:30:46Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index.report;

import java.util.Date;

import edu.tum.cs.conqat.clonedetective.core.IdProvider;

/**
 * Common base class for clone reporter which deals with the birth data and the
 * ID generation.
 * 
 * @author hummelb
 * @author $Author: juergens $
 * @version $Rev: 28787 $
 * @levd.rating GREEN Hash: F9B7F33A7092196C3B91C62F5841E4A0
 */
public abstract class CloneClassReporterBase implements ICloneClassReporter {

	/** Stores the current date. */
	private final Date now = new Date();

	/** The ID provider used. */
	private final IdProvider idProvider = new IdProvider();

	/** {@inheritDoc} */
	@Override
	public Date getBirthDate() {
		return now;
	}

	/** {@inheritDoc} */
	@Override
	public long provideId() {
		return idProvider.provideId();
	}
}

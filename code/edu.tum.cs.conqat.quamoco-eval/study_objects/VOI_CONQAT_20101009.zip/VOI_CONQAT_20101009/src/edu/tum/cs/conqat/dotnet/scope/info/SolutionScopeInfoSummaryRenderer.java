/*--------------------------------------------------------------------------+
$Id: SolutionScopeInfoSummaryRenderer.java 29913 2010-08-25 16:10:06Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.info;

import static edu.tum.cs.conqat.dotnet.scope.info.EContainment.EXCLUDED;
import static edu.tum.cs.conqat.dotnet.scope.info.EContainment.INCLUDED;
import static edu.tum.cs.conqat.dotnet.scope.info.EFileType.ASSEMBLY;
import static edu.tum.cs.conqat.dotnet.scope.info.EFileType.PROJECT;
import static edu.tum.cs.conqat.dotnet.scope.info.EFileType.SOLUTION;
import static edu.tum.cs.conqat.dotnet.scope.info.EFileType.SOURCE;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.dotnet.scope.SolutionScopeInfo;

/**
 * {@ConQAT.Doc}
 * 
 * @author ladmin
 * @author $Author: juergens $
 * @version $Rev: 29913 $
 * @levd.rating YELLOW Hash: 282468A9955EB29B114D03B4C4FC1371
 */
@AConQATProcessor(description = "Extracts a SolutionScopeInfo object from a scope and creates a conqat node structure "
		+ "from it that can be rendered into a table.")
public class SolutionScopeInfoSummaryRenderer extends
		SolutionScopeInfoRendererBase {

	/** Constructor */
	public SolutionScopeInfoSummaryRenderer() {
		super(true);
	}

	/** {@inheritDoc} */
	@Override
	protected void render(ListNode root, SolutionScopeInfo info) {
		appendFileCountNode(root, info, INCLUDED, SOLUTION);
		appendFileCountNode(root, info, INCLUDED, PROJECT);
		appendFileCountNode(root, info, INCLUDED, SOURCE);
		appendFileCountNode(root, info, INCLUDED, ASSEMBLY);

		appendFileCountNode(root, info, EXCLUDED, PROJECT);
		appendFileCountNode(root, info, EXCLUDED, SOURCE);
	}

	/** Counts files and appends a corresponding node */
	private void appendFileCountNode(ListNode root, SolutionScopeInfo info,
			EContainment containment, EFileType fileType) {
		String name = containment.name().toLowerCase() + " "
				+ fileType.name().toLowerCase() + " files";
		int count = info.getFiles(containment, fileType).size();
		appendNameValueNode(root, name, Integer.toString(count));
	}

	/** {@inheritDoc} */
	@Override
	protected String[] getKeys() {
		return new String[] { VALUE };
	}

}

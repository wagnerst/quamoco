/*--------------------------------------------------------------------------+
$Id: HITSLabeler.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.label;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.uci.ics.jung.algorithms.importance.HITS;
import edu.uci.ics.jung.utils.MutableDouble;

/**
 * This processor labels every vertex with its HITS (hypertext induced topic
 * selection) value. HITS is based on hub and authority values.
 * 
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: D4B3E8114593BA06F6B6C891936825F4
 */
@AConQATProcessor(description = "This processor labels every vertex of the "
		+ "graph with its HITS (hypertext induced topic selection) value. "
		+ "HITS is based on hub and authority values.")
public class HITSLabeler extends ConQATPipelineProcessorBase<ConQATGraph> {

	/** Key used for writing. */
	@AConQATKey(description = "The HITS value calculated.", type = "java.lang.Double")
	public static final String HITS_KEY = "hits";

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) {
		NodeUtils.addToDisplayList(graph, HITS_KEY);

		HITS ranker = new HITS(graph.getGraph());
		ranker.setRemoveRankScoresOnFinalize(false);
		ranker.evaluate();

		// copy results to outputKey
		for (ConQATVertex v : graph.getVertices()) {
			MutableDouble md = (MutableDouble) v.getValue(ranker
					.getRankScoreKey());
			v.setValue(HITS_KEY, md.doubleValue());
		}
	}
}
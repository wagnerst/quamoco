/*--------------------------------------------------------------------------+
$Id: CloneAssessmentAnnotator.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import org.conqat.resource.text.ITextElement;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Assesses elements with clones red, elements without clones green.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 30460 $
 * @levd.rating GREEN Hash: 00873743A91D904DCC5C055574AD9785
 */
@AConQATProcessor(description = "Rates elements with clones red, elements without clones green.")
public class CloneAssessmentAnnotator extends CloneAnnotatorBase {

	/** Key for Clone assessement. */
	@AConQATKey(description = "Key for clone assessment", type = "edu.tum.cs.commons.assessment.Assessment")
	public static final String CLONE_ASSESSMENT_KEY = "Clone Assessment";

	/** Makes clone assessment key visible */
	@Override
	protected String[] getKeys() {
		return new String[] { CLONE_ASSESSMENT_KEY };
	}

	/** Assesses elements based on their clones */
	@Override
	protected void annotateClones(ITextElement element,
			UnmodifiableList<Clone> clonesList) {
		Assessment assessment;
		if (clonesList.isEmpty()) {
			assessment = new Assessment(ETrafficLightColor.GREEN);
		} else {
			assessment = new Assessment(ETrafficLightColor.RED);
		}

		element.setValue(CLONE_ASSESSMENT_KEY, assessment);
	}

}
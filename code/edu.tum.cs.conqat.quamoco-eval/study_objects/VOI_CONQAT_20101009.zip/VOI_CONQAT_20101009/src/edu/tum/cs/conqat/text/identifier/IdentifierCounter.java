/*--------------------------------------------------------------------------+
$Id: IdentifierCounter.java 30496 2010-10-07 21:23:56Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import org.conqat.sourcecode.resource.ITokenElement;
import org.conqat.sourcecode.resource.ITokenResource;
import org.conqat.sourcecode.resource.TokenElementUtils;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.conqat.commons.util.ConQATInputProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.ETokenType.ETokenClass;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Revision: 30496 $
 * @levd.rating YELLOW Hash: 56022D5DAFFFE85DCB44D21F9DC9B68E
 */
@AConQATProcessor(description = "This processor counts the "
		+ "occurrences of identifiers from a source code tree. The result is a counterset that stores "
		+ "the frequency of each identifier")
public class IdentifierCounter extends ConQATInputProcessorBase<ITokenResource> {

	/** Maps the identifier text to the number of occurrences. */
	private final CounterSet<String> counter = new CounterSet<String>();

	/** {@inheritDoc} */
	public CounterSet<String> process() throws ConQATException {
		for (ITokenElement element : TokenElementUtils.listTokenElements(input)) {
			processElement(element);
		}
		return counter;
	}

	/** Process a single source element. */
	private void processElement(ITokenElement element) throws ConQATException {
		for (IToken token : element.getTokens(getLogger())) {
			if (token.getType().getTokenClass() == ETokenClass.IDENTIFIER) {
				counter.inc(token.getText());
			}
		}
	}
}

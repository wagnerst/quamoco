/*--------------------------------------------------------------------------+
$Id: CloneCountAnnotator.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import org.conqat.resource.text.ITextElement;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Annotates an element with the number of clones it contains.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 30460 $
 * @levd.rating GREEN Hash: 643168987933555B8D36410AF9B1FC83
 */
@AConQATProcessor(description = "Annotates an element with the number of clones it contains.")
public class CloneCountAnnotator extends CloneAnnotatorBase {

	/** Key which is used to store the Clone Count value. */
	@AConQATKey(description = "Key that stores Clone Count value", type = "java.lang.Integer")
	public final static String CLONE_COUNT_KEY = "Clone Count";

	/** Makes CLONE_COUNT_KEY visible */
	@Override
	protected String[] getKeys() {
		return new String[] { CLONE_COUNT_KEY };
	}

	/** Annotates Clone Count metric at element */
	@Override
	protected void annotateClones(ITextElement element,
			UnmodifiableList<Clone> clonesList) {
		element.setValue(CLONE_COUNT_KEY, clonesList.size());
	}

}
/*--------------------------------------------------------------------------+
$Id: WordNormalization.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.string;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;

import org.conqat.resource.text.ITextElement;
import org.conqat.resource.text.ITextResource;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.lazyscope.IElementProvider;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.commons.pattern.PatternTransformationList;

/**
 * The {@link WordNormalization} component works on plain text files and splits
 * them into words that can be accessed one by one.
 * 
 * @author Florian Deissenboeck
 * @author $Author: juergens $
 * 
 * @version $Revision: 30460 $
 * @levd.rating GREEN Hash: 9A8BE9A16A00D9DE2CBD586674303EF0
 */
public class WordNormalization extends StringNormalizationBase implements
		Serializable {

	/** Keeps track of next word in current line */
	Iterator<String> wordIterator = null;

	/**
	 * Constructor. See base class constructor for documentation of parameters.
	 */
	public WordNormalization(
			IElementProvider<ITextResource, ITextElement> inputProvider,
			PatternList removeConfig, PatternTransformationList replacements,
			boolean trimLines, boolean ignoreEmptyLines,
			boolean removeAllWhitespace) {
		super(inputProvider, removeConfig, replacements, trimLines,
				ignoreEmptyLines, removeAllWhitespace);
	}

	/** Returns next word that has not been ignored */
	@Override
	protected String findNextUnignoredInFile() {
		// load iterator with new words
		if (wordIterator == null) {
			String line = getNextNonemptyLine();
			if (line == null) {
				return null;
			}

			wordIterator = Arrays.asList(line.split("\\s+")).iterator();
		}

		// return next word from iterator
		String nextWord = wordIterator.next();
		if (!wordIterator.hasNext()) {
			wordIterator = null;
		}
		return nextWord;
	}

	/**
	 * Returns next nonempty line in current file, or null, if none could be
	 * found
	 */
	private String getNextNonemptyLine() {
		String line = StringUtils.EMPTY_STRING;
		while (line != null && line.length() == 0) {
			line = getNextLine();
			if (line != null) {
				line = line.trim();
			}
		}
		return line;
	}

	/** No normalization on word level implemented */
	@Override
	protected String normalize(String content) {
		return content;
	}

}
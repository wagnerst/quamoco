/*--------------------------------------------------------------------------+
$Id: ClonePairReportGenerator.java 30411 2010-10-07 10:09:29Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.util.Collection;
import java.util.Collections;

import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;

/**
 * Creates reports containing pairs of clone classes
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 30411 $
 * @levd.rating YELLOW Hash: A8B7D66D17E7BDD703BFBA4E44FF40AB
 */
public class ClonePairReportGenerator extends PairReportGeneratorBase {

	/** {@inheritDoc} */
	@Override
	protected Collection<CloneClass> createPairClasses(
			ImmutablePair<Clone, Clone> clonePair) {

		CloneClass cloneClass = new CloneClass(clonePair.getFirst()
				.getCloneClass().getNormalizedLength(), idProvider.provideId());
		copyClone(clonePair.getFirst(), cloneClass);
		copyClone(clonePair.getSecond(), cloneClass);

		return Collections.singleton(cloneClass);
	}

	/**
	 * Create a copy of a clone with a fresh id.
	 * 
	 * @param cloneClass
	 *            {@link CloneClass} to which new clone gets added
	 */
	private Clone copyClone(Clone clone, CloneClass cloneClass) {
		String fingerPrint = "Fingerprint" + cloneClass.getId();
		Clone copy = new Clone(idProvider.provideId(), cloneClass, clone
				.getLocation(), clone.getUniformPath(), clone.getStartLineInFile(),
				clone.getLengthInFile(), clone.getStartUnitIndexInFile(), clone
						.getLengthInUnits(), fingerPrint, clone
						.getDeltaInUnits());
		copy.setBirth(clone.getBirth());
		if (CloneUtils.getUnits(clone) != null) {
			CloneUtils.setUnits(copy, CloneUtils.getUnits(clone));
		}

		return copy;
	}
}
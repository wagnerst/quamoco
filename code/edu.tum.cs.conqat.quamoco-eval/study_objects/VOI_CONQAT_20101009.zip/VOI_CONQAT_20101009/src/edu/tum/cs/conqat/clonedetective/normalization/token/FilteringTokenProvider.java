/*--------------------------------------------------------------------------+
$Id: FilteringTokenProvider.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.conqat.resource.util.ResourceTraversalUtils;
import org.conqat.sourcecode.resource.ITokenElement;
import org.conqat.sourcecode.resource.ITokenResource;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.region.RegionSet;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.regions.RegionSetDictionary;
import edu.tum.cs.scanner.IToken;

/**
 * Token provider that filters tokens based on the filter region information
 * stored in the IFileSystemElements the tokens originated from, and based on an
 * optional pattern list against which tokens are matched.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 30460 $
 * @levd.rating RED Hash: 3522BAF747578BAFC2EA1046AE2B3755
 */
public class FilteringTokenProvider extends TokenProviderBase implements
		Serializable {

	/** Default name of region set of ignored tokens */
	public static final String IGNORE = "ignore";

	/** Source of the tokens that are filtered */
	private final ITokenProvider tokenProvider;

	// TODO (EJ) If elements no longer expose CanonicalFiles, use UniformPaths
	// for Mapping
	/** Maps files to their filtered regions */
	private transient HashedListMap<String, RegionSet> idToFilteredregions;

	/** Ignore patterns for tokens */
	private final PatternList ignorePatterns;

	/** Element that needs to be initialized */
	private ITokenResource toInit = null;

	/**
	 * Names of the {@link RegionSet}s that for which matching tokens are
	 * filtered out.
	 */
	private final Set<String> ignoreRegionSetNames;

	/**
	 * Default constructor. Ignores tokens from default ignore set
	 * {@value #IGNORE} and empty ignore patterns.
	 * 
	 * @param tokenProvider
	 *            Source of unfiltered tokens.
	 */
	public FilteringTokenProvider(ITokenProvider tokenProvider) {
		this(tokenProvider, CollectionUtils.asHashSet(new String[] { IGNORE }),
				new PatternList());
	}

	/**
	 * Creates a {@link FilteringTokenProvider}
	 * 
	 * @param tokenProvider
	 *            Source of unfiltered tokens.
	 * 
	 * @param ignoreRegionSetNames
	 *            Name of the {@link RegionSet} for which matching tokens get
	 *            ignored
	 * 
	 * @param ignorePatterns
	 *            Tokens that are matched by these patterns are ignored.
	 */
	public FilteringTokenProvider(ITokenProvider tokenProvider,
			Set<String> ignoreRegionSetNames, PatternList ignorePatterns) {
		this.tokenProvider = tokenProvider;
		this.ignoreRegionSetNames = ignoreRegionSetNames;
		this.ignorePatterns = ignorePatterns;
	}

	/** Returns next token that is not filtered out */
	@Override
	protected IToken provideNext() throws CloneDetectionException {
		if (toInit != null) {
			initRegionMap(toInit);
			toInit = null;
		}

		IToken token = tokenProvider.getNext();

		while (token != null && isFilteredOut(token)) {
			token = tokenProvider.getNext();
		}

		return token;
	}

	/** Returns true, if a token should be filtered out */
	private boolean isFilteredOut(IToken token) {
		int tokenOffset = token.getOffset();

		List<RegionSet> ignoredRegionSets = idToFilteredregions.getList(token
				.getOriginId());
		if (ignoredRegionSets == null) {
			return false;
		}

		for (RegionSet ignoredRegionSet : ignoredRegionSets) {
			if (ignoredRegionSet.contains(tokenOffset)) {
				return true;
			}
		}

		if (ignorePatterns.matchesAny(token.getText())) {
			return true;
		}

		return false;
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ITokenResource root) throws CloneDetectionException {
		// init token provider
		tokenProvider.init(root, getLogger());

		toInit = root;
	}

	/** Init region map for element */
	private void initRegionMap(ITokenResource root) {
		idToFilteredregions = new HashedListMap<String, RegionSet>();

		// init map that maps from element id to set of filtered regions
		Map<String, ITokenElement> idToElement;
		idToElement = ResourceTraversalUtils.createUniformPathToElementMap(
				root, ITokenElement.class);

		for (String file : idToElement.keySet()) {
			ITokenElement element = idToElement.get(file);

			RegionSet filteredRegions;
			try {
				for (String ignoreRegionSetName : ignoreRegionSetNames) {
					filteredRegions = RegionSetDictionary.retrieve(element,
							ignoreRegionSetName);
					if (filteredRegions != null) {
						idToFilteredregions.add(file, filteredRegions);
					}
				}
			} catch (ConQATException e) {
				getLogger().warn(
						"Skipping element '" + element.getId() + "': "
								+ e.getMessage());
			}

		}
	}
}
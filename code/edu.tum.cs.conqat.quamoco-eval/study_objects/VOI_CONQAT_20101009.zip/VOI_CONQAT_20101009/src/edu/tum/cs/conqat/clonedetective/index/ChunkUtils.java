/*--------------------------------------------------------------------------+
$Id: ChunkUtils.java 28956 2010-06-30 15:04:11Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.digest.Digester;
import edu.tum.cs.commons.digest.MD5Digest;
import edu.tum.cs.commons.string.FastStringComparator;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.detection.SentinelUnit;
import edu.tum.cs.conqat.clonedetective.index.store.ICloneIndexStore;
import edu.tum.cs.conqat.database.store.StorageException;

/**
 * Utility methods for dealing with chunks.
 * 
 * @author hummelb
 * @author $Author: juergens $
 * @version $Rev: 28956 $
 * @levd.rating GREEN Hash: 466CFC9E9CCDAC4777D524D0DDF69D9F
 */
/* package */class ChunkUtils {

	/**
	 * String used for separating units in
	 * {@link #calculateChunks(List, int, String)}.
	 */
	private static final byte[] UNIT_SEPARATOR = "*#*".getBytes();

	/**
	 * Singleton instance of a comparator used to sort by originId and then unit
	 * index (both ascending).
	 */
	private static final Comparator<Chunk> chunkComparator = new Comparator<Chunk>() {
		@Override
		public int compare(Chunk cd1, Chunk cd2) {
			int cmp = FastStringComparator.INSTANCE.compare(cd1.getOriginId(),
					cd2.getOriginId());
			if (cmp != 0) {
				return cmp;
			}
			return cd1.getFirstUnitIndex() - cd2.getFirstUnitIndex();
		}
	};

	/**
	 * Obtains the list of ordered chunks for a list of chunks from a single
	 * origin. The returned list stores for each unit position in the origin
	 * (list) all chunks with the same hash. All of the lists will be sorted by
	 * originId and then unit index.
	 */
	public static List<ChunkList> obtainOrderedChunks(ICloneIndexStore store,
			List<Chunk> originChunks) throws StorageException {
		List<ChunkList> orderedChunks = new ArrayList<ChunkList>();
		HashMap<MD5Digest, List<Chunk>> lookupCache = new HashMap<MD5Digest, List<Chunk>>();
		for (Chunk cd : originChunks) {
			int index = cd.getFirstUnitIndex();
			while (index >= orderedChunks.size()) {
				orderedChunks.add(new ChunkList());
			}

			List<Chunk> chunksByHash = cachedGetChunksByHash(store, cd
					.getChunkHash(), lookupCache);
			if (chunksByHash == null) {
				throw new StorageException("Inconsistent database!");
			}
			if (chunksByHash.size() >= 2) {
				List<Chunk> chunks = orderedChunks.get(index);
				chunks.addAll(chunksByHash);
				Collections.sort(chunks, chunkComparator);
			}
		}
		return orderedChunks;
	}

	/**
	 * Returns the chunks for the given hash, but uses the provided map for
	 * caching. Caching is used to prevent expensive lookups in the case of many
	 * equal hashes in an origin.
	 */
	private static List<Chunk> cachedGetChunksByHash(ICloneIndexStore store,
			MD5Digest hash, Map<MD5Digest, List<Chunk>> cache)
			throws StorageException {
		List<Chunk> chunks = cache.get(hash);

		if (chunks == null) {
			chunks = store.getChunksByHash(hash);
			if (chunks == null) {
				chunks = CollectionUtils.emptyList();
			}
			cache.put(hash, chunks);
		}

		if (chunks.isEmpty()) {
			return null;
		}

		return chunks;
	}

	/**
	 * Returns the first {@link Chunk} from the list matching the given
	 * originId. Returns null if none is found.
	 */
	public static Chunk findFirstChunkFor(String originId, List<Chunk> chunks) {
		for (Chunk chunk : chunks) {
			if (chunk.getOriginId().equals(originId)) {
				return chunk;
			}
		}
		return null;
	}

	/**
	 * Returns whether the chunk locations from the <code>subSet</code> list are
	 * a subset of those from the <code>superSet</code> list. For this
	 * comparison, only {@link Chunk#getOriginId()} and
	 * {@link Chunk#getFirstUnitIndex()} are used, as this is sufficient to
	 * uniquely identify a chunk. This method respects that the locations in
	 * subSet are advanced by <code>distance</code> compared to superSet.
	 * <p>
	 * The lists put into this method must be sorted!
	 */
	public static boolean isSubSet(List<Chunk> subSet, List<Chunk> superSet,
			int distance) {
		int subIndex = 0;
		int superIndex = 0;
		while (subIndex < subSet.size()) {
			if (superIndex >= superSet.size()) {
				return false;
			}

			Chunk subLocation = subSet.get(subIndex);
			Chunk superLocation = superSet.get(superIndex);
			int cmp = compareWithDistance(superLocation, subLocation, distance);
			if (cmp == 0) {
				++subIndex;
				++superIndex;
			} else if (cmp < 0) {
				// element in super is "too small", but element in sub might
				// still be found
				++superIndex;
			} else {
				// element in super is "too big"; no chance to find element in
				// sub
				return false;
			}
		}

		return true;
	}

	/**
	 * Returns a (sorted) list containing the intersection of the two lists of
	 * locations based on {@link Chunk#getOriginId()} and
	 * {@link Chunk#getFirstUnitIndex()} only, as this is sufficient to uniquely
	 * identify a chunk. This method respects that the locations in
	 * <code>next</code> are advanced by one compared to <code>prev</code>. The
	 * returned list is a subset of nextLocations (i.e. using its indices).
	 * <p>
	 * The lists put into this method must be sorted!
	 * 
	 * @param prev
	 *            this is the previous chunk (i.e. the one before distance).
	 * @param next
	 *            this is the next chunk (i.e. the one after distance).
	 */
	public static List<Chunk> intersect(List<Chunk> prev, List<Chunk> next) {
		List<Chunk> result = new ArrayList<Chunk>();
		int prevIndex = 0;
		int nextIndex = 0;
		int prevSize = prev.size();
		int nextSize = next.size();
		while (prevIndex < prevSize && nextIndex < nextSize) {
			int cmp = compareWithDistance(prev.get(prevIndex), next
					.get(nextIndex), 1);
			if (cmp == 0) {
				result.add(next.get(nextIndex));
				++prevIndex;
				++nextIndex;
			} else if (cmp < 0) {
				// prev is "too small"
				++prevIndex;
			} else {
				++nextIndex;
			}
		}

		return result;
	}

	/**
	 * Performs a comparison based on {@link Chunk#getOriginId()} and
	 * {@link Chunk#getFirstUnitIndex()}, but increasing the unit index of prev
	 * by <code>distance</code> before comparison.
	 * 
	 * @param prev
	 *            this is the previous chunk (i.e. the one before distance).
	 * @param next
	 *            this is the next chunk (i.e. the one after distance).
	 */
	public static int compareWithDistance(Chunk prev, Chunk next, int distance) {
		int cmp = FastStringComparator.INSTANCE.compare(prev.getOriginId(),
				next.getOriginId());
		if (cmp != 0) {
			return cmp;
		}
		return prev.getFirstUnitIndex() + distance - next.getFirstUnitIndex();
	}

	/**
	 * Calculates the list of {@link Chunk}s for a list of units for one
	 * originId. The chunks are calculated for all continuous subsequences of
	 * given chunk length, where sublists containing seninel units are skipped
	 * (as they should never match anything).
	 */
	public static List<Chunk> calculateChunks(List<Unit> units, int chunkSize,
			String originId) {
		List<Chunk> result = new ArrayList<Chunk>();

		for (int i = chunkSize - 1; i < units.size(); ++i) {
			int first = i - (chunkSize - 1);
			MD5Digest digest = buildChunkHash(units, first, i);
			if (digest == null) {
				continue;
			}

			Unit lastUnit = units.get(first + chunkSize - 1);
			Chunk chunk = new Chunk(originId, digest, first, units.get(first)
					.getStartLineInFile(), lastUnit.getStartLineInFile()
					+ lastUnit.getCoveredLines());

			result.add(chunk);
		}

		return result;
	}

	/**
	 * Calculates the chunk hash from the given sub list. Returns null if a
	 * sentinel unit is encountered.
	 */
	private static MD5Digest buildChunkHash(List<Unit> units, int first,
			int last) {
		MessageDigest md5 = Digester.getMD5();
		for (int j = first; j <= last; ++j) {
			Unit unit = units.get(j);
			if (unit instanceof SentinelUnit) {
				// completely skip sentinel units (will not match anything)
				return null;
			}
			md5.update(unit.getContent().getBytes());
			md5.update(UNIT_SEPARATOR);
		}
		return new MD5Digest(md5);
	}
}

/*--------------------------------------------------------------------------+
$Id: CrossProjectCloneClassFilter.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection.filter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This clone class filter can be used to determine clone classes that span
 * several projects. All clone classes that span less than a certain number of
 * projects are filtered out.
 * <p>
 * Membership of a clone in a project is determined by project-specific path
 * prefixes.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: E43DCA773C3068C0A4B5CD1632529718
 */
@AConQATProcessor(description = "Filters out clone classes that do not span a minimum number of different projects")
public class CrossProjectCloneClassFilter extends CloneClassFilterBase {

	/** List of project-specific prefixes */
	private final List<String> projectPrefixes = new ArrayList<String>();

	/** Minimum number of spanned projects */
	private int requiredProjectsCount = 2;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "project", minOccurrences = 2, description = ""
			+ "Prefix of all file paths or ids of this project (typically project root directory or package)")
	public void addProjectPathPrefix(
			@AConQATAttribute(name = "prefix", description = "Prefix of all file paths or ids of this project") String projectPathPrefix) {
		this.projectPrefixes.add(projectPathPrefix);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "projects", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Number of required projects")
	public void setRequiredProjectsCount(
			@AConQATAttribute(name = "count", description = "Number of required projects (default is 2)") int requiredProjectsCount) {
		this.requiredProjectsCount = requiredProjectsCount;
	}

	/** Filters out clone classes that do not span enough projects */
	@Override
	protected boolean filteredOut(CloneClass cloneClass) {
		return computeSpannedProjects(cloneClass).size() < requiredProjectsCount;
	}

	/**
	 * Determines the set of projects spanned by a clone class. Projects are
	 * identified by their prefix.
	 */
	private Set<String> computeSpannedProjects(CloneClass cloneClass) {
		Set<String> spannedProjects = new HashSet<String>();

		for (Clone clone : cloneClass.getClones()) {
			CanonicalFile file = clone.getFile();

			for (String projectPrefix : projectPrefixes) {
				if (file.getCanonicalPath().startsWith(projectPrefix)) {
					spannedProjects.add(projectPrefix);
				}
			}
		}

		return spannedProjects;
	}

}
/*--------------------------------------------------------------------------+
$Id: StorageConsumerProcessorBase.java 28491 2010-06-22 09:08:36Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database.store.base;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.database.store.IStorageSystem;
import edu.tum.cs.conqat.database.store.IStore;
import edu.tum.cs.conqat.database.store.StorageException;

/**
 * Base class for a processor that requires a single store as input.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 28491 $
 * @levd.rating GREEN Hash: 3CF945B631354D1A427B1C5AA321C5F7
 */
public abstract class StorageConsumerProcessorBase extends ConQATProcessorBase {

	/** The storage system. */
	protected IStorageSystem storageSystem;

	/** The name of the store. */
	protected String storeName;

	/** The (cached) store. Use {@link #getStore()} to access this. */
	private IStore store;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "store", minOccurrences = 1, maxOccurrences = 1, description = "Sets the store this processor works on.")
	public void setStore(
			@AConQATAttribute(name = "system", description = "Reference to the storage system.") IStorageSystem storageSystem,
			@AConQATAttribute(name = "name", description = "Name of the accessed store.") String storeName) {
		this.storageSystem = storageSystem;
		this.storeName = storeName;
	}

	/**
	 * Returns the store to be used. The processor is responsible for closing
	 * the store. The store itself is cached in a variable, so this method may
	 * be called multiple times.
	 */
	protected IStore getStore() throws StorageException {
		if (store == null) {
			store = storageSystem.openStore(storeName);
		}
		return store;
	}

}

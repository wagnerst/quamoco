/*--------------------------------------------------------------------------+
$Id: SourceFileDescriptor.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.io.File;

/**
 * Collects information about a source file that was analyzed during clone
 * detection. This class is immutable.
 * 
 * @author juergens
 * @author aswolins
 * @author $Author: juergens $
 * @version $Rev: 30460 $
 * @levd.rating YELLOW Hash: 1F952A61B4A0B526EAE319D2C1703009
 */
public final class SourceFileDescriptor {

	/**
	 * The id that is used by clones to reference the file. Must be unique
	 * inside a single detection result.
	 */
	private final int id;

	/** The file. */
	private final File file;

	/** Length of the file */
	private final int length;

	/** String that identifies content of source file during detection */
	private final String fingerprint;

	/**
	 * @param id
	 *            Used to identify the source file.
	 * @param file
	 *            File
	 * @param length
	 *            Char length of the file
	 */
	public SourceFileDescriptor(int id, File file, int length,
			String fingerprint) {
		this.id = id;
		this.file = file;
		this.length = length;
		this.fingerprint = fingerprint;
	}

	/** Returns the file */
	public File getFile() {
		return file;
	}

	/** Returns length in lines. */
	public int getLength() {
		return length;
	}

	/** Returns id that is used by clones to reference the file. */
	public int getId() {
		return id;
	}

	/** Returns file fingerprint */
	public String getFingerprint() {
		return fingerprint;
	}
}
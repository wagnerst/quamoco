/*--------------------------------------------------------------------------+
$Id: CloneClassNode.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;

/**
 * This class represents a clone class. It works as an adapter between
 * {@link CloneClass}es and {@link edu.tum.cs.conqat.commons.node.IConQATNode}s.
 * 
 * @author Florian Deissenboeck
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 2D203947EE19C2AE04248F3F86F69B47
 */
public class CloneClassNode extends ConQATNodeBase {

	/** The clone class represented by this node */
	private final CloneClass cloneClass;

	/**
	 * The children for this node, that is, the nodes representing the clones of
	 * this clone class.
	 */
	private final List<CloneNode> children = new ArrayList<CloneNode>();

	/** The parent of this node. */
	private DetectionResultRootNode parent = null;

	/**
	 * Create clone class node from a clone class. This automatically creates
	 * the child nodes ({@link CloneNode}).
	 */
	public CloneClassNode(CloneClass cloneClass, String rootPath) {
		CCSMAssert.isNotNull(cloneClass, "CloneClass must not be null");
		this.cloneClass = cloneClass;

		storeMetrics(cloneClass);

		for (Clone clone : cloneClass.getClones()) {
			addChild(new CloneNode(clone, rootPath));
		}
	}

	/** Set clone classes metric values */
	private void storeMetrics(CloneClass cloneClass) {
		setValue(CloneListBuilderBase.CARDINALITY, cloneClass.size());
		setValue(CloneListBuilderBase.NORMALIZED_LENGTH, cloneClass
				.getNormalizedLength());
		setValue(CloneListBuilderBase.VOLUME, cloneClass.getNormalizedLength()
				* cloneClass.size());
	}

	/** Copy constructor. */
	private CloneClassNode(CloneClassNode node) throws DeepCloneException {
		super(node);
		cloneClass = node.cloneClass;
		for (CloneNode c : children) {
			addChild(c.deepClone());
		}
	}

	/** Add a new node. */
	/* package */void addChild(CloneNode node) {
		children.add(node);
		node.setParent(this);
	}

	/** {@inheritDoc} */
	public String getId() {
		return cloneClass.getNormalizedLength() + ":" + cloneClass.size();
	}

	/** {@inheritDoc} */
	public String getName() {
		return "Clone Class [" + cloneClass.getId() + "]";
	}

	/** {@inheritDoc} */
	public CloneClassNode deepClone() throws DeepCloneException {
		return new CloneClassNode(this);
	}

	/** {@inheritDoc} */
	public CloneNode[] getChildren() {
		return children.toArray(new CloneNode[children.size()]);
	}

	/** {@inheritDoc} */
	public DetectionResultRootNode getParent() {
		return parent;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !children.isEmpty();
	}

	/** Set the parent for this node. */
	/* package */void setParent(DetectionResultRootNode node) {
		parent = node;
	}

	/** Removes the given node from the child list. */
	/* package */void removeNode(CloneNode node) {
		children.remove(node);
	}

	/** Returns underlying {@link CloneClass} */
	public CloneClass getCloneClass() {
		return cloneClass;
	}

	/** Clone class comparator */
	public static class CloneClassNodeComparator implements
			Comparator<CloneClassNode> {

		/** Comparator used to compare clone classes */
		private final Comparator<CloneClass> cloneClassComparator;

		/** Constructor */
		public CloneClassNodeComparator(
				Comparator<CloneClass> cloneClassComparator) {
			this.cloneClassComparator = cloneClassComparator;
		}

		/** {@inheritDoc} */
		public int compare(CloneClassNode o1, CloneClassNode o2) {
			if (o1 == null && o2 == null) {
				return 0;
			}
			if (o1 == null) {
				return -1;
			}
			if (o2 == null) {
				return 1;
			}

			return cloneClassComparator.compare(o1.getCloneClass(), o2
					.getCloneClass());
		}

	}
}
/*--------------------------------------------------------------------------+
$Id: InMemoryCloneIndexStoreFactory.java 29795 2010-08-19 09:38:28Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index.store.mem;

import edu.tum.cs.conqat.clonedetective.index.store.ICloneIndexStore;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29795 $
 * @levd.rating GREEN Hash: 424101823E4A3FA7C1BEAA8D6430307C
 */
@AConQATProcessor(description = "Factory for a clone index store that resides completely in memory. "
		+ "No disk access is needed but also nothing will be persisted for later use.")
public class InMemoryCloneIndexStoreFactory extends ConQATProcessorBase {

	/** {@inheritDoc} */
	@Override
	public ICloneIndexStore process() {
		// no need to close this in the end
		return new InMemoryCloneIndexStore();
	}
}

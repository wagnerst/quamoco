/*--------------------------------------------------------------------------+
$Id: IlaXmlReaderBase.java 28733 2010-06-24 11:52:44Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.ila.xml;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.xml.sax.SAXException;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableSet;
import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.commons.xml.XMLReader;
import edu.tum.cs.commons.xml.XMLResolver;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for classes that read XML files produced by the Intermediate
 * Language Analyzer.
 * 
 * 
 * @author Elmar Juergens
 * @author $Author: heineman $
 * 
 * @version $Revision: 28733 $
 * @levd.rating GREEN Hash: F0431BD224DAC175D4089320C70E5720
 */
public abstract class IlaXmlReaderBase
		extends
		XMLReader<EIlaXmlElement, EIlaXmlAttribute, NeverThrownRuntimeException> {

	/** Root node under which all encountered class nodes are stored */
	protected final ListNode root;

	/** All members that match any of these patterns are ignored */
	private final PatternList ignorePatterns;

	/**
	 * If not null, only members matching one of these patterns are included
	 */
	private final PatternList includePatterns;

	/** Set of all dependencies that have been imported. */
	private final Set<String> dependencies = new HashSet<String>();

	/**
	 * Constructor
	 * 
	 * @param file
	 *            IL-XML file that gets parsed
	 * @param root
	 *            Root under which the nodes representing types found during
	 *            parse are attached
	 * @param ignorePatterns
	 *            List of patterns for members that are ignored during import.
	 * @param includePatterns
	 *            If not null, only members matching one of these patterns are
	 *            included.
	 */
	public IlaXmlReaderBase(File file, ListNode root,
			PatternList ignorePatterns, PatternList includePatterns) {
		super(file, new XMLResolver<EIlaXmlElement, EIlaXmlAttribute>(
				EIlaXmlAttribute.class));
		this.root = root;
		this.ignorePatterns = ignorePatterns;
		this.includePatterns = includePatterns;
	}

	/**
	 * Parses the IL-XML file.
	 * 
	 * @throws ConQATException
	 *             if file could not be parsed.
	 */
	public void parse() throws ConQATException {
		try {
			parseFile();
		} catch (SAXException e) {
			throw new ConQATException(
					"Could not parse file: " + e.getMessage(), e);
		} catch (IOException e) {
			throw new ConQATException("Could not read file: " + e.getMessage(),
					e);
		}

		doParse();
	}

	/** Template method that deriving classes override to implement parsing */
	protected abstract void doParse();

	/**
	 * Adds a dependency to the list, if dependency is not excluded by patterns
	 */
	protected void addDependency(String dependency, List<String> dependencies) {
		if (!StringUtils.isEmpty(dependency) && included(dependency)
				&& !ignored(dependency)) {
			dependencies.add(dependency);
		}
	}

	/** Writes a set of dependencies to debug collection */
	protected void logDependencies(List<String> dependencies, String source) {
		for (String dependencyTarget : this.dependencies) {
			dependencies.add(source + " -> " + dependencyTarget);
		}
	}

	/** Checks whether dependency is ignored */
	private boolean ignored(String dependency) {
		return ignorePatterns != null && ignorePatterns.matchesAny(dependency);
	}

	/** Checks whether dependency is included */
	private boolean included(String dependency) {
		return includePatterns == null
				|| includePatterns.matchesAny(dependency);
	}

	/** Get all dependencies. */
	public UnmodifiableSet<String> getAllDependencies() {
		return CollectionUtils.asUnmodifiable(dependencies);
	}
}
/*--------------------------------------------------------------------------+
$Id: ECloneReportAttribute.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;

/**
 * Attributes for the XML result report.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 0B3F8CB0D2B70DA2A3D3B96EC89441B0
 */
public enum ECloneReportAttribute {

	/** Id of clone class */
	id,

	/** Clone class rating */
	rating,

	/** Length of source file in LOC */
	length,

	/** See {@link Clone#getLengthInFile()} */
	lineCount,

	/** See {@link CloneClass#getNormalizedLength()} */
	normalizedLength,

	/**
	 * Fingerprint of source file or clone class. (See
	 * {@link CloneClass#getFingerprint()})
	 */
	fingerprint,

	/** See {@link Clone#getStartLineInFile()} */
	startLine,

	/** Gap information in gapped clone */
	gaps,

	/** Path of source file */
	path,

	/** Id of source file */
	sourceFileId,

	/** See {@link Clone#getStartUnitIndexInFile()} */
	startUnitIndexInFile,

	/** See {@link Clone#getLengthInUnits()} */
	lengthInUnits,
	
	/** See {@link Clone#getDeltaInUnits()} */
	deltaInUnits,

	/** Namespace attribute */
	xmlns, 
	
	/** Clone class value mechanism key attribute */
	key,
	
	/** Clone class value mechanism value attribute */
	value,
	
	/** Clone class value mechanism type attribute */
	type, 
	
	/** Date denoting the system version on which clone detection was performed */
	systemdate,
	
	/** Globally unique id attribute */
	uniqueId;

}
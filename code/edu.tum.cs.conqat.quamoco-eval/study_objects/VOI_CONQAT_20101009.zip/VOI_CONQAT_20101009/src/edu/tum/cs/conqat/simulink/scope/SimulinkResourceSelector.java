/*--------------------------------------------------------------------------+
$Id: SimulinkResourceSelector.java 30490 2010-10-07 17:20:05Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.scope;

import org.conqat.resource.IResource;
import org.conqat.resource.base.ResourceSelectorBase;

import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30490 $
 * @levd.rating GREEN Hash: C3DCE4ADCF9CDCBF60621CDD99CB9617
 */
@AConQATProcessor(description = "This processor filters all resources "
		+ "that are not ITextResources.")
public class SimulinkResourceSelector extends
		ResourceSelectorBase<ISimulinkResource, SimulinkContainer> {

	/** {@inheritDoc} */
	@Override
	protected SimulinkContainer createContainer(String name) {
		return new SimulinkContainer(name);
	}

	/** {@inheritDoc} */
	@Override
	protected boolean keepElement(IResource element) {
		return element instanceof ISimulinkElement;
	}

}

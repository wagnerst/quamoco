/*--------------------------------------------------------------------------+
$Id: CloneDependencyAnnotator.java 30460 2010-10-07 14:29:44Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.conqat.resource.text.ITextElement;
import org.conqat.resource.util.ResourceTraversalUtils;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Annotates each file in the file tree with a list of the files to which it has
 * clone dependencies.
 * <p>
 * These dependency lists can be used to create graph representations of the
 * clone relationships using the ConQAT Graph bundle.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 30460 $
 * @levd.rating GREEN Hash: 8E65C1E11C5BFFA3101D0B16061B313B
 */
@AConQATProcessor(description = "Annotates each file in the file tree with a list of the files to which "
		+ "it has clone dependencies.")
public class CloneDependencyAnnotator extends CloneAnnotatorBase {

	/** Key for List of clone dependencies. */
	@AConQATKey(description = "Holds list of element ids with which this element has "
			+ "cloning relations, or empty list, if it has no cloning relations", type = "java.util.List<String>")
	public static final String CLONE_DEPENDENCY_LIST_KEY = "Clone Dependency";

	/** Mapping from files to IDs. */
	private Map<String, String> fileToIdMap;

	/** {@inheritDoc} */
	@Override
	protected void processInput(CloneDetectionResultElement input)
			throws ConQATException {
		fileToIdMap = ResourceTraversalUtils.createElementToIdMapping(input, ITextElement.class);
		super.processInput(input);
	}

	/** Stores the dependency list at an element */
	@Override
	protected void annotateClones(ITextElement element,
			UnmodifiableList<Clone> clonesList) {
		List<String> fileDependencies = createFileDependencies(clonesList);

		element.setValue(CLONE_DEPENDENCY_LIST_KEY, fileDependencies);
	}

	/** Create a list of the files involved in list of clones */
	private List<String> createFileDependencies(List<Clone> clonesList) {
		Set<String> ids = new HashSet<String>();

		if (!clonesList.isEmpty()) {
			// all all sibling files
			for (Clone clone : clonesList) {
				// we tolerate creation of self loops here, since we remove them
				// below anyway
				for (Clone sibling : clone.getCloneClass().getClones()) {
					ids.add(fileToIdMap.get(sibling.getFile()));
				}
			}

			// remove self loops
			ids.remove(fileToIdMap.get(CollectionUtils.getAny(clonesList)
					.getFile()));
			ids.remove(null);
		}

		return new ArrayList<String>(ids);
	}

}
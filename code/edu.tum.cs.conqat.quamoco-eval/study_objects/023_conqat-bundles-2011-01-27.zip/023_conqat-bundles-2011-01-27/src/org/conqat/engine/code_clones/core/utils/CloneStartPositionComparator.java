/*--------------------------------------------------------------------------+
$Id: CloneStartPositionComparator.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.core.utils;

import java.util.Comparator;

import org.conqat.engine.code_clones.core.Clone;

/**
 * Compares clones by comparing their start positions.
 * <p>
 * Can be used to sort clones in a file by their start positions
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: D8E0742C065B6C65725FD8951E8BABF4
 */
public class CloneStartPositionComparator implements Comparator<Clone> {

	/** Singleton instance */
	private static CloneStartPositionComparator instance = null;

	/** Enforce use of singleton instance */
	private CloneStartPositionComparator() {
		// Nothing to do
	}

	/** {@inheritDoc} */
	public int compare(Clone clone1, Clone clone2) {
		Integer start1 = clone1.getStartLineInElement();
		Integer start2 = clone2.getStartLineInElement();
		return start1.compareTo(start2);
	}

	/** Get singleton instance of this comparator */
	public static CloneStartPositionComparator getInstance() {
		if (instance == null) {
			instance = new CloneStartPositionComparator();
		}
		return instance;
	}

}
/*--------------------------------------------------------------------------+
$Id: InMemoryCloneIndexStore.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.index.store.mem;

import java.util.List;

import org.conqat.lib.commons.collections.CollectionUtils;
import org.conqat.lib.commons.collections.HashedListMap;
import org.conqat.lib.commons.collections.UnmodifiableList;
import org.conqat.lib.commons.digest.MD5Digest;
import org.conqat.engine.code_clones.index.Chunk;

/**
 * A clone index store that keeps all data in memory.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 828B8361B75FBD1D24BEEF584057256A
 */
public class InMemoryCloneIndexStore extends MemoryStoreBase {

	/** Map for storing {@link Chunk}s by originId. */
	protected final HashedListMap<String, Chunk> byOrigin = new HashedListMap<String, Chunk>();

	/** Map for storing {@link Chunk}s by hash. */
	protected final HashedListMap<MD5Digest, Chunk> byHash = new HashedListMap<MD5Digest, Chunk>();

	/** {@inheritDoc} */
	@Override
	public void batchInsertChunks(List<Chunk> chunks) {
		for (Chunk chunk : chunks) {
			byOrigin.add(chunk.getOriginId(), chunk);
			byHash.add(chunk.getChunkHash(), chunk);
		}
	}

	/** {@inheritDoc} */
	@Override
	public void removeChunks(String originId) {
		List<Chunk> chunks = byOrigin.getList(originId);
		byOrigin.removeList(originId);

		for (Chunk chunk : chunks) {
			List<Chunk> list = byHash.getList(chunk.getChunkHash());
			list.remove(chunk);
		}
	}

	/** {@inheritDoc} */
	@Override
	public List<Chunk> getChunksByOrigin(String originId) {
		return byOrigin.getList(originId);
	}

	/** {@inheritDoc} */
	@Override
	public UnmodifiableList<Chunk> getChunksByHash(MD5Digest chunkHash) {
		return CollectionUtils.asUnmodifiable(byHash.getList(chunkHash));
	}
}

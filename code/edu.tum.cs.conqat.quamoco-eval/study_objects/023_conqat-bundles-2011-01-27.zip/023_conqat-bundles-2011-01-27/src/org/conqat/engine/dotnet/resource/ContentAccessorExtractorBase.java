/*--------------------------------------------------------------------------+
$Id: ContentAccessorExtractorBase.java 32162 2010-12-22 23:46:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 by the ConQAT Project                                |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.dotnet.resource;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.conqat.engine.resource.IContentAccessor;
import org.conqat.engine.resource.base.PatternSupportingInputProcessorBase;
import org.conqat.engine.resource.text.ITextElement;
import org.conqat.engine.resource.text.ITextResource;
import org.conqat.engine.resource.util.ResourceTraversalUtils;

import org.conqat.engine.commons.logging.IncludeExcludeListLogMessage;
import org.conqat.engine.commons.logging.StructuredLogTags;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.core.logging.IConQATLogger;

/**
 * Base class for processors that extract {@link IContentAccessor}s from
 * {@link ITextResource}s.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32162 $
 * @levd.rating GREEN Hash: 294583C080A5B07C63CB07CC849B9E3A
 */
public abstract class ContentAccessorExtractorBase extends
		PatternSupportingInputProcessorBase<ITextResource> {

	/** {@inheritDoc} */
	@Override
	public IContentAccessor[] process() throws ConQATException {
		List<IContentAccessor> included = new ArrayList<IContentAccessor>();
		List<IContentAccessor> excluded = new ArrayList<IContentAccessor>();

		for (ITextElement containerElement : ResourceTraversalUtils
				.listTextElements(input)) {
			extractContentAccessors(containerElement, included, excluded,
					getLogger());
		}

		// remove duplicates
		included = removeDuplicates(included);
		excluded = removeDuplicates(excluded);

		// log all included, but excluded only if not empty
		logAccessors(included, true);
		if (excluded.size() > 0) {
			logAccessors(excluded, false);
		}

		return included.toArray(new IContentAccessor[included.size()]);
	}

	/** Remove all duplicate content accessors. */
	private static List<IContentAccessor> removeDuplicates(
			List<IContentAccessor> accessors) {
		List<IContentAccessor> result = new ArrayList<IContentAccessor>();
		Set<String> containedUniformPaths = new HashSet<String>();
		for (IContentAccessor accessor : accessors) {
			String uniformPath = accessor.getUniformPath();
			if (containedUniformPaths.add(uniformPath)) {
				result.add(accessor);
			}
		}

		return result;
	}

	/**
	 * Template method that deriving classes override to implement actual
	 * extraction
	 */
	protected abstract void extractContentAccessors(ITextElement element,
			List<IContentAccessor> included, List<IContentAccessor> excluded,
			IConQATLogger logger) throws ConQATException;

	/** Log accessors */
	private void logAccessors(List<IContentAccessor> accessors, boolean included) {
		Set<String> locations = new HashSet<String>();
		for (IContentAccessor accessor : accessors) {
			locations.add(accessor.getLocation());
		}

		getLogger().info(
				new IncludeExcludeListLogMessage("files", included, locations,
						StructuredLogTags.SCOPE, StructuredLogTags.FILES));
	}
}
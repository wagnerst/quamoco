/*--------------------------------------------------------------------------+
   $Id: MetricQuery.java 32087 2010-12-22 21:03:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch;

import org.apache.lucene.search.Query;
import org.apache.lucene.search.function.CustomScoreQuery;
import org.apache.lucene.search.function.FieldScoreQuery;

/**
 * 
 * @author deissenb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: F65FDDE319C60DAC0B7AD21B00D7C5B3
 */
public class MetricQuery extends CustomScoreQuery {

	private final boolean useSimilarity;

	public MetricQuery(Query subQuery, String metric, boolean useSimilarity) {
		super(subQuery, new FieldScoreQuery(metric, FieldScoreQuery.Type.FLOAT));
		this.useSimilarity = useSimilarity;
	}

	public float customScore(int doc, float subQueryScore, float valSrcScore) {
		if (useSimilarity) {
			return subQueryScore + valSrcScore;
		}
		return valSrcScore;
	}
}

/*--------------------------------------------------------------------------+
$Id: CloneListReportWriterProcessor.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.result;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.conqat.lib.commons.collections.CollectionUtils;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.core.report.CloneReportWriter;
import org.conqat.engine.code_clones.core.report.SourceElementDescriptor;
import org.conqat.engine.commons.ConQATParamDoc;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.core.logging.IConQATLogger;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * @version $Revision: 32087 $
 * @levd.rating GREEN Hash: 95FCA445D8FB544F7016FFC8F523A66A
 */
@AConQATProcessor(description = "Processor that writes a clone detection result file in xml format."
		+ "This processor writes a report based on the clone list alone.")
public class CloneListReportWriterProcessor extends
		CloneReportWriterProcessorBase {

	/** Clone detection result for which report gets written */
	private List<CloneClass> cloneClasses;

	/** ConQAT Parameter */
	@AConQATParameter(name = "clone-classes", description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setDetectionResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) List<CloneClass> cloneClasses) {
		this.cloneClasses = cloneClasses;
	}

	/** {@inheritDoc} */
	@Override
	protected void doWriteReport() throws ConQATException {
		writeReport(cloneClasses, new Date(), targetFile, getLogger());
	}

	/**
	 * Writes a clone report file using a {@link CloneReportWriter}.
	 * 
	 * @param cloneClasses
	 *            Result clone classes that get written to the report
	 * @param systemDate
	 *            Date denoting the system version on which clone detection was
	 *            performed.
	 * @param targetFile
	 *            File into which report gets written
	 * @param logger
	 *            Logger used to log errors occurring during report writing
	 * 
	 * @throws ConQATException
	 *             If report creation fails.
	 */
	public static void writeReport(List<CloneClass> cloneClasses,
			Date systemDate, File targetFile, IConQATLogger logger)
			throws ConQATException {
		CloneReportWriter.writeReport(cloneClasses,
				createSourceElementDescriptors(cloneClasses), systemDate,
				targetFile);
	}

	/** Creates a Map from Clone locations to {@link SourceElementDescriptor}s. */
	private static Map<String, SourceElementDescriptor> createSourceElementDescriptors(
			List<CloneClass> cloneClasses) {
		Map<String, SourceElementDescriptor> sourceElementInfos = new HashMap<String, SourceElementDescriptor>();
		int sourceElementIdCounter = 0;

		// determine set of elements
		Map<String, String> uniformPathToLocation = new HashMap<String, String>();
		for (CloneClass cloneClass : cloneClasses) {
			for (Clone clone : cloneClass.getClones()) {
				uniformPathToLocation.put(clone.getUniformPath(), clone
						.getLocation());
			}
		}

		// compute mapping
		for (String uniformPath : CollectionUtils.sort(uniformPathToLocation
				.keySet())) {
			String location = uniformPathToLocation.get(uniformPath);
			sourceElementInfos.put(uniformPath, new SourceElementDescriptor(
					sourceElementIdCounter++, location, uniformPath, -1,
					StringUtils.EMPTY_STRING));
		}

		return sourceElementInfos;
	}
}
/*--------------------------------------------------------------------------+
$Id: ExternalCodeCloneDetector.java 32159 2010-12-22 23:42:52Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.index;

import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.conqat.engine.resource.scope.memory.InMemoryContentAccessor;
import org.conqat.engine.resource.text.ITextElement;
import org.conqat.engine.resource.text.ITextResource;
import org.conqat.engine.resource.text.TextContainer;
import org.conqat.engine.resource.text.TextElement;
import org.conqat.engine.resource.util.ResourceTraversalUtils;
import org.conqat.engine.resource.util.UniformPathUtils;
import org.conqat.engine.sourcecode.resource.ITokenElement;
import org.conqat.engine.sourcecode.resource.ITokenResource;

import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.collections.CollectionUtils;
import org.conqat.lib.commons.collections.UnmodifiableList;
import org.conqat.lib.commons.digest.MD5Digest;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.core.constraint.ConstraintList;
import org.conqat.engine.code_clones.core.constraint.ICloneClassConstraint;
import org.conqat.engine.code_clones.detection.CloneDetectionResultElement;
import org.conqat.engine.code_clones.index.report.ConstraintAwareCollectingCloneClassReporter;
import org.conqat.engine.code_clones.index.store.ICloneIndexStore;
import org.conqat.engine.code_clones.index.store.mem.InMemoryCloneIndexStore;
import org.conqat.engine.commons.ConQATParamDoc;
import org.conqat.engine.commons.ConQATProcessorBase;
import org.conqat.engine.commons.traversal.TraversalUtils;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.persistence.store.StorageException;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32159 $
 * @levd.rating RED Hash: 12C161BD4AF14C1DB4B61A2CE5EFA5F4
 */
@AConQATProcessor(description = "A processor for finding clones between a prepared index and code that is external to the index.")
public class ExternalCodeCloneDetector extends ConQATProcessorBase {

	/** The store factory. */
	private ICloneIndexStore store;

	/**
	 * Number of units that a clone must at least comprise. If it has less, it
	 * gets filtered out.
	 */
	private int minLength = -1;

	/** List of constraints that all detected clone classes must satisfy */
	private final ConstraintList constraints = new ConstraintList();

	/** Root of the input tree */
	private ITokenResource input;

	/** Sets the input */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setInput(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) ITokenResource input) {
		this.input = input;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "store", description = "The store factory used to access and persist the clone index.", minOccurrences = 1, maxOccurrences = 1)
	public void setStoreFactory(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) ICloneIndexStore store) {
		// whether the index is valid (contains data) is implicitly checked in
		// the process() method
		this.store = store;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "constraint", minOccurrences = 0, maxOccurrences = -1, description = ""
			+ "Adds a constraint that each detected clone class must satisfy")
	public void addConstraint(
			@AConQATAttribute(name = "type", description = "Clone classes that do not match the constraint are filtered") ICloneClassConstraint constraint) {
		constraints.add(constraint);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "clonelength", description = "Minimal length of Clone. If none is set, all clones will be reported (limited by chunk size of the index).", minOccurrences = 0, maxOccurrences = 1)
	public void setMinLength(
			@AConQATAttribute(name = "min", description = "Minimal length of Clone") int minLength) {
		this.minLength = minLength;
	}

	/** {@inheritDoc} */
	@Override
	public CloneDetectionResultElement process() throws ConQATException {
		int chunkLength = new PersistedOptions(store).getChunkLength();
		if (minLength < 0) {
			minLength = chunkLength;
		}
		if (minLength < chunkLength) {
			throw new ConQATException("The minimal clone length of "
					+ minLength + " is smaller than the chunk length of "
					+ chunkLength
					+ " stored in the index, which is not supported.");
		}

		AugmentingCloneIndexStore augStore = new AugmentingCloneIndexStore(
				store);
		CloneIndex index = new CloneIndex(augStore, getLogger());

		// make sure that we skip clones that only affect a single file (not
		// cross project)
		constraints.add(new ICloneClassConstraint() {
			@Override
			public boolean satisfied(CloneClass cloneClass) {
				Set<String> files = new HashSet<String>();
				for (Clone clone : cloneClass.getClones()) {
					files.add(clone.getUniformPath());
				}
				return files.size() > 1;
			}
		});

		ConstraintAwareCollectingCloneClassReporter reporter = new ConstraintAwareCollectingCloneClassReporter(
				minLength, constraints);

		for (ITokenElement element : ResourceTraversalUtils.listElements(input,
				ITokenElement.class)) {
			index.insertFile(element);
			index.reportClones(element.getUniformPath(), reporter, false /*
																		 * really
																		 * all
																		 * clones
																		 * !
																		 */,
					minLength);
			augStore.clear();
		}

		getLogger().info("Overall performance: " + index.getPerformanceInfo());
		getLogger().info("Clone classes: " + reporter.getCloneClasses().size());

		return new CloneDetectionResultElement(reporter.getBirthDate(),
				createFileList(reporter.getCloneClasses()), reporter
						.getCloneClasses(), null);
	}

	/** Creates file list from given clone classes. */
	private ITextResource createFileList(List<CloneClass> cloneClasses) {
		Set<String> files = new HashSet<String>();
		for (CloneClass cloneClass : cloneClasses) {
			for (Clone clone : cloneClass.getClones()) {
				files.add(clone.getUniformPath());
			}
		}
		if (files.isEmpty()) {
			return TraversalUtils.listLeavesDepthFirst(input).get(0);
		}

		TextContainer root = new TextContainer("");
		for (String file : files) {
			insert(new TextElement(new InMemoryContentAccessor(file,
					new byte[0]), Charset.defaultCharset()), root);
		}
		return root;
	}

	/** Inserts the given element into the hierarchy. */
	// TODO (BH): Clones from ResourceBuilder
	private void insert(ITextElement element, TextContainer container) {
		String[] segments = UniformPathUtils
				.splitPath(element.getUniformPath());
		int start = 0;
		if (!container.getName().isEmpty()) {
			CCSMAssert.isTrue(container.getName().equals(segments[0]),
					"Root should be named after the only one project!");
			start = 1;
		}

		for (int i = start; i < segments.length - 1; ++i) {
			ITextResource child = container.getNamedChild(segments[i]);
			if (!(child instanceof TextContainer)) {
				child = new TextContainer(segments[i]);
				container.addChild(child);
			}
			container = (TextContainer) child;
		}
		container.addChild(element);
	}

	/**
	 * A clone index store implementation that augments an existing store by
	 * additional entries.
	 */
	public static class AugmentingCloneIndexStore extends
			InMemoryCloneIndexStore {

		/** The store being augmented. */
		private final ICloneIndexStore wrappedStore;

		/** Constructor. */
		public AugmentingCloneIndexStore(ICloneIndexStore wrappedStore) {
			this.wrappedStore = wrappedStore;
		}

		/** Clears the augmented area. */
		public void clear() {
			byHash.clear();
			byOrigin.clear();
		}

		/** {@inheritDoc} */
		@Override
		public void close() {
			try {
				wrappedStore.close();
			} catch (StorageException e) {
				// TODO (BH): Ugly!
				throw new RuntimeException(e);
			}
			super.close();
		}

		/** {@inheritDoc} */
		@Override
		public Serializable getOption(String key) {
			try {
				return wrappedStore.getOption(key);
			} catch (StorageException e) {
				// TODO (BH): Ugly!
				throw new RuntimeException(e);
			}
		}

		/** {@inheritDoc} */
		@Override
		public List<Chunk> getChunksByOrigin(String originId) {
			// we do not access the wrapped store here, as we "know" that
			// nothing relevant is there
			return super.getChunksByOrigin(originId);
		}

		/** {@inheritDoc} */
		@Override
		public UnmodifiableList<Chunk> getChunksByHash(MD5Digest chunkHash) {
			List<Chunk> result = new ArrayList<Chunk>();
			result.addAll(super.getChunksByHash(chunkHash));
			try {
				result.addAll(wrappedStore.getChunksByHash(chunkHash));
			} catch (StorageException e) {
				// TODO (BH): Ugly!
				throw new RuntimeException(e);
			}
			return CollectionUtils.asUnmodifiable(result);
		}
	}
}

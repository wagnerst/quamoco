/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.findingdev
 |                                                                       |
   $Id: FindingsDateFilter.java 32087 2010-12-22 21:03:01Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import java.util.Date;

import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.core.core.AConQATFieldParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.finding_tracking.database.FindingGateway;

/**
 * {@ConQAT.Doc}
 * 
 * @author Martin P�hlmann
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating YELLOW Hash: 7A23523DFC3D894DBFE3E3EA2D20810C
 */

@AConQATProcessor(description = "This processor filters a finding report "
		+ "according to a baseline date.")
public class FindingsDateFilter extends FindingsFilterBase {

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "baseline", attribute = "date", description = "Baseline date. All findings born before this date get filtered.")
	public Date baseline;

	/** {@inheritDoc} */
	@Override
	protected boolean isFiltered(Finding finding) {
		Object dateObject = finding.getValue(FindingGateway.FIRST_SEEN);
		if (dateObject == null) {
			return false;
		}

		Date birth = new Date(Long.parseLong(dateObject.toString()));
		return birth.before(baseline);
	}

}

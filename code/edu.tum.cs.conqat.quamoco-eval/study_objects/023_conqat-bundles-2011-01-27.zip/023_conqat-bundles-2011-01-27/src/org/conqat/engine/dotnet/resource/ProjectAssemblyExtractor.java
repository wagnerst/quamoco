/*--------------------------------------------------------------------------+
$Id: ProjectAssemblyExtractor.java 32162 2010-12-22 23:46:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 by the ConQAT Project                                |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.dotnet.resource;

import java.util.List;

import org.conqat.engine.resource.IContentAccessor;
import org.conqat.engine.resource.text.ITextElement;

import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.dotnet.resource.project.ProjectParser;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32162 $
 * @levd.rating GREEN Hash: FD777604F679885CCB77D1C789857420
 */
@AConQATProcessor(description = "This processor provides content accessors for the assemblies "
		+ "belonging to a set of Visual Studio project elements that are input as a text element tree.")
public class ProjectAssemblyExtractor extends ProjectContentExtractorBase {

	/** The default name of the build configuration */
	public static final String DEFAULT_CONFIGURATION_NAME = "Debug";

	/** The platform used by default */
	public static final String DEFAULT_PLATFORM = "AnyCPU";

	/** The build configuration that is used to compile the projects */
	private BuildConfiguration configuration = new BuildConfiguration(
			DEFAULT_CONFIGURATION_NAME, DEFAULT_PLATFORM);

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "build-configuration", description = "The configuration used to build the solution", minOccurrences = 0, maxOccurrences = 1)
	public void setConfiguration(
			@AConQATAttribute(name = "name", defaultValue = DEFAULT_CONFIGURATION_NAME, description = "Name of the configuration, e.g. 'Debug' or 'Release'") String configurationName,
			@AConQATAttribute(name = "platform", defaultValue = DEFAULT_PLATFORM, description = "Name of the platform, e.g. 'AnyCPU'") String platformName) {
		configuration = new BuildConfiguration(configurationName, platformName);
	}

	/** {@inheritDoc} */
	@Override
	protected List<IContentAccessor> extractElementsFromProject(
			ITextElement projectElement, ProjectParser projectParser)
			throws ConQATException {
		return projectParser.extractAssemblyAccessors(projectElement,
				configuration);
	}
}

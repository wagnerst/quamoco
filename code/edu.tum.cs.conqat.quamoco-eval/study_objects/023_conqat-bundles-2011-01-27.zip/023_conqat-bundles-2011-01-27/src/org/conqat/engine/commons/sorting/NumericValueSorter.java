/*--------------------------------------------------------------------------+
$Id: NumericValueSorter.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.sorting;

import java.util.Comparator;

import org.conqat.lib.commons.clone.IDeepCloneable;
import org.conqat.engine.commons.ConQATParamDoc;
import org.conqat.engine.commons.node.IConQATNode;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * This processor sorts all nodes according to some numeric value.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 0E8F03B3F7292D75E4D5D0A0C6C4AD06
 */
@AConQATProcessor(description = "A processor to sort nodes according to a "
		+ "numeric value stored under a provided key. Correctly spoken the "
		+ "nodes are not sorted, but a corresponding comparator is assigned "
		+ "to all internal nodes which should be considered in the "
		+ "presentation.")
public class NumericValueSorter extends SorterBase {

	/** The comparator used. */
	private NumericValueComparator comparator;

	/** Set the key used for sorting. */
	@AConQATParameter(name = ConQATParamDoc.READKEY_KEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The key used to read the values for sorting. The value received "
			+ "via this key should be numeric, otherwise a value of infinity is "
			+ "assumed.")
	public void setKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC) String key) {
		this.comparator = new NumericValueComparator(key);
	}

	/** {@inheritDoc} */
	@Override
	protected Comparator<IConQATNode> getComparator(IConQATNode node) {
		return comparator;
	}

	/** The class used for sorting. */
	private static class NumericValueComparator implements
			Comparator<IConQATNode>, IDeepCloneable {

		/** The key used to find the value. */
		private final String key;

		/** Constructor. */
		public NumericValueComparator(String key) {
			this.key = key;
		}

		/**
		 * Compare the numbers stored at both nodes at the specified key. This
		 * handles cases where one or both of the values are not defined or are
		 * no numbers.
		 */
		public int compare(IConQATNode node1, IConQATNode node2) {
			Object o1 = node1.getValue(key);
			Object o2 = node2.getValue(key);

			if (!(o1 instanceof Number)) {
				if (!(o2 instanceof Number)) {
					return 0;
				}
				return -1;
			}
			if (!(o2 instanceof Number)) {
				return 1; // we already know d1 != null
			}

			double d1 = ((Number) o1).doubleValue();
			double d2 = ((Number) o2).doubleValue();

			if (d1 < d2) {
				return -1;
			}

			if (d1 > d2) {
				return 1;
			}

			return 0;
		}

		/** {@inheritDoc} */
		public IDeepCloneable deepClone() {
			// no changeable fields, so no cloning needed
			return this;
		}
	}
}
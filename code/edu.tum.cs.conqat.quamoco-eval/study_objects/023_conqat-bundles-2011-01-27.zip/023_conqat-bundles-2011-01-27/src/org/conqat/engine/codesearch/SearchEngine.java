/*--------------------------------------------------------------------------+
   $Id: SearchEngine.java 32373 2010-12-30 23:14:23Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.highlight.Formatter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.NullFragmenter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.util.Version;

import org.conqat.lib.commons.color.ECCSMColor;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.engine.codesearch.servlet.SearchResult;
import org.conqat.engine.codesearch.servlet.StartupServlet;

/** Simple command-line based search demo. */
public class SearchEngine {

	private static final Logger logger = Logger.getLogger(SearchEngine.class);

	private final String[] fields;

	private final StartupServlet startupServlet = StartupServlet.getInstance();

	private final Analyzer analyzer = new SourceCodeAnalyzer(startupServlet
			.getLanguage());

	private final Formatter formatter;

	public SearchEngine() throws CorruptIndexException, IOException {

		formatter = new SimpleHTMLFormatter("<span style=\"color:"
				+ ECCSMColor.BLUE.getHTMLColorCode() + ";font-weight:bold\">",
				"</span>");

		fields = new String[2 + startupServlet.getMetrics().size()];
		fields[0] = "path";
		fields[1] = "contents";
		int i = 2;
		for (String metric : startupServlet.getMetrics()) {
			fields[i] = metric;
			i++;
		}
	}

	public SearchResult search(String queryString, int from, int to,
			String metric, boolean useSimilarity) throws CorruptIndexException,
			IOException, ParseException {

		long startTime = System.currentTimeMillis();

		Query query = createQuery(queryString, metric, useSimilarity);

		IndexSearcher searcher = StartupServlet.getInstance()
				.getIndexSearcher();

		// FIXME (BH): Query interface has changed!
		return null;
//		Hits hits = searcher.search(query);
//
//		long time = System.currentTimeMillis() - startTime;
//
//		Highlighter highlighter = new Highlighter(formatter, new QueryScorer(
//				query));
//		ArrayList<Result> results = new ArrayList<Result>();
//
//		logger.debug(hits.length() + " hits");
//
//		for (int i = Math.min(hits.length(), from); i < Math.min(hits.length(),
//				to); i++) {
//			Document document = hits.doc(i);
//
//			String text = document.get(fields[1]);
//			TokenStream tokenStream = analyzer.tokenStream(fields[1],
//					new StringReader(text));
//			String preview = highlighter.getBestFragments(tokenStream, text, 3,
//					"...");
//
//			String metricValue = format(document.get(metric));
//
//			Result result = new Result(i, hits.id(i), hits.score(i), document
//					.get("path"), preview, metricValue);
//			results.add(result);
//		}
//
//		return new SearchResult(results, hits.length(), time);
	}

	private String format(String string) {
		if (StringUtils.isEmpty(string)) {
			return "";
		}

		try {
			Float f = Float.parseFloat(string);
			return StringUtils.format(f);
		} catch (NumberFormatException ex) {
			return string;
		}

	}

	public String getPreview(int doc, String queryString)
			throws ParseException, IOException {
		QueryParser parser = new MultiFieldQueryParser(Version.LUCENE_30,
				fields, analyzer);
		Query query = parser.parse(queryString);
		Highlighter highlighter = new Highlighter(formatter, new QueryScorer(
				query));
		highlighter.setTextFragmenter(new NullFragmenter());
		String text = startupServlet.getIndexSearcher().doc(doc).get(fields[1]);
		TokenStream tokenStream = analyzer.tokenStream(fields[1],
				new StringReader(text));
		String preview;
		try {
			preview = highlighter.getBestFragment(tokenStream, text);
		} catch (InvalidTokenOffsetsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}
		return preview;
	}

	private Query createQuery(String queryString, String metric,
			boolean useSimilarity) throws ParseException {
		QueryParser parser = new MultiFieldQueryParser(Version.LUCENE_30,
				fields, analyzer);
		Query subQuery = parser.parse(queryString);
		if (metric == null) {
			return subQuery;
		}
		return new MetricQuery(subQuery, metric, useSimilarity);

	}

}

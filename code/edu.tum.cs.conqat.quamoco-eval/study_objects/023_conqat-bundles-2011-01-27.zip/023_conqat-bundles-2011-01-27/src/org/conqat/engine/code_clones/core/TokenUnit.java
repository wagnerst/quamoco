/*--------------------------------------------------------------------------+
$Id: TokenUnit.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.core;

import org.conqat.lib.scanner.ETokenType;

/**
 * Unit-implementation for tokens.
 * 
 * @author $Author: hummelb $
 * @version $Revision: 32087 $
 * @levd.rating GREEN Hash: D00A4AF6EA4CF1D7931A76674D71F5F4
 */
public class TokenUnit extends Unit {

	/** Type of underlying token */
	private final ETokenType tokenType;

	/** Start position of token in its element */
	private final int offset;

	/**
	 * Create new {@link TokenUnit}.
	 * <p>
	 * Since we don't know how many lines a token spans, we always use 1 for
	 * covered lines.
	 * 
	 * @param content
	 *            the token's content
	 * @param startLineInElement
	 *            Line number of start of unit in element
	 * @param elementUniformPath
	 *            Uniform path of the element this unit stems from
	 */
	public TokenUnit(String content, String unnormalizedContent, int offset,
			int startLineInElement, String elementUniformPath,
			ETokenType tokenType, int indexInElement) {
		super(startLineInElement, elementUniformPath, content,
				unnormalizedContent, 1, indexInElement);
		this.tokenType = tokenType;
		this.offset = offset;
	}

	/**
	 * Create new {@link TokenUnit} with same normalized and unnormalized
	 * content.
	 */
	public TokenUnit(String content, int offset, int startLineInElement,
			String elementUniformPath, ETokenType tokenType, int indexInElement) {
		this(content, content, offset, startLineInElement, elementUniformPath,
				tokenType, indexInElement);
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		String result = "TOKEN '" + getContent() + "' (" + getType() + ")";
		result += " \"" + getElementUniformPath() + "\"" + " line "
				+ getStartLineInElement();
		return result;
	}

	/** Returns type of underlying token. */
	public ETokenType getType() {
		return tokenType;
	}

	/** Returns offset. */
	public int getOffset() {
		return offset;
	}

}
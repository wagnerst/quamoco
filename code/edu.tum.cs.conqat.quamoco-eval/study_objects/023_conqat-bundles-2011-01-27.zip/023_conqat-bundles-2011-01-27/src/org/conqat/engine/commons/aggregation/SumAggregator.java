/*--------------------------------------------------------------------------+
$Id: SumAggregator.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.aggregation;

import java.util.List;

import org.conqat.engine.core.core.AConQATProcessor;

/**
 * An aggregator for summing up the leaf values.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 18155F76BD38D65E37A478856D10D3F2
 */
@AConQATProcessor(description = "An aggregator for summing up the values of the leaves. "
		+ "This works only for numbers.")
public class SumAggregator extends AggregatorBase<Number> {

	/** {@inheritDoc} */
	@Override
	protected Double aggregate(List<Number> values) {
		double sum = 0;
		for (Number num : values) {
			sum += num.doubleValue();
		}
		return sum;
	}
}
/*--------------------------------------------------------------------------+
$Id: OptionalsProcessorBase.java 32573 2011-01-19 13:24:36Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.optionals;

import org.conqat.engine.commons.ConQATProcessorBase;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.ConQATException;

/**
 * Base class for optionals processors.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32573 $
 * @levd.rating RED Hash: 35F38A1FA1ABBD52E662278B4FB9E3DA
 */
public class OptionalsProcessorBase<T> extends ConQATProcessorBase {

	/** Documentation string. */
	public static final String DOC = "This processor allows to define optional values. "
			+ "If the actual value is not set, null is returned, otherwise the "
			+ "actual value is returned.";

	/** The actual value. */
	protected T actualValue;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "actual", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "If set, this value will be used.")
	public void setActualValue(
			@AConQATAttribute(name = "value", description = "Value") T value)
			throws ConQATException {
		if (value == null) {
			// TODO (BH): Why should null not be a valid value?
			throw new ConQATException(
					"null value for actual value not supported.");
		}
		actualValue = value;
	}

	/** {@inheritDoc} */
	@Override
	public T process() {
		// TODO (BH): I would not use a null check here, to allow also a null
		// value to be propagated. Better use a boolean flag.
		if (actualValue == null) {
			// TODO (BH): Why return null? This parameter is required, so better
			// throw a ConQATException if it is not present
			return null;
		}
		return actualValue;
	}

}
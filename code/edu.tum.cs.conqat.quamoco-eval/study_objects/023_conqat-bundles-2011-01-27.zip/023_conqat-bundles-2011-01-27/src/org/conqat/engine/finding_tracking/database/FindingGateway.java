/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: FindingGateway.java 32461 2011-01-10 16:41:19Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import org.conqat.engine.commons.findings.EFindingKeys;
import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.FindingCategory;
import org.conqat.engine.commons.findings.FindingGroup;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.commons.findings.location.CodeLineLocation;
import org.conqat.engine.commons.findings.location.CodeRegionLocation;
import org.conqat.engine.commons.findings.location.ElementLocation;
import org.conqat.engine.persistence.DatabaseUtils;

/**
 * Manages storing and retrieving of Findings from a database.
 * 
 * @author Martin P�hlmann
 * @author $Author: juergens $
 * @version $Rev: 32461 $
 * @levd.rating RED Hash: 59EC2BE5E0C85B5F7EF0AC780E608AE7
 */
public class FindingGateway extends AbstractGateway {

	/** Constant used to indicate that integer db value is empty */
	private static final int EMPTY = -1;

	/** The database table for findings. */
	/* package */static final String FINDING_TABLE_NAME = "FINDING";

	/** The primary database key. */
	public static final String FINDING_ID = "FINDING_ID";

	/** The first time this Finding has been seen. */
	public static final String FIRST_SEEN = "FIRST_SEEN";
	/** The last time this Finding has been seen. */
	public static final String LAST_SEEN = "LAST_SEEN";
	/** The time the finding has died. */
	public static final String DIED = "DIED";

	/** The line or content of the finding. */
	public static final String CONTENT = "CONTENT";
	/** Context before the content of the finding. */
	public static final String PRE_CONTEXT = "PRE_CONTEXT";
	/** Context after the content of the finding. */
	public static final String POST_CONTEXT = "POST_CONTEXT";
	/** Length (in lines) of the context surrounding a finding. */
	public static final int CONTEXT_LENGTH = 3;

	/** Message column for findings. */
	public static final String MESSAGE = "MESSAGE";

	/** start line number of a finding's location */
	public static final String FIRST_LINE_NUMBER = "FIRST_LINE_NUMBER";
	/** end line number of a finding's location */
	public static final String LAST_LINE_NUMBER = "LAST_LINE_NUMBER";
	/** start position of a finding's location */
	public static final String FIRST_CHAR_POSITION = "FIRST_CHAR_POSITION";
	/** end position of a finding's location */
	public static final String LAST_CHAR_POSITION = "LAST_CHAR_POSITION";
	/** start position of a finding's content */
	public static final String CONTENT_CHAR_POSITION = "CONTENT_CHAR_POSITION";

	/** Gateway for the finding path table. */
	private final FindingPathGateway pathGateway;

	/** Gateway for the finding type table. */
	private final FindingTypeGateway typeGateway;

	/** Prepared statement for inserting a finding */
	private final PreparedStatement insertFinding;

	/** Prepared statement for updating a finding */
	private final PreparedStatement updateFinding;

	/**
	 * Constructor. One can specify a path that is used to save filenames
	 * relatively, otherwise pass null.
	 */
	public FindingGateway(Connection dbConnection) throws SQLException {
		super(dbConnection);

		/*
		 * Database structure - 3 Tables: The FINDING_TYPE table holds an unique
		 * identifier for a category/group pair. The FINDING_LOCATION table
		 * assigns a filename an unique identifier. Finally the FINDING table
		 * holds the finding message, location and references both a
		 * finding_type and a finding_path.
		 * 
		 * The database layout/statements have been tested with HSQLDB and
		 * MySQL.
		 */

		pathGateway = new FindingPathGateway(dbConnection);
		typeGateway = new FindingTypeGateway(dbConnection);

		// init prepared statements
		insertFinding = dbConnection.prepareStatement(getPreparedInsertSQL());
		updateFinding = dbConnection.prepareStatement(getPreparedUpdateSQL());
	}

	/** Stores or updates a finding in the database. */
	public void storeFinding(Finding finding) throws SQLException {
		// If we matched a finding, update the database
		if (finding.getValue(FINDING_ID) != null) {
			updateFinding(finding);
			return;
		}

		// store new finding
		long findingID = keyProvider.getKey();
		insertFinding.setLong(1, findingID);
		finding.setValue(FINDING_ID, findingID);

		insertFinding.setInt(2, typeGateway.storeAndGetFindingTypeID(finding));
		insertFinding.setInt(3, pathGateway.storeAndGetPathID(finding));
		insertFinding.setString(4, finding.getMessage());

		long timestamp = finding.getParent().getParent().getParent().getTime()
				.getTime();
		finding.setValue(FIRST_SEEN, timestamp);
		insertFinding.setLong(5, timestamp);
		finding.setValue(LAST_SEEN, timestamp);
		insertFinding.setLong(6, timestamp);

		attachLocation(finding, insertFinding, 7);

		insertFinding.executeUpdate();
		// statement should remain open

	}

	/** Invalidates a finding by assigning the DIED timestamp. */
	public void invalidateFinding(Finding finding, Date timeOfDeath)
			throws SQLException {
		long death = timeOfDeath.getTime();

		StringBuilder query = new StringBuilder();
		query.append("UPDATE " + FINDING_TABLE_NAME);
		query.append(" SET " + DIED + " = " + death);
		query.append(" WHERE " + FINDING_ID + " = "
				+ ((Long) finding.getValue(FINDING_ID)).toString());

		DatabaseUtils.executeUpdate(connection, query.toString());

		finding.setValue(DIED, death);
	}

	/** Updates an existing finding. */
	private void updateFinding(Finding finding) throws SQLException {

		updateFinding.setLong(1, (Long) finding.getValue(LAST_SEEN));
		int nextColumn = attachLocation(finding, updateFinding, 2);
		updateFinding.setLong(nextColumn, (Long) finding.getValue(FINDING_ID));

		updateFinding.executeUpdate();
		// statement should remain open
	}

	/**
	 * Attaches the location information to a prepared statement. The <em>i</em>
	 * argument determines the number of PreparedStatement parameters already
	 * used. Returns the next column number for prepared statements.
	 */
	private int attachLocation(Finding finding, PreparedStatement stmt, int i)
			throws SQLException {
		int numParams = 7;

		if (finding.getLocations().size() > 0) {
			// TODO (MP) support multi location findings
			ElementLocation locationbase = finding.getLocations().get(0);
			if (locationbase instanceof CodeLineLocation) {
				CodeLineLocation location = (CodeLineLocation) locationbase;
				stmt.setInt(i++, location.getFirstLine());

				// store file contents
				stmt.setString(i++, (String) finding.getValue(CONTENT));
				stmt.setString(i++, (String) finding.getValue(PRE_CONTEXT));
				stmt.setString(i++, (String) finding.getValue(POST_CONTEXT));
			} else {
				// MySQL doesn't allow to omit some rows
				stmt.setObject(i++, EMPTY);
				stmt.setObject(i++, EMPTY);
				stmt.setObject(i++, EMPTY);
			}

			if (locationbase instanceof CodeRegionLocation) {
				// Add some more values if the locations is a code region
				CodeRegionLocation location = (CodeRegionLocation) locationbase;
				stmt.setInt(i++, location.getLastLine());
				stmt.setInt(i++, location.getFirstPosition());
				stmt.setInt(i++, location.getLastPosition());
				stmt.setInt(i++, (Integer) finding
						.getValue(CONTENT_CHAR_POSITION));
			} else {
				// MySQL doesn't allow to omit some rows
				stmt.setObject(i++, EMPTY);
				stmt.setObject(i++, EMPTY);
				stmt.setObject(i++, EMPTY);
				stmt.setObject(i++, EMPTY);
			}
			return i;
		}

		// MySQL doesn't allow to omit some rows
		for (int j = i; j < i + numParams; j++) {
			stmt.setObject(j, null);
		}
		return i + numParams;
	}

	/**
	 * Extracts a finding report with the data of the connected database
	 */
	public FindingReport extractReport(boolean returnExistingFindings,
			boolean returnDeadFindings) throws SQLException {

		FindingReport report = new FindingReport(getLastModifiedTime());

		// Returns an empty report
		if (!returnExistingFindings && !returnDeadFindings) {
			return report;
		}

		StringBuilder query = new StringBuilder();
		query.append("SELECT * ");
		query.append("FROM " + FINDING_TABLE_NAME + " AS findingTable ");
		query.append(" JOIN " + FindingPathGateway.PATH_TABLE_NAME
				+ " AS pathTable ");
		query.append(" ON findingTable." + FindingPathGateway.PATH_ID
				+ "=pathTable." + FindingPathGateway.PATH_ID);
		query.append(" JOIN " + FindingTypeGateway.TYPE_TABLE_NAME
				+ " AS typeTable ");
		query.append(" ON findingTable." + FindingTypeGateway.TYPE_ID
				+ "=typeTable." + FindingTypeGateway.TYPE_ID);

		// both cases are catched above by returning an empty report
		if (!returnExistingFindings) {
			query.append(" WHERE " + DIED + " IS NOT NULL");
		} else if (!returnDeadFindings) {
			query.append(" WHERE " + DIED + " IS NULL");
		}

		Statement stmt = DatabaseUtils.executeQuery(connection, query
				.toString());

		ResultSet result = stmt.getResultSet();
		while (result.next()) {
			processExtractResult(report, result);
		}
		return report;
	}

	/** Returns last date a modification was written to the database. */
	private Date getLastModifiedTime() throws SQLException {
		String query = "SELECT MAX(" + LAST_SEEN + ") as DATE1, MAX(" + DIED
				+ ") as DATE2 FROM " + FINDING_TABLE_NAME;
		Statement stmt = DatabaseUtils.executeQuery(connection, query);
		ResultSet result = stmt.getResultSet();

		long date = 0;
		if (result.next()) {
			date = result.getLong("DATE1");
			if (result.getLong("DATE2") > date) {
				date = result.getLong("DATE2");
			}
		}

		stmt.close();

		return new Date(date);
	}

	/** Processes a result from the extraction query. */
	private void processExtractResult(FindingReport report, ResultSet result)
			throws SQLException {
		FindingCategory category = report.getOrCreateCategory(result
				.getString(FindingTypeGateway.CATEGORY_NAME));
		FindingGroup group = category.getOrCreateFindingGroup(result
				.getString(FindingTypeGateway.GROUP_NAME));
		Finding finding = group.createFinding(result
				.getString(FindingTypeGateway.ORIGIN_TOOL));
		finding.setValue(EFindingKeys.MESSAGE.toString(), result
				.getString(MESSAGE));
		finding.setValue(FINDING_ID, result.getLong(FINDING_ID));
		finding.setValue(FIRST_SEEN, result.getLong(FIRST_SEEN));
		finding.setValue(LAST_SEEN, result.getLong(LAST_SEEN));

		if (result.getObject(DIED) != null) {
			finding.setValue(DIED, result.getLong(DIED));
		}

		if (result.getObject(FindingPathGateway.PATH) != null) {
			String filepath = result.getString(FindingPathGateway.PATH);
			// FIXME (EJ) Also store uniform path?
			String uniformPath = filepath;

			ElementLocation location;
			if (notEmpty(result, LAST_LINE_NUMBER)) {
				// Create a new CodeRegionLocation
				if (notEmpty(result, FIRST_CHAR_POSITION)
						&& notEmpty(result, LAST_CHAR_POSITION)) {
					location = new CodeRegionLocation(filepath, uniformPath,
							result.getInt(FIRST_LINE_NUMBER), result
									.getInt(LAST_LINE_NUMBER), result
									.getInt(FIRST_CHAR_POSITION), result
									.getInt(LAST_CHAR_POSITION));
				} else {
					location = new CodeRegionLocation(filepath, uniformPath,
							result.getInt(FIRST_LINE_NUMBER), result
									.getInt(LAST_LINE_NUMBER));
				}
			} else if (notEmpty(result, FIRST_LINE_NUMBER)) {
				location = new CodeLineLocation(filepath, uniformPath, result
						.getInt(FIRST_LINE_NUMBER));
			} else {
				location = new ElementLocation(filepath, uniformPath);
			}

			finding.addLocation(location);

			// Attach content & context information
			if (result.getObject(CONTENT) != null) {
				finding.setValue(CONTENT, result.getString(CONTENT));
			}
			if (result.getObject(PRE_CONTEXT) != null) {
				finding.setValue(PRE_CONTEXT, result.getString(PRE_CONTEXT));
			}
			if (result.getObject(POST_CONTEXT) != null) {
				finding.setValue(POST_CONTEXT, result.getString(POST_CONTEXT));
			}

		}
	}

	/** Checks whether a field is set */
	private boolean notEmpty(ResultSet result, String columnName)
			throws SQLException {
		Object value = result.getObject(columnName);
		return value != null && !value.equals(new Integer(EMPTY));
	}

	/** {@inheritDoc} */
	@Override
	protected String getPrimaryRow() {
		return FINDING_ID;
	}

	/** {@inheritDoc} */
	@Override
	protected String getTableName() {
		return FINDING_TABLE_NAME;
	}

	/** {@inheritDoc} */
	@Override
	protected String initTableSQL() {
		StringBuilder query = new StringBuilder();
		query.append("CREATE TABLE " + FINDING_TABLE_NAME + " ");
		query.append("( ");
		query.append(FINDING_ID + " BIGINT PRIMARY KEY, ");
		query.append(FindingTypeGateway.TYPE_ID + " INTEGER, ");
		query.append(FindingPathGateway.PATH_ID + " INTEGER, ");
		query.append(FIRST_LINE_NUMBER + " INTEGER, ");
		query.append(LAST_LINE_NUMBER + " INTEGER, ");
		query.append(FIRST_CHAR_POSITION + " INTEGER, ");
		query.append(LAST_CHAR_POSITION + " INTEGER, ");
		query.append(CONTENT_CHAR_POSITION + " INTEGER, ");
		query.append(FIRST_SEEN + " BIGINT, ");
		query.append(LAST_SEEN + " BIGINT, ");
		query.append(DIED + " BIGINT, ");
		query.append(MESSAGE + " VARCHAR(8000), ");
		query.append(CONTENT + " VARCHAR(8000), ");
		query.append(PRE_CONTEXT + " VARCHAR(8000), ");
		query.append(POST_CONTEXT + " VARCHAR(8000) ");
		query.append(");");
		return query.toString();
	}

	/** returns the SQL code for a prepared update statement. */
	private String getPreparedInsertSQL() {
		StringBuilder insertSQL = new StringBuilder();
		insertSQL.append("INSERT INTO " + FINDING_TABLE_NAME + " (");
		insertSQL.append(FINDING_ID);
		insertSQL.append("," + FindingTypeGateway.TYPE_ID);
		insertSQL.append("," + FindingPathGateway.PATH_ID);
		insertSQL.append("," + MESSAGE);
		insertSQL.append("," + FIRST_SEEN);
		insertSQL.append("," + LAST_SEEN);
		insertSQL.append("," + FIRST_LINE_NUMBER);
		insertSQL.append("," + CONTENT);
		insertSQL.append("," + PRE_CONTEXT);
		insertSQL.append("," + POST_CONTEXT);
		insertSQL.append("," + LAST_LINE_NUMBER);
		insertSQL.append("," + FIRST_CHAR_POSITION);
		insertSQL.append("," + LAST_CHAR_POSITION);
		insertSQL.append("," + CONTENT_CHAR_POSITION);
		insertSQL
				.append(") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

		return insertSQL.toString();
	}

	/** returns the SQL code for a prepared insert statement. */
	private String getPreparedUpdateSQL() {
		StringBuilder updateSQL = new StringBuilder();
		updateSQL.append("UPDATE " + FINDING_TABLE_NAME);
		updateSQL.append(" SET " + LAST_SEEN + " = ?");
		updateSQL.append(", " + FIRST_LINE_NUMBER + " = ?");
		updateSQL.append(", " + CONTENT + " = ?");
		updateSQL.append(", " + PRE_CONTEXT + " = ?");
		updateSQL.append(", " + POST_CONTEXT + " = ?");
		updateSQL.append(", " + LAST_LINE_NUMBER + " = ?");
		updateSQL.append(", " + FIRST_CHAR_POSITION + " = ?");
		updateSQL.append(", " + LAST_CHAR_POSITION + " = ?");
		updateSQL.append(", " + CONTENT_CHAR_POSITION + " = ?");
		updateSQL.append(" WHERE " + FINDING_ID + " = ?");

		return updateSQL.toString();
	}
}

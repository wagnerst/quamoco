/*--------------------------------------------------------------------------+
$Id: TokenElementProvider.java 32159 2010-12-22 23:42:52Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.lazyscope;

import java.io.Serializable;
import java.util.List;


import org.conqat.engine.resource.regions.RegionMarkerStrategyBase;
import org.conqat.engine.sourcecode.resource.ITokenElement;
import org.conqat.engine.sourcecode.resource.ITokenResource;

/**
 * Provider for {@link ITokenElement}s.
 * <p>
 * Remark on implementation: this class only sets the generic parameter its base
 * class to {@link ITokenElement}. This way, the ConQAT load time type checking
 * mechanism does not have to deal with generic types (which it cannot).
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32159 $
 * @levd.rating GREEN Hash: 80BEAFE523C839FFFF342E352F3AE728
 */
public class TokenElementProvider extends
		ElementProviderBase<ITokenResource, ITokenElement> implements
		Serializable {

	/** Constructor. */
	public TokenElementProvider() {
		// nothing to do
	}

	/** Constructor. */
	public TokenElementProvider(
			List<RegionMarkerStrategyBase<ITokenElement>> strategies) {
		super(strategies);
	}

	/** {@inheritDoc} */
	@Override
	protected Class<ITokenElement> getElementClass() {
		return ITokenElement.class;
	}
}
/*--------------------------------------------------------------------------+
$Id: ProjectSourceExtractor.java 32162 2010-12-22 23:46:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 by the ConQAT Project                                |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.dotnet.resource;

import java.util.List;

import org.conqat.engine.resource.IContentAccessor;
import org.conqat.engine.resource.text.ITextElement;

import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.dotnet.resource.project.ProjectParser;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32162 $
 * @levd.rating GREEN Hash: E713B821BD005EA9618D1466254EBEEE
 */
@AConQATProcessor(description = "This processor provides content accessors for the project sources "
		+ "belonging to a set of Visual Studio project elements that are input as a text element tree.")
public class ProjectSourceExtractor extends ProjectContentExtractorBase {

	/** {@inheritDoc} */
	@Override
	protected List<IContentAccessor> extractElementsFromProject(
			ITextElement projectElement, ProjectParser projectParser)
			throws ConQATException {
		return projectParser.extractSourceElementAccessors(projectElement);
	}
}

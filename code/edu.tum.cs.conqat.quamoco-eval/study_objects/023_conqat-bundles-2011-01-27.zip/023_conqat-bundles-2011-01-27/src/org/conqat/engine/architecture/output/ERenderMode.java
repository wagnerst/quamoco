/*--------------------------------------------------------------------------+
$Id: ERenderMode.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.architecture.output;

import org.conqat.lib.commons.assessment.ETrafficLightColor;
import org.conqat.engine.architecture.format.EAssessmentType;
import org.conqat.engine.architecture.format.EPolicyType;
import org.conqat.engine.architecture.scope.DependencyPolicy;

/**
 * The mode used for rendering.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 700599A03C4EADD7AD47ABBF179DA8CA
 */
public enum ERenderMode {

	/** Renders plain policies. */
	POLICIES,

	/** Renders assessments (red, yellow, green). */
	ASSESSMENT,

	/** Renders violations only (red). */
	VIOLATIONS,

	/** Renders violations and tolerations (red, yellow). */
	VIOLATIONS_AND_TOLERATIONS;

	/**
	 * Returns whether a policy should be included when using this render mode.
	 */
	public boolean includePolicy(DependencyPolicy edge) {
		switch (this) {
		case POLICIES:
			return edge.getPolicyType() != EPolicyType.ALLOW_IMPLICIT
					&& edge.getPolicyType() != EPolicyType.DENY_IMPLICIT;
		case VIOLATIONS:
			return edge.getAssessment() == EAssessmentType.INVALID;
		case VIOLATIONS_AND_TOLERATIONS:
			return edge.getAssessment() == EAssessmentType.INVALID
					|| edge.getPolicyType() == EPolicyType.TOLERATE_EXPLICIT;
		default:
			return true;
		}
	}

	/** Returns the traffic light color used for a policy. */
	public ETrafficLightColor determineColor(DependencyPolicy edge) {
		if (this == POLICIES) {
			return edge.getPolicyType().toTrafficLightColor();
		}

		if (edge.getAssessment() == null) {
			return ETrafficLightColor.UNKNOWN;
		}
		if (edge.getAssessment() == EAssessmentType.INVALID) {
			return ETrafficLightColor.RED;
		}
		if (edge.getPolicyType() == EPolicyType.TOLERATE_EXPLICIT) {
			return ETrafficLightColor.YELLOW;
		}

		return ETrafficLightColor.GREEN;
	}
}
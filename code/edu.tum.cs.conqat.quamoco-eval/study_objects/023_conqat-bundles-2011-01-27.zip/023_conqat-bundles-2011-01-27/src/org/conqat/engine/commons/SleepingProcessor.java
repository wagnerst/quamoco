/*--------------------------------------------------------------------------+
$Id: SleepingProcessor.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons;

import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATFieldParameter;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: AB7918CD56A5DB201E03823DD0BE9253
 */
@AConQATProcessor(description = "A processor acting as a delay element. Useful for testing (sometimes).")
public class SleepingProcessor extends ConQATProcessorBase {

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "delay", attribute = "seconds", description = "The delay in seconds.")
	public int delaySeconds;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "predecessor", description = "Any predecessors.")
	public void predecessor(
			@SuppressWarnings("unused") @AConQATAttribute(name = "ref", description = "Any predecessor") Object o) {
		// does nothing
	}

	/** {@inheritDoc} */
	@Override
	public Object process() {
		try {
			Thread.sleep(1000 * delaySeconds);
		} catch (InterruptedException e) {
			// ignore
		}
		return null;
	}
}

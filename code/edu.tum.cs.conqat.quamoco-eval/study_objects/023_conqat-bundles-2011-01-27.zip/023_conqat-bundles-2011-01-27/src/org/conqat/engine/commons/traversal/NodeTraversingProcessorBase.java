/*--------------------------------------------------------------------------+
$Id: NodeTraversingProcessorBase.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.traversal;

import java.util.List;

import org.conqat.engine.commons.ConQATPipelineProcessorBase;
import org.conqat.engine.commons.node.IConQATNode;
import org.conqat.engine.core.core.ConQATException;

/**
 * Base class for processors which work by traversing the tree of ConQATNodes
 * provided (using DFS) and possibly changing the values attached to these
 * nodes. This processor also deals with progress.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 7DD2A0766217F0E53B1790EDF1A0F204
 */
public abstract class NodeTraversingProcessorBase<E extends IConQATNode>
		extends ConQATPipelineProcessorBase<E> implements
		INodeVisitor<E, ConQATException> {

	/** Returns the targets for the visitor (template method). */
	protected abstract ETargetNodes getTargetNodes();

	/** {@inheritDoc} */
	@Override
	protected void processInput(E root) throws ConQATException {
		setUp(root);
		List<E> nodes = TraversalUtils.listDepthFirst(root, getTargetNodes());
		setOverallWork(Math.max(1, nodes.size()));
		for (E node : nodes) {
			visit(node);
			workDone(1);
		}
		finish(root);
	}

	/**
	 * This method is called before any visiting method is called, so subclasses
	 * can check values, setup data structures or perform manipulations on the
	 * root. This is an empty implementation, so subclasses do not have to
	 * implement it themselves.
	 */
	@SuppressWarnings("unused")
	protected void setUp(E root) throws ConQATException {
		// nothing to do here
	}

	/**
	 * This method is called after visiting has been completed, so subclasses
	 * can perform final manipulations on the root. This is an empty
	 * implementation, so subclasses do not have to implement it themselves.
	 */
	@SuppressWarnings("unused")
	protected void finish(E root) throws ConQATException {
		// nothing to do here
	}
}
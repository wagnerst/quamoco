package org.conqat.engine.code_clones.core.constraint;

import java.util.HashSet;
import java.util.Set;

import org.conqat.lib.commons.string.StringUtils;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.corelocal.CloneUtils;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author ladmin
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: 226416B795DF336D43999787DA205184
 */
@AConQATProcessor(description = "Constraint that is satisfied, if at least two clones in a clone class have different content, modulo whitespace")
public class DifferentContentConstraint extends ConstraintBase {

	/** {@inheritDoc} */
	@Override
	public boolean satisfied(CloneClass cloneClass) throws ConQATException {
		Set<String> contents = new HashSet<String>();

		for (Clone clone : cloneClass.getClones()) {
			String content = StringUtils.removeWhitespace(CloneUtils
					.getCloneContentFromLocalFileSystem(clone));
			contents.add(content);
		}

		return contents.size() > 1;
	}

}

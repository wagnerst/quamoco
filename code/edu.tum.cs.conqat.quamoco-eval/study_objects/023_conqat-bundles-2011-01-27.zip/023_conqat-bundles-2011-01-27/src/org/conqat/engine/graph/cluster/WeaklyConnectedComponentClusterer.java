/*--------------------------------------------------------------------------+
$Id: WeaklyConnectedComponentClusterer.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.graph.cluster;

import org.conqat.engine.core.core.AConQATProcessor;
import edu.uci.ics.jung.algorithms.cluster.GraphClusterer;
import edu.uci.ics.jung.algorithms.cluster.WeakComponentClusterer;

/**
 * Divide the graph into its weakly connected components.
 * 
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 9615E0D6647212F1A2F595F3949C1B94
 */
@AConQATProcessor(description = "Clusters the graph into its weakly connected components. "
		+ "The weakly connected components of a directed graph are the maximal connected "
		+ "components of the induced undirected graph (i.e. when interpreting each edge "
		+ "as undirected).")
public class WeaklyConnectedComponentClusterer extends ClustererBase {

	/** {@inheritDoc} */
	@Override
	protected GraphClusterer obtainGraphClusterer() {
		return new WeakComponentClusterer();
	}
}
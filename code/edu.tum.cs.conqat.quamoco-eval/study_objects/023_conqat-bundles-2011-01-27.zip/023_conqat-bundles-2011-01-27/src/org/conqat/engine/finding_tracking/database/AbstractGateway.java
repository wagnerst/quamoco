/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: AbstractGateway.java 32448 2011-01-10 10:17:01Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking.database;

import java.sql.Connection;
import java.sql.SQLException;

import org.conqat.engine.persistence.DatabaseUtils;

/**
 * Abstract base class for table gateways.
 * 
 * @author Martin P�hlmann
 * @author $Author: juergens $
 * @version $Rev: 32448 $
 * @levd.rating YELLOW Hash: 5FA3CE0E65C1EF1CE8A203F51AD9F4E8
 */
public abstract class AbstractGateway {

	/** The database we work on. */
	protected final Connection connection;

	/** Unique key provider for the table. */
	protected final DatabaseKeyProvider keyProvider;

	/** Constructor. */
	/* package */AbstractGateway(Connection connection) throws SQLException {
		this.connection = connection;

		try {
			DatabaseUtils.executeUpdate(connection, initTableSQL());
		} catch (SQLException e) {
			// Caught, since we just want to perform the above statement if the
			// table does not exist.
		}

		keyProvider = new DatabaseKeyProvider(connection, getTableName(),
				getPrimaryRow());
	}

	/** SQL for initializing an empty table. */
	protected abstract String initTableSQL();

	/** Returns the name of the managed table. */
	protected abstract String getTableName();

	/** Returns the name of the primary table row. */
	protected abstract String getPrimaryRow();

}
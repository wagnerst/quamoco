/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.findingsdev
 |                                                                       |
   $Id: FindingsTracker.java 32548 2011-01-14 08:16:11Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.conqat.engine.commons.ConQATParamDoc;
import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.FindingCategory;
import org.conqat.engine.commons.findings.FindingGroup;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.commons.findings.location.ElementLocation;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.APipelineSource;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.finding_tracking.database.FindingGateway;
import org.conqat.engine.persistence.DatabaseProcessorBase;
import org.conqat.engine.resource.text.ITextElement;
import org.conqat.engine.resource.text.ITextResource;
import org.conqat.engine.resource.util.ResourceTraversalUtils;
import org.conqat.lib.commons.algo.MaxWeightMatching;
import org.conqat.lib.commons.collections.HashedListMap;
import org.conqat.lib.commons.collections.PairList;

/**
 * {@ConQAT.Doc}
 * 
 * @author Martin P�hlmann
 * @author $Author: juergens $
 * @version $Rev: 32548 $
 * @levd.rating RED Hash: FAEA0FE9CEBB40160B5C21AA1CD8A337
 */

@AConQATProcessor(description = "This processor stores findings "
		+ "in a database file for tracking. It also matches the new findings "
		+ "with existing findings in the database.")
public class FindingsTracker extends DatabaseProcessorBase {

	// TODO (EJ) rename to originalReport and loadedReport?
	// (MP) changed to newReport and knownReport, since this is used in more
	// places of the tracker
	/** The new report being matched and saved to a database. */
	private FindingReport newReport;

	/** The extracted report from the database */
	private FindingReport knownReport;

	/** The gateway for database management */
	private FindingGateway gateway;

	// TODO (EJ) Does it make sense to make this parameterizable, or do you
	// expect this not to change? Then simply delete this comment.
	// (MP) This is a value based on Baker's research. I don't think it makes
	// sense to make it parameterizable, since usually you won't change this
	// anyways.
	/** The minimum weight between two findings so that they are matched. */
	private final double MINIMUM_MATCH_WEIGHT = 0.65;

	/** List of a all unmatched known findings. */
	private List<Finding> unmatchedKnownFindings;

	/**
	 * Flag for debugging purposes. If true the matching weigths are attached to
	 * each tracked Finding.
	 */
	private boolean debugWeight;

	/** Value name used for storing weighting debug information. */
	private static final String DEBUG_MATCHING_WEIGHT = "DEBUG_MATCHING_WEIGHT";

	/** Scope in which findings were detected */
	private ITextResource input;

	/** Files that can be invalidated. */
	private Set<String> elementUniformPaths;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "report", minOccurrences = 1, maxOccurrences = 1, description = "The report being tracked.")
	public void setReport(
			@APipelineSource @AConQATAttribute(name = "ref", description = "The report being tracked.") FindingReport report) {
		this.newReport = report;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "debug", minOccurrences = 0, maxOccurrences = 1, description = "Attaches some debug information to the tracked findings.")
	public void setDebug(
			@AConQATAttribute(name = "weigth", defaultValue = "false", description = "The report being tracked.") boolean weight) {
		debugWeight = weight;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 0, maxOccurrences = 1)
	public void setInput(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) ITextResource input) {
		this.input = input;
	}

	// TODO (EJ) Processing of unmatched findings is interleaved with other
	// stuff in this method. Move it all together to end of method? Maybe
	// extract different concerns into different methods
	// (MP) we cannot achieve this w/o interleaving. During the matching process
	// the matched findings are removed from the (see updateFinding()) list.
	/** {@inheritDoc} */
	public FindingReport process() throws ConQATException {
		initMatchingData();

		processFindingGroups();

		invalidateUnmatchedFindings();

		return newReport;
	}

	/** Initializes all fields need by the matching algorithm. */
	private void initMatchingData() throws ConQATException {
		if (invalidateUnknownLocations()) {
			elementUniformPaths = new HashSet<String>();
			for (ITextElement element : ResourceTraversalUtils
					.listTextElements(input)) {
				elementUniformPaths.add(element.getUniformPath());
			}
		}

		try {
			gateway = new FindingGateway(dbConnection);
			knownReport = gateway.extractReport(true, false);
		} catch (SQLException e) {
			throw wrap(e);
		}

		// store the known findings from the database in a list, so we can
		// invalidate unmatched ones later
		unmatchedKnownFindings = LocationTrackingUtils.getFindings(knownReport);
	}

	/**
	 * Invalidates all unmatched findings, this means they will be marked as
	 * dead/resolved in the database.
	 */
	private void invalidateUnmatchedFindings() throws ConQATException {
		for (Finding finding : unmatchedKnownFindings) {
			if (!invalidateUnknownLocations() || locationContained(finding)) {
				try {
					gateway.invalidateFinding(finding, newReport.getTime());
				} catch (SQLException e) {
					throw wrap(e);
				}
			}
		}

	}

	/**
	 * Returns true, if at least one of the file locations of the finding is
	 * contained in the file set
	 */
	private boolean locationContained(Finding finding) {

		for (ElementLocation location : finding.getLocations()) {
			if (location instanceof ElementLocation) {
				if (elementUniformPaths.contains(((ElementLocation) location)
						.getUniformPath())) {
					return true;
				}
			}
		}

		return false;
	}

	/** Returns whether invalid locations should be invalidated or not. */
	private boolean invalidateUnknownLocations() {
		return input != null;
	}

	/**
	 * Processes a finding group and matches new findings (stores them in the
	 * database)
	 */
	private void processFindingGroups() throws ConQATException {
		for (FindingGroup group : LocationTrackingUtils
				.getFindingGroups(newReport)) {
			HashedListMap<FindingMatchClassifier, Finding> newFindings = initFindingMatchMap(group);

			FindingCategory extrCategory = knownReport.getCategory(group
					.getParent().getName());
			if (extrCategory != null) {
				FindingGroup extrGroup = extrCategory.getGroupByName(group
						.getName());
				if (extrGroup != null && extrGroup.hasChildren()) {
					HashedListMap<FindingMatchClassifier, Finding> knownFindings = initFindingMatchMap(extrGroup);

					matchFindings(newFindings, knownFindings);
				}
			}

			// store new and matched findings
			storeFindings(newFindings.getValues());
		}
	}

	/**
	 * Matches all new findings of a finding class with the known findings in
	 * the database.
	 */
	private void matchFindings(
			HashedListMap<FindingMatchClassifier, Finding> newFindingClasses,
			HashedListMap<FindingMatchClassifier, Finding> knownFindingClasses) {

		for (FindingMatchClassifier newFmc : newFindingClasses.getKeys()) {
			List<Finding> newFindings = newFindingClasses.getList(newFmc);
			List<Finding> knownFindings = knownFindingClasses.getList(newFmc);

			// we need to check if there are findings for this class in the
			// database at all
			if (knownFindings == null) {
				continue;
			}

			PairList<Finding, Finding> matching = new PairList<Finding, Finding>();

			FindingsWeightProvider weights = new FindingsWeightProvider();
			MaxWeightMatching<Finding, Finding> matcher = new MaxWeightMatching<Finding, Finding>();
			matcher.calculateMatching(newFindings, knownFindings, weights,
					matching);

			for (int i = 0; i < matching.size(); i++) {
				double weight = weights.getConnectionWeight(matching
						.getFirst(i), matching.getSecond(i));
				if (debugWeight) {
					matching.getFirst(i)
							.setValue(DEBUG_MATCHING_WEIGHT, weight);
				}
				// TODO (EJ) ?
				// (MP) Meant as reminder to maybe alter the MaxWeightMatching
				// algorithm to accept a threshold value. So weightings below
				// this threshold will not make it into the match set. But after
				// re-thinking I think it might be good as it is now.
				// TODO modify matching algorithm (ccsm-commons) to accept a
				// threshold
				if (weight < MINIMUM_MATCH_WEIGHT) {
					continue; // Do not update values and discard this matching
				}
				updateFinding(matching.getFirst(i), matching.getSecond(i));
			}
		}
	}

	// TODO (EJ) The relationship between the "finding" and the
	// "existing finding" is important for tracking. I think that we should
	// reflect it in the terminology. The "existing finding" could be the
	// "ancestor", or "predecessor". What do you think?
	// (MP) As I've introduced the new/known finding terminology already in
	// other places (db) I've adopted this here as well.
	/** updates a new finding wrt to an known finding from the database. */
	private void updateFinding(Finding newFinding, Finding knownFinding) {
		newFinding.setValue(FindingGateway.FINDING_ID, knownFinding
				.getValue(FindingGateway.FINDING_ID));
		newFinding.setValue(FindingGateway.FIRST_SEEN, knownFinding
				.getValue(FindingGateway.FIRST_SEEN));
		newFinding.setValue(FindingGateway.LAST_SEEN, newFinding.getParent()
				.getParent().getParent().getTime().getTime());

		// remove the known finding from the list of unmatched findings
		unmatchedKnownFindings.remove(knownFinding);
	}

	/** Stores new findings in the database */
	private void storeFindings(List<Finding> findings) {
		for (Finding finding : findings) {
			try {
				// TODO (EJ) Use batch commands here? This should speed up
				// processing, as it reduces the number of process context
				// switches in the OS.
				// (MP) True, will be done as soon you've reviewed the db stuff
				gateway.storeFinding(finding);
			} catch (SQLException e) {
				// TODO (EJ) Why swallow this? Why not throw an error and fail?
				// Is there a reason why we want to tolerate this?
				// (MP) will be fixed when we change to batch
				getLogger().error(
						"Storing finding failed: " + finding.getName() + ": "
								+ e.getMessage());
			}
		}
	}

	/**
	 * Creates a HashedListMap that manages findings with the same
	 * FindingMatchClass.
	 */
	private HashedListMap<FindingMatchClassifier, Finding> initFindingMatchMap(
			FindingGroup group) throws ConQATException {
		HashedListMap<FindingMatchClassifier, Finding> matchMap = new HashedListMap<FindingMatchClassifier, Finding>();
		for (Finding finding : group.getChildren()) {
			if (finding.getValue(FindingGateway.FINDING_ID) == null) {
				// The location information should only be attached if the
				// finding does not come from the database (has no tracking id)
				LocationTrackingUtils.attachLocationInformation(finding,
						FindingGateway.CONTEXT_LENGTH);
			}
			matchMap.add(new FindingMatchClassifier(finding), finding);
		}
		return matchMap;
	}
}

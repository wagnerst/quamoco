/*--------------------------------------------------------------------------+
$Id: CppDepAnnotator.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.graph;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import org.conqat.lib.commons.assessment.Assessment;
import org.conqat.lib.commons.assessment.ETrafficLightColor;
import org.conqat.lib.commons.collections.Pair;
import org.conqat.lib.commons.filesystem.FileSystemUtils;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.lib.commons.xml.XMLUtils;
import org.conqat.engine.commons.ConQATPipelineProcessorBase;
import org.conqat.engine.core.core.AConQATFieldParameter;
import org.conqat.engine.core.core.AConQATKey;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.graph.nodes.ConQATGraph;
import org.conqat.engine.graph.nodes.ConQATVertex;
import org.conqat.engine.graph.nodes.DeepCloneCopyAction;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * TODO (BH): This is a hack performed for EADS analysis.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: 79C68D3B2F9A209CFB414BFCF27779B5
 */
@AConQATProcessor(description = "Extract C++ dependencies")
public class CppDepAnnotator extends ConQATPipelineProcessorBase<ConQATGraph> {

	@AConQATKey(description = "", type = "")
	public static final String KEY = "assessment";

	@AConQATFieldParameter(parameter = "dep", attribute = "file", description = "TODO")
	public String depFile;

	private final Map<Pair<String, String>, String> deps = new HashMap<Pair<String, String>, String>();

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph input) throws ConQATException {

		getLogger().info("Graph has " + input.getEdges().size() + " edges");

		Document doc;
		try {
			doc = XMLUtils.parse(new File(depFile));
		} catch (Exception e) {
			throw new ConQATException(e);
		}

		processElement(doc.getDocumentElement());
		getLogger().info("Extracted " + deps.size() + " dependencies");

		Map<String, DirectedSparseEdge> edgeLookup = new HashMap<String, DirectedSparseEdge>();
		for (DirectedSparseEdge edge : input.getEdges()) {
			edgeLookup.put(edge.getSource() + "->" + edge.getDest(), edge);

			edge.setUserDatum(KEY, new Assessment(ETrafficLightColor.YELLOW),
					DeepCloneCopyAction.getInstance());
		}

		Map<String, ConQATVertex> componentMap = new HashMap<String, ConQATVertex>();
		for (ConQATVertex v : input.getVertices()) {
			String name = v.getName();
			name = StringUtils.stripPrefix("OSS_", name);
			name = name.replaceFirst("_", "/");
			name = name.toLowerCase();

			componentMap.put(name, v);
		}

		Set<String> missing = new HashSet<String>();
		int numViolations = 0;

		for (Pair<String, String> dep : deps.keySet()) {
			ConQATVertex from = componentMap.get(dep.getFirst());
			ConQATVertex to = componentMap.get(dep.getSecond());
			if (from == null) {
				missing.add(dep.getFirst());
			} else if (to == null) {
				missing.add(dep.getSecond());
			} else {
				String edgeLabel = from + "->" + to;
				DirectedSparseEdge edge = edgeLookup.get(edgeLabel);
				if (edge == null) {
					++numViolations;
					edge = input.addEdge(from, to);
					edge.setUserDatum(KEY, new Assessment(
							ETrafficLightColor.RED), DeepCloneCopyAction
							.getInstance());

					getLogger().info("Example violation: " + deps.get(dep));
				} else {
					edge.setUserDatum(KEY, new Assessment(
							ETrafficLightColor.GREEN), DeepCloneCopyAction
							.getInstance());
				}
			}
		}

		for (String m : missing) {
			getLogger().warn("Missing component for " + m);
		}
		getLogger().info("Had to create " + numViolations + " new edges!");
	}

	private void processElement(Element element) {

		List<Element> childNodes = XMLUtils.getNamedChildren(element, "node");

		if (childNodes.isEmpty() && element.getNodeName().equals("node")) {
			String id = element.getAttribute("id");
			id = StringUtils.stripPrefix("D:\\SBX\\OSS-Release\\Impl\\", id);

			if (!id.startsWith("CGM")) {
				extractDeps(id, element);
			}

		} else {
			for (Element child : childNodes) {
				processElement(child);
			}
		}
	}

	private void extractDeps(String id, Element element) {
		List<Element> values = XMLUtils.getNamedChildren(element, "value");
		for (Element value : values) {
			if (!"Include targets".equals(value.getAttribute("key"))) {
				continue;
			}

			Element coll = XMLUtils.getNamedChild(value, "collection");
			if (coll == null) {
				continue;
			}

			for (Element item : XMLUtils.getNamedChildren(coll, "item")) {
				String include = item.getTextContent();
				include = include.substring(1, include.length() - 1);
				include = FileSystemUtils.normalizeSeparators(include);
				include = StringUtils.stripPrefix("./", include);

				// ignore includes within component
				if (!include.contains("/")
						|| StringUtils.startsWithOneOf(include, "gen/",
								"entitys/", "classes/", "meta/", "types/",
								"hmlib/", "../", "converter/", "medusa/")) {
					continue;
				}

				insertDependency(FileSystemUtils.normalizeSeparators(id
						.toLowerCase()), include.toLowerCase());
			}
		}
	}

	private void insertDependency(String from, String to) {
		String example = from + " -> " + to;

		String[] parts = from.split("/");
		from = parts[0] + "/" + parts[1];

		if (to.startsWith(from) || to.split("/").length <= 3
				|| to.startsWith("cgm")) {
			return;
		}

		int index = to.indexOf("/export/");
		if (index >= 0) {
			to = to.substring(0, index);
		} else {
			getLogger().warn("Include target without export: " + example);
			return;
		}

		deps.put(new Pair<String, String>(from, to), example);
	}
}

/*--------------------------------------------------------------------------+
   $Id: IndexBuilder.java 32373 2010-12-30 23:14:23Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.store.SimpleFSDirectory;
import org.conqat.engine.commons.node.IConQATNode;
import org.conqat.engine.commons.node.NodeUtils;
import org.conqat.engine.commons.traversal.ETargetNodes;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.sourcecode.resource.ITokenElement;
import org.conqat.engine.sourcecode.resource.ITokenResource;
import org.conqat.engine.sourcecode.resource.TokenElementProcessorBase;
import org.conqat.engine.sourcecode.resource.TokenElementUtils;
import org.conqat.lib.commons.filesystem.FileSystemUtils;
import org.conqat.lib.scanner.ELanguage;

@AConQATProcessor(description = "Lucene Index Builder")
public class IndexBuilder extends TokenElementProcessorBase {

	private static final String FIELD_DESCRIPTOR = "field_descriptor";

	private final int PERCENTAGE = 1000;

	private IndexWriter indexWriter;

	private File indexDirectory;

	private List<String> displayList;

	private int documentCount;

	private int currentDocument;

	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	@AConQATParameter(name = "index", minOccurrences = 1, maxOccurrences = 1, description = "Index directory")
	public void setIndexDirectory(
			@AConQATAttribute(name = "directory", description = "directory") String directory) {
		indexDirectory = new File(directory);
	}

	@Override
	protected void setUp(ITokenResource root) throws ConQATException {

		documentCount = countLeaves(root);

		getLogger().info("Indexing " + documentCount + " documents");

		displayList = NodeUtils.getDisplayList(root);

		try {
			FileSystemUtils.ensureDirectoryExists(indexDirectory);

			ELanguage language = TokenElementUtils.getUniqueLanguage(root);

			indexWriter = new IndexWriter(
					new SimpleFSDirectory(indexDirectory),
					new SourceCodeAnalyzer(language), true,
					MaxFieldLength.UNLIMITED);
			indexWriter.setRAMBufferSizeMB(500);
			addFieldDescriptor(language);
		} catch (IOException e) {
			throw new ConQATException(e);
		}
	}

	private void addFieldDescriptor(ELanguage language)
			throws CorruptIndexException, IOException {

		Document doc = new Document();
		doc.add(new Field("path", FIELD_DESCRIPTOR, Field.Store.YES,
				Field.Index.NOT_ANALYZED));
		doc.add(new Field("language", language.name(), Field.Store.YES,
				Field.Index.NOT_ANALYZED));

		for (String key : displayList) {
			doc.add(new Field(key, "0", Field.Store.YES,
					Field.Index.NOT_ANALYZED));
		}
		indexWriter.addDocument(doc);
	}

	private int countLeaves(IConQATNode node) {
		int sum = 1;
		if (node.hasChildren()) {
			sum = 0;
			for (IConQATNode child : node.getChildren()) {
				sum += countLeaves(child);
			}
		}
		return sum;
	}

	@Override
	protected void finish(ITokenResource root) throws ConQATException {
		try {
			getLogger().info("Optimizing index...");
			indexWriter.optimize();
			getLogger().info("Closing index");
			indexWriter.close();
		} catch (IOException e) {
			throw new ConQATException(e);
		}

	}

	/** {@inheritDoc} */
	@Override
	protected void processElement(ITokenElement node) throws ConQATException {
		currentDocument++;

		if ((currentDocument % PERCENTAGE) == 0) {
			getLogger().info("Indexing document #" + currentDocument);
		}

		Document document;
		try {
			document = createDocument(node);
		} catch (ConQATException e) {
			getLogger()
					.warn(
							"Could not create document for file: "
									+ node.getLocation());
			return;
		}

		try {
			document = createDocument(node);
			indexWriter.addDocument(document);
		} catch (CorruptIndexException e) {
			throw new ConQATException(e);
		} catch (IOException e) {
			throw new ConQATException(e);
		}

	}

	private Document createDocument(ITokenElement element)
			throws ConQATException {

		Document doc = new Document();

		for (String key : displayList) {
			Object valueObject = element.getValue(key);
			if (valueObject == null) {
				continue;
			}
			Field field = new Field(key, valueObject.toString(),
					Field.Store.YES, Field.Index.NOT_ANALYZED);
			doc.add(field);
		}

		doc.add(new Field("path", element.getUniformPath(), Field.Store.YES,
				Field.Index.NOT_ANALYZED));

		doc.add(new Field("contents", element.getTextContent(),
				Field.Store.YES, Field.Index.ANALYZED));

		// return the document
		return doc;
	}
}

/*--------------------------------------------------------------------------+
$Id: ProjectParser.java 32162 2010-12-22 23:46:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.dotnet.resource.project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.conqat.engine.resource.IContentAccessor;
import org.conqat.engine.resource.text.ITextElement;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.xml.IXMLElementProcessor;
import org.conqat.lib.commons.xml.XMLReader;
import org.conqat.lib.commons.xml.XMLResolver;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.core.logging.IConQATLogger;
import org.conqat.engine.dotnet.resource.BuildConfiguration;
import org.conqat.engine.dotnet.resource.solution.SolutionParser.EFormatVersion;

/**
 * Base class for parsers of VS.NET project elements.
 * <p>
 * Since different versions of the Visual Studio generate different project
 * formats, different project parsers exist. This class serves as factory to
 * create a {@link ProjectParser} for a specific VS.NET version.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32162 $
 * @levd.rating GREEN Hash: AF0272C6E5290E87C0FC9BDDF6B7B484
 */
public abstract class ProjectParser {

	/** The build configuration that is used to build the project. */
	protected BuildConfiguration configuration = null;

	/** Logger used to issue log statements */
	protected final IConQATLogger logger;

	/** Constructor */
	public ProjectParser(IConQATLogger logger) {
		this.logger = logger;
	}

	/** Extracts accessors for the source elements that are part of the project. */
	public List<IContentAccessor> extractSourceElementAccessors(
			ITextElement projectElement) throws ConQATException {
		ProjectElementReaderBase reader = createReader(projectElement);
		List<IContentAccessor> accessors = new ArrayList<IContentAccessor>();

		for (String relativename : reader.readRelativeSourceNames()) {
			accessors.add(projectElement.createRelativeAccessor(relativename));
		}
		return accessors;
	}

	/**
	 * Extracts the accessors to the assemblies that are generated when
	 * compiling this project.
	 */
	public List<IContentAccessor> extractAssemblyAccessors(
			ITextElement projectElement, BuildConfiguration buildConfiguration)
			throws ConQATException {
		ProjectElementReaderBase reader = createReader(projectElement);
		List<IContentAccessor> accessors = new ArrayList<IContentAccessor>();
		this.configuration = buildConfiguration;
		String relativename = reader.readRelativeAssemblyName();

		// the relative name is null if the relative output path could not be
		// retrieved. The warning is already set by readRelativeAssemblyName()
		if (relativename != null) {
			accessors.add(projectElement.createRelativeAccessor(relativename));
		}
		return accessors;
	}

	/**
	 * Template factory name that returns the project version specific XMLReader
	 */
	protected abstract ProjectElementReaderBase createReader(
			ITextElement projectElement) throws ConQATException;

	/**
	 * Factory method that creates a {@link ProjectParser} according to the
	 * solution version
	 */
	public static ProjectParser create(EFormatVersion version,
			IConQATLogger logger) {
		switch (version) {
		case VERSION_9_10:
			return new ProjectParser9_10(logger);
		case VERSION_8:
			return new ProjectParser8(logger);
		default:
			throw new RuntimeException(
					"No reader for this project format implemented!");
		}
	}

	/** Xml reader that performs actual XML processing. */
	protected abstract class ProjectElementReaderBase
			extends
			XMLReader<EProjectXmlElement, EProjectXmlAttribute, ConQATException> {

		/** The list of relative source names. */
		protected final List<String> relativeSourceElementNames = new ArrayList<String>();

		/** The name of the assembly */
		protected String assemblyName = null;

		/** The relative path to the assembly */
		protected String outputPath = null;

		/** The output type (can be either Library or Exe) */
		protected String outputType = null;

		/** Location of the project element */
		protected final String projectLocation;

		/** Constructor */
		public ProjectElementReaderBase(String projectContent,
				String projectLocation) {
			super(projectContent, null,
					new XMLResolver<EProjectXmlElement, EProjectXmlAttribute>(
							EProjectXmlAttribute.class));
			this.projectLocation = projectLocation;
		}

		/**
		 * Reads the relative names of the included source elements from the
		 * project.
		 */
		public List<String> readRelativeSourceNames() throws ConQATException {
			parseProject();
			processDecendantElements(createProcessor());
			return relativeSourceElementNames;
		}

		/** Reads the relative names of the executables created by this project. */
		public String readRelativeAssemblyName() throws ConQATException {
			String extension = "";
			parseProject();

			// get the name of the assembly
			processDecendantElements(createAssemblyNameProcessor());

			// get the output type (it can only be "Library" or "Exe")
			IXMLElementProcessor<EProjectXmlElement, ConQATException> processor = createOutputTypeProcessor();

			// The createOutputTypeProcessor method in VS2003 projects returns
			// null because the AssemblyNameProcessor already sets the output
			// type for VS2003 projects
			if (processor != null) {
				processDecendantElements(processor);
			}

			if (outputType == null || assemblyName == null) {
				// This happens if .vcproj-files are parsed (CR#2556 requests
				// parsing of .vcproj files).
				logger
						.warn("No valid assembly name was identified in the project "
								+ projectLocation + ".");
				return null;
			}

			if (outputType.equals("Library")) {
				extension = ".dll";
			} else {
				if (!outputType.equals("Exe") && !outputType.equals("WinExe")) {
					logger.warn("The assembly " + assemblyName
							+ " that was found in project " + projectLocation
							+ " is neither a .dll nor a .exe");
					return null;
				}
				extension = ".exe";
			}

			// get the relative path to the assembly
			processDecendantElements(createRelativeAssemblyPathProcessor());

			CCSMAssert.isNotNull(assemblyName, "No assemblyName in project "
					+ projectLocation + " identified");
			if (outputPath == null) {
				logger.warn("No relative output path found for project "
						+ projectLocation
						+ ". Perhaps the build configuration ("
						+ configuration.getName() + "|"
						+ configuration.getPlatform()
						+ ") is not valid for the project.");
				return null;
			}

			return outputPath + assemblyName + extension;
		}

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectXmlElement, ConQATException> createProcessor();

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectXmlElement, ConQATException> createAssemblyNameProcessor();

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectXmlElement, ConQATException> createOutputTypeProcessor();

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectXmlElement, ConQATException> createRelativeAssemblyPathProcessor();

		/** Parse XML */
		private void parseProject() throws ConQATException {
			try {
				parseFile();
			} catch (SAXParseException e) {
				throw new ConQATException("XML parsing exception at line "
						+ e.getLineNumber() + ", colum " + e.getColumnNumber()
						+ " (" + e.getMessage() + ")");
			} catch (SAXException e) {
				throw new ConQATException("XML parsing exception)");
			} catch (IOException e) {
				throw new ConQATException("XML " + projectLocation
						+ " could not be read");
			}
		}
	}
}
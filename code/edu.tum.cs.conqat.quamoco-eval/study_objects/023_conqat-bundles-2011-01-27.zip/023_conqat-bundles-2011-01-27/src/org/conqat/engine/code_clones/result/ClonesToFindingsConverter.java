/*--------------------------------------------------------------------------+
$Id: ClonesToFindingsConverter.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.result;

import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.detection.CloneDetectionResultElement;
import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.FindingCategory;
import org.conqat.engine.commons.findings.FindingGroup;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.commons.findings.location.CodeRegionLocation;
import org.conqat.engine.commons.node.NodeUtils;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 497903F2EF81F40FA84A63A6756E7132
 */
@AConQATProcessor(description = "Creates findings for the contained clones and "
		+ "adds them to the findings report at the root node. "
		+ "Does not modify or remove the clones.")
public class ClonesToFindingsConverter extends DetectionResultProcessorBase {

	/** Tool name */
	private static final String TOOL_NAME = "ConQAT Clone Detection";

	/** {@inheritDoc} */
	@Override
	public CloneDetectionResultElement process() {
		FindingReport findingReport = NodeUtils
				.getFindingReport(detectionResult.getRoot());
		FindingCategory category = findingReport.getOrCreateCategory("Clones");

		convertClonesToFindings(category);

		return detectionResult;
	}

	/** Creates findings for the detected clones */
	private void convertClonesToFindings(FindingCategory targetCategory) {
		for (CloneClass cloneClass : detectionResult.getList()) {
			FindingGroup group = targetCategory
					.createFindingGroup("Clone class " + cloneClass.getId());
			for (Clone clone : cloneClass.getClones()) {
				Finding finding = group.createFinding(TOOL_NAME);
				CodeRegionLocation location = new CodeRegionLocation(clone
						.getLocation(), clone.getUniformPath(), clone
						.getStartLineInElement(), clone.getLastLineInElement());
				finding.addLocation(location);
			}
		}
	}
}

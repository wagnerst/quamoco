/*--------------------------------------------------------------------------+
$Id: ReportUtils.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.core.report;

import java.util.ArrayList;
import java.util.List;

import org.conqat.lib.commons.string.StringUtils;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.EEditOperation;

/**
 * Utility functions for reading and writing clone reports.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: B699B71384A4C670FCCCCA6E5ED077D9
 */
public class ReportUtils {

	/**
	 * Creates a gap string for a gapped clone.
	 */
	public static String createGapOffsetString(Clone clone) {
		List<String> gapDigests = new ArrayList<String>();

		for (int lineOffset = 0; lineOffset < clone.getLengthInElement(); lineOffset++) {
			EEditOperation gapType = clone.getGapTypeAt(lineOffset);
			if (gapType != EEditOperation.NONE) {
				gapDigests.add(lineOffset + ":" + gapType);
			}
		}

		return StringUtils.concat(gapDigests, ",");
	}

	/**
	 * Reads gap information from a gap offset string and stores it in a
	 * {@link Clone}
	 */
	/* package */static void parseGapOffsetString(Clone clone,
			String gapOffsetsString) {
		if (StringUtils.isEmpty(gapOffsetsString)) {
			return;
		}

		for (String gapDigest : gapOffsetsString.split(",")) {
			String[] gapDigestParts = gapDigest.split(":");
			int gapOffset = Integer.parseInt(gapDigestParts[0]);
			EEditOperation gapType = EEditOperation.valueOf(gapDigestParts[1]);
			clone.addGap(gapOffset, gapType);
		}
	}

}
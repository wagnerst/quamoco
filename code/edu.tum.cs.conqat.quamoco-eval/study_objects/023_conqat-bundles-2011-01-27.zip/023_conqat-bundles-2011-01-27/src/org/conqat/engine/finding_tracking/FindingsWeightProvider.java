/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: FindingsWeightProvider.java 32461 2011-01-10 16:41:19Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.location.CodeLineLocation;
import org.conqat.engine.commons.findings.location.CodeRegionLocation;
import org.conqat.engine.commons.findings.location.ElementLocation;
import org.conqat.engine.commons.findings.location.QualifiedNameLocation;
import org.conqat.engine.finding_tracking.database.FindingGateway;
import org.conqat.lib.commons.algo.MaxWeightMatching.IWeightProvider;

/**
 * Describes a weighted relation between two findings. This relation is used to
 * match the findings greedily. Generally all kind of findings can be matched,
 * but it is wise to create some kind of matching classes (e.g. same file and
 * same message) before running the match algorithm. This weight provider will
 * check if the findings are in the same finding category and group, but it will
 * not compare messages or filenames. This must be done before the matching
 * starts with MatchingClasses. Findings with no location attached are not
 * matched at all.
 * 
 * @author Martin P�hlmann
 * @author $Author: juergens $
 * @version $Rev: 32461 $
 * @levd.rating RED Hash: AEBDA668D9C41B08270DD3CA2A706448
 */
public class FindingsWeightProvider implements
		IWeightProvider<Finding, Finding> {

	/** Weight between two findings considered as match. */
	private static final double MATCH = 1.0;

	/** Weight between two findings not considered as match. */
	private static final double NO_MATCH = 0.0;

	/** Returns the matching weight between two findings. */
	@Override
	public double getConnectionWeight(Finding finding1, Finding finding2) {
		if (!haveSameCategoryAndGroup(finding1, finding2)) {
			return NO_MATCH;
		}

		// if one (or both) finding has no location attached, do not match them
		if (!finding1.hasLocations() || !finding2.hasLocations()) {
			return NO_MATCH;
		}

		// Now we can assume both findings have a location attached
		// TODO multiple locations
		ElementLocation location1 = finding1.getLocations().get(0);
		ElementLocation location2 = finding2.getLocations().get(0);

		return weightLocations(finding1, location1, finding2, location2);

	}

	/** Returns the similarity (weighting) between two locations. */
	private double weightLocations(Finding finding1, ElementLocation location1,
			Finding finding2, ElementLocation location2) {

		// no matching (for now) if the two locations have different types
		if (!location1.getClass().equals(location2.getClass())) {
			return NO_MATCH;
		}

		if (location1 instanceof QualifiedNameLocation) {
			return weigthQualifiedNameLocations(
					(QualifiedNameLocation) location1,
					(QualifiedNameLocation) location2);
		}

		if (location1 instanceof ElementLocation) {
			return weightFileLocations(finding1, location1, finding2, location2);

		}
		return NO_MATCH;
	}

	/** Weights two FileLocations. */
	private double weightFileLocations(Finding finding1,
			ElementLocation location1, Finding finding2,
			ElementLocation location2) {
		// value used for returned weight
		double returnValue = MATCH;

		if (location1 instanceof CodeLineLocation) {

			double weighting = weightContents(finding1, finding2);
			returnValue = returnValue * weighting;
		}

		if (location1 instanceof CodeRegionLocation) {
			// TODO (MP) covered by code above, but we could be more precise
			// here...
		}

		return returnValue;
	}

	/**
	 * Returns the weighting between two findings according to their content and
	 * context.
	 */
	private double weightContents(Finding finding1, Finding finding2) {
		double findingContentDistance = LocationTrackingUtils
				.getNormalizedWordSimilarity((String) finding1
						.getValue(FindingGateway.CONTENT), (String) finding2
						.getValue(FindingGateway.CONTENT));
		double preContextDistance = LocationTrackingUtils
				.getNormalizedWordSimilarity((String) finding1
						.getValue(FindingGateway.PRE_CONTEXT),
						(String) finding2.getValue(FindingGateway.PRE_CONTEXT));
		double postContextDistance = LocationTrackingUtils
				.getNormalizedWordSimilarity((String) finding1
						.getValue(FindingGateway.POST_CONTEXT),
						(String) finding2.getValue(FindingGateway.POST_CONTEXT));

		// weighting according to albatran
		return 0.5 * findingContentDistance + 0.25 * preContextDistance + 0.25
				* postContextDistance;

	}

	/** Weights two qualified name locations. */
	private double weigthQualifiedNameLocations(
			QualifiedNameLocation location1, QualifiedNameLocation location2) {
		// just compare the path of the qualified location
		if (location1.getQualifiedName().equals(location2.getQualifiedName())) {
			return MATCH;
		}
		return NO_MATCH;
	}

	/** Returns whether two findings are in the same finding category and group. */
	private boolean haveSameCategoryAndGroup(Finding finding1, Finding finding2) {
		// different groups aren't matched
		if (!finding1.getParent().getName().equals(
				finding2.getParent().getName())) {
			return false;
		}

		// different categories aren't matched as well
		if (!finding1.getParent().getParent().getName().equals(
				finding2.getParent().getParent().getName())) {
			return false;
		}

		return true;
	}
}

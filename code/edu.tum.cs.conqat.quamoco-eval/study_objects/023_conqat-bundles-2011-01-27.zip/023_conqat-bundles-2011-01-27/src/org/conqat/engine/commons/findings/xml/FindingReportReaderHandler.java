/*--------------------------------------------------------------------------+
$Id: FindingReportReaderHandler.java 32493 2011-01-11 18:27:20Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.findings.xml;

import java.text.ParseException;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.enums.EnumUtils;
import org.conqat.lib.commons.reflect.ReflectionUtils;
import org.conqat.lib.commons.reflect.TypeConversionException;
import org.conqat.engine.commons.findings.EFindingKeys;
import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.FindingCategory;
import org.conqat.engine.commons.findings.FindingGroup;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.commons.findings.location.CodeLineLocation;
import org.conqat.engine.commons.findings.location.CodeRegionLocation;
import org.conqat.engine.commons.findings.location.ElementLocation;
import org.conqat.engine.commons.findings.location.QualifiedNameLocation;
import org.conqat.engine.commons.node.IConQATNode;

/**
 * Code for reading finding reports. This is package visible and only used by
 * the {@link FindingReportIO} class.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32493 $
 * @levd.rating GREEN Hash: C2C4D2C8EC737A3A146438036848970F
 */
/* package */class FindingReportReaderHandler extends DefaultHandler {

	/** Mapping from element names to element enum values */
	private static final Map<String, EFindingElements> ELEMENTS_BY_NAME = new HashMap<String, EFindingElements>();

	/** Mapping from attribute names to attribute enum values */
	private static final Map<String, EFindingAttributes> ATTRIBUTES_BY_NAME = new HashMap<String, EFindingAttributes>();

	static {
		for (EFindingElements element : EFindingElements.values()) {
			ELEMENTS_BY_NAME.put(FindingReportIO.XML_RESOLVER
					.resolveElementName(element), element);
		}
		for (EFindingAttributes attribute : EFindingAttributes.values()) {
			ATTRIBUTES_BY_NAME.put(FindingReportIO.XML_RESOLVER
					.resolveAttributeName(attribute), attribute);
		}
	}

	/** The report. */
	private FindingReport report;

	/** The current category. */
	private FindingCategory currentCategory;

	/** The current group. */
	private FindingGroup currentGroup;

	/** The current finding. */
	private Finding currentFinding;

	/** The current key/value receiver (can be group or finding). */
	private IConQATNode keyValueReceiver;

	/** Current key for key/value data. */
	private String currentKey;

	/** Buffer for text content in a key/value pair. */
	private StringBuilder textContent = new StringBuilder();

	/** Returns the report. */
	/* package */FindingReport getReport() {
		return report;
	}

	/** {@inheritDoc} */
	@Override
	public void startElement(String uri, String localName, String name,
			Attributes attributes) throws SAXException {
		EFindingElements element = determineElement(localName);
		Map<EFindingAttributes, String> attributeMap = determineAttributes(attributes);
		String uniformPath = attributeMap.get(EFindingAttributes.UNIFORM_PATH);

		try {

			switch (element) {
			case FINDING_REPORT:
				try {
					report = new FindingReport(FindingReportIO.DATE_FORMAT
							.parse(attributeMap.get(EFindingAttributes.TIME)));
				} catch (ParseException e) {
					throw new SAXException("Invalid date format: "
							+ attributeMap.get(EFindingAttributes.TIME), e);
				}
				break;

			case FINDING_CATEGORY:
				currentCategory = report.getOrCreateCategory(attributeMap
						.get(EFindingAttributes.NAME));
				break;

			case FINDING_GROUP:
				currentGroup = currentCategory.createFindingGroup(attributeMap
						.get(EFindingAttributes.DESCRIPTION));
				keyValueReceiver = currentGroup;
				// as findings are after key/values, no reset of
				// keyValueReceiver is needed in endElement()
				break;

			case FINDING:
				currentFinding = currentGroup.createFinding(attributeMap
						.get(EFindingAttributes.ORIGIN_TOOL));
				keyValueReceiver = currentFinding;
				break;

			case KEY_VALUE_PAIR:
				currentKey = attributeMap.get(EFindingAttributes.KEY);
				textContent.setLength(0);
				break;

			case CODE_FILE:
				currentFinding.addLocation(new ElementLocation(uniformPath,
						uniformPath));
				break;

			case CODE_LINE:
				currentFinding.addLocation(new CodeLineLocation(uniformPath,
						uniformPath, Integer.parseInt(attributeMap
								.get(EFindingAttributes.LINE_NUMBER))));
				break;

			case CODE_REGION:
				currentFinding.addLocation(new CodeRegionLocation(uniformPath,
						uniformPath, Integer.parseInt(attributeMap
								.get(EFindingAttributes.START_LINE_NUMBER)),
						Integer.parseInt(attributeMap
								.get(EFindingAttributes.END_LINE_NUMBER)),
						Integer.parseInt(attributeMap
								.get(EFindingAttributes.START_POSITION)),
						Integer.parseInt(attributeMap
								.get(EFindingAttributes.END_POSITION))));
				break;

			case QUALIFIED_NAME:
				currentFinding.addLocation(new QualifiedNameLocation(
						attributeMap.get(EFindingAttributes.NAME), uniformPath,
						uniformPath));
				break;

			default:
				CCSMAssert.fail("Unknown element!");
			}
		} catch (NumberFormatException e) {
			throw new SAXException("Invalid number!", e);
		}
	}

	/** {@inheritDoc} */
	@Override
	public void characters(char[] ch, int start, int length) {
		textContent.append(ch, start, length);
	}

	/** {@inheritDoc} */
	@Override
	public void endElement(String uri, String localName, String name)
			throws SAXException {
		EFindingElements element = determineElement(localName);
		if (element == EFindingElements.KEY_VALUE_PAIR) {
			Object value = textContent.toString();
			EFindingKeys key = EnumUtils.valueOfIgnoreCase(EFindingKeys.class,
					currentKey);
			if (key != null) {
				try {
					value = ReflectionUtils.convertString(value.toString(), key
							.getType());
				} catch (TypeConversionException e) {
					throw new SAXException("Unexpected value " + value
							+ " for key " + key);
				}
			}
			keyValueReceiver.setValue(currentKey, value);
		}
	}

	/** Returns the element for the local name. */
	private static EFindingElements determineElement(String localName)
			throws SAXException {
		EFindingElements element = ELEMENTS_BY_NAME.get(localName);
		if (element == null) {
			throw new SAXException("Could not find element for " + localName);
		}
		return element;
	}

	/** Returns the attributes as a map from enum value to string. */
	private Map<EFindingAttributes, String> determineAttributes(
			Attributes attributes) throws SAXException {
		Map<EFindingAttributes, String> result = new EnumMap<EFindingAttributes, String>(
				EFindingAttributes.class);
		for (int i = 0; i < attributes.getLength(); ++i) {
			EFindingAttributes attribute = ATTRIBUTES_BY_NAME.get(attributes
					.getLocalName(i));
			if (attribute == null) {
				throw new SAXException("Could not find attribute for "
						+ attributes.getLocalName(i));
			}
			result.put(attribute, attributes.getValue(i));
		}
		return result;
	}

	/** {@inheritDoc} */
	@Override
	public void error(SAXParseException e) throws SAXException {
		throw e;
	}

	/** {@inheritDoc} */
	@Override
	public void fatalError(SAXParseException e) throws SAXException {
		throw e;
	}

	/** {@inheritDoc} */
	@Override
	public void warning(SAXParseException e) throws SAXException {
		throw e;
	}
}
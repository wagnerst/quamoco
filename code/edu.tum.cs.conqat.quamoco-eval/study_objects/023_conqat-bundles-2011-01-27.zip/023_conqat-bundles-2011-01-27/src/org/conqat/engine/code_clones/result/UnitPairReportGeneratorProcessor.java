/*-----------------------------------------------------------------------+
 | org.conqat.engine.code_clones
 |                                                                       |
   $Id: UnitPairReportGeneratorProcessor.java 32087 2010-12-22 21:03:01Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.code_clones.result;

import java.util.List;

import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.core.report.UnitPairReportGenerator;
import org.conqat.engine.code_clones.detection.CloneDetectionResultElement;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 127BB69A62FCFCE7C4F6947D72BB5876
 */
@AConQATProcessor(description = "Generates a clone detection result that contains a clone pair "
		+ "for each pair of cloned statements in an input report. This can be useful for tailoring.")
public class UnitPairReportGeneratorProcessor extends
		DetectionResultProcessorBase {

	/** {@inheritDoc} */
	public CloneDetectionResultElement process() {
		List<CloneClass> pairClasses = new UnitPairReportGenerator()
				.createDetectionResult(detectionResult.getList());
		return detectionResultForCloneClasses(pairClasses);
	}

}

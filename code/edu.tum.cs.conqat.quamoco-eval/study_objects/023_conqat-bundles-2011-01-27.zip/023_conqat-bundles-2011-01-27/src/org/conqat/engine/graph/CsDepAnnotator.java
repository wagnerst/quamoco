/*--------------------------------------------------------------------------+
$Id: CsDepAnnotator.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.graph;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import org.conqat.lib.commons.assessment.Assessment;
import org.conqat.lib.commons.assessment.ETrafficLightColor;
import org.conqat.lib.commons.collections.Pair;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.lib.commons.xml.XMLUtils;
import org.conqat.engine.commons.ConQATPipelineProcessorBase;
import org.conqat.engine.core.core.AConQATFieldParameter;
import org.conqat.engine.core.core.AConQATKey;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.graph.nodes.ConQATGraph;
import org.conqat.engine.graph.nodes.ConQATVertex;
import org.conqat.engine.graph.nodes.DeepCloneCopyAction;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * TODO (BH): This is a hack performed for EADS analysis.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: 465EED9593C39D618EF1E54EA03CF0B4
 */
@AConQATProcessor(description = "Extract C++ dependencies")
public class CsDepAnnotator extends ConQATPipelineProcessorBase<ConQATGraph> {

	@AConQATKey(description = "", type = "")
	public static final String KEY = "assessment";

	@AConQATFieldParameter(parameter = "dep", attribute = "file", description = "TODO")
	public String depFile;

	@AConQATFieldParameter(parameter = "type-map", attribute = "file", description = "TODO")
	public String typeMapFile;

	private final Map<String, String> typeToFile = new HashMap<String, String>();

	private final Set<Pair<String, String>> deps = new HashSet<Pair<String, String>>();

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph input) throws ConQATException {

		getLogger().info("Graph has " + input.getEdges().size() + " edges");

		extractTypeMapping();

		extractFileDependencies();

		Map<String, DirectedSparseEdge> edgeLookup = new HashMap<String, DirectedSparseEdge>();
		for (DirectedSparseEdge edge : input.getEdges()) {
			edgeLookup.put(edge.getSource() + "->" + edge.getDest(), edge);

			edge.setUserDatum(KEY, new Assessment(ETrafficLightColor.YELLOW),
					DeepCloneCopyAction.getInstance());
		}

		Map<String, ConQATVertex> componentMap = new HashMap<String, ConQATVertex>();
		for (ConQATVertex v : input.getVertices()) {
			String name = v.getName();
			name = StringUtils.stripPrefix("OSS_", name);
			name = name.replaceFirst("_", "/");
			name = name.toLowerCase();

			componentMap.put(name, v);
		}

		Set<String> missing = new HashSet<String>();
		int numViolations = 0;

		for (Pair<String, String> dep : deps) {
			ConQATVertex from = componentMap.get(dep.getFirst());
			ConQATVertex to = componentMap.get(dep.getSecond());
			if (from == null) {
				missing.add(dep.getFirst());
			} else if (to == null) {
				missing.add(dep.getSecond());
			} else {
				String edgeLabel = from + "->" + to;
				DirectedSparseEdge edge = edgeLookup.get(edgeLabel);
				if (edge == null) {
					++numViolations;
					edge = input.addEdge(from, to);
					edge.setUserDatum(KEY, new Assessment(
							ETrafficLightColor.RED), DeepCloneCopyAction
							.getInstance());
				} else {
					edge.setUserDatum(KEY, new Assessment(
							ETrafficLightColor.GREEN), DeepCloneCopyAction
							.getInstance());
				}
			}
		}

		for (String m : missing) {
			getLogger().warn("Missing component for " + m);
		}
		getLogger().info("Had to create " + numViolations + " new edges!");
	}

	private void extractTypeMapping() throws ConQATException {
		Document doc;
		try {
			doc = XMLUtils.parse(new File(typeMapFile));
		} catch (Exception e) {
			throw new ConQATException(e);
		}
		processTypeMapping(doc.getDocumentElement());
	}

	private void processTypeMapping(Element rootElement) {
		Element firstNode = XMLUtils.getNamedChild(rootElement, "node");
		for (Element node : XMLUtils.getNamedChildren(firstNode, "node")) {
			String type = node.getAttribute("id");
			String file = XMLUtils.getNamedChildContent(node, "value");

			file = StringUtils.stripPrefix(
					"D:\\SBX\\OSS-Release\\Kopie_Impl\\", file);
			file = StringUtils.stripPrefix("D:\\SBX\\OSS-Core1\\Impl\\", file);
			file = StringUtils.stripPrefix(
					"D:\\SBX\\OSS-Release\\Kopie von Impl\\", file);
			file = StringUtils.stripPrefix(
					"d:\\sbx\\oss-release\\kopie_impl\\", file);

			if (!file.contains(":")) {
				typeToFile.put(type, file.toLowerCase());
			}
		}
	}

	private void extractFileDependencies() throws ConQATException {
		Document doc;
		try {
			doc = XMLUtils.parse(new File(depFile));
		} catch (Exception e) {
			throw new ConQATException(e);
		}

		processElement(doc.getDocumentElement());
		getLogger().info("Extracted " + deps.size() + " dependencies");
	}

	private void processElement(Element element) {

		List<Element> childNodes = XMLUtils.getNamedChildren(element, "node");

		if (childNodes.isEmpty() && element.getNodeName().equals("node")) {
			String id = element.getAttribute("id");

			id = typeToFile.get(id);
			if (id == null) {
				return;
			}

			if (!id.startsWith("cgm")) {
				extractDeps(id, element);
			}
		} else {
			for (Element child : childNodes) {
				processElement(child);
			}
		}
	}

	private void extractDeps(String id, Element element) {
		List<Element> values = XMLUtils.getNamedChildren(element, "value");
		for (Element value : values) {
			if (!"Dependency List".equals(value.getAttribute("key"))) {
				continue;
			}

			Element coll = XMLUtils.getNamedChild(value, "collection");
			if (coll == null) {
				continue;
			}

			for (Element item : XMLUtils.getNamedChildren(coll, "item")) {
				String include = item.getTextContent();
				include = typeToFile.get(include);

				if (include == null
						/*|| StringUtils.startsWithOneOf(include, "cmn\\") */) {
					continue;
				}

				insertDependency(id, include);
			}
		}
	}

	private void insertDependency(String from, String to) {
		String fromComponent = findComponent(from);
		String toComponent = findComponent(to);

		if (fromComponent.equals(toComponent)) {
			return;
		}

		deps.add(new Pair<String, String>(fromComponent, toComponent));
	}

	private String findComponent(String file) {
		String[] parts = file.split("\\\\");
		return parts[0] + "/" + parts[1];
	}
}

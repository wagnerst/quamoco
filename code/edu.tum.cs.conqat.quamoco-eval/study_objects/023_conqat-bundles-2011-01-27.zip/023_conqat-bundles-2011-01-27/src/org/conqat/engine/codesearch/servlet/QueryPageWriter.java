/*--------------------------------------------------------------------------+
   $Id: QueryPageWriter.java 32087 2010-12-22 21:03:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch.servlet;

import static org.conqat.lib.commons.html.ECSSProperty.TEXT_ALIGN;
import static org.conqat.lib.commons.html.ECSSProperty.WIDTH;
import static org.conqat.lib.commons.html.EHTMLAttribute.ACTION;
import static org.conqat.lib.commons.html.EHTMLAttribute.METHOD;
import static org.conqat.lib.commons.html.EHTMLAttribute.NAME;
import static org.conqat.lib.commons.html.EHTMLAttribute.SIZE;
import static org.conqat.lib.commons.html.EHTMLAttribute.SRC;
import static org.conqat.lib.commons.html.EHTMLAttribute.STYLE;
import static org.conqat.lib.commons.html.EHTMLAttribute.TYPE;
import static org.conqat.lib.commons.html.EHTMLAttribute.VALUE;
import static org.conqat.lib.commons.html.EHTMLAttribute.CHECKED;
import static org.conqat.lib.commons.html.EHTMLAttribute.CELLPADDING;
import static org.conqat.lib.commons.html.EHTMLAttribute.CELLSPACING;
import static org.conqat.lib.commons.html.EHTMLAttribute.HREF;
import static org.conqat.lib.commons.html.EHTMLElement.DIV;
import static org.conqat.lib.commons.html.EHTMLElement.FORM;
import static org.conqat.lib.commons.html.EHTMLElement.IMG;
import static org.conqat.lib.commons.html.EHTMLElement.INPUT;
import static org.conqat.lib.commons.html.EHTMLElement.TABLE;
import static org.conqat.lib.commons.html.EHTMLElement.TR;
import static org.conqat.lib.commons.html.EHTMLElement.TD;
import static org.conqat.lib.commons.html.EHTMLElement.A;
import static org.conqat.lib.commons.html.EHTMLElement.SPAN;
import static org.conqat.engine.codesearch.servlet.CSSMananger.DEFAULT_FONT;
import static org.conqat.engine.codesearch.servlet.CSSMananger.SMALL_FONT;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.conqat.lib.commons.html.CSSDeclarationBlock;
import org.conqat.lib.commons.string.StringUtils;

public class QueryPageWriter extends PageWriterBase {

	private final StartupServlet startupServlet;
	private final boolean advancedMode;

	public QueryPageWriter(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		super("TUM CodeSearch", request, response);
		startupServlet = StartupServlet.getInstance();
		advancedMode = "true".equals(request.getParameter("advanced"));
	}

	@Override
	protected void writePageBody() {
		openElement(DIV, STYLE, new CSSDeclarationBlock(TEXT_ALIGN, "center"));
		openElement(DIV, STYLE, new CSSDeclarationBlock(WIDTH, "50%")
				.setMargin("auto").setPadding("26px"));
		// openElement(H1, STYLE, CSSMananger.LARGE_BOLD_FONT);
		// addText("CCSM CodeSearch");
		// closeElement(H1);
		addClosedElement(IMG, SRC, "codesearch_logo.png");
		addBR();
		openElement(FORM, ACTION, "result", METHOD, "GET");
		addClosedElement(INPUT, TYPE, "text", SIZE, "30", NAME, "query");
		addClosedElement(INPUT, TYPE, "submit", VALUE, "Search");

		if (advancedMode) {
			addClosedTextElement(A, "Default Search", HREF, "?advanced=false",
					STYLE, SMALL_FONT);
		} else {
			addClosedTextElement(A, "Advanced Search", HREF, "?advanced=true",
					STYLE, SMALL_FONT);
			addClosedElement(INPUT, TYPE, "hidden", NAME, "similarity", VALUE,
					true);
			addClosedElement(INPUT, TYPE, "hidden", NAME, "metric", VALUE,
					"none");
		}

		addClosedElement(INPUT, TYPE, "hidden", NAME, "from", VALUE, 0);
		addClosedElement(INPUT, TYPE, "hidden", NAME, "to", VALUE,
				ResultPageWriter.NUM_OF_RESULTS);
		addBR();
		if (advancedMode) {
			writeScoringPanel();
		}
		addBR();
		addText(StringUtils.format(startupServlet.getDocCount()) + " indexed "
				+ startupServlet.getLanguage() + " documents ");
		addBR();
		addBR();
		openElement(SPAN, STYLE, SMALL_FONT);
		addRawString("&copy; 2006&mdash;");
		addText(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));
		addRawString(" Technische Universit&auml;t M&uuml;nchen");
		closeElement(SPAN);
		closeElement(FORM);
		closeElement(DIV);
		closeElement(DIV);
	}

	private void writeScoringPanel() {
		openElement(TABLE, STYLE, DEFAULT_FONT, CELLPADDING, "0", CELLSPACING,
				"0");
		openElement(TR);
		openElement(TD);
		addClosedElement(INPUT, TYPE, "checkbox", NAME, "similarity", VALUE,
				"true", CHECKED, "checked");
		addText("Use Similarity");
		closeElement(TD);

		ArrayList<String> options = new ArrayList<String>();
		options.add("none");
		options.addAll(startupServlet.getMetrics());

		int i;

		for (i = 0; i < Math.min(2, options.size()); i++) {
			addMetricOption(options.get(i), i == 0);
		}
		closeElement(TR);

		for (int j = i; j < options.size(); j = j + 2) {
			openElement(TR);
			openElement(TD);
			addText(" ");
			closeElement(TD);

			addMetricOption(options.get(j), false);
			if (j + 1 < options.size()) {
				addMetricOption(options.get(j + 1), false);
			}
			closeElement(TR);
		}

		closeElement(TABLE);
	}

	private void addMetricOption(String metric, boolean checked) {
		openElement(TD);
		openElement(INPUT, TYPE, "radio", NAME, "metric", VALUE, metric);
		if (checked) {
			addAttribute(CHECKED, "checked");
		}
		closeElement(INPUT);
		addText(metric);
		closeElement(TD);
	}
}

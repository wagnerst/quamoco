/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: FindingTypeGateway.java 32087 2010-12-22 21:03:01Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.conqat.engine.commons.findings.Finding;

/**
 * Gateway for managing the finding type table.
 * 
 * @author Martin P�hlmann
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating YELLOW Hash: F7C6A74D424BB8E50ED6501E3335C06A
 */
public class FindingTypeGateway extends AbstractGateway {

	/** The database table for finding types (= Category and Group) */
	/* package */static final String TYPE_TABLE_NAME = "FINDING_TYPE";

	/** Type ID column (= Category and Group) of a finding. */
	/* package */static final String TYPE_ID = "TYPE_ID";

	/** Group name column of a finding type. */
	/* package */static final String GROUP_NAME = "GROUP_NAME";

	/** Category name column of a finding type. */
	/* package */static final String CATEGORY_NAME = "CATEGORY_NAME";

	/** Origin tool name column of a finding type. */
	/* package */static final String ORIGIN_TOOL = "ORIGIN_TOOL_NAME";

	/** Constructor. */
	/* package */FindingTypeGateway(Connection dbConnection)
			throws SQLException {
		super(dbConnection);
	}

	/** {@inheritDoc} */
	@Override
	protected String initTableSQL() {
		StringBuilder query = new StringBuilder();
		query.append("CREATE TABLE " + TYPE_TABLE_NAME + " ");
		query.append("( ");
		query.append(TYPE_ID + " INTEGER PRIMARY KEY, ");
		query.append(CATEGORY_NAME + " VARCHAR(512), ");
		query.append(GROUP_NAME + " VARCHAR(512), ");
		query.append(ORIGIN_TOOL + " VARCHAR(512) ");
		query.append(");");
		return query.toString();
	}

	/**
	 * Looks in the database for the category/group pair corresponding to this
	 * finding. If not found it is created. In both cases a unique TYPE_ID is
	 * returned.
	 */
	/* package */int storeAndGetFindingTypeID(Finding finding)
			throws SQLException {
		// check first if the finding type already exists (common case), could
		// be cached
		PreparedStatement typeSelect = connection.prepareStatement("SELECT "
				+ TYPE_ID + " FROM " + TYPE_TABLE_NAME + " WHERE " + GROUP_NAME
				+ " = ? AND " + CATEGORY_NAME + " = ? ;");
		typeSelect.setString(1, finding.getParent().getName());
		typeSelect.setString(2, finding.getParent().getParent().getName());
		ResultSet result = typeSelect.executeQuery();

		// Return existing type if found
		if (result.next()) {
			return result.getInt(TYPE_ID);
		}

		// Otherwise create category / group pair
		PreparedStatement typeInsert = connection
				.prepareStatement("INSERT INTO " + TYPE_TABLE_NAME + " ("
						+ TYPE_ID + "," + GROUP_NAME + "," + CATEGORY_NAME
						+ "," + ORIGIN_TOOL + ") VALUES (?, ?, ?, ?);");
		int key = (int) keyProvider.getKey();
		typeInsert.setInt(1, key);
		typeInsert.setString(2, finding.getParent().getName());
		typeInsert.setString(3, finding.getParent().getParent().getName());
		typeInsert.setString(4, finding.getOriginTool());
		typeInsert.executeUpdate();
		typeInsert.close();

		return key;
	}

	/** {@inheritDoc} */
	@Override
	protected String getPrimaryRow() {
		return TYPE_ID;
	}

	/** {@inheritDoc} */
	@Override
	protected String getTableName() {
		return TYPE_TABLE_NAME;
	}
}

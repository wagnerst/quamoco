/*--------------------------------------------------------------------------+
$Id: SourceElementDescriptor.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.core.report;

/**
 * Collects information about an element that was analyzed during clone
 * detection. This class is immutable.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 021B08C603C8F6D0B957D9157610560B
 */
public final class SourceElementDescriptor {

	/**
	 * The id that is used by clones to reference the element. Must be unique
	 * inside a single detection result.
	 */
	private final int id;

	/** The location. */
	private final String location;

	/** The uniform path. */
	private final String uniformPath;

	/** Length of the element */
	private final int length;

	/** String that identifies content of source element during detection */
	private final String fingerprint;

	/**
	 * @param id
	 *            Used to identify the source element.
	 * @param length
	 *            Char length of the element
	 */
	public SourceElementDescriptor(int id, String location, String uniformPath,
			int length, String fingerprint) {
		this.id = id;
		this.location = location;
		this.uniformPath = uniformPath;
		this.length = length;
		this.fingerprint = fingerprint;
	}

	/** Returns the location. */
	public String getLocation() {
		return location;
	}

	/** Returns the uniform path. */
	public String getUniformPath() {
		return uniformPath;
	}

	/** Returns length in lines. */
	public int getLength() {
		return length;
	}

	/** Returns id that is used by clones to reference the element. */
	public int getId() {
		return id;
	}

	/** Returns element fingerprint */
	public String getFingerprint() {
		return fingerprint;
	}
}
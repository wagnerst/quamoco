/*-----------------------------------------------------------------------+
 | org.conqat.engine.code_clones
 |                                                                       |
   $Id: UnitPairReportGenerator.java 32087 2010-12-22 21:03:01Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.code_clones.core.report;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.collections.ImmutablePair;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.core.Unit;
import org.conqat.engine.code_clones.core.utils.CloneUtils;

/**
 * Generates a clone detection result that contains a clone pair for each pair
 * of cloned statements in an input report. This can be useful for tailoring.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: CE20AA1FBA9EEBE43DF339C9C14AAD03
 */
public class UnitPairReportGenerator extends PairReportGeneratorBase {

	/** Create pair clone classes for the statements between two clones */
	@Override
	protected Set<CloneClass> createPairClasses(
			ImmutablePair<Clone, Clone> clonePair) {

		Clone first = clonePair.getFirst();
		Clone second = clonePair.getSecond();

		// TODO (BH): What about gapped clones?
		CCSMAssert.isTrue(
				first.getLengthInUnits() == second.getLengthInUnits(),
				"Clones must have same number of units. CloneClass id:"
						+ first.getCloneClass().getId() + ", Clone ids: "
						+ first.getId() + ", " + second.getId());

		LinkedHashSet<CloneClass> pairClasses = new LinkedHashSet<CloneClass>();
		for (int unitIndex = 0; unitIndex < first.getLengthInUnits(); unitIndex++) {
			CloneClass pairClass = new CloneClass(1, idProvider.provideId());
			createUnitClone(first, unitIndex, pairClass);
			createUnitClone(second, unitIndex, pairClass);
			pairClasses.add(pairClass);
		}

		return pairClasses;
	}

	/** Create a clone covering exactly one unit of a larger clone */
	private Clone createUnitClone(Clone containingClone, int unitIndex,
			CloneClass cloneClass) {

		List<Unit> units = CloneUtils.getUnits(containingClone);

		// TODO (BH): I would not use an assertion here, as this is caused by a
		// misconfiguration by the ConQAT user
		CCSMAssert.isNotNull(units, "Must store units");

		Unit unit = units.get(unitIndex);

		int startLineInFile = unit.getStartLineInElement();
		int lengthInFile = unit.getCoveredLines();
		int lengthInUnits = 1;
		int startUnitIndexInFile = containingClone.getStartUnitIndexInElement()
				+ unitIndex;

		// we create an artificial fingerprint that is equal for all clones of
		// the clone class.
		String fingerprint = "Fingerprint" + cloneClass.getId();

		Clone clone = new Clone(idProvider.provideId(), cloneClass,
				containingClone.getLocation(),
				containingClone.getUniformPath(), startLineInFile,
				lengthInFile, startUnitIndexInFile, lengthInUnits, fingerprint);
		cloneClass.add(clone);

		return clone;
	}

}

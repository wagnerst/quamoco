/*--------------------------------------------------------------------------+
$Id: ProjectParser8.java 32162 2010-12-22 23:46:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.dotnet.resource.project;

import org.conqat.engine.resource.text.ITextElement;

import org.conqat.lib.commons.string.StringUtils;
import org.conqat.lib.commons.xml.IXMLElementProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.core.logging.IConQATLogger;

/**
 * Parses VS.NET 2003 projects.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32162 $
 * @levd.rating GREEN Hash: 780D2116B71BAC1CB3EBE0DF8F4DB28E
 */
/* package */class ProjectParser8 extends ProjectParser {

	/** Constructor */
	public ProjectParser8(IConQATLogger logger) {
		super(logger);
	}

	/** {@inheritDoc} */
	@Override
	protected ProjectReader8 createReader(ITextElement projectElement)
			throws ConQATException {
		return new ProjectReader8(projectElement.getTextContent(),
				projectElement.getLocation());
	}

	/** Xml reader that performs actual XML processing. */
	private class ProjectReader8 extends ProjectElementReaderBase {

		/** Creates a {@link ProjectReader8} for a project */
		public ProjectReader8(String projectContent, String projectLocation) {
			super(projectContent, projectLocation);
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectXmlElement, ConQATException> createProcessor() {
			return new IncludeProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectXmlElement, ConQATException> createAssemblyNameProcessor() {
			return new AssemblyProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectXmlElement, ConQATException> createOutputTypeProcessor() {
			// No outputTypeProcessor needed in VS2003 projects because both
			// AssemblyName and OutputType
			// are an attribute of Settings. These are extracted by the
			// AssemblyProcessor.
			return null;
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectXmlElement, ConQATException> createRelativeAssemblyPathProcessor() {
			return new ConfigProcessor();
		}

		/** Processor for AssemblyName elements */
		private class AssemblyProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.Settings;
			}

			/** {@inheritDoc} */
			public void process() {
				assemblyName = getStringAttribute(EProjectXmlAttribute.AssemblyName);
				outputType = getStringAttribute(EProjectXmlAttribute.OutputType);
			}
		}

		/** Processor for Config elements */
		private class ConfigProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.Config;
			}

			/** {@inheritDoc} */
			public void process() {
				if (configuration.getName().equals(
						getStringAttribute(EProjectXmlAttribute.Name))) {
					outputPath = getStringAttribute(EProjectXmlAttribute.OutputPath);
				}
			}
		}

		/** Processor for Include elements */
		private class IncludeProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.Include;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				processChildElements(new FileProcessor());
			}
		}

		/** Processor for File elements */
		private class FileProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.File;
			}

			/** {@inheritDoc} */
			public void process() {
				String relativeSourceElementName = getStringAttribute(EProjectXmlAttribute.RelPath);
				String buildAction = getStringAttribute(EProjectXmlAttribute.BuildAction);
				if (buildAction != null && buildAction.equals("Compile")) {
					String link = getStringAttribute(EProjectXmlAttribute.Link);
					if (!StringUtils.isEmpty(link)) {
						relativeSourceElementName = link;
					}
					relativeSourceElementNames.add(relativeSourceElementName);
				}
			}

		}

	}

}
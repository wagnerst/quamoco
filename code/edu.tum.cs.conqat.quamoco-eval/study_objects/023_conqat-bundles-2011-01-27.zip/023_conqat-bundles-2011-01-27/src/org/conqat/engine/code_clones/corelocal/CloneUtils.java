/*--------------------------------------------------------------------------+
$Id: CloneUtils.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.corelocal;

import java.io.IOException;
import java.util.Arrays;

import org.conqat.engine.resource.text.ITextElement;
import org.conqat.engine.resource.text.TextElementUtils;
import org.conqat.engine.resource.util.ResourceUtils;

import org.conqat.lib.commons.assertion.CCSMPre;
import org.conqat.lib.commons.filesystem.CanonicalFile;
import org.conqat.lib.commons.filesystem.FileSystemUtils;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.core.core.ConQATException;

/**
 * This class contains clone related utility methods that depend on ConQAT.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: B0AFD7A486779CA7049CB3F822B22D6B
 */
public class CloneUtils {

	/** Read cloned code from the element that belongs to the clone. */
	public static String getCloneContent(Clone clone, ITextElement cloneElement)
			throws ConQATException {
		CCSMPre.isTrue(clone.getUniformPath().equals(
				cloneElement.getUniformPath()),
				"Uniform paths are expected to match!");

		return extractCloneLines(TextElementUtils.getLines(cloneElement), clone);
	}

	/** Extracts the lines belonging to the given clone. */
	private static String extractCloneLines(String[] lines, Clone clone) {
		String cloneContent = StringUtils.concat(Arrays.asList(lines).subList(
				clone.getStartLineInElement(), clone.getLastLineInElement()),
				StringUtils.CR);
		return cloneContent;
	}

	/**
	 * Read cloned code directly from the file. Contrary to the
	 * {@link #getCloneContent(Clone, ITextElement)} method, this only works if
	 * the clones refer to files in the file system.
	 */
	public static String getCloneContentFromLocalFileSystem(Clone clone)
			throws ConQATException {
		CanonicalFile file = ResourceUtils.getFileFromLocation(clone
				.getLocation());
		if (file == null) {
			throw new ConQATException(
					"Could not determine file for clone location "
							+ clone.getLocation()
							+ "! This only works for files in the file system.");
		}

		try {
			return extractCloneLines(StringUtils.splitLines(FileSystemUtils
					.readFile(file)), clone);
		} catch (IOException e) {
			throw new ConQATException("Filed to read file " + file + ": "
					+ e.getMessage(), e);
		}
	}
}
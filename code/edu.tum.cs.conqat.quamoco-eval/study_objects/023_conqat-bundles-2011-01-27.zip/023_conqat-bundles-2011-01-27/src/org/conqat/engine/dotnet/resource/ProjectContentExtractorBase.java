/*--------------------------------------------------------------------------+
$Id: ProjectContentExtractorBase.java 32162 2010-12-22 23:46:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 by the ConQAT Project                                |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.dotnet.resource;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.conqat.engine.resource.IContentAccessor;
import org.conqat.engine.resource.text.ITextElement;

import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.core.logging.IConQATLogger;
import org.conqat.engine.dotnet.resource.project.ProjectParser;
import org.conqat.engine.dotnet.resource.solution.SolutionParser.EFormatVersion;

/**
 * Base class for processors that extract content accessors from VS projects.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32162 $
 * @levd.rating GREEN Hash: 3874468E71F2850175925036C0300396
 */
public abstract class ProjectContentExtractorBase extends
		ContentAccessorExtractorBase {

	/**
	 * Regular expression used to extract format version number from projects.
	 * Product version is either in the form 'ProductVersion = "7.10.3077"' or
	 * in form '<ProductVersion>8.0.5027</ProductVersion>' (with varying
	 * numbers). This pattern matches both forms. The numbers are matched by
	 * capturing group with index 1.
	 */
	private static final Pattern versionPattern = Pattern
			.compile("<?ProductVersion>?\\s*=?\\s*\"?(\\d+)\\.\\d+\\.\\d+\"?");

	/** {@inheritDoc} */
	@Override
	protected void extractContentAccessors(ITextElement projectElement,
			List<IContentAccessor> included, List<IContentAccessor> excluded,
			IConQATLogger logger) throws ConQATException {
		ProjectParser projectParser = ProjectParser.create(
				determineFormat(projectElement), getLogger());

		List<IContentAccessor> accessors = null;

		try {
			accessors = extractElementsFromProject(projectElement,
					projectParser);
		} catch (ConQATException e) {
			getLogger().warn(
					"Could not parse project: " + projectElement.getLocation()
							+ ": " + e.getMessage());
			return;
		}

		for (IContentAccessor accessor : accessors) {
			if (isContained(accessor.getUniformPath())) {
				included.add(accessor);
			} else {
				excluded.add(accessor);
			}
		}
	}

	/** Determine format for a project element. */
	public static EFormatVersion determineFormat(ITextElement projectElement)
			throws ConQATException {
		Matcher matcher = versionPattern.matcher(projectElement
				.getTextContent());

		// check format assumption
		if (!matcher.find()) {
			throw new ConQATException(
					"Project element has no ProductVersion entry: "
							+ projectElement.getLocation());
		}

		String majorVersionString = matcher.group(1);
		int major = Integer.parseInt(majorVersionString);

		// unfortunately, the project file format numbers and the VS version
		// numbers are not the same. Thus we need to map individually.
		switch (major) {
		case 7:
			return EFormatVersion.VERSION_8;
		case 8:
			// fall through to case 9
		case 9:
			return EFormatVersion.VERSION_9_10;
		default:
			throw new ConQATException("Project Element "
					+ projectElement.getLocation() + " has unknown format");
		}
	}

	/**
	 * Template method to extract the relevant elements (source or assemblies)
	 * from a project.
	 */
	protected abstract List<IContentAccessor> extractElementsFromProject(
			ITextElement projectElement, ProjectParser projectParser)
			throws ConQATException;
}

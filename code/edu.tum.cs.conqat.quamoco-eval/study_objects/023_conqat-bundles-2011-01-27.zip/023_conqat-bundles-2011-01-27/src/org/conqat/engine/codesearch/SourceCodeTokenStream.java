/*--------------------------------------------------------------------------+
   $Id: SourceCodeTokenStream.java 32373 2010-12-30 23:14:23Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;

import org.conqat.engine.text.identifier.CompoundBreaker;
import org.conqat.lib.scanner.ETokenType;
import org.conqat.lib.scanner.IScanner;
import org.conqat.lib.scanner.IToken;
import org.conqat.lib.scanner.ScannerException;
import org.conqat.lib.scanner.ETokenType.ETokenClass;

public class SourceCodeTokenStream extends TokenStream {

	private static Logger logger = Logger
			.getLogger(SourceCodeTokenStream.class);

	private final Iterator<Token> iterator;

	private final CompoundBreaker breaker = new CompoundBreaker();

	public SourceCodeTokenStream(IScanner scanner) {
		iterator = createIterator(scanner);
	}

	private Iterator<Token> createIterator(IScanner scanner) {
		ArrayList<Token> result = new ArrayList<Token>();
		try {
			IToken token;

			while ((token = scanner.getNextToken()).getType() != ETokenType.EOF) {
				if (token.getType().getTokenClass() == ETokenClass.IDENTIFIER) {
					addIdentifier(token, result);
				} else if (token.getType().getTokenClass() == ETokenClass.COMMENT) {
					addString(token, result);
				} else if (token.getType() == ETokenType.STRING_LITERAL) {
					addString(token, result);
				}
			}

		} catch (IOException e) {
			logger.warn(e);
		} catch (ScannerException e) {
			logger.warn(e);
		}
		return result.iterator();
	}

	private void addString(IToken token, ArrayList<Token> tokens) {

		String comment = token.getText();
		// we do not use \w as this includes the underscore
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]+");

		Matcher matcher = pattern.matcher(comment);

		while (matcher.find()) {
			String tokenText = comment
					.substring(matcher.start(), matcher.end());

			Token newToken = new Token(tokenText.toLowerCase().trim(), token
					.getOffset()
					+ matcher.start(), token.getOffset() + matcher.end());
			tokens.add(newToken);
		}

	}

	private void addIdentifier(IToken token, ArrayList<Token> tokens) {

		// tokens.add(new Token(token.getText(), 0, 0));

		List<String> components = breaker.breakCompound(token.getText());

		for (String text : components) {
			tokens.add(createToken(text, token.getOffset(), token.getOffset()
					+ token.getText().length()));
		}

	}

	private Token createToken(String text, int start, int end) {
		return new Token(text.toLowerCase().trim(), start, end);
	}

	public Token next() throws IOException {

		if (!iterator.hasNext()) {
			return null;
		}

		return iterator.next();
	}

	/** {@inheritDoc} */
	@Override
	public boolean incrementToken() throws IOException {
		// TODO Auto-generated method stub
		return false;
	}

}

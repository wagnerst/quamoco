/*--------------------------------------------------------------------------+
$Id: FindingGroupDistributionProcessor.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.findings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.conqat.engine.commons.statistics.KeyedData;
import org.conqat.engine.commons.util.ConQATInputProcessorBase;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating YELLOW Hash: 3D2543F14CF4A5EB35D764CA600ADC6A
 */
@AConQATProcessor(description = "Produces a KeyedData object that contains the "
		+ "distribution of findings accross groups.")
public class FindingGroupDistributionProcessor extends
		ConQATInputProcessorBase<FindingReport> {

	/** Category names. */
	private final Set<String> categoryNames = new LinkedHashSet<String>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "category", minOccurrences = 0, description = "Name of the findings category for which the "
			+ "distribution gets computed. If unspecified all categories are taken into account.")
	public void addCategory(
			@AConQATAttribute(name = "name", description = "Category name") String categoryName) {
		categoryNames.add(categoryName);
	}

	/** {@inheritDoc} */
	@Override
	public KeyedData<?> process() {

		KeyedData<String> result = new KeyedData<String>();

		if (!input.hasChildren()) {
			getLogger().warn("Findings report is empty!");
			return result;
		}

		List<FindingCategory> categories = determineCategories();
		for (FindingCategory category : categories) {
			for (FindingGroup group : category.getChildren()) {
				int count = group.getChildrenSize();

				String name = group.getName();

				// group names are only unique within a category
				if (categories.size() > 1) {
					name = category.getName() + "/" + name;
				}

				result.add(name, count);
			}
		}

		return result;
	}

	/** Determine the finding categories to take into account. */
	private List<FindingCategory> determineCategories() {
		if (categoryNames.isEmpty()) {
			return Arrays.asList(input.getChildren());
		}

		List<FindingCategory> result = new ArrayList<FindingCategory>();
		for (String categoryName : categoryNames) {
			FindingCategory category = input.getCategory(categoryName);

			if (category == null) {
				getLogger().warn(
						"No finding category '" + categoryName + "' found");
			} else {
				result.add(category);
			}
		}
		return result;
	}

}

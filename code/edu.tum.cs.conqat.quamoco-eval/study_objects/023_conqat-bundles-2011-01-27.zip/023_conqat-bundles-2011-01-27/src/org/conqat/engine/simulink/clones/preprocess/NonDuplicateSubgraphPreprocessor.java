/*--------------------------------------------------------------------------+
$Id: NonDuplicateSubgraphPreprocessor.java 32552 2011-01-16 14:57:27Z hummelb $
|                                                                          |
| Copyright 2005-2010 by the ConQAT Project                                |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.simulink.clones.preprocess;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATFieldParameter;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.model_clones.detection.util.ICloneReporter;
import org.conqat.engine.model_clones.detection.util.SubgraphEnumerator;
import org.conqat.engine.model_clones.label.CanonicalLabelCreator;
import org.conqat.engine.model_clones.model.IDirectedEdge;
import org.conqat.engine.model_clones.model.INode;
import org.conqat.engine.simulink.clones.model.SimulinkModelGraph;
import org.conqat.engine.simulink.clones.model.SimulinkModelGraphCreator;
import org.conqat.engine.simulink.clones.model.SimulinkNode;
import org.conqat.engine.simulink.clones.normalize.ISimulinkNormalizer;
import org.conqat.engine.simulink.scope.ISimulinkResource;
import org.conqat.lib.commons.collections.HashedListMap;
import org.conqat.lib.commons.collections.IdentityHashSet;
import org.conqat.lib.commons.collections.PairList;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.lib.simulink.model.SimulinkBlock;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32552 $
 * @levd.rating YELLOW Hash: C2A6D26EEBB8DBA986E7AF0827B8FE13
 */
@AConQATProcessor(description = ""
		+ "This preprocessor discards all nodes that are not part of at least one duplicated subgraph. "
		+ "The processor does not detect any clones, but can speed up the detection by reducing the size of the graph being searched.")
public class NonDuplicateSubgraphPreprocessor extends SimulinkPreprocessorBase {

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "subgraph", attribute = "size", optional = true, description = ""
			+ "The size of the subgraphs that are generated and checked. "
			+ "This should not be chosen too large, as then the performance is reduced instead of improved. "
			+ "The default value is 3.")
	public int subgraphSize = 3;

	/** List of required block prefixes. */
	private final List<String> blockPrefixes = new ArrayList<String>();

	/** Set of nodes selected by prefixes. */
	private final Set<INode> selectedNodes = new IdentityHashSet<INode>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "block", description = "Adds a required block id prefix. "
			+ "If at least one prefix is given, only duplicated subgraphs with at least one block matching the prefix are considered. "
			+ "This can be used to simulate an index-based retrieval strategy.")
	public void addBlockPrefix(
			@AConQATAttribute(name = "prefix", description = "The prefix") String prefix) {
		blockPrefixes.add(prefix);
	}

	/** {@inheritDoc} */
	@Override
	public void preprocess(ISimulinkResource model,
			ISimulinkNormalizer normalizer, Set<SimulinkBlock> ignoredBlocks,
			ICloneReporter reporter) throws ConQATException {

		// we measure time, as this is a strategy that is run in the context of
		// another processor.
		long start = System.currentTimeMillis();

		SimulinkModelGraph graph = SimulinkModelGraphCreator.createModelGraph(
				model, normalizer, ignoredBlocks);

		determineSelectedNodes(graph);

		Set<INode> keep = determineKeptNodes(graph);
		int removed = 0;
		for (INode node : graph.getNodes()) {
			if (!keep.contains(node)) {
				++removed;
				ignoredBlocks.add(((SimulinkNode) node).getBlock());
			}
		}

		getLogger().info(
				"Could remove " + removed + " of " + graph.getNodes().size()
						+ " blocks.");
		getLogger().info(
				"Preprocessing took " + (System.currentTimeMillis() - start)
						/ 1000. + " seconds");
	}

	/** Fills the {@link #selectedNodes} using the {@link #blockPrefixes}. */
	private void determineSelectedNodes(SimulinkModelGraph graph) {
		if (!blockPrefixes.isEmpty()) {
			String[] prefixes = blockPrefixes.toArray(new String[0]);
			for (INode node : graph.getNodes()) {
				if (StringUtils.startsWithOneOf(((SimulinkNode) node)
						.getBlock().getId(), prefixes)) {
					selectedNodes.add(node);
				}
			}
		}

		getLogger()
				.info("Prefixes selected " + selectedNodes.size() + " nodes");
	}

	/**
	 * Calculates the set of nodes that should be kept as they occur in at least
	 * one duplicated subgraph.
	 */
	private Set<INode> determineKeptNodes(SimulinkModelGraph graph) {
		HashedListMap<String, List<INode>> nodesByLabel = getSubgraphsByLabel(graph);
		Set<INode> keep = new IdentityHashSet<INode>();
		for (String label : nodesByLabel.getKeys()) {
			List<List<INode>> list = nodesByLabel.getList(label);
			if (list != null && list.size() >= 2 && containsSelectedNode(list)) {
				for (List<INode> nodes : list) {
					keep.addAll(nodes);
				}
			}
		}
		return keep;
	}

	/** Returns whether at least one node is in {@link #selectedNodes}. */
	private boolean containsSelectedNode(List<List<INode>> list) {
		if (selectedNodes.isEmpty()) {
			return true;
		}

		for (List<INode> nodes : list) {
			for (INode node : nodes) {
				if (selectedNodes.contains(node)) {
					return true;
				}
			}
		}
		return false;
	}

	/** Returns the subgraphs clustered by their canonical label. */
	private HashedListMap<String, List<INode>> getSubgraphsByLabel(
			SimulinkModelGraph graph) {
		HashedListMap<String, List<INode>> nodesByLabel = new HashedListMap<String, List<INode>>();

		PairList<List<INode>, List<IDirectedEdge>> subgraphs = SubgraphEnumerator
				.getConnectedSubGraphs(graph.getNodes(), graph.getEdges(),
						subgraphSize);
		getLogger().info("Extracted " + subgraphs.size() + " subgraphs");

		for (int i = 0; i < subgraphs.size(); ++i) {
			String label = CanonicalLabelCreator.getCanonicalLabel(
					subgraphs.getFirst(i), subgraphs.getSecond(i))
					.getTextualHash();
			nodesByLabel.add(label, subgraphs.getFirst(i));
		}
		return nodesByLabel;
	}
}

/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: LongToDate.java 32087 2010-12-22 21:03:01Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import java.util.ArrayList;
import java.util.Date;

import org.conqat.engine.commons.node.IConQATNode;
import org.conqat.engine.commons.traversal.ETargetNodes;
import org.conqat.engine.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;

// TODO (EJ) Please document where you need it. Could we not store dates directly? 
// (MP) The whole database part bases upon dates coded in longs right now. Depends on you if I should fix this before your review?
/**
 * {@ConQAT.Doc}
 * 
 * @author Martin P�hlmann
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: FEAAB431086BC68C2F3FCA71F09C03CE
 */
@AConQATProcessor(description = "This processor converts Long values "
		+ "to objects of type java.util.Date. Default target nodes are LEAVES.")
public class LongToDate extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** Keys that are converted. */
	private final ArrayList<String> keys = new ArrayList<String>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "key", minOccurrences = 1, description = "Key to convert.")
	public void addKey(
			@AConQATAttribute(name = "value", description = "The key.") String value) {
		keys.add(value);
	}

	/** Returns {@link ETargetNodes#LEAVES}. */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) {
		for (String key : keys) {
			convert(node, key);
		}
	}

	/** Converts the stored time stamp (Long) to a Date object. */
	private void convert(IConQATNode node, String key) {
		Object value = node.getValue(key);
		if (value instanceof Date) {
			return;
		}

		if (value == null) {
			getLogger().warn(
					"No value stored at node '" + node.getId() + "' for key '"
							+ key + "'");
			return;
		}

		if (!(value instanceof Long)) {
			getLogger().warn(
					"The value stored at node '" + node.getId() + "' for key '"
							+ key + "' is not of type Long");
			return;
		}

		node.setValue(key, new Date((Long) value));
	}
}
/*--------------------------------------------------------------------------+
$Id: ArchitectureEdgeAssessor.java 32608 2011-01-25 14:24:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.architecture.assessment;

import java.util.ArrayList;
import java.util.Collection;

import org.conqat.engine.architecture.format.EAssessmentType;
import org.conqat.engine.architecture.scope.AnnotatedArchitecture;
import org.conqat.engine.architecture.scope.DependencyPolicy;
import org.conqat.engine.commons.ConQATPipelineProcessorBase;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.collections.ImmutablePair;

/**
 * {@ConQAT.Doc}
 * 
 * @author Benjamin Hummel
 * @author Tilman Seifert
 * @author $Author: juergens $
 * @version $Rev: 32608 $
 * @levd.rating YELLOW Hash: 9F5468F368AFD04A43C8D4A7E5D79295
 */
@AConQATProcessor(description = "This processor assesses the policies of the given "
		+ "architecture according to the dependencies stored there.")
public class ArchitectureEdgeAssessor extends
		ConQATPipelineProcessorBase<AnnotatedArchitecture> {

	/** {@inheritDoc} */
	@Override
	protected void processInput(AnnotatedArchitecture arch) {
		Collection<DependencyPolicy> policies = new ArrayList<DependencyPolicy>();
		arch.collectPolicies(policies);
		for (DependencyPolicy policy : policies) {
			policy.setAssessment(determineAssessmentType(policy));
		}
	}

	/** Returns a policy's assessments based on the dependencies. */
	private EAssessmentType determineAssessmentType(DependencyPolicy policy) {
		boolean empty = policy.getDependencies().isEmpty();

		switch (policy.getPolicyType()) {
		case ALLOW_EXPLICIT:
		case ALLOW_IMPLICIT:
			if (empty) {
				return EAssessmentType.UNNECESSARY;
			}
			return EAssessmentType.VALID;

		case DENY_IMPLICIT:
		case DENY_EXPLICIT:
			if (empty || isAllowedPublicAccess(policy)) {
				return EAssessmentType.VALID;
			}
			return EAssessmentType.INVALID;

		case TOLERATE_EXPLICIT:
			if (empty) {
				return EAssessmentType.UNNECESSARY;
			}
			for (ImmutablePair<String, String> dependency : policy
					.getDependencies()) {
				if (!policy.tolerated(dependency.getFirst(), dependency
						.getSecond())) {
					return EAssessmentType.INVALID;
				}
			}
			return EAssessmentType.VALID;

		default:
			CCSMAssert.fail("Unknown value: " + policy.getPolicyType());
		}
		return null;
	}

	/**
	 * @return whether this is an allowed access to a public component.
	 */
	private static boolean isAllowedPublicAccess(DependencyPolicy policy) {
		return policy.getTarget().isPublic();
	}

}
/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking.database
 |                                                                       |
   $Id: DatabaseKeyProvider.java 32087 2010-12-22 21:03:01Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.conqat.engine.persistence.DatabaseUtils;

/**
 * Provides auto-incremented key identifiers for a database table.
 * 
 * @author Martin P�hlmann
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating YELLOW Hash: B1FC2B82E8F6D0E3A06DAD3B3E289558
 */
public class DatabaseKeyProvider {

	/** Holds the current maximum key value */
	private long key;

	/** Constructor. */
	/* package */public DatabaseKeyProvider(Connection connection,
			String table, String keyColumn) throws SQLException {
		String query = "SELECT MAX(" + keyColumn + ") as ID FROM " + table;
		Statement stmt = DatabaseUtils.executeQuery(connection, query);
		ResultSet result = stmt.getResultSet();

		if (result.next()) {
			this.key = result.getLong("ID");
		} else {
			this.key = 1;
		}

		stmt.close();
	}

	/**
	 * Returns the next key identifier available for the current database table.
	 */
	public long getKey() {
		return key++;
	}

}

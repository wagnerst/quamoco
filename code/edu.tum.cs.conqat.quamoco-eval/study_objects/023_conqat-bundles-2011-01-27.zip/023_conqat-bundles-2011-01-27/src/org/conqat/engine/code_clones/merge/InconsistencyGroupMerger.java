/*--------------------------------------------------------------------------+
   $Id: InconsistencyGroupMerger.java 32087 2010-12-22 21:03:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.merge;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.conqat.lib.commons.algo.UnionFind;
import org.conqat.lib.commons.collections.HashedListMap;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.core.IdProvider;
import org.conqat.engine.code_clones.detection.CloneDetectionResultElement;
import org.conqat.engine.commons.ConQATPipelineProcessorBase;
import org.conqat.engine.core.core.AConQATProcessor;

// TODO (EJ) This class is currently not applicable to clone tracing
/**
 * Merges clone classes with overlapping inconsistencies
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: 03C40EA7E1DF978451469E6766C5F3A7
 */
@AConQATProcessor(description = "Merges clone classes with overlapping inconsistencies")
public class InconsistencyGroupMerger extends
		ConQATPipelineProcessorBase<CloneDetectionResultElement> {

	/** Maps from a gap position to a clone group */
	Map<String, Integer> gapToGroup = new HashMap<String, Integer>();

	/** Manages clone groups */
	UnionFind cloneGroups = new UnionFind();

	/** Map from clone to its group index */
	Map<Clone, Integer> cloneToGroup = new IdentityHashMap<Clone, Integer>();

	/** Provides ids of merged clone classes */
	private final IdProvider idProvider = new IdProvider();

	/** {@inheritDoc} */
	@Override
	protected void processInput(CloneDetectionResultElement input) {
		// determine which clones are to be merged into groups
		for (CloneClass cloneClass : input.getList()) {
			categorize(cloneClass);
		}

		// create new clone classes based on clone groups
		HashedListMap<Integer, Clone> groups = new HashedListMap<Integer, Clone>();
		for (Clone clone : cloneToGroup.keySet()) {
			int groupIndex = cloneGroups.find(cloneToGroup.get(clone));
			groups.add(groupIndex, clone);
		}

		List<CloneClass> newCloneClasses = new ArrayList<CloneClass>();
		for (int groupIndex : groups.getKeys()) {
			List<Clone> clones = groups.getList(groupIndex);
			int maxLen = 0;
			for (Clone clone : clones) {
				maxLen = Math.max(maxLen, clone.getLengthInUnits());
			}
			CloneClass cloneClass = new CloneClass(maxLen, idProvider
					.provideId());
			for (Clone clone : clones) {
				cloneClass.add(clone);
			}
			newCloneClasses.add(cloneClass);
		}
		input.setList(newCloneClasses);
	}

	private void categorize(CloneClass cloneClass) {
		// categorize all clones from clone class into a new group
		int groupIndex = cloneGroups.addElement();
		for (Clone clone : cloneClass.getClones()) {
			cloneToGroup.put(clone, groupIndex);
		}

		// merge with all other groups that share gaps
		Set<String> gapFingerprints = gapFingerprintsFor(cloneClass);
		for (String gapFingerprint : gapFingerprints) {
			if (gapToGroup.containsKey(gapFingerprint)) {
				int relatedGroup = cloneGroups.find(gapToGroup
						.get(gapFingerprint));
				cloneGroups.union(groupIndex, relatedGroup);
			} else {
				gapToGroup.put(gapFingerprint, cloneGroups.find(groupIndex));
			}
		}
	}

	/** Computes the gap positions for a clone class */
	private Set<String> gapFingerprintsFor(CloneClass cloneClass) {
		Set<String> gapFingerprints = new HashSet<String>();

		for (Clone clone : cloneClass.getClones()) {
			for (int gapPosition : clone.getGapPositions()) {
				int positionInFile = clone.getStartLineInElement() + gapPosition;
				String gapFingerprint = clone.getUniformPath() + ":"
						+ positionInFile;
				gapFingerprints.add(gapFingerprint);
			}
		}

		return gapFingerprints;
	}

}

/*--------------------------------------------------------------------------+
   $Id: BrowserPageWriter.java 32087 2010-12-22 21:03:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch.servlet;

import static org.conqat.lib.commons.html.EHTMLAttribute.BORDER;
import static org.conqat.lib.commons.html.EHTMLAttribute.SRC;
import static org.conqat.lib.commons.html.EHTMLAttribute.STYLE;
import static org.conqat.lib.commons.html.EHTMLElement.IMG;
import static org.conqat.lib.commons.html.EHTMLElement.PRE;
import static org.conqat.lib.commons.html.EHTMLElement.TABLE;
import static org.conqat.lib.commons.html.EHTMLElement.TD;
import static org.conqat.lib.commons.html.EHTMLElement.TR;
import static org.conqat.engine.codesearch.servlet.CSSMananger.LARGE_BOLD_FONT;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.lucene.queryParser.ParseException;

import org.conqat.lib.commons.html.EHTMLAttribute;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.engine.codesearch.SearchEngine;
import static org.conqat.engine.codesearch.servlet.CSSMananger.CODE;

public class BrowserPageWriter extends PageWriterBase {

	private static Logger logger = Logger.getLogger(BrowserPageWriter.class);
	private final SearchEngine searchEngine;
	private final String queryString;

	private final StartupServlet startupServlet = StartupServlet.getInstance();
	private final int docNum;

	public BrowserPageWriter(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		super("Preview", request, response);
		searchEngine = new SearchEngine();
		queryString = request.getParameter("query");
		docNum = parseInt(request.getParameter("docNum"), -1);

	}

	private int parseInt(String string, int defaultValue) {
		if (StringUtils.isEmpty(string)) {
			return defaultValue;
		}
		try {
			return Integer.parseInt(string);
		} catch (NumberFormatException ex) {
			return defaultValue;
		}
	}

	@Override
	protected void writePageBody() {

		writeHeader();

		if (docNum < 0) {
			addText("Document not specified");
			return;
		}
		
		addText("in document ");
		addRawString("&laquo;");
		addText(startupServlet.getPath(docNum));
		addRawString("&raquo;");
		
		try {
			String preview = searchEngine.getPreview(docNum, queryString);
			openElement(PRE, STYLE, CODE);
			addRawString(preview);
			closeElement(PRE);
		} catch (ParseException e) {
			addText(e.getMessage());
		} catch (IOException e) {
			addText(e.getMessage());
		}
	}

	private void writeHeader() {
		openElement(TABLE, BORDER, 0, EHTMLAttribute.WIDTH, "100%");
		openElement(TR);
		openElement(TD, EHTMLAttribute.WIDTH, "100%", STYLE, LARGE_BOLD_FONT);
		addText("Search for ");
		addRawString("&laquo;");
		addText(queryString);
		addRawString("&raquo;");
		closeElement(TD);
		openElement(TD);
		addClosedElement(IMG, SRC, "codesearch_logo.png");
		closeElement(TD);
		closeElement(TR);
		closeElement(TABLE);

	}

}

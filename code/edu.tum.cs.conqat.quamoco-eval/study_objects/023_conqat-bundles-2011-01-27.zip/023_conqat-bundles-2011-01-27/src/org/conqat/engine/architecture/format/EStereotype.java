/*--------------------------------------------------------------------------+
$Id: EFindingKeys.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.architecture.format;

/**
 * Represents the type of a stereotype for components.
 * 
 * @author heineman
 * @author $Author$
 * @version $Rev$
 * @levd.rating GREEN Hash: 6D6027D202F46D387DFD077BB20D8B51
 */
public enum EStereotype {

	/** a normal component */
	NONE,

	/** a component that may be accessed from every component within its parent */
	PUBLIC;
}
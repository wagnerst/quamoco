/*--------------------------------------------------------------------------+
$Id: CrossProjectCloneClassFilter.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.detection.filter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: A046F189C5D9FB8D1F06A2E1FDF73971
 */
@AConQATProcessor(description = "Filters out clone classes that do not span a minimum number of different projects")
public class CrossProjectCloneClassFilter extends CloneClassFilterBase {

	/** List of project-specific prefixes */
	private final List<String> projectPrefixes = new ArrayList<String>();

	/** Minimum number of spanned projects */
	private int requiredProjectsCount = 2;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "project", minOccurrences = 2, description = ""
			+ "Prefix of all uniform paths of this project (typically project root directory or package)")
	public void addProjectPathPrefix(
			@AConQATAttribute(name = "prefix", description = "Prefix of all uniform paths of this project") String projectPathPrefix) {
		this.projectPrefixes.add(projectPathPrefix);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "projects", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Number of required projects")
	public void setRequiredProjectsCount(
			@AConQATAttribute(name = "count", description = "Number of required projects (default is 2)") int requiredProjectsCount) {
		this.requiredProjectsCount = requiredProjectsCount;
	}

	/** Filters out clone classes that do not span enough projects */
	@Override
	protected boolean filteredOut(CloneClass cloneClass) {
		return computeSpannedProjects(cloneClass).size() < requiredProjectsCount;
	}

	/**
	 * Determines the set of projects spanned by a clone class. Projects are
	 * identified by their prefix.
	 */
	private Set<String> computeSpannedProjects(CloneClass cloneClass) {
		Set<String> spannedProjects = new HashSet<String>();
		for (Clone clone : cloneClass.getClones()) {
			for (String projectPrefix : projectPrefixes) {
				if (clone.getUniformPath().startsWith(projectPrefix)) {
					spannedProjects.add(projectPrefix);
				}
			}
		}
		return spannedProjects;
	}
}
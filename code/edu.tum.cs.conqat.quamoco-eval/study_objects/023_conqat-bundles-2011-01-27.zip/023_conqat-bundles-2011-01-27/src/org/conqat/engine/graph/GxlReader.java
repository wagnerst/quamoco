/*--------------------------------------------------------------------------+
$Id: GxlReader.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.graph;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import org.conqat.lib.commons.xml.XMLUtils;
import org.conqat.engine.commons.ConQATProcessorBase;
import org.conqat.engine.core.core.AConQATFieldParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.graph.nodes.ConQATGraph;
import org.conqat.engine.graph.nodes.ConQATGraphInnerNode;
import org.conqat.engine.graph.nodes.ConQATVertex;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: 2F466EC442307F91DAA7F7A93A2DAC1A
 */
@AConQATProcessor(description = "A processor for reading GXL files and converting them to a ConQAT graph.")
public class GxlReader extends ConQATProcessorBase {

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "input", attribute = "file", description = "The name of the GXL file to read.")
	public String fileName;

	/** The nodes (mapping from id to actual node. */
	private final Map<String, Node> nodes = new HashMap<String, Node>();

	/** The root node of the hierarchy. */
	private Node rootNode;

	/** {@inheritDoc} */
	@Override
	public ConQATGraph process() throws ConQATException {

		Document doc;
		try {
			doc = XMLUtils.parse(new File(fileName));
		} catch (SAXException e) {
			throw new ConQATException(e);
		} catch (IOException e) {
			throw new ConQATException(e);
		}

		Element graphNode = XMLUtils.getNamedChild(doc.getDocumentElement(),
				"graph");

		for (Element node : XMLUtils.getNamedChildren(graphNode, "node")) {
			Node n = new Node(node);

			// we know that the first node is the root node
			if (rootNode == null) {
				rootNode = n;
			}
			nodes.put(n.id, n);
		}

		for (Element edge : XMLUtils.getNamedChildren(graphNode, "edge")) {
			Node from = nodes.get(edge.getAttribute("from"));
			Node to = nodes.get(edge.getAttribute("to"));
			if (from == null || to == null) {
				throw new ConQATException("Edges references unknown nodes!");
			}

			String type = XMLUtils.getNamedChild(edge, "type").getAttribute(
					"xlink:href");
			if ("Source_Dependency".equals(type)) {
				from.targets.add(to);
			} else if ("Enclosing".equals(type)) {
				to.children.add(from);
			} else {
				throw new ConQATException("Unknown edge type in GXL file: "
						+ type);
			}
		}

		return createGraph();
	}

	/** Returns the graph. */
	private ConQATGraph createGraph() throws ConQATException {
		if (rootNode.children.isEmpty()) {
			throw new ConQATException("Root node does not have children!");
		}

		ConQATGraph graph = new ConQATGraph();
		mapNode(rootNode, graph, graph);
		mapEdges(graph);
		return graph;
	}

	/**
	 * Performs the mapping from the internal node representation to a ConQAT
	 * graph node.
	 */
	private void mapNode(Node node, ConQATGraph graph,
			ConQATGraphInnerNode conqatNode) throws ConQATException {
		for (Node child : node.children) {
			if (child.children.isEmpty()) {
				child.vertex = graph.createVertex(child.name, child.name,
						conqatNode);
			} else {
				mapNode(child, graph, conqatNode.createChildNode(child.name,
						child.name));
			}
		}
	}

	/** Maps the edges into the graph. */
	private void mapEdges(ConQATGraph graph) throws ConQATException {
		for (Node from : nodes.values()) {
			for (Node to : from.targets) {
				if (from.vertex == null) {
					throw new ConQATException(
							"Edges between inner nodes not supported (source id "
									+ from.id + ")!");
				}
				if (to.vertex == null) {
					throw new ConQATException(
							"Edges between inner nodes not supported (target id "
									+ to.id + ")!");
				}

				graph.addEdge(from.vertex, to.vertex);
			}
		}
	}

	/** Intermediate node representation. */
	private static class Node {

		/** The node's id. */
		private final String id;

		/** The node's name. */
		private final String name;

		/** The children of the node. */
		private final List<Node> children = new ArrayList<Node>();

		/** The nodes that can be reached from this node. */
		private final List<Node> targets = new ArrayList<Node>();

		/** The vertex that this node is mapped to. */
		private ConQATVertex vertex;

		/** Constructor. */
		public Node(Element node) {
			id = node.getAttribute("id");
			name = getAttribute(node, "Source.Name");
		}
	}

	/** Returns a GXL node's attribute. */
	private static String getAttribute(Element node, String name) {
		for (Element attr : XMLUtils.getNamedChildren(node, "attr")) {
			if (name.equals(attr.getAttribute("name"))) {
				return XMLUtils.elementNodes(attr.getChildNodes()).get(0)
						.getTextContent();
			}
		}
		return null;
	}

}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.findingdev
 |                                                                       |
   $Id: FindingsBlacklistFilter.java 32461 2011-01-10 16:41:19Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.finding_tracking.database.FindingGateway;
import org.conqat.lib.commons.filesystem.CanonicalFile;
import org.conqat.lib.commons.filesystem.FileSystemUtils;
import org.conqat.lib.commons.string.StringUtils;

/**
 * {@ConQAT.Doc}
 * 
 * @author Martin P�hlmann
 * @author $Author: juergens $
 * @version $Rev: 32461 $
 * @levd.rating YELLOW Hash: 1B0BCE809A4B8AB6EA284E8834B046D4
 */

@AConQATProcessor(description = "This processor filters a finding report "
		+ "according to a specified blacklist.")
public class FindingsBlacklistFilter extends FindingsFilterBase {

	/** File path of a blacklist or whitelist file. */
	private CanonicalFile blacklist;

	/** IDs of findings that get filtered */
	private final Set<Long> filter = new HashSet<Long>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "file", minOccurrences = 1, maxOccurrences = 1, description = "Path to a blacklist file.")
	public void setFile(
			@AConQATAttribute(name = "path", description = "Path to a blacklist file containing the tracked finding IDs. If no blacklist file is specified, filtering is disabled.") String path)
			throws ConQATException {
		try {
			blacklist = new CanonicalFile(FileSystemUtils
					.normalizeSeparators(path));
		} catch (IOException e) {
			throw new ConQATException("Could not find blacklist: "
					+ e.getMessage());
		}
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp() throws ConQATException {
		String[] lines;
		try {
			lines = StringUtils.splitLines(FileSystemUtils.readFile(blacklist));
		} catch (IOException e) {
			throw new ConQATException(e);
		}
		getLogger().info("Blacklist size: " + lines.length);

		for (String line : lines) {
			// Strip comments
			String findingID = StringUtils.getFirstParts(line, 1, ';');
			filter.add(Long.parseLong(findingID));
		}
	}

	/** {@inheritDoc} */
	@Override
	protected boolean isFiltered(Finding finding) {
		return filter.contains(finding.getValue(FindingGateway.FINDING_ID));
	}

}

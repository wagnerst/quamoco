/*--------------------------------------------------------------------------+
   $Id: DifferentGapPositionsConstraint.java 32087 2010-12-22 21:03:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.core.constraint;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.conqat.lib.commons.assertion.CCSMPre;
import org.conqat.lib.commons.collections.CollectionUtils;
import org.conqat.lib.commons.collections.UnmodifiableList;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * @{ConQAT.doc}
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: 24575DB0E7AA20C1CD73B474DA3B90FF
 */
@AConQATProcessor(description = ""
		+ "Constraint that is satisfied, if not all clones in the clone class have the same number of gaps"
		+ " with the same intervals between them")
public class DifferentGapPositionsConstraint extends ConstraintBase {

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) {
		if (cloneClass.getMaxGapNumber() == 0) {
			return false;
		}

		Clone anyClone = CollectionUtils.getAny(cloneClass.getClones());
		UnmodifiableList<Integer> gaps = anyClone.getGapPositions();
		for (Clone clone : cloneClass.getClones()) {
			if (!intervalsEqual(gaps, clone.getGapPositions())) {
				return false;
			}
		}

		return true;
	}

	/** Compares two lists for equality */
	private boolean intervalsEqual(UnmodifiableList<Integer> list1,
			UnmodifiableList<Integer> list2) {
		// compare sizes
		if (list1.size() != list2.size()) {
			return false;
		}

//		// handle single inconsistency
//		if (list1.size() == 1) {
//			return list1.get(0) == list2.get(0);
//		}

		// compare interval lists
		return Arrays.equals(intervals(list1).toArray(), intervals(list2)
				.toArray());
	}

	/** Computes the intervals between elements in a list */
	private List<Integer> intervals(List<Integer> list) {
		// assert that list is sorted
		for (int i = 1; i < list.size(); i++) {
			CCSMPre
					.isTrue(list.get(i) >= list.get(i - 1),
							"List is not sorted");
		}

		// compute intervals
		List<Integer> intervals = new ArrayList<Integer>();
		for (int i = 1; i < list.size(); i++) {
			intervals.add(list.get(i) - list.get(i - 1));
		}
		return intervals;
	}

}

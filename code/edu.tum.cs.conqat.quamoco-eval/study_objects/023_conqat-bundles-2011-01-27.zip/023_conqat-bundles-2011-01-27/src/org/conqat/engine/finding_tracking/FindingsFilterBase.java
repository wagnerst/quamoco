/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.findingdev
 |                                                                       |
   $Id: FindingsFilterBase.java 32087 2010-12-22 21:03:01Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import org.conqat.engine.commons.ConQATPipelineProcessorBase;
import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.FindingCategory;
import org.conqat.engine.commons.findings.FindingGroup;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.ConQATException;

/**
 * Base class for processors that filter findings
 * 
 * @author Martin P�hlmann
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating YELLOW Hash: 7D0A3002D6ADD4CECDE3C41AEB2976A1
 */
public abstract class FindingsFilterBase extends
		ConQATPipelineProcessorBase<FindingReport> {

	/** Flag that determines whether filter is inverted */
	private boolean invert = false;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "invert", description = "If set to true, filter is inverted.", minOccurrences = 0, maxOccurrences = 1)
	public void setInvert(
			@AConQATAttribute(name = "value", description = "Default: false") boolean invert) {
		this.invert = invert;
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(FindingReport report) throws ConQATException {
		setUp();

		filterFindings(report);

		cleanUpReport(report);
	}

	/**
	 * Template method that deriving classes can override to perform
	 * initialization
	 */
	protected void setUp() throws ConQATException {
		// default implementation does nothing
	}

	/** Filters a finding report according to a list of database finding ids. */
	private void filterFindings(FindingReport report) {
		int filteredFindingsCount = 0;
		for (Finding finding : LocationTrackingUtils.getFindings(report)) {
			boolean filtered = isFiltered(finding);
			if (invert) {
				filtered = !filtered;
			}

			if (filtered) {
				finding.remove();
				filteredFindingsCount += 1;
				getLogger().debug("Blacklisted finding: " + finding.getName());
			}
		}

		getLogger().info("Filtered " + filteredFindingsCount + " findings.");
	}

	/**
	 * Template method that deriving classes override to decide whether a
	 * finding is filtered.
	 */
	protected abstract boolean isFiltered(Finding finding);

	/**
	 * Removes empty finding categories and finding groups from a finding
	 * report.
	 */
	private void cleanUpReport(FindingReport report) {
		for (FindingCategory category : report.getChildren()) {
			for (FindingGroup group : category.getChildren()) {
				if (!group.hasChildren()) {
					group.remove();
					getLogger().info(
							"Removed group " + group.getName()
									+ " because it was empty");
				}
			}
			if (!category.hasChildren()) {
				category.remove();
				getLogger().info(
						"Removed category " + category.getName()
								+ " because it was empty");
			}
		}
	}
}

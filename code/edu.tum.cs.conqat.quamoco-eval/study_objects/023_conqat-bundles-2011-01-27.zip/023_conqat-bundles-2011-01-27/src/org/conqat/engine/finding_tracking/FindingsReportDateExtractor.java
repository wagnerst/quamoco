/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: FindingsReportDateExtractor.java 32087 2010-12-22 21:03:01Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import java.util.Date;

import org.conqat.engine.commons.ConQATProcessorBase;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author Martin P�hlmann
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating YELLOW Hash: A577737537ED319D85E0D68C3E20EEBE
 */

@AConQATProcessor(description = "This processor extracts the date of a finding report.")
public class FindingsReportDateExtractor extends ConQATProcessorBase {

	/** The date of the finding report. */
	private FindingReport report;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "finding-report", minOccurrences = 1, maxOccurrences = 1, description = "The report to extract the date from.")
	public void setFindingReport(
			@AConQATAttribute(name = "ref", description = "The report to extract the date from.") FindingReport findingReport) {
		report = findingReport;
	}

	/** {@inheritDoc} */
	@Override
	public Date process() {
		return report.getTime();
	}

}

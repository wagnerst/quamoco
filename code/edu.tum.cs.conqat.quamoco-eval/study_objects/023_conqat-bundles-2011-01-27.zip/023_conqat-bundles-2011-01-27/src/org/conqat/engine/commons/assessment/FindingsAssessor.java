/*--------------------------------------------------------------------------+
$Id: FindingsAssessor.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.assessment;

import java.util.List;

import org.conqat.lib.commons.assessment.Assessment;
import org.conqat.lib.commons.assessment.ETrafficLightColor;
import org.conqat.engine.commons.findings.FindingsList;
import org.conqat.engine.commons.node.IConQATNode;
import org.conqat.engine.commons.node.NodeUtils;
import org.conqat.engine.commons.traversal.ETargetNodes;
import org.conqat.engine.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import org.conqat.engine.core.core.AConQATKey;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: ABCD8A64D225FDF4F8CCB9618A278D26
 */
@AConQATProcessor(description = ""
		+ "This processor rates leaf nodes based on findings found. "
		+ "For this all keys mentioned in the display list are inspected.")
public class FindingsAssessor extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "The assessment based on findings for the node.", type = "org.conqat.lib.commons.assessment.Assessment")
	public static final String KEY = "FindingsAssessment";

	/** The display list. */
	private List<String> displayList;

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		NodeUtils.addToDisplayList(root, KEY);
		displayList = NodeUtils.getDisplayList(root);
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) {
		ETrafficLightColor color = ETrafficLightColor.GREEN;
		for (String key : displayList) {
			Object o = node.getValue(key);
			if (o instanceof FindingsList && !((FindingsList) o).isEmpty()) {
				color = ETrafficLightColor.RED;
				break;
			}
		}
		node.setValue(KEY, new Assessment(color));
	}
}
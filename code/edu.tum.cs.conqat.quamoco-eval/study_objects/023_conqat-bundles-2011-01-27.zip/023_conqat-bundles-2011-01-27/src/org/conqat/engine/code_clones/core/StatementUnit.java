/*--------------------------------------------------------------------------+
$Id: StatementUnit.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.core;

import java.util.List;

/**
 * This class implements a unit for lists of tokens that represent statements.
 * 
 * @author $Author: hummelb $
 * @version $Revision: 32087 $
 * @levd.rating GREEN Hash: E2F323EE359199303EDDCA05F5164AF9
 */
public class StatementUnit extends Unit {

	/** List of tokens this statement comprises. */
	private TokenUnit[] tokens;

	/** Create new StatementUnit */
	public StatementUnit(int startLineInElement, String elementUniformPath,
			String content, String unnormalizedContent, int coveredLines,
			int indexInElement) {
		super(startLineInElement, elementUniformPath, content,
				unnormalizedContent, coveredLines, indexInElement);
	}

	/**
	 * Constructor that allows storage of token list.
	 * <p>
	 * Caution: If {@link StatementUnit} is used during clone detection by the
	 * suffix tree, storage of token list requires a lot of memory!
	 * 
	 * @param tokenList
	 *            List of tokens the {@link StatementUnit} comprises
	 * @param storeTokens
	 *            Flag that determines whether list is stored
	 */
	public StatementUnit(List<TokenUnit> tokenList, String elementUniformPath,
			boolean storeTokens, int indexInElement) {
		super(tokenList.get(0).getStartLineInElement(), elementUniformPath,
				createContent(tokenList), createUnnormalizedContent(tokenList),
				computeCoveredLines(tokenList), indexInElement);
		if (storeTokens) {
			tokens = tokenList.toArray(new TokenUnit[] {});
		}
	}

	/**
	 * Computes the number of lines covered by the list of tokens. Since we
	 * don't know the number of lines a token covers, we have to compute it from
	 * the tokens' start positions. We assume that the last token does not leave
	 * the line it starts on.
	 * <p>
	 * Since we call this method from within the call to the superclass
	 * constructor, it must be static.
	 */
	private static int computeCoveredLines(List<TokenUnit> tokens) {
		int firstTokenLine = tokens.get(0).getStartLineInElement();
		int lastTokenLine = tokens.get(tokens.size() - 1).getStartLineInElement();
		return lastTokenLine - firstTokenLine + 1;
	}

	/**
	 * Creates unit content string from a token list
	 * <p>
	 * Since we call this method from within the call to the superclass
	 * constructor, it must be static.
	 */
	private static String createContent(List<TokenUnit> tokens) {
		StringBuilder builder = new StringBuilder();
		for (TokenUnit token : tokens) {
			builder.append(token.getContent());
		}
		return builder.toString();
	}

	/**
	 * Creates unnormalized unit content string from a token list
	 * <p>
	 * Since we call this method from within the call to the superclass
	 * constructor, it must be static.
	 */
	private static String createUnnormalizedContent(List<TokenUnit> tokens) {
		StringBuilder builder = new StringBuilder();
		for (TokenUnit token : tokens) {
			builder.append(token.getUnnormalizedContent());
		}
		return builder.toString();
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return getContent() + " [" + getElementUniformPath() + "("
				+ getStartLineInElement() + ")][index:" + getIndexInElement() + "]";
	}

	/**
	 * Gets stored tokens.
	 * 
	 * @throws IllegalStateException
	 *             , if underlying tokens have not been stored
	 */
	public TokenUnit[] getTokens() {
		assertTokensStored();

		return tokens;
	}

	/**
	 * Gets start offset of {@link StatementUnit}
	 * 
	 * @throws IllegalStateException
	 *             , if underlying tokens have not been stored
	 */
	public int getStartOffset() {
		assertTokensStored();
		return tokens[0].getOffset();
	}

	/**
	 * Gets offset of the last character covered by this {@link StatementUnit}.
	 * This method is rather inaccurate, since the content of the token unit has
	 * been normalized
	 * 
	 * @throws IllegalStateException
	 *             , if underlying tokens have not been stored
	 */
	public int getEndOffset() {
		assertTokensStored();
		TokenUnit lastToken = tokens[tokens.length - 1];
		return lastToken.getOffset() + lastToken.getContent().length();
	}

	/** Throws an {@link IllegalStateException}, if tokens have not been stored */
	private void assertTokensStored() {
		if (tokens == null) {
			throw new IllegalStateException(
					"In order to access the underlying tokens, StatementUnit must store its tokens. "
							+ "(Set storeTokens flag in constructor)");
		}
	}

}
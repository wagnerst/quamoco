/*--------------------------------------------------------------------------+
$Id: FindingReportWriter.java 32493 2011-01-11 18:27:20Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.findings.xml;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.FindingCategory;
import org.conqat.engine.commons.findings.FindingGroup;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.commons.findings.location.CodeLineLocation;
import org.conqat.engine.commons.findings.location.CodeRegionLocation;
import org.conqat.engine.commons.findings.location.ElementLocation;
import org.conqat.engine.commons.findings.location.QualifiedNameLocation;
import org.conqat.engine.commons.node.ConQATNodeBase;
import org.conqat.engine.commons.node.NodeConstants;
import org.conqat.lib.commons.filesystem.FileSystemUtils;
import org.conqat.lib.commons.xml.XMLWriter;

/**
 * Code for writing finding reports. This is package visible and only used by
 * the {@link FindingReportIO} class.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32493 $
 * @levd.rating GREEN Hash: D55BA41525E1910F2D3CC90BF7C9DF6C
 */
/* package */class FindingReportWriter {

	/**
	 * Set of keys which are omitted during the export as they have no meaning
	 * for findings but may be added by other processors.
	 */
	private static final Set<String> FILTERED_KEYS = new HashSet<String>(Arrays
			.asList(NodeConstants.COMPARATOR, NodeConstants.HIDE_ROOT,
					NodeConstants.DISPLAY_LIST, NodeConstants.SUMMARY));

	/** The XML writer. */
	private final XMLWriter<EFindingElements, EFindingAttributes> writer;

	/** Constructor. */
	/* package */FindingReportWriter(OutputStream out) {
		this.writer = new XMLWriter<EFindingElements, EFindingAttributes>(
				new PrintWriter(new OutputStreamWriter(out, Charset
						.forName(FileSystemUtils.UTF8_ENCODING))),
				FindingReportIO.XML_RESOLVER);
	}

	/** Writes the report into the writer. */
	/* package */void write(FindingReport report) {
		try {
			writer.addHeader("1.0", FileSystemUtils.UTF8_ENCODING);
			String time = FindingReportIO.DATE_FORMAT.format(report.getTime());
			writer.openElement(EFindingElements.FINDING_REPORT,
					EFindingAttributes.TIME, time, EFindingAttributes.XMLNS,
					"http://conqat.cs.tum.edu/ns/findings");

			for (FindingCategory category : report.getChildren()) {
				if (category.hasChildren()) {
					writeCategory(category);
				}
			}

			writer.closeElement(EFindingElements.FINDING_REPORT);
		} finally {
			writer.close();
		}
	}

	/** Writes the category into the writer. */
	private void writeCategory(FindingCategory category) {
		writer.openElement(EFindingElements.FINDING_CATEGORY,
				EFindingAttributes.NAME, category.getName());

		for (FindingGroup group : category.getChildren()) {
			if (group.hasChildren()) {
				writeGroup(group);
			}
		}

		writer.closeElement(EFindingElements.FINDING_CATEGORY);
	}

	/** Writes the group into the writer. */
	private void writeGroup(FindingGroup group) {
		writer.openElement(EFindingElements.FINDING_GROUP,
				EFindingAttributes.DESCRIPTION, group.getName());

		writeKeyValues(group);

		for (Finding finding : group.getChildren()) {
			writeFinding(finding);
		}

		writer.closeElement(EFindingElements.FINDING_GROUP);
	}

	/** Writes the finding into the writer. */
	private void writeFinding(Finding finding) {
		writer.openElement(EFindingElements.FINDING,
				EFindingAttributes.ORIGIN_TOOL, finding.getOriginTool());

		writeKeyValues(finding);

		for (ElementLocation location : finding.getLocations()) {
			writeLocation(location);
		}

		writer.closeElement(EFindingElements.FINDING);
	}

	/** Writes key/value pairs. */
	private void writeKeyValues(ConQATNodeBase node) {
		for (String key : node.getKeys()) {
			if (FILTERED_KEYS.contains(key)) {
				continue;
			}

			Object value = node.getValue(key);
			if (value != null) {
				writer.addClosedTextElement(EFindingElements.KEY_VALUE_PAIR,
						value.toString(), EFindingAttributes.KEY, key);
			}
		}
	}

	/** Writes the location to the writer. */
	private void writeLocation(ElementLocation location) {
		if (location instanceof QualifiedNameLocation) {
			writer.addClosedElement(EFindingElements.QUALIFIED_NAME,
					EFindingAttributes.NAME, ((QualifiedNameLocation) location)
							.getQualifiedName());
		} else if (location instanceof CodeRegionLocation) {
			CodeRegionLocation crl = (CodeRegionLocation) location;
			writer.addClosedElement(EFindingElements.CODE_REGION,
					EFindingAttributes.UNIFORM_PATH, crl.getUniformPath(),
					EFindingAttributes.START_LINE_NUMBER, crl.getFirstLine(),
					EFindingAttributes.END_LINE_NUMBER, crl.getLastLine(),
					EFindingAttributes.START_POSITION, crl.getFirstPosition(),
					EFindingAttributes.END_POSITION, crl.getLastPosition());

		} else if (location instanceof CodeLineLocation) {
			CodeLineLocation cll = (CodeLineLocation) location;
			writer.addClosedElement(EFindingElements.CODE_LINE,
					EFindingAttributes.UNIFORM_PATH, cll.getUniformPath(),
					EFindingAttributes.LINE_NUMBER, cll.getFirstLine());
		} else {
			writer.addClosedElement(EFindingElements.CODE_FILE,
					EFindingAttributes.UNIFORM_PATH, location.getUniformPath());
		}
	}
}
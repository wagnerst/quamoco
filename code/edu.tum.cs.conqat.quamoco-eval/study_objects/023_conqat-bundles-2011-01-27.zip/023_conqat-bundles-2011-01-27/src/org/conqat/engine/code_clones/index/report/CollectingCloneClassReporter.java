/*--------------------------------------------------------------------------+
$Id: CollectingCloneClassReporter.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.index.report;

import java.util.ArrayList;
import java.util.List;

import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.core.core.ConQATException;

/**
 * An {@link ICloneClassReporter} that collects its results in a list.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 600E57DFE28C86F79F236FF71C0DB035
 */
public class CollectingCloneClassReporter extends CloneClassReporterBase {

	/** The reported clone classes. */
	private final List<CloneClass> cloneClasses = new ArrayList<CloneClass>();

	/** {@inheritDoc} */
	@SuppressWarnings("unused")
	@Override
	public void report(CloneClass cloneClass) throws ConQATException {
		cloneClasses.add(cloneClass);
	}

	/**
	 * Returns the clone classes found so far. This list is not unmodifiable, so
	 * the caller may also reset this list after reading.
	 */
	public List<CloneClass> getCloneClasses() {
		return cloneClasses;
	}
}

/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: FindingMatchClassifier.java 32461 2011-01-10 16:41:19Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.location.ElementLocation;
import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.string.StringUtils;

/**
 * In order to create small subsets for the matching algorithm we need to
 * classify findings according to the canonical path (or qualified name
 * location) and the finding message. From the finding messages all digits are
 * stripped.
 * 
 * @author Martin Poehlmann
 * @author $Author: juergens $
 * @version $Rev: 32461 $
 * @levd.rating RED Hash: FB53C54B60C3D8D37745D561B32F5F6B
 */
public class FindingMatchClassifier {

	// TODO (EJ) Could this be made final?
	/**
	 * Location name (path or qualified name) of the finding belonging to this
	 * classification.
	 */
	private String locationName;

	/** Message of the findings belonging to this classification. */
	private final String message;

	/** Private Constructor. */
	FindingMatchClassifier(Finding finding) {
		CCSMAssert.isNotNull(finding.getMessage());

		message = StringUtils.stripDigits(finding.getMessage());
		locationName = StringUtils.EMPTY_STRING;

		if (finding.hasLocations()) {
			// TODO multi-location findings
			ElementLocation location = finding.getLocations().get(0);

			// FIXME (EJ) Pull into base class
			if (location instanceof ElementLocation) {
				locationName = ((ElementLocation) location).getUniformPath();
			} else {
				throw new RuntimeException("Location type: "
						+ location.getClass() + " not implemented");
			}

		}
	}

	// TODO (EJ) Can this overflow?
	/** {@inheritDoc} */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		// influence hashcode by locationName
		result = prime * result + locationName.hashCode();
		// influence hashcode by message
		result = prime * result + message.hashCode();
		return result;
	}

	/** {@inheritDoc} */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		// location name and message need to be equal
		FindingMatchClassifier other = (FindingMatchClassifier) obj;
		if (!locationName.equals(other.locationName)) {
			return false;
		}
		if (!message.equals(other.message)) {
			return false;
		}
		return true;
	}
}

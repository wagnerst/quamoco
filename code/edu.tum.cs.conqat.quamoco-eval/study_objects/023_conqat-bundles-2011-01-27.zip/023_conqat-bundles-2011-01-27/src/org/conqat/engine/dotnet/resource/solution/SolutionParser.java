/*--------------------------------------------------------------------------+
$Id: SolutionParser.java 32162 2010-12-22 23:46:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.dotnet.resource.solution;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.conqat.engine.resource.IContentAccessor;
import org.conqat.engine.resource.text.ITextElement;
import org.conqat.engine.resource.text.TextElementUtils;

import org.conqat.engine.commons.pattern.PatternList;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.core.logging.IConQATLogger;

/**
 * Reads Visual Studio.NET Solution files and extracts the project file names.
 * <p>
 * Consult the package documentation for a description of those aspects of the
 * VS.NET solution file format that are relevant for the extraction of project
 * file names.
 * <p>
 * This parser simply iterates the lines of the solution file. Lines that start
 * with {@value #PROJECT_DEFINITION_LINE_PREFIX} contain the
 * solution-file-relative path to the project file in the third string literal.
 * I.e., the line
 * 
 * <pre>
 * Project(&quot;{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}&quot;) = &quot;ILAnalyzerTest&quot;, &quot;ILAnalyzerTest\ILAnalyzerTest.csproj&quot;, &quot;{291BC6FE-152B-460A-AD21-EFD9AE3D02FC}&quot;
 * </pre>
 * 
 * points to the file <code>ILAnalyzerTest\ILAnalyzerTest.csproj</code>
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32162 $
 * @levd.rating GREEN Hash: E59D3EA20FFC5DB2BF45B13A81977D47
 */
public class SolutionParser {

	/** Lines in the solution that define projects start with this prefix */
	private static final String PROJECT_DEFINITION_LINE_PREFIX = "Project(\"{";

	/** Version of solution format */
	public static enum EFormatVersion {
		/** VS.NET 2003 format */
		VERSION_8,

		/** VS.NET 2005 and 2008 format */
		VERSION_9_10,
	}

	/** String that identifies VS.NET 2008 solution */
	public static final String SOLUTION_HEADER_10 = "Microsoft Visual Studio Solution File, Format Version 10.00";

	/** String that identifies VS.NET 2005 solution */
	public static final String SOLUTION_HEADER_9 = "Microsoft Visual Studio Solution File, Format Version 9.00";

	/** String that identifies VS.NET 2003 solution */
	public static final String SOLUTION_HEADER_8 = "Microsoft Visual Studio Solution File, Format Version 8.00";

	/** Special project names that are excluded */
	private static PatternList blacklist = new PatternList();
	static {
		blacklist.add(Pattern.compile(Pattern.quote("Solution Items")));
	}

	/**
	 * Extracts the project {@link IContentAccessor}s from the solution
	 * 
	 * @throws ConQATException
	 *             if the format of the solution is not known
	 */
	public static List<IContentAccessor> parse(ITextElement solutionElement,
			IConQATLogger logger) throws ConQATException {
		checkSolutionFormat(solutionElement);
		List<IContentAccessor> projectAccessors = new ArrayList<IContentAccessor>();
		for (String line : TextElementUtils.getLines(solutionElement)) {
			if (line.startsWith(PROJECT_DEFINITION_LINE_PREFIX)) {
				String relativeProjectElementName = retrieveRelativeProjectElementName(line);
				if (!blacklist.findsAnyIn(relativeProjectElementName)) {
					IContentAccessor projectAccessor;
					try {
						projectAccessor = solutionElement
								.createRelativeAccessor(relativeProjectElementName);
						projectAccessors.add(projectAccessor);
					} catch (ConQATException e) {
						logger.error("Could not access: "
								+ relativeProjectElementName + ": "
								+ e.getMessage());
					}
				}
			}
		}
		return projectAccessors;
	}

	/**
	 * Retrieves the relative project name from a project definition line.
	 * <p>
	 * The relative project name is contained in the third string literal.
	 */
	private static String retrieveRelativeProjectElementName(String line) {
		return retrieveStringLiterals(line).get(2).replaceAll("\"", "");
	}

	/** Returns an array of the string literals contained in the project line. */
	private static List<String> retrieveStringLiterals(String projectLine) {
		Pattern stringLiteralPattern = Pattern.compile("\\\"[^\\\"]*\\\"");
		Matcher matcher = stringLiteralPattern.matcher(projectLine);

		List<String> matches = new ArrayList<String>();
		while (matcher.find()) {
			matches.add(matcher.group());
		}

		return matches;
	}

	/**
	 * Determines the format of the solution.
	 * 
	 * @throws ConQATException
	 *             If the solution format is not known.
	 */
	private static EFormatVersion checkSolutionFormat(
			ITextElement solutionElement) throws ConQATException {
		EFormatVersion formatVersion = null;

		String[] lines = TextElementUtils.getLines(solutionElement);

		if (lines[0].equals(SOLUTION_HEADER_10)
				|| lines[1].equals(SOLUTION_HEADER_10)
				|| lines[0].equals(SOLUTION_HEADER_9)
				|| lines[1].equals(SOLUTION_HEADER_9)) {
			formatVersion = EFormatVersion.VERSION_9_10;
		} else if (lines[0].equals(SOLUTION_HEADER_8)
				|| lines[1].equals(SOLUTION_HEADER_8)) {
			formatVersion = EFormatVersion.VERSION_8;
		} else {
			throw new ConQATException("Format of solution "
					+ solutionElement.getLocation() + " unknown");
		}

		return formatVersion;
	}

}
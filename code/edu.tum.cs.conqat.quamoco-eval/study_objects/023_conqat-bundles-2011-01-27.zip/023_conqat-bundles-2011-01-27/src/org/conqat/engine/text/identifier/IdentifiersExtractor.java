/*--------------------------------------------------------------------------+
$Id: IdentifiersExtractor.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.text.identifier;

import java.util.HashSet;
import java.util.Set;

import org.conqat.engine.core.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: ED9FB743DF4DE1A4F1F34D6E9F7F57D7
 */
@AConQATProcessor(description = "This processor extracts the set of "
		+ "identifiers from a source code tree.")
public class IdentifiersExtractor extends IdentifierProcessorBase<Set<String>> {

	/** Set of identifiers. */
	private final HashSet<String> identifiers = new HashSet<String>();

	/** {@inheritDoc} */
	@Override
	protected Set<String> obtainResult() {
		return identifiers;
	}

	/** {@inheritDoc} */
	@Override
	protected void processIdentifier(String identifier) {
		identifiers.add(identifier);
	}
}
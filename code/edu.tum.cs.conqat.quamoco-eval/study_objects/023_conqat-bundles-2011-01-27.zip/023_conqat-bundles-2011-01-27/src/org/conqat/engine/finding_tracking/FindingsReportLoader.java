/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: FindingsReportLoader.java 32461 2011-01-10 16:41:19Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import java.sql.SQLException;

import org.conqat.engine.commons.ConQATParamDoc;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.finding_tracking.database.FindingGateway;
import org.conqat.engine.persistence.DatabaseProcessorBase;

/**
 * {@ConQAT.Doc}
 * 
 * @author Martin P�hlmann
 * @author $Author: juergens $
 * @version $Rev: 32461 $
 * @levd.rating YELLOW Hash: 90003B8A8A5D49726E6D915CBC016550
 */

@AConQATProcessor(description = "This processor extracts a finding report "
		+ "from a findings database.")
public class FindingsReportLoader extends DatabaseProcessorBase {

	/** Flag that determines whether to include existing findings */
	private boolean includeExisting;

	/** Flag that determines whether to include dead findings */
	private boolean includeDead;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "include", minOccurrences = 1, maxOccurrences = 1, description = "Determine which findings will be included in the loaded report")
	public void setIncludedFindings(
			@AConQATAttribute(name = "existing", defaultValue = "true", description = "Include findings that were existant in the last stored report.") boolean includeExisting,
			@AConQATAttribute(name = "dead", defaultValue = "false", description = "Include resolved findings that did not exist in the last stored report anymore.") boolean includeDead) {
		this.includeExisting = includeExisting;
		this.includeDead = includeDead;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.PREDECESSOR_NAME, description = ConQATParamDoc.PREDECESSOR_NAME_DESC)
	public void addPredecessor(
			@AConQATAttribute(name = ConQATParamDoc.PREDECESSOR_REF_NAME, description = ConQATParamDoc.PREDECESSOR_REF_DESC) Object predecessor) {
		// do nothing
	}

	/** {@inheritDoc} */
	public FindingReport process() throws ConQATException {
		FindingReport report = null;

		try {
			FindingGateway gateway = new FindingGateway(dbConnection);
			report = gateway.extractReport(includeExisting, includeDead);
		} catch (SQLException e) {
			throw wrap(e);
		}

		return report;
	}
}

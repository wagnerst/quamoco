/*--------------------------------------------------------------------------+
$Id: DateFilterBase.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.date;

import java.util.Date;

import org.conqat.engine.commons.filter.KeyBasedFilterBase;
import org.conqat.engine.commons.node.IRemovableConQATNode;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;

/**
 * Base class for filters that deal with dates.
 * 
 * @author deissenb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: A008113435B710DBC17A6CADC3644BF3
 */
public abstract class DateFilterBase extends
		KeyBasedFilterBase<Date, IRemovableConQATNode> {

	/** The date to compare to. */
	protected Date date;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "date", minOccurrences = 1, maxOccurrences = 1, description = "The date to compare to.")
	public void setDate(
			@AConQATAttribute(name = "value", description = "Date") Date date) {
		this.date = date;
	}

}
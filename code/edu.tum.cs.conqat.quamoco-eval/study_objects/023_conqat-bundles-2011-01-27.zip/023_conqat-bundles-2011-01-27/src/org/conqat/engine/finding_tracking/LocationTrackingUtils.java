/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: LocationTrackingUtils.java 32461 2011-01-10 16:41:19Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking;

import static org.conqat.engine.finding_tracking.database.FindingGateway.CONTENT;
import static org.conqat.engine.finding_tracking.database.FindingGateway.CONTENT_CHAR_POSITION;
import static org.conqat.engine.finding_tracking.database.FindingGateway.POST_CONTEXT;
import static org.conqat.engine.finding_tracking.database.FindingGateway.PRE_CONTEXT;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.FindingCategory;
import org.conqat.engine.commons.findings.FindingGroup;
import org.conqat.engine.commons.findings.FindingReport;
import org.conqat.engine.commons.findings.location.CodeLineLocation;
import org.conqat.engine.commons.findings.location.CodeRegionLocation;
import org.conqat.engine.commons.findings.location.ElementLocation;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.lib.commons.algo.Diff;
import org.conqat.lib.commons.algo.Diff.Delta;
import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.filesystem.FileSystemUtils;
import org.conqat.lib.commons.string.StringUtils;

/**
 * Util class for miscellaneous location related tasks.
 * 
 * @author Martin P�hlmann
 * @author albatran
 * @author $Author: juergens $
 * @version $Rev: 32461 $
 * @levd.rating RED Hash: 790398DEE60E6A2588B09AB46224304B
 */
public class LocationTrackingUtils {

	// FIXME (EJ) Use better cache implementation
	/** Caches lines from files */
	private static final Map<String, String[]> linesCache = new HashMap<String, String[]>();

	// TODO (EJ) Move this to FileLibrary?
	// (MP) Depends on you. We can split this util class at some point. So one
	// part moves to finding utils, one to FileLib, ...
	/**
	 * Returns one line of a file. Lines range from 1 to n. If a line outside
	 * this range is given, null is returned.
	 */
	public static String getLine(String location, int line)
			throws ConQATException {
		return getLines(location, line, line);
	}

	// TODO (EJ) Move this to FileLibrary?
	// (MP) See above
	/**
	 * Returns a range of lines of a file. Lines range from 1 to n. The given
	 * line range will be clipped according to the actual line numbers.
	 * Nevertheless if both the start and the endline are greater than the total
	 * number of lines null is returned.
	 */
	public static String getLines(String location, int startline, int endline)
			throws ConQATException {
		CCSMAssert.isTrue(startline <= endline,
				"The startline needs to be smaller than the endline");
		CCSMAssert.isTrue(endline > 0,
				"Code lines need to be greater than zero.");

		String[] lines = linesCache.get(location);
		if (lines == null) {
			try {
				lines = StringUtils.splitLines(FileSystemUtils
						.readFile(new File(location)));
				linesCache.put(location, lines);
			} catch (IOException e) {
				throw new ConQATException(e);
			}
		}

		startline = normalizeLineCounting(startline);
		endline = normalizeLineCounting(endline);

		// TODO (EJ) Se comment at if in method above: use CCSMAssert in some
		// cases, or document why this can happen
		// (MP) If we will put this in a UtilClass it makes sense to return null
		// (documented now), since Asserts are ugly to handle and we do not
		// 100%-ly know if the given line number really exists (the file is read
		// in the method for maybe the first time).

		// return null if the range is (positively) outside the file
		if (startline >= lines.length) {
			return null;
		}

		// clip according to total amount of lines
		if (startline < 0) {
			startline = 0;
		}
		if (endline >= lines.length) {
			endline = lines.length - 1;
		}

		List<String> lineRange = Arrays.asList(lines).subList(startline,
				endline + 1);
		return StringUtils.concat(lineRange, StringUtils.CR);
	}

	/**
	 * Usually lines are counted like 1..n, nevertheless in Arrays we have
	 * 0..n-1. This methods normalizes to start by zero.
	 */
	private static int normalizeLineCounting(int line) {
		return line - 1;
	}

	/**
	 * Returns the context (in lines) before a given line. Lines range from 1 to
	 * n.
	 */
	public static String getPreContext(String location, int line, int length)
			throws ConQATException {
		// We need to catch the special case, when the pre-context would range
		// from -length to 0.
		if (line == 1) {
			return null;
		}
		return getLines(location, line - length, line - 1);
	}

	/**
	 * Returns the context (in lines) after a given line. Lines range from 1 to
	 * n.
	 */
	public static String getPostContext(String location, int line, int length)
			throws ConQATException {
		return getLines(location, line + 1, line + length);
	}

	/**
	 * Attaches location information to a fiding node. Optionally one can
	 * specify a path that is used to save filenames relatively, otherwise pass
	 * null.
	 */
	public static void attachLocationInformation(Finding finding,
			int contextLength) throws ConQATException {

		if (finding.getLocations().size() > 0) { // TODO (MP) support multi
			// location findings
			ElementLocation locationbase = finding.getLocations().get(0);

			if (locationbase instanceof CodeRegionLocation) {
				CodeRegionLocation location = (CodeRegionLocation) locationbase;

				// TODO (EJ) Use static imports for all FindingGateway constants
				// //
				// to simplify readability? // TODO (EJ) Extract
				// location.getFile into a
				// local variable to // simplify readability? Why not do this
				// for all //
				// variables, or at least those ones that are read more // than
				// once?
				// you can even move some of them out of the // if, since they
				// are used
				// in both branches
				// FIXME (EJ) For long findings, this is too expensive.
				int from = location.getFirstLine();
				int to = location.getLastLine();
				int length = to - from + 1;
				if (length > contextLength) {
					to = from + contextLength - 1;
				}
				finding.setValue(CONTENT, LocationTrackingUtils.getLines(
						location.getLocation(), from, to));

				finding.setValue(PRE_CONTEXT, LocationTrackingUtils
						.getPreContext(location.getLocation(), from,
								contextLength));

				finding.setValue(POST_CONTEXT, LocationTrackingUtils
						.getPostContext(location.getLocation(), location
								.getLastLine(), contextLength));

				finding.setValue(CONTENT_CHAR_POSITION, LocationTrackingUtils
						.getCharPositionFromLine(location.getLocation(), from));
			} else if (locationbase instanceof CodeLineLocation) {
				CodeLineLocation location = (CodeLineLocation) locationbase;

				finding.setValue(CONTENT, LocationTrackingUtils.getLine(
						location.getLocation(), location.getFirstLine()));

				finding.setValue(PRE_CONTEXT, LocationTrackingUtils
						.getPreContext(location.getLocation(), location
								.getFirstLine(), contextLength));

				finding.setValue(POST_CONTEXT, LocationTrackingUtils
						.getPostContext(location.getLocation(), location
								.getFirstLine(), contextLength));

			}
		}

	}

	/**
	 * Returns the relative character position of a line in a file. The line
	 * numbers range from 1 to n. Specifying anything greater than n will return
	 * the total amount of column chars.
	 */
	public static int getCharPositionFromLine(String location, int line)
			throws ConQATException {
		CCSMAssert.isTrue(line > 0, "A line number needs to be positive.");

		line = normalizeLineCounting(line);

		String[] lines;
		try {
			lines = StringUtils.splitLines(FileSystemUtils.readFile(new File(
					location)));
		} catch (IOException e) {
			throw new ConQATException(e);
		}

		// clip
		if (line > lines.length) {
			line = lines.length;
		}

		int charPosition = 0;

		for (int i = 0; i < line; i++) {
			charPosition += lines[i].length();
		}

		return charPosition;
	}

	/**
	 * Returns the normalized similarity between two Strings. The similarity
	 * will be between 0 and 1 and is calculated based on the word edit distance
	 * calculated by the Diff algorithm.
	 */
	public static double getNormalizedWordSimilarity(String string0,
			String string1) {
		// catch special cases
		if (StringUtils.isEmpty(string0) && StringUtils.isEmpty(string1)) {
			return 1.0;
		}
		if (StringUtils.isEmpty(string0) || StringUtils.isEmpty(string1)) {
			return 0.0;
		}

		Delta<String> delta = Diff.computeDelta(split(string0.toLowerCase()),
				split(string1.toLowerCase()));

		int wordCount = delta.getN() + delta.getM();
		int editDistance = delta.getSize();

		// Prohibit DivisionByZero Exception, also catch special case
		if (wordCount == 0) {
			return 1.0;
		}

		// return normalized similarity
		return 1.0 - (double) editDistance / wordCount;
	}

	/** Splits the String in words */
	public static String[] split(String string) {
		StringTokenizer toc = new StringTokenizer(string,
				"\n \b \t \n \f \r . -> ( ) [ ] : - +");
		String[] words = new String[toc.countTokens()];
		for (int i = 0; i < words.length; i++) {
			words[i] = toc.nextToken();
		}
		return words;
	}

	/** Returns all findings stored in a findings report. */
	public static List<Finding> getFindings(FindingReport report) {
		List<Finding> findings = new ArrayList<Finding>();
		for (FindingGroup group : getFindingGroups(report)) {
			for (Finding finding : group.getChildren()) {
				findings.add(finding);
			}
		}

		return findings;
	}

	/** Returns all finding groups of a finding report. */
	public static List<FindingGroup> getFindingGroups(FindingReport report) {
		List<FindingGroup> groups = new ArrayList<FindingGroup>();
		for (FindingCategory category : report.getChildren()) {
			for (FindingGroup group : category.getChildren()) {
				groups.add(group);
			}
		}

		return groups;
	}

}

/*--------------------------------------------------------------------------+
$Id: CollectionSizeProcessor.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.commons.collections;

import java.util.Collection;

import org.conqat.engine.commons.ConQATParamDoc;
import org.conqat.engine.commons.ConQATProcessorBase;
import org.conqat.engine.commons.node.IConQATNode;
import org.conqat.engine.commons.node.NodeUtils;
import org.conqat.engine.commons.node.ListNode;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;

/**
 * A simple processor that creates a dummy ConQATNode and attaches the size of a
 * collection as value.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 18935BAAFA861A9652CE25650DA1D64F
 */
@AConQATProcessor(description = "A simple processor that creates a dummy ConQATNode and attaches "
		+ "the size of a collection as value.")
public class CollectionSizeProcessor extends ConQATProcessorBase {

	/** The key to write the result into. */
	private String key;

	/** The collection. */
	private Collection<?> collection;

	/** Set the collection to measure. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The collection to measure.")
	public void setCollection(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			Collection<?> list) {
		this.collection = list;
	}

	/** Set the key used for writing the result. */
	@AConQATParameter(name = ConQATParamDoc.WRITEKEY_KEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The key to write the size into.")
	public void setWriteKey(
			@AConQATAttribute(name = ConQATParamDoc.WRITEKEY_KEY_NAME, description = ConQATParamDoc.WRITEKEY_KEY_DESC)
			String key) {
		this.key = key;
	}

	/** {@inheritDoc} */
	public IConQATNode process() {
		IConQATNode result = new ListNode();
		NodeUtils.addToDisplayList(result, key);
		result.setValue(key, collection.size());
		return result;
	}
}
/*--------------------------------------------------------------------------+
$Id: DependencyAnnotator.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.architecture.assessment;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.conqat.lib.commons.clone.DeepCloneException;
import org.conqat.engine.architecture.scope.AnnotatedArchitecture;
import org.conqat.engine.architecture.scope.ArchitectureDefinition;
import org.conqat.engine.architecture.scope.ComponentNode;
import org.conqat.engine.architecture.scope.ComponentResolver;
import org.conqat.engine.commons.ConQATParamDoc;
import org.conqat.engine.commons.ConQATProcessorBase;
import org.conqat.engine.commons.node.IConQATNode;
import org.conqat.engine.commons.node.NodeUtils;
import org.conqat.engine.commons.traversal.INodeVisitor;
import org.conqat.engine.commons.traversal.TraversalUtils;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATKey;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 60FF737A29552F9062CA0C2A73797C00
 */
@AConQATProcessor(description = "This processor adds dependencies to the "
		+ "policies of an architecture. The result is the same architecture "
		+ "definition enriched with scope this processor was run on.")
public class DependencyAnnotator extends ConQATProcessorBase {

	/** Key for elements w/o a component. */
	@AConQATKey(description = "Stores the list of orphaned nodes.", type = "java.util.List<String>")
	public static final String ORPHANS_KEY = "orphans";

	/** Key under which the set of matched types is stored */
	@AConQATKey(description = "Stores the names of types matched to a component.", type = "java.util.Set<String>")
	public static final String MATCHED_TYPES_KEY = "matched_types";

	/** The root node currently being analyzed. */
	private IConQATNode root;

	/** Set of keys storing the string lists containing the dependencies. */
	private final Set<String> keys = new HashSet<String>();

	/** The resolver used to locate components. */
	private ComponentResolver resolver;

	/** Orphans are element IDs which could not be mapped to a component. */
	private final Set<String> orphans = new HashSet<String>();

	/** Counts the number of dependencies processed. */
	private int dependencyCount = 0;

	/** The input architecture definition. */
	private ArchitectureDefinition arch;

	/** Set the root element to work on. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) ArchitectureDefinition arch) {
		this.arch = arch;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "dependencies", minOccurrences = 1, maxOccurrences = 1, description = "The node structure providing the dependencies.")
	public void setDependencies(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IConQATNode root) {
		this.root = root;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "list-key", description = ""
			+ "Add a key to read a dependency list from. "
			+ "The same key is put into the edge summary lists of all edges created from these lists.")
	public void addListKey(
			@AConQATAttribute(name = "key", description = "The name of the key.") String key) {
		keys.add(key);
	}

	/** {@inheritDoc} */
	@Override
	public AnnotatedArchitecture process() throws ConQATException {
		resolver = new ComponentResolver(arch, getLogger());

		TraversalUtils.visitLeavesDepthFirst(new DependencyVisitor(), root);

		NodeUtils.addToDisplayList(arch, ORPHANS_KEY);
		NodeUtils.getOrCreateStringList(arch, ORPHANS_KEY).addAll(orphans);

		getLogger().info("Processed " + dependencyCount + " dependencies.");
		getLogger().info(
				"Number of orphans (classes that could not be mapped to component): "
						+ orphans.size());

		// fail if no suitable input was provided.
		if (dependencyCount == 0) {
			throw new ConQATException(
					"No dependencies found in provided scope! Probably this is a configuration error.");
		}

		// what we basically need to do is to copy the input architecture. As
		// this object has a lot of fields this a bit tedious. On the other
		// hand, this already implemented in the deep cloning facility of the
		// ArchitectureDefinition. Hence, we reuse this here. This has two
		// drawbacks: First, it performs a deep clone which wouldn't really need
		// at this point. Second, we need to care about the deep clone
		// exceptions. The former problem is not serious as architectures are
		// usually rather small. The latter, is addressed by construct below. We
		// chose not use an assertion here as the user could potentially create
		// a block that triggers this exception. It is, hence, not strictly a
		// programming error.
		try {
			return new AnnotatedArchitecture(arch, root);
		} catch (DeepCloneException e) {
			throw new ConQATException(
					"There was an unexpected mismatch between "
							+ "the architecture definition and the associated scope: "
							+ e.getMessage());
		}
	}

	/**
	 * Returns the component for a given ID using the {@link #resolver}. Returns
	 * null if no component could be found.
	 */
	private ComponentNode findComponent(String id) {
		ComponentNode component = resolver.findComponentFor(id);
		if (component == null) {
			orphans.add(id);
		} else {
			NodeUtils.getOrCreateStringSet(component, MATCHED_TYPES_KEY)
					.add(id);
		}
		return component;
	}

	/** Inserts a dependency into this architecture. */
	private void insertDependency(ComponentNode sourceComponent,
			ComponentNode targetComponent, String sourceId, String targetId) {
		dependencyCount += 1;

		if (sourceComponent == targetComponent
				|| sourceComponent.getAncestorSet().contains(targetComponent)
				|| targetComponent.getAncestorSet().contains(sourceComponent)) {
			// dependency within component or along the hierarchy is always
			// allowed
			return;
		}

		sourceComponent.getOrCreatePolicy(targetComponent).addDependency(
				sourceId, targetId);
	}

	/** Visitor for inserting the dependencies. */
	private class DependencyVisitor implements
			INodeVisitor<IConQATNode, ConQATException> {

		/** {@inheritDoc} */
		public void visit(IConQATNode node) {
			ComponentNode sourceNode = findComponent(node.getId());
			if (sourceNode == null) {
				return;
			}

			for (String key : keys) {
				Collection<String> targetList = NodeUtils.getStringCollection(
						node, key);
				if (targetList == null) {
					continue;
				}

				for (String targetID : targetList) {
					ComponentNode targetComponent = findComponent(targetID);
					if (targetComponent != null) {
						insertDependency(sourceNode, targetComponent, node
								.getId(), targetID);
					}
				}
			}
		}
	}

}
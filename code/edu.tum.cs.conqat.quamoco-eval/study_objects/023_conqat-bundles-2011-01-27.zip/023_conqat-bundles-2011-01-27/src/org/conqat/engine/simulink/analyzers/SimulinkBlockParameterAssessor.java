/*--------------------------------------------------------------------------+
$Id: SimulinkBlockParameterAssessor.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.simulink.analyzers;

import java.util.regex.Pattern;

import org.conqat.lib.commons.collections.PairList;
import org.conqat.lib.commons.collections.TwoDimHashMap;
import org.conqat.engine.commons.CommonUtils;
import org.conqat.engine.commons.ConQATParamDoc;
import org.conqat.engine.core.core.AConQATAttribute;
import org.conqat.engine.core.core.AConQATKey;
import org.conqat.engine.core.core.AConQATParameter;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.simulink.scope.ISimulinkElement;
import org.conqat.lib.simulink.model.SimulinkBlock;

/**
 * {@ConQAT.Doc}
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: 73583E98EFF8AC37D8C5EBF87CFF03F2
 */
@AConQATProcessor(description = "This processor checks if block parameters "
		+ "conform to a set of rules and creates findings if a block has "
		+ "parameters that are not conform to the rules.")
public class SimulinkBlockParameterAssessor extends
		FindingsBlockTraversingProcessorBase {

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Parameter Assessment Findings", type = ConQATParamDoc.FINDING_LIST_TYPE)
	public static final String KEY = "Parameter Assessment Findings";

	/** Type constant used if rule is specified for all block types. */
	/* package */static final String ALL_BLOCKS_TYPE = "_ALL_BLOCKS_";

	/**
	 * Constant that stand for a pattern that matches everything. Note: This
	 * pattern is not actually used, it serves as marker only.
	 */
	/* package */static final String ALLOW_EVERYTHING_PATTERN = ".*";

	/**
	 * Constant that stand for a pattern that matches nothing. Note: This
	 * pattern is not actually used, it serves as marker only.
	 */
	/* package */static final String DENY_EVERYTHING_PATTERN = "**";

	/**
	 * This map from (Block type X parameter name) to a list of pairs (allowed
	 * pattern, denied pattern). <code>null</code> values are stored to signal
	 * allow-all/deny-all patterns. Implementation would be way more elegant if
	 * there was pattern that match no string at all.
	 */
	private final TwoDimHashMap<String, String, PairList<Pattern, Pattern>> patterns = new TwoDimHashMap<String, String, PairList<Pattern, Pattern>>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "rule", description = "Add rule to be checked by the processor.", minOccurrences = 1)
	public void addRule(
			@AConQATAttribute(name = "type", description = "Defines block type "
					+ "this rule applies for. Use 'Reference.<type>' for library "
					+ "types. Omit attribute if rule "
					+ "applies for all block types.", defaultValue = ALL_BLOCKS_TYPE) String blockType,
			@AConQATAttribute(name = "param", description = "Defines parameter this "
					+ "rule applies for.") String parameterName,
			@AConQATAttribute(name = "allow", description = "Define legal expressions "
					+ "for this parameter. Omit attribute to allow "
					+ "all values. " + ConQATParamDoc.REGEX_PATTERN_DESC, defaultValue = ALLOW_EVERYTHING_PATTERN) String allowPatternString,
			@AConQATAttribute(name = "deny", description = "Define illegal expressions "
					+ "for this parameter. Omit attribute to deny "
					+ "no values. " + ConQATParamDoc.REGEX_PATTERN_DESC, defaultValue = DENY_EVERYTHING_PATTERN) String denyPatternString)
			throws ConQATException {

		PairList<Pattern, Pattern> pairList = patterns.getValue(blockType,
				parameterName);

		if (pairList == null) {
			pairList = new PairList<Pattern, Pattern>();
			patterns.putValue(blockType, parameterName, pairList);
		}

		Pattern allowPattern = createPattern(allowPatternString,
				ALLOW_EVERYTHING_PATTERN);

		Pattern denyPattern = createPattern(denyPatternString,
				DENY_EVERYTHING_PATTERN);

		pairList.add(allowPattern, denyPattern);
	}

	/**
	 * Create pattern from string. Returns <code>null</code> if the the pattern
	 * string equals the marker string.
	 */
	private Pattern createPattern(String patternString, String markerString)
			throws ConQATException {
		if (markerString.equals(patternString)) {
			return null;
		}

		return CommonUtils.compilePattern(patternString);
	}

	/** Check parameters of a block. */
	@Override
	protected void visitBlock(SimulinkBlock block, ISimulinkElement element) {

		// getParameterNames() also returns default parameters
		for (String parameterName : block.getParameterNames()) {
			String parameterValue = block.getParameter(parameterName);
			String type = block.getResolvedType();

			if (!assessParameterValue(parameterValue, ALL_BLOCKS_TYPE,
					parameterName)
					|| !assessParameterValue(parameterValue, type,
							parameterName)) {

				String message = "Parameter '" + parameterName
						+ "' has illegal value '" + parameterValue + "'.";

				attachFinding(message, element, block.getId());
			}
		}
	}

	/** Check if a parameter value is legal or not. */
	private boolean assessParameterValue(String value, String blockType,
			String parameterName) {

		PairList<Pattern, Pattern> patternList = patterns.getValue(blockType,
				parameterName);

		if (patternList == null) {
			return true;
		}

		for (int i = 0; i < patternList.size(); i++) {
			Pattern allowPattern = patternList.getFirst(i);
			Pattern denyPattern = patternList.getSecond(i);

			if (!isAllowed(allowPattern, value) || isDenied(denyPattern, value)) {
				return false;
			}

		}

		return true;
	}

	/** Checks if value is allowed. */
	private boolean isAllowed(Pattern allowPattern, String value) {
		if (allowPattern == null) {
			return true;
		}
		return allowPattern.matcher(value).matches();
	}

	/** Checks if value is denied. */
	private boolean isDenied(Pattern denyPattern, String value) {
		if (denyPattern == null) {
			return false;
		}
		return denyPattern.matcher(value).matches();
	}

	/** {@inheritDoc} */
	@Override
	protected String getKey() {
		return KEY;
	}
}
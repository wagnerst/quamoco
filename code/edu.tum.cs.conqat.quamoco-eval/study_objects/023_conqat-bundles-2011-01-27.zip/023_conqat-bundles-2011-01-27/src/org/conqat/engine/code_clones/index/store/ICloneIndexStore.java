/*--------------------------------------------------------------------------+
$Id: ICloneIndexStore.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.index.store;

import java.io.Serializable;
import java.util.List;

import org.conqat.lib.commons.collections.UnmodifiableList;
import org.conqat.lib.commons.digest.MD5Digest;
import org.conqat.engine.code_clones.index.Chunk;
import org.conqat.engine.persistence.store.StorageException;

/**
 * Interface for a clone index store. A clone index store is used to persist
 * chunk information collected and used during index-based clone detection.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: A2C76D0C22D85280B9B35B4B0A3F6876
 */
public interface ICloneIndexStore {

	/**
	 * Returns the object stored under the given key. If no object is stored,
	 * <code>null</code> should be returned.
	 */
	Serializable getOption(String key) throws StorageException;

	/**
	 * Stores an object under the given key. This is used to store certain clone
	 * detection options which have to be reused when updating data in the
	 * store.
	 */
	void setOption(String key, Serializable value)
			throws StorageException;

	/**
	 * Returns all stored {@link Chunk} objects for the given
	 * originId. Returns <code>null</code> if the file was not found.
	 */
	List<Chunk> getChunksByOrigin(String originId)
			throws StorageException;

	/**
	 * Returns the list of {@link Chunk}s stored for the given chunk
	 * hash. 
	 */
	UnmodifiableList<Chunk> getChunksByHash(MD5Digest chunkHash)
			throws StorageException;

	/**
	 * Inserts a batch of {@link Chunk}s. All chunks must belong to the same origin.
	 */
	void batchInsertChunks(List<Chunk> chunks)
			throws StorageException;

	/** Removes all chunks from the store which belong to the given originId name. */
	void removeChunks(String originId) throws StorageException;

	/**
	 * Closes this store. No operations should be performed on the store after
	 * calling this method.
	 */
	void close() throws StorageException;
}

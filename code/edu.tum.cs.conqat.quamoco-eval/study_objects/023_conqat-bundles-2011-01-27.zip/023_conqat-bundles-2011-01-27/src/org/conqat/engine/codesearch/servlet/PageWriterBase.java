/*--------------------------------------------------------------------------+
   $Id: PageWriterBase.java 32087 2010-12-22 21:03:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package org.conqat.engine.codesearch.servlet;

import static org.conqat.lib.commons.html.ECSSProperty.BACKGROUND_COLOR;
import static org.conqat.lib.commons.html.EHTMLElement.BODY;
import static org.conqat.lib.commons.html.EHTMLElement.HEAD;
import static org.conqat.lib.commons.html.EHTMLElement.HTML;
import static org.conqat.lib.commons.html.EHTMLElement.BR;
import static org.conqat.lib.commons.html.EHTMLElement.LINK;
import static org.conqat.lib.commons.html.EHTMLElement.TITLE;
import static org.conqat.lib.commons.html.EHTMLAttribute.HREF;
import static org.conqat.lib.commons.html.EHTMLAttribute.REL;
import static org.conqat.lib.commons.html.EHTMLAttribute.STYLE;
import static org.conqat.engine.codesearch.servlet.CSSMananger.DEFAULT_FONT;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.conqat.lib.commons.html.CSSDeclarationBlock;
import org.conqat.lib.commons.html.HTMLWriter;

public abstract class PageWriterBase extends HTMLWriter {

	private final String title;

	private static CSSDeclarationBlock WHITE_BODY = new CSSDeclarationBlock(
			DEFAULT_FONT, BACKGROUND_COLOR, "white");

	protected final HttpServletRequest request;

	public PageWriterBase(String title, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		super(response.getWriter(), CSSMananger.getInstance());
		this.title = title;
		this.request = request;
	}

	public void writePage() {
		openPage();
		writePageBody();
		closePage();
	}

	protected abstract void writePageBody();

	private void openPage() {
		openElement(HTML);

		openElement(HEAD);
		addClosedTextElement(TITLE, title);
		addClosedElement(LINK, REL, "SHORTCUT ICON", HREF, "TUM-icon.ico");
		closeElement(HEAD);

		openElement(BODY);
		addAttribute(STYLE, DEFAULT_FONT);
	}

	private void closePage() {
		closeElement(BODY);
		closeElement(HTML);
		close();
	}

	protected void addBR() {
		addClosedElement(BR);
	}
}

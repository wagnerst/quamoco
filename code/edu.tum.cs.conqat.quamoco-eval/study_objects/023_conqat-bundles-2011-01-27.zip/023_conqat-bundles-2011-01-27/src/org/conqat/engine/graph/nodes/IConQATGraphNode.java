/*--------------------------------------------------------------------------+
$Id: IConQATGraphNode.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.graph.nodes;

import org.conqat.engine.commons.node.IRemovableConQATNode;

/**
 * This is the most general interface for ConQATNodes in the hierarchy of the
 * ConQAT graph. A {@link IConQATGraphNode} is either a
 * {@link IConQATGraphInnerNode} or an {@link IConQATGraphVertex}.
 * <p>
 * This does not introduce new methods but only makes some return values more
 * concrete.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: A91EA0D690C19E5450ACF1640CC67A36
 */
public interface IConQATGraphNode extends IRemovableConQATNode {

	/** {@inheritDoc} */
	public IConQATGraphNode[] getChildren();

	/** {@inheritDoc} */
	public IConQATGraphInnerNode getParent();
}
package org.conqat.engine.code_clones.normalization.string;

import org.conqat.engine.resource.text.ITextElement;
import org.conqat.engine.resource.text.ITextResource;

import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.engine.code_clones.lazyscope.IElementProvider;
import org.conqat.engine.commons.pattern.PatternList;
import org.conqat.engine.commons.pattern.PatternTransformationList;

/**
 * Normalization for POS normalizing clone detection.
 * 
 * @author ladmin
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: 7A8B9E71CD73C3AB6D251F24E6E48386
 */
public class POSNormalization extends LineNormalization {

	/** Constructor */
	public POSNormalization(
			IElementProvider<ITextResource, ITextElement> inputProvider,
			PatternList removeConfig, PatternTransformationList replacements,
			boolean trimLines, boolean ignoreEmptyLines,
			boolean removeAllWhitespace) {
		super(inputProvider, removeConfig, replacements, trimLines,
				ignoreEmptyLines, removeAllWhitespace);
	}

	/** {@inheritDoc} */
	@Override
	protected String normalize(String posTag) {
		String[] parts = posTag.split("\t");
		CCSMAssert.isTrue(parts.length == 3, "Unexpected posTag format:'"
				+ posTag + "'");
		return parts[1];
	}

}

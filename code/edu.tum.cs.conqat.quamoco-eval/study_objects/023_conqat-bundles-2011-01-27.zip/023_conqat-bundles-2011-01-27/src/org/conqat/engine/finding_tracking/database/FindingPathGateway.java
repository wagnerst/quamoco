/*-----------------------------------------------------------------------+
 | org.conqat.engine.finding_tracking
 |                                                                       |
   $Id: FindingPathGateway.java 32461 2011-01-10 16:41:19Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package org.conqat.engine.finding_tracking.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.conqat.engine.commons.findings.Finding;
import org.conqat.engine.commons.findings.location.CodeLineLocation;
import org.conqat.engine.commons.findings.location.ElementLocation;
import org.conqat.engine.commons.findings.location.QualifiedNameLocation;

/**
 * Gateway for maintaining the finding path table.
 * 
 * @author Martin P�hlmann
 * @author $Author: juergens $
 * @version $Rev: 32461 $
 * @levd.rating RED Hash: 2A4A877A827376B1BCCE7E801E0B0C12
 */
public class FindingPathGateway extends AbstractGateway {

	/** The database table for finding paths. */
	/* package */static final String PATH_TABLE_NAME = "FINDING_PATH";

	/** Path ID column of a finding. */
	/* package */static final String PATH_ID = "PATH_ID";

	/** Location path column of a finding. */
	/* package */static final String PATH = "PATH";

	/** Type of the location. */
	/* package */static final String LOCATION_TYPE = "LOCATION_TYPE";

	/** Enumeration of location types. */
	/* package */static enum ELocationType {
		/** Corresponds to not supported LocationTypes */
		NOT_SUPPORTED(0),
		/** Corresponds to QualifiedNameLocation. */
		QUALIFIED_NAME(2);

		/** Integer value of the location. */
		private final int value;

		/** Constructor. */
		ELocationType(int value) {
			this.value = value;
		}

		// TODO (EJ) Clean up
		/** Returns the type of a location. */
		static ELocationType getType(ElementLocation location) {
			if (location instanceof ElementLocation
					|| location instanceof QualifiedNameLocation) {
				return ELocationType.QUALIFIED_NAME;
			}
			return ELocationType.NOT_SUPPORTED;
		}

		/** Returns the enumID of a location */
		/* package */int getID() {
			return this.value;
		}
	}

	/**
	 * Constructor. One can specify a path that is used to save filenames
	 * relatively, otherwise pass null.
	 */
	/* package */FindingPathGateway(Connection dbConnection)
			throws SQLException {
		super(dbConnection);
	}

	/** {@inheritDoc} */
	@Override
	protected String initTableSQL() {
		StringBuilder query = new StringBuilder();
		query.append("CREATE TABLE " + PATH_TABLE_NAME + " ");
		query.append("( ");
		query.append(PATH_ID + " INTEGER PRIMARY KEY, ");
		query.append(LOCATION_TYPE + " INTEGER, ");
		query.append(PATH + " VARCHAR(8000) ");
		query.append(");");

		return query.toString();
	}

	/**
	 * Looks in the database for the given path of this finding. If found it
	 * returns the PATH_ID, otherwise the filename is stored and a new PATH_ID
	 * is returned.
	 */
	/* package */int storeAndGetPathID(Finding finding) throws SQLException {
		// first check if the finding has an location attached
		if (finding.getLocations().size() == 0) {
			return 0;
		}

		// TODO Multilocation findings might need to be handled here
		ElementLocation location = finding.getLocations().get(0);

		ELocationType locationType = ELocationType.getType(location);

		// Check if we need to store a location at all?
		if (locationType.equals(ELocationType.NOT_SUPPORTED)) {
			return 0;
		}

		String locationPath = ((CodeLineLocation) location).getUniformPath();

		// check if the path already exists (most likely), could be cached
		PreparedStatement pathSelect = connection.prepareStatement("SELECT "
				+ PATH_ID + " FROM " + PATH_TABLE_NAME + " WHERE " + PATH
				+ " = ? AND " + LOCATION_TYPE + " = ? ;");
		pathSelect.setString(1, locationPath);
		pathSelect.setInt(2, locationType.getID());
		ResultSet result = pathSelect.executeQuery();

		// return the PATH_ID if found in the database
		if (result.next()) {
			return result.getInt(PATH_ID);
		}

		// Otherwise store the path in the database
		PreparedStatement pathInsert = connection
				.prepareStatement("INSERT INTO " + PATH_TABLE_NAME + " ("
						+ PATH_ID + "," + PATH + "," + LOCATION_TYPE
						+ ") VALUES (?, ?, ?);");
		int key = (int) keyProvider.getKey();
		pathInsert.setInt(1, key);
		pathInsert.setString(2, locationPath);
		if (locationType.getID() > 0) {
			pathInsert.setInt(3, locationType.getID());
		}
		pathInsert.executeUpdate();
		pathInsert.close();

		return key;
	}

	/** {@inheritDoc} */
	@Override
	protected String getPrimaryRow() {
		return PATH_ID;
	}

	/** {@inheritDoc} */
	@Override
	protected String getTableName() {
		return PATH_TABLE_NAME;
	}
}

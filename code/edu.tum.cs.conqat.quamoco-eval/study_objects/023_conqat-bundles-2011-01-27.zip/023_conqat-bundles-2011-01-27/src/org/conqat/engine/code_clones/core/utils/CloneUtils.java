/*--------------------------------------------------------------------------+
$Id: CloneUtils.java 32087 2010-12-22 21:03:01Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.code_clones.core.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.conqat.lib.commons.algo.Diff.Delta;
import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.collections.CollectionUtils;
import org.conqat.lib.commons.collections.HashedListMap;
import org.conqat.lib.commons.digest.Digester;
import org.conqat.lib.commons.region.Region;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.core.Unit;

/**
 * This class offers utility methods useful in the context of clone detection.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating GREEN Hash: FC92CC904D4ED61D430B08B471A7ADF2
 */
public class CloneUtils {

	/** Key under which list of units is stored */
	public static final String UNIT_LIST = "unit_list";

	/** Key under which delta is stored */
	public static final String EDIT_OPERATIONS = "edit_operations";

	/** Key under which clone class change type is stored */
	private static final String CHANGE_TYPE = "change_type";

	/** Key under which ancestor id is stored */
	private static final String ANCESTOR_ID = "ancestor_id";

	/** Constant that depicts the number unlimited */
	public static final int UNLIMITED = -1;

	/** Count the clones contained in a list of clone classes. */
	public static int countClones(List<CloneClass> cloneClasses) {
		int count = 0;
		for (CloneClass cloneClass : cloneClasses) {
			count += cloneClass.size();
		}
		return count;
	}

	/** Gets the siblings of a clone in its clone class */
	public static ArrayList<Clone> getSiblings(Clone clone) {
		ArrayList<Clone> siblings = new ArrayList<Clone>();
		for (Clone sibling : clone.getCloneClass().getClones()) {
			if (clone != sibling) {
				siblings.add(sibling);
			}
		}
		return siblings;
	}

	/**
	 * Computes the fingerprint for a collection of clones. If the clones have
	 * different fingerprints, a new fingerprint is created, else the common
	 * fingerprint is returned.
	 */
	public static String createFingerprint(Collection<Clone> clones) {
		CCSMAssert.isFalse(clones.isEmpty(),
				"Cannot create fingerprint for empty collection of clones");

		if (allFingerprintsEqual(clones)) {
			return CollectionUtils.getAny(clones).getFingerprint();
		}

		// as long as the fingerprints of the individual clones do not change,
		// we need to assure that the clone class fingerprint does not change
		// either. in order to compute a stable fingerprint for a clone class,
		// we thus need to establish a stable order in which clone fingerprints
		// are added to the clone class fingerprint. since we want to be
		// independent of clone filenames or clone positions in files, we
		// compute this order directly on the fingerprints.
		Set<String> fingerprints = new HashSet<String>();
		for (Clone clone : clones) {
			fingerprints.add(clone.getFingerprint());
		}

		return Digester.createMD5Digest(fingerprints);
	}

	/** Determines whether the fingerprints of all clones are equal. */
	private static boolean allFingerprintsEqual(Collection<Clone> clones) {
		String commonFingerprint = CollectionUtils.getAny(clones)
				.getFingerprint();
		for (Clone clone : clones) {
			if (!commonFingerprint.equals(clone.getFingerprint())) {
				return false;
			}
		}

		return true;
	}

	/** Determines whether one clone class covers another */
	public static boolean covers(CloneClass cover, CloneClass covered) {
		if (cover.size() < covered.size()) {
			return false;
		}

		boolean result = true;
		for (Clone coverClone : cover.getClones()) {
			boolean cloneCovered = false;
			for (Clone coveredClone : covered.getClones()) {
				if (covers(coverClone, coveredClone)) {
					cloneCovered = true;
					break;
				}
			}
			if (!cloneCovered) {
				result = false;
				break;
			}
		}

		return result;
	}

	/** Determines whether one clone covers another */
	public static boolean covers(Clone cover, Clone covered) {
		if (!sameElement(cover, covered)) {
			return false;
		}

		return cover.getStartLineInElement() <= covered.getStartLineInElement()
				&& cover.getLastLineInElement() >= covered
						.getLastLineInElement();
	}

	/** Determines whether two clones are in the same file */
	private static boolean sameElement(Clone cover, Clone covered) {
		return cover.getUniformPath().equals(covered.getUniformPath());
	}

	/** Determines whether two clones overlap */
	public static boolean overlap(Clone clone1, Clone clone2) {
		if (!sameElement(clone1, clone2)) {
			return false;
		}

		return regionFor(clone1).overlaps(regionFor(clone2));
	}

	/** Compute a region for a clone based on its line numbers */
	private static Region regionFor(Clone clone1) {
		return new Region(clone1.getStartLineInElement(), clone1
				.getLastLineInElement());
	}

	/** Creates a map from element to list of contained clones */
	public static HashedListMap<String, Clone> createFileMapping(
			List<CloneClass> cloneClasses) {
		return initElementMapping(cloneClasses,
				new HashedListMap<String, Clone>());
	}

	/**
	 * Store mapping from elements to clones in an existing map. This way, maps
	 * that are stored as fields in classes can be declared final, if they never
	 * change.
	 */
	public static HashedListMap<String, Clone> initElementMapping(
			List<CloneClass> cloneClasses,
			HashedListMap<String, Clone> clonesPerElement) {
		CCSMAssert.isTrue(clonesPerElement.areAllListsEmpty(),
				"Map is not empty");

		for (CloneClass cloneClass : cloneClasses) {
			for (Clone clone : cloneClass.getClones()) {
				clonesPerElement.add(clone.getUniformPath(), clone);
			}
		}
		return clonesPerElement;
	}

	/**
	 * Returns a list that is truncated after n clones. Use {@link #UNLIMITED}
	 * to switch off truncation.
	 */
	public static List<CloneClass> cloneClassesForFirstNClones(
			List<CloneClass> allCloneClasses, int maxCloneCount) {
		List<CloneClass> keptCloneClasses = new ArrayList<CloneClass>();

		int clonesSoFar = 0;
		for (CloneClass cloneClass : allCloneClasses) {
			if (maxCloneCount == CloneUtils.UNLIMITED
					|| clonesSoFar + cloneClass.size() <= maxCloneCount) {
				keptCloneClasses.add(cloneClass);
				clonesSoFar += cloneClass.size();
			}
		}

		return keptCloneClasses;
	}

	/** Return list of clone units, or <code>null</code>, if no list was stored */
	@SuppressWarnings("unchecked")
	public static List<Unit> getUnits(Clone clone) {
		return (List<Unit>) clone.getValue(UNIT_LIST);
	}

	/** Store list of units at a clone */
	public static void setUnits(Clone clone, List<Unit> cloneUnits) {
		clone.setValue(UNIT_LIST, cloneUnits);
		clone.setTransient(UNIT_LIST, true);
	}

	/** Return edit operations, or <code>null</code>, if no edit ops were stored */
	@SuppressWarnings("unchecked")
	public static Delta<Unit> getEditOperations(Clone clone) {
		return (Delta<Unit>) clone.getValue(EDIT_OPERATIONS);
	}

	/** Store edit operations since last change in a clone */
	public static void setEditOperations(Clone clone, Delta<Unit> delta) {
		clone.setValue(EDIT_OPERATIONS, delta);
		clone.setTransient(EDIT_OPERATIONS, true);
	}

	/** Return change type, or <code>null</code>, if none was found */
	public static ECloneClassChange getChangeType(CloneClass cloneClass) {
		return (ECloneClassChange) cloneClass.getValue(CHANGE_TYPE);
	}

	/** Store change type at clone class */
	public static void setChangeType(CloneClass cloneClass,
			ECloneClassChange change) {
		cloneClass.setValue(CHANGE_TYPE, change);
	}

	/** Store ancestor ID */
	public static void setAncestorId(Clone newClone, long id) {
		newClone.setValue(ANCESTOR_ID, id);
	}

	/** Retrieve ancestor ID */
	public static long getAncestorId(Clone clone) {
		return clone.getLong(ANCESTOR_ID);
	}

	/** Increment counter for a change type. */
	public static void incrementChangeTypeCounter(CloneClass cloneClass,
			ECloneClassChange changeType) {
		String key = changeType.name();
		int count = 0;
		if (cloneClass.containsValue(key)) {
			count = cloneClass.getInt(key);
		}
		count += 1;
		cloneClass.setValue(key, count);
	}

	/**
	 * Return change type count stored for change type, or 0, if no count was
	 * stored
	 */
	public static int getChangeTypeCounter(CloneClass cloneClass,
			ECloneClassChange changeType) {
		String key = changeType.name();
		if (cloneClass.containsValue(key)) {
			return cloneClass.getInt(key);
		}
		return 0;
	}

	/** Copy change type counts */
	public static void copyChangeTypeCounts(CloneClass to, CloneClass from) {
		for (ECloneClassChange changeType : ECloneClassChange.values()) {
			String key = changeType.name();
			if (from.containsValue(key)) {
				to.setValue(key, from.getValue(key));
			}
		}
	}

	/**
	 * Computes a set of strings that identifies gap positions for a clone
	 * class. Gap identifier contain uniform path and line number.
	 */
	public static Set<String> gapIdentifierFor(CloneClass cloneClass) {
		Set<String> gapIdentifiers = new HashSet<String>();

		for (Clone clone : cloneClass.getClones()) {
			String uniformPath = clone.getUniformPath();
			for (int gapPosition : clone.getGapPositions()) {
				int positionInFile = clone.getStartLineInElement()
						+ gapPosition;
				String gapIdentifier = uniformPath + ":" + positionInFile;
				gapIdentifiers.add(gapIdentifier);
			}
		}

		return gapIdentifiers;
	}

}
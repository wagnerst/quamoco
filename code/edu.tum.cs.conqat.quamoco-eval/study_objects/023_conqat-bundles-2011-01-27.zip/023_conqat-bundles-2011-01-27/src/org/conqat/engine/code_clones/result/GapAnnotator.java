package org.conqat.engine.code_clones.result;

import org.conqat.lib.commons.algo.Diff;
import org.conqat.lib.commons.algo.Diff.Delta;
import org.conqat.lib.commons.assertion.CCSMAssert;
import org.conqat.lib.commons.string.StringUtils;
import org.conqat.engine.code_clones.core.Clone;
import org.conqat.engine.code_clones.core.CloneClass;
import org.conqat.engine.code_clones.core.EEditOperation;
import org.conqat.engine.code_clones.corelocal.CloneUtils;
import org.conqat.engine.code_clones.detection.CloneDetectionResultElement;
import org.conqat.engine.core.core.AConQATProcessor;
import org.conqat.engine.core.core.ConQATException;

/**
 * {ConQAT.Doc}
 * 
 * @author ladmin
 * @author $Author: hummelb $
 * @version $Rev: 32087 $
 * @levd.rating RED Hash: BDCB66E3B80FB36422534EDA29A05A83
 */
@AConQATProcessor(description = "Annotates gaps in clone pairs")
public class GapAnnotator extends DetectionResultProcessorBase {

	/** {@inheritDoc} */
	@Override
	public CloneDetectionResultElement process() throws ConQATException {
		for (CloneClass cloneClass : detectionResult.getList()) {
			Clone[] clones = cloneClass.getClones().toArray(new Clone[] {});
			CCSMAssert
					.isTrue(clones.length >= 2, "Singleton clone class found");
			Clone representative = clones[0];
			Clone other = clones[1];

			// TODO (BH): It would be nicer to switch to CloneUtils.getCloneContent(Clone, ITextElement)
			String contentRepresentative = CloneUtils
					.getCloneContentFromLocalFileSystem(representative);
			String contentOther = CloneUtils.getCloneContentFromLocalFileSystem(other);

			Delta<String> delta = Diff.computeDelta(StringUtils
					.splitLines(contentRepresentative), StringUtils
					.splitLines(contentOther));
			for (int editPosition = 0; editPosition < delta.getSize(); editPosition++) {
				int gapLocation = Math.abs(delta.getPosition(editPosition)) - 1;
				representative.addGap(gapLocation, EEditOperation.CHANGE);
				other.addGap(gapLocation, EEditOperation.CHANGE);
			}
		}

		return detectionResult;
	}

}

/*--------------------------------------------------------------------------+
$Id: ProjectParser9_10.java 32162 2010-12-22 23:46:11Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package org.conqat.engine.dotnet.resource.project;

import org.conqat.engine.resource.text.ITextElement;

import org.conqat.lib.commons.xml.IXMLElementProcessor;
import org.conqat.engine.core.core.ConQATException;
import org.conqat.engine.core.logging.IConQATLogger;

/**
 * Parses VS.NET 2005 and VS.NET 2008 projects.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 32162 $
 * @levd.rating GREEN Hash: 2683981240C1A5F145AE02A4004A775B
 */
/* package */class ProjectParser9_10 extends ProjectParser {

	/** Constructor */
	public ProjectParser9_10(IConQATLogger logger) {
		super(logger);
	}

	/** {@inheritDoc} */
	@Override
	protected ProjectReader9_10 createReader(ITextElement projectElement)
			throws ConQATException {
		return new ProjectReader9_10(projectElement.getTextContent(),
				projectElement.getLocation());
	}

	/** Xml reader that performs actual XML processing. */
	private class ProjectReader9_10 extends ProjectElementReaderBase {

		/** Creates a {@link ProjectParser9_10} for a project */
		public ProjectReader9_10(String projectContent, String projectLocation) {
			super(projectContent, projectLocation);
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectXmlElement, ConQATException> createProcessor() {
			return new ItemGroupProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectXmlElement, ConQATException> createAssemblyNameProcessor() {
			return new AssemblyNameProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectXmlElement, ConQATException> createRelativeAssemblyPathProcessor() {
			return new PropertyGroupProcessor();
		}

		/** {@inheritDoc} */
		@Override
		protected IXMLElementProcessor<EProjectXmlElement, ConQATException> createOutputTypeProcessor() {
			return new OutputTypeProcessor();
		}

		/** Processor for ItemGroup elements */
		private class ItemGroupProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.ItemGroup;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				processChildElements(new CompileProcessor());
			}
		}

		/** Processor for PropertyGroup elements */
		private class PropertyGroupProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.PropertyGroup;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {

				// check if the current PropertyGroup is the one used in the
				// build configuration
				String condition = getStringAttribute(EProjectXmlAttribute.Condition);

				// check if we are in the default PropertyGroup
				if (condition == null || condition.equals("")) {

					// find the name and type of the assembly
					processChildElements(new OutputTypeProcessor());
					processChildElements(new AssemblyNameProcessor());

					// the arguments defined here are used if the used build
					// configuration does not override them
					processChildElements(new OutputPathProcessor());
				} else {

					// we are not interested in conditions other than "=="
					String conditionSeparator = "==";
					if (!condition.contains(conditionSeparator)) {
						return;
					}

					String[] expressionParts = condition
							.split(conditionSeparator);
					String currentConfiguration = expressionParts[1].trim();

					// check if the propertyGroup is the one for the used
					// configuration and platform
					String config = "'" + configuration.getName() + "|"
							+ configuration.getPlatform() + "'";
					if (currentConfiguration.equals(config)) {
						processChildElements(new OutputPathProcessor());
					}
				}
			}
		}

		/** Processor for OutputPath elements */
		private class OutputPathProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.OutputPath;
			}

			/** {@inheritDoc} */
			public void process() {
				outputPath = getText();
			}
		}

		/** Processor for ExecutableGroup elements */
		private class AssemblyNameProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.AssemblyName;
			}

			/** {@inheritDoc} */
			public void process() {
				assemblyName = getText();
			}
		}

		/** Processor for ExecutableGroup elements */
		private class OutputTypeProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.OutputType;
			}

			/** {@inheritDoc} */
			public void process() {
				outputType = getText();
			}
		}

		/** Processor for Compile elements */
		private class CompileProcessor implements
				IXMLElementProcessor<EProjectXmlElement, ConQATException> {

			/** {@inheritDoc} */
			public EProjectXmlElement getTargetElement() {
				return EProjectXmlElement.Compile;
			}

			/** {@inheritDoc} */
			public void process() {
				relativeSourceElementNames
						.add(getStringAttribute(EProjectXmlAttribute.Include));
			}
		}
	}
}
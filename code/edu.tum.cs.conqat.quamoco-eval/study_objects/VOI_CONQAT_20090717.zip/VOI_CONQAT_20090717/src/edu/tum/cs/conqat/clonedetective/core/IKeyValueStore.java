package edu.tum.cs.conqat.clonedetective.core;

import edu.tum.cs.commons.collections.UnmodifiableList;

// TODO (EJ) Should we use a standard interface here? Or should we even unify it with IConQATNode?
/**
 * Interfaces for classes that allow storage of arbitrary key-value pairs.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 22020 $
 * @levd.rating YELLOW Rev: 22020
 */
public interface IKeyValueStore {

	/** Returns the id of this store */
	public int getId();

	/** Stores a value in the {@link CloneClass} by using a keyword. */
	public void setValue(String key, Object value);

	/** Gets a value */
	public Object getValue(String key);

	/** Checks whether a value is stored under this key */
	public boolean containsValue(String key);

	/**
	 * Get a sorted list of the keys stored. Each key is guaranteed to only
	 * appear once. Keys are sorted in lexical order.
	 */
	public UnmodifiableList<String> getKeyList();

	/** Gets an int value */
	public int getInt(String key);

	/** Gets a string value */
	public String getString(String key);

	/** Determines whether a value is transient. Default value is false. */
	public boolean getTransient(String key);

	/** Stores the transient flag for a key */
	public void setTransient(String key, boolean value);
}
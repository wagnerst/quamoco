/*--------------------------------------------------------------------------+
   $Id: PatternListDef.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.pattern;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Processor used for defining a pattern list.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "Defines a pattern list.")
public class PatternListDef extends ConQATProcessorBase {

	/** Underlying pattern list. */
	private final PatternList patternList = new PatternList();

	/** Insert a new pattern. */
	@AConQATParameter(name = "pattern", description = "Definition of a pattern.")
	public void addPattern(
			@AConQATAttribute(name = "regex", description = ConQATParamDoc.REGEX_PATTERN_DESC)
			String regex) throws ConQATException {

		try {
			patternList.add(Pattern.compile(regex));
		} catch (PatternSyntaxException e) {
			throw new ConQATException("Invalid pattern: " + regex + " ("
					+ e.getMessage() + ")");
		}
	}

	/** Insert a new pattern list. */
	@AConQATParameter(name = "pattern-list", description = "Takes all entries of a pattern list.")
	public void addPatternList(
			@AConQATAttribute(name = "list", description = "The referenced pattern list.")
			PatternList list) {
		patternList.addAll(list);
	}

	/** Does not really process anything, but just returns the created list. */
	public PatternList process() {
		return patternList;
	}
}

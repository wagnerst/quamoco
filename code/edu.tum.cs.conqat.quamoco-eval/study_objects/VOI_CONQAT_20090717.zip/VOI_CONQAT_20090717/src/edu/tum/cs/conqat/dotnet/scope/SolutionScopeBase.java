/*--------------------------------------------------------------------------+
   $Id: SolutionScopeBase.java 18793 2009-03-08 14:35:33Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.scope.project.ProjectFileParser;
import edu.tum.cs.conqat.dotnet.scope.solution.SolutionFileParser;
import edu.tum.cs.conqat.dotnet.scope.solution.SolutionFileParser.EFormatVersion;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.filesystem.scope.FileSystemElement;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.conqat.sourcecode.scope.SourceCodeElement;
import edu.tum.cs.conqat.sourcecode.scope.SourceCodeElementFactory;
import edu.tum.cs.scanner.ELanguage;

/**
 * Base class for solution scopes.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 18793 $
 * @levd.rating GREEN Rev: 18793
 */
public abstract class SolutionScopeBase extends ConQATProcessorBase {

	/** Language of the files contained in the solution scope */
	private ELanguage language;

	/**
	 * Patterns that govern which source files are included. If null, all source
	 * files from a solution are included
	 */
	private PatternList sourceIncludePatterns = null;

	/**
	 * Patterns that govern which source files are excluded. If null, no source
	 * files are excluded. Exclusion has priority over inclusion.
	 */
	private PatternList sourceExcludePatterns = null;

	/**
	 * Patterns that govern which project files are included. If null, all
	 * project files from a solution are included
	 */
	private PatternList projectIncludePatterns = null;

	/**
	 * Patterns that govern which project files are excluded. If null, no
	 * project files are excluded. Exclusion has priority over inclusion.
	 */
	private PatternList projectExcludePatterns = null;

	/**
	 * Encoding that gets used for parsing of VS.NET project files, or
	 * <code>null</code>, if default encoding is to be used.
	 */
	private String encoding = null;

	/** ConQAT Parameter */
	@AConQATParameter(name = "include-source", description = ""
			+ "Patterns that govern which source files are included.", minOccurrences = 0, maxOccurrences = 1)
	public void setSourceIncludePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "If not set, all source files from a solution are included") PatternList sourceIncludePatterns) {
		this.sourceIncludePatterns = sourceIncludePatterns;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "exclude-source", description = ""
			+ "Patterns that govern which source files are excluded. Exclusion has preference over inclusion.", minOccurrences = 0, maxOccurrences = 1)
	public void setSourceExcludePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "If not set, no source files from a solution are excluded") PatternList sourceExcludePatterns) {
		this.sourceExcludePatterns = sourceExcludePatterns;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "include-projects", description = ""
			+ "Patterns that govern which project files are included.", minOccurrences = 0, maxOccurrences = 1)
	public void setProjectIncludePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "If not set, all project files from a solution are included") PatternList projectIncludePatterns) {
		this.projectIncludePatterns = projectIncludePatterns;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "exclude-projects", description = ""
			+ "Patterns that govern which project files are excluded. Exclusion has preference over inclusion.", minOccurrences = 0, maxOccurrences = 1)
	public void setProjectExcludePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "If not set, no project files from a solution are excluded") PatternList projectExcludePatterns) {
		this.projectExcludePatterns = projectExcludePatterns;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "language", minOccurrences = 1, maxOccurrences = 1, description = "Define programming language.")
	public void setLanguage(
			@AConQATAttribute(name = "name", description = ""
					+ "A programming language of enum type edu.tum.cs.scanner.ELanguage") ELanguage language) {

		this.language = language;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "encoding", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "XML Encoding of the XML project files.")
	public void setEncoding(
			@AConQATAttribute(name = "name", description = "Use any value that can also be used in as XML encoding attribute."
					+ "If not specified, parser uses default encoding") String encoding) {
		this.encoding = encoding;
	}

	/** {@inheritDoc} */
	public ISourceCodeElement process() throws ConQATException {
		SourceCodeElement scope = new SourceCodeElement("", language);

		try {
			String solutionDir = determineRootDirectory().getCanonicalPath();
			SourceCodeElementFactory factory = new SourceCodeElementFactory(
					language);
			FileSystemElement root = factory.create(solutionDir);
			scope.addChild(root);

			Iterable<String> sourceFiles = determineSourceFiles();
			sourceFiles = canonicalize(sourceFiles);
			for (String sourceFile : sourceFiles) {
				FileLibrary.getInstance().insertFile(root,
						relativePath(solutionDir, sourceFile), factory);
			}

			return scope;
		} catch (IOException e) {
			throw new ConQATException("Problems creating solution scope: "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Template method that allows deriving classes to return the root directory
	 * under which all solution files reside.
	 * 
	 * @throws ConQATException
	 *             if root directory cannot be determined
	 */
	protected abstract File determineRootDirectory() throws ConQATException;

	/**
	 * Canonicalizes a list of file names. This is necessary to avoid multiple,
	 * syntactically different entries that point to the same physical file.
	 * 
	 * @param filenames
	 *            List of file names that gets canonicalized
	 * 
	 * @return Set of canonicalized filenames
	 * 
	 * @throws IOException
	 *             If canonicalization fails.
	 */
	private Set<String> canonicalize(Iterable<String> filenames)
			throws IOException {
		Set<String> canonicalFilenames = new HashSet<String>();

		for (String filename : filenames) {
			canonicalFilenames.add(new File(filename).getCanonicalPath());
		}

		return canonicalFilenames;
	}

	/**
	 * Template method that allows deriving classes to return the list of source
	 * files.
	 * 
	 * @throws ConQATException
	 *             if source files cannot be determined
	 */
	protected abstract List<String> determineSourceFiles()
			throws ConQATException;

	/**
	 * Computes a relative file name.
	 * 
	 * @param workingDir
	 *            Directory relative to which filename gets computed
	 * @param filename
	 *            File for which relative gets computed
	 * @return Path from working directory to file
	 */
	private String relativePath(String workingDir, String filename) {
		String relativeFilename = filename.substring(workingDir.length());
		if (relativeFilename.startsWith(File.separator)) {
			relativeFilename = relativeFilename.substring(1);
		}
		return relativeFilename;
	}

	/**
	 * Gets those source files from a solution file that are contained in this
	 * scope.
	 * 
	 * @throws ConQATException
	 *             if the format of the solution file is unknown or if the
	 *             solution file cannot be read.
	 */
	protected List<String> parseSolutionFile(File solutionFile)
			throws ConQATException {
		List<String> sourceFiles = new ArrayList<String>();

		SolutionFileParser solutionParser = new SolutionFileParser();
		EFormatVersion solutionFormat = solutionParser
				.checkSolutionFileFormat(solutionFile);

		for (String projectFilename : solutionParser.parse(solutionFile)) {
			if (projectFileContained(projectFilename)) {
				getLogger().debug("\tParsing project file: " + projectFilename);
				parseProjectFile(sourceFiles, solutionFormat, projectFilename);
			} else {
				getLogger()
						.debug("\tExcluded project file: " + projectFilename);
			}
		}

		return sourceFiles;
	}

	/**
	 * Gets those source files from a project file, that are included by the
	 * source- and project level include and exclude {@link PatternList}s
	 */
	private void parseProjectFile(List<String> sourceFiles,
			EFormatVersion solutionFormat, String projectFilename) {
		ProjectFileParser projectParser = ProjectFileParser
				.create(solutionFormat);
		projectParser.setEncoding(encoding);

		List<String> sourceFileNames = null;

		try {
			sourceFileNames = projectParser.parse(new File(projectFilename));
		} catch (ConQATException e) {
			getLogger().warn(
					"Could not parse project file: " + projectFilename + ": "
							+ e.getMessage());
			return;
		}

		for (String sourceFilename : sourceFileNames) {
			if (sourceFileContained(sourceFilename)) {
				sourceFiles.add(sourceFilename);
				getLogger()
						.debug("\t\tIncluded source file: " + sourceFilename);
			} else {
				getLogger()
						.debug("\t\tExcluded source file: " + sourceFilename);
			}
		}

	}

	/**
	 * Tests whether a project filename is contained in the scope by evaluating
	 * the project-level include and exclude {@link PatternList}s.
	 */
	private boolean projectFileContained(String projectFilename) {
		if (projectIncludePatterns != null
				&& !projectIncludePatterns.matchesAny(projectFilename)) {
			return false;
		}
		if (projectExcludePatterns != null
				&& projectExcludePatterns.matchesAny(projectFilename)) {
			return false;
		}
		return true;
	}

	/**
	 * Tests whether a source filename is contained in the scope by evaluating
	 * the source-level include and exclude {@link PatternList}s.
	 */
	private boolean sourceFileContained(String sourceFilename) {
		if (sourceIncludePatterns != null
				&& !sourceIncludePatterns.matchesAny(sourceFilename)) {
			return false;
		}
		if (sourceExcludePatterns != null
				&& sourceExcludePatterns.matchesAny(sourceFilename)) {
			return false;
		}
		return true;
	}

}

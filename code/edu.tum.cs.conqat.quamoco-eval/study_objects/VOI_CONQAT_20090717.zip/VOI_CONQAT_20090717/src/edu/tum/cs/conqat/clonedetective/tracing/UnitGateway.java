package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.IUnit;
import edu.tum.cs.conqat.clonedetective.normalization.statement.StatementUnit;
import edu.tum.cs.conqat.core.ConQATException;

// TODO (EJ) currently, units are set fixedly to statement units. Store type of unit 
// as well and instantiate appropriately. 
/**
 * Stores the source code in form of lists of normalized units in the database.
 * The units can be retrieved for a timestamp.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 21458 $
 * @levd.rating RED Rev:
 */
public class UnitGateway extends DatabaseBase {

	/** Provisorial table name */
	public static String TABLE_NAME = "CloneDetectionUnits";

	/**  */
	private final String TIMESTAMP = "TIMESTAMP";
	/**  */
	private final String START_LINE_IN_FILE = "START_LINE_IN_FILE";
	/**  */
	private final String ORIGIN = "ORIGIN";
	/**  */
	private final String COVERED_LINES = "COVERED_LINES";
	/**  */
	private final String INDEX_IN_FILE = "INDEX_IN_FILE";
	/**  */
	private final String CONTENT = "CONTENT";

	/** Constructor */
	public UnitGateway(Connection dbConnection, String tableName) {
		super(dbConnection, tableName);
	}

	/** {@inheritDoc} */
	@Override
	protected String createCreateTableString() {
		StringBuilder result = new StringBuilder();
		result.append("CREATE TABLE " + tableName);
		result.append(" (" + TIMESTAMP + " BIGINT, " + START_LINE_IN_FILE
				+ " INT, " + ORIGIN + " VARCHAR, " + COVERED_LINES + " INT, "
				+ INDEX_IN_FILE + " INT, " + CONTENT + " VARCHAR) ");
		return result.toString();
	}

	/** Performs a batch insertion of the units of a system version */
	public void storeUnits(Date timeStamp,
			HashedListMap<String, IUnit> unitsPerOrigin, String rootOrigin)
			throws SQLException, ConQATException {

		// prepare statement
		Statement stmt = dbConnection.createStatement();
		for (String relativeOrigin : unitsPerOrigin.getKeys()) {
			List<IUnit> units = unitsPerOrigin.getList(relativeOrigin);
			for (IUnit unit : units) {
				String insertSql = createInsertSql(timeStamp, unit, rootOrigin);
				stmt.addBatch(insertSql);
			}
		}

		// execute statement
		DatabaseUtils.executeStatement(stmt);
	}

	/**
	 * Create SQL string to insert the units of a single file into the db
	 * 
	 * @param rootOrigin
	 */
	private String createInsertSql(Date timeStamp, IUnit unit, String rootOrigin) {
		StringBuilder result = new StringBuilder();
		result.append("INSERT INTO " + tableName + " (");

		result.append(TIMESTAMP + ", ");
		result.append(START_LINE_IN_FILE + ", ");
		result.append(ORIGIN + ", ");
		result.append(COVERED_LINES + ", ");
		result.append(INDEX_IN_FILE + ", ");
		result.append(CONTENT);

		result.append(") VALUES (");

		result.append(timeStamp.getTime());
		result.append(", " + unit.getStartLineInFile());
		String origin = StringUtils.stripPrefix(rootOrigin, unit.getOriginId());
		result.append(", '" + origin + "'");
		result.append(", " + unit.getCoveredLines());
		result.append(", " + unit.getIndexInFile());
		result.append(", '" + unit.getContent() + "'");
		result.append(")");

		return result.toString();
	}

	/**
	 * Returns latest stored timestamp. Returns null, if no timestamp could be
	 * found.
	 */
	public Date getLatestTimestamp() throws SQLException {
		ResultSet result = DatabaseUtils.executeQuery(dbConnection,
				createSelectLatestTimestampSql());
		if (result.next()) {
			return new Date(result.getLong("TIMESTAMP"));
		}
		return null;
	}

	/**
	 * Returns the second latest stored timestamp. Returns null, if no second
	 * latest timestamp could be found.
	 */
	public Date getSecondLatestTimestamp() throws SQLException {
		ResultSet result = DatabaseUtils.executeQuery(dbConnection,
				createSelectLatestTimestampSql());
		if (result.next() && result.next()) {
			return new Date(result.getLong("TIMESTAMP"));
		}
		return null;
	}

	/** Create SQL string for selection of latest timestamp. */
	private String createSelectLatestTimestampSql() {
		StringBuilder result = new StringBuilder();
		result.append("SELECT Distinct TIMESTAMP from " + tableName);
		result.append(" ORDER BY TIMESTAMP DESC");
		return result.toString();
	}

	/** Get map with units for a certain timestamp */
	public Map<String, IUnit[]> getUnitsFor(Date timestamp) throws SQLException {
		if (timestamp == null) {
			return null;
		}

		Map<String, IUnit[]> unitsMap = new HashMap<String, IUnit[]>();
		ResultSet result = DatabaseUtils.executeQuery(dbConnection,
				createSelectUnitsSql(timestamp));

		HashedListMap<String, IUnit> unitsPerOrigin = new HashedListMap<String, IUnit>();
		while (result.next()) {

			int startLineInFile = result.getInt(START_LINE_IN_FILE);
			String origin = result.getString(ORIGIN);
			int coveredLines = result.getInt(COVERED_LINES);
			int indexInFile = result.getInt(INDEX_IN_FILE);
			String content = result.getString(CONTENT);
			IUnit unit = new StatementUnit(startLineInFile, origin, content,
					coveredLines, indexInFile);

			unitsPerOrigin.add(origin, unit);
		}

		for (String origin : unitsPerOrigin.getKeys()) {
			unitsMap.put(origin, unitsPerOrigin.getList(origin).toArray(
					new IUnit[] {}));
		}

		return unitsMap;
	}

	/** Create SQL string for selection of all entries for one timestamp */
	private String createSelectUnitsSql(Date timestamp) {
		StringBuilder result = new StringBuilder();
		result.append("SELECT * from " + tableName);
		result.append(" WHERE TIMESTAMP = " + timestamp.getTime());
		return result.toString();
	}
}

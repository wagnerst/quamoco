/*--------------------------------------------------------------------------+
   $Id: StatementUnit.java 22022 2009-07-16 09:38:18Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.statement;

import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.UnitBase;
import edu.tum.cs.conqat.clonedetective.normalization.token.TokenUnit;

/**
 * This class implements a unit for lists of tokens that represent statements.
 * 
 * @author Uwe Hermann
 * @author $Author: juergens $
 * 
 * @version $Revision: 22022 $
 * @levd.rating RED Rev: 
 */
public class StatementUnit extends UnitBase {

	/** List of tokens this statement comprises. */
	private TokenUnit[] tokens;

	// TODO (EJ) Unused?
	/**
	 * Default constructor. Create a new statement unit from a list of tokens.
	 * <p>
	 * Tokens are not stored per default, since storage requires a lot of memory
	 * during clone detection.
	 */
	public StatementUnit(List<TokenUnit> tokens, int indexInFile) {
		this(tokens, false, indexInFile);
	}
	
	/** Create new StatementUnit */
	public StatementUnit(int startLineInFile, String originId, String content,
			int coveredLines, int indexInFile) {
		super(startLineInFile, originId, content, coveredLines, indexInFile);
	}

	/**
	 * Constructor that allows storage of token list.
	 * <p>
	 * Caution: If {@link StatementUnit} is used during clone detection by the
	 * suffix tree, storage of token list requires a lot of memory!
	 * 
	 * @param tokenList
	 *            List of tokens the {@link StatementUnit} comprises
	 * @param storeTokens
	 *            Flag that determines whether list is stored
	 */
	public StatementUnit(List<TokenUnit> tokenList, boolean storeTokens,
			int indexInFile) {
		super(tokenList.get(0).getStartLineInFile(), tokenList.get(0)
				.getOriginId(), createContent(tokenList),
				computeCoveredLines(tokenList), indexInFile);
		if (storeTokens) {
			this.tokens = tokenList.toArray(new TokenUnit[] {});
		}
	}

	/**
	 * Computes the number of lines covered by the list of tokens. Since we
	 * don't know the number of lines a token covers, we have to compute it from
	 * the tokens' start positions. We assume that the last token does not leave
	 * the line it starts on.
	 * <p>
	 * Since we call this method from within the call to the superclass
	 * constructor, it must be static.
	 */
	private static int computeCoveredLines(List<TokenUnit> tokens) {
		int firstTokenLine = tokens.get(0).getStartLineInFile();
		int lastTokenLine = tokens.get(tokens.size() - 1).getStartLineInFile();
		return lastTokenLine - firstTokenLine + 1;
	}

	/**
	 * Creates unit content string from a token list
	 * <p>
	 * Since we call this method from within the call to the superclass
	 * constructor, it must be static.
	 */
	private static String createContent(List<TokenUnit> tokens) {
		StringBuilder builder = new StringBuilder();
		for (TokenUnit token : tokens) {
			builder.append(token.getContent());
		}

		return builder.toString();
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return getContent() + " [" + getOriginId() + "(" + getStartLineInFile()
				+ ")][index:" + getIndexInFile() + "]";
	}

	/**
	 * Gets stored tokens.
	 * 
	 * @throws IllegalStateException,
	 *             if underlying tokens have not been stored
	 */
	public TokenUnit[] getTokens() {
		assertTokensStored();

		return tokens;
	}

	/**
	 * Gets start offset of {@link StatementUnit}
	 * 
	 * @throws IllegalStateException,
	 *             if underlying tokens have not been stored
	 */
	public int getStartOffset() {
		assertTokensStored();
		return tokens[0].getOffset();
	}

	/**
	 * Gets offset of the last character covered by this {@link StatementUnit}.
	 * This method is rather inaccurate, since the content of the token unit has
	 * been normalized
	 * 
	 * @throws IllegalStateException,
	 *             if underlying tokens have not been stored
	 */
	public int getEndOffset() {
		assertTokensStored();
		TokenUnit lastToken = tokens[tokens.length - 1];
		return lastToken.getOffset() + lastToken.getContent().length();
	}

	/** Throws an {@link IllegalStateException}, if tokens have not been stored */
	private void assertTokensStored() {
		if (tokens == null) {
			throw new IllegalStateException(
					"In order to access the start offset, StatementUnit must store its tokens. "
							+ "(Set storeTokens flag in constructor)");
		}
	}

}
/*--------------------------------------------------------------------------+
   $Id: CloneBase.java 22030 2009-07-16 09:50:09Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import static edu.tum.cs.commons.string.StringUtils.CR;
import static edu.tum.cs.commons.string.StringUtils.TWO_SPACES;

import java.util.Date;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.string.StringUtils;

/**
 * Base class for clones.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 22030 $
 * @levd.rating YELLOW Rev: 22020
 */
public abstract class CloneBase extends LazyKeyValueStoreBase implements IClone {

	/** {@link CloneClass} this clone belongs to */
	private final CloneClass cloneClass;

	/** Id of the element this clone stems from */
	private String origin;

	/** Fingerprint of clone */
	private final String fingerprint;

	/** Birth timestamp */
	private Date birth;

	/** Death timestamp */
	private Date death;

	/** Timestamp fingerprint was last modified */
	private Date fingerprintLastModified;

	/** Constructor */
	protected CloneBase(int id, CloneClass cloneClass, String origin,
			String fingerprint) {
		super(id);

		CCSMAssert.isFalse(origin == null,
				"Must not feed empty origin into clone");

		this.cloneClass = cloneClass;
		this.origin = origin;

		// We use the Java string pool here for several reasons
		// - during clone detection, many clones can be created
		// - all fingerprints of non-gapped clones in same clone class are equal
		// (but created as different instances)
		this.fingerprint = fingerprint.intern();
	}

	/** {@inheritDoc} */
	public CloneClass getCloneClass() {
		return cloneClass;
	}

	/** {@inheritDoc} */
	public String getOrigin() {
		return origin;
	}

	/** {@inheritDoc} */
	public String getFingerprint() {
		return fingerprint;
	}

	/**
	 * Two clones are considered equal, if they describe the same region of code
	 * in the same file with the same gaps.
	 */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof IClone)) {
			return false;
		}

		IClone other = (IClone) obj;

		// compare origins
		if (!getOrigin().equals(other.getOrigin())) {
			return false;
		}

		// compare start lines
		if (getStartLineInFile() != other.getStartLineInFile()) {
			return false;
		}

		// compare length
		if (getLengthInFile() != other.getLengthInFile()) {
			return false;
		}

		// compare gaps
		if (gapCount() != other.gapCount()) {
			return false;
		}
		for (int gapPosition : getGapPositions()) {
			if (!getGapTypeAt(gapPosition).equals(
					other.getGapTypeAt(gapPosition))) {
				return false;
			}
		}

		// if code reaches here, clones are equal
		return true;
	}

	/**
	 * Returns the hash code based on the Origin, the start and length. Gap
	 * information is ignored.
	 */
	@Override
	public int hashCode() {
		return (getOrigin().hashCode() * 13 + getStartLineInFile()) * 17
				+ getLengthInFile();
	}

	/** {@inheritDoc} */
	public int getLastLineInFile() {
		return getStartLineInFile() + getLengthInFile() - 1;
	}

	/** {@inheritDoc} */
	public int getLastUnitInFile() {
		return getStartUnitIndexInFile() + getLengthInUnits() - 1;
	}

	/** {@inheritDoc} */
	public EEditOperation getGapTypeAt(int lineOffset) {
		return EEditOperation.NONE;
	}

	/** {@inheritDoc} */
	public boolean containsGaps() {
		return false;
	}

	/** {@inheritDoc} */
	public int gapCount() {
		return 0;
	}

	/** {@inheritDoc} */
	public int getDeltaInUnits() {
		return 0;
	}

	/** {@inheritDoc} */
	public UnmodifiableList<Integer> getGapPositions() {
		return CollectionUtils.emptyList();
	}

	/**
	 * Sets the origin. This method is used in CloneInspector if a user decides
	 * to relocate his source files.
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}

	/** String representation of the essential clone data. */
	@Override
	public String toString() {
		String indent = TWO_SPACES;

		String result = "Clone [" + CR;
		result += indent + "lengthInFile=" + getLengthInFile() + CR;
		result += indent + "startLineInFile=" + getStartLineInFile() + CR;
		result += indent + "origin=" + getOrigin() + CR;
		result += toStringHook(indent);
		result += "]" + CR;

		return result;
	}

	/**
	 * This method allows deriving classes to insert information into the
	 * <code>toString()</code> method.
	 * 
	 * @param indent
	 *            Space by which every new line should be indented
	 */
	protected String toStringHook(String indent) {
		return StringUtils.EMPTY_STRING;
	}

	/** {@inheritDoc} */
	public Date getBirth() {
		return birth;
	}

	/** {@inheritDoc} */
	public Date getDeath() {
		return death;
	}

	/** {@inheritDoc} */
	public void setBirth(Date birth) {
		this.birth = birth;
	}

	/** {@inheritDoc} */
	public void setDeath(Date death) {
		this.death = death;
	}

	/** {@inheritDoc} */
	public void setFingerprintLastModified(Date timestamp) {
		this.fingerprintLastModified = timestamp;
	}

	/** {@inheritDoc} */
	public Date getFingerprintLastModified() {
		return fingerprintLastModified;
	}
}
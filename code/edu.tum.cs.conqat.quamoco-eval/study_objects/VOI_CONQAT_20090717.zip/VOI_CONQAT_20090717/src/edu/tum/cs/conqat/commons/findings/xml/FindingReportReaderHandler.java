/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingReportReaderHandler.java 22035 2009-07-16 10:28:06Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.xml;

import java.io.IOException;
import java.text.ParseException;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.commons.color.ColorUtils;
import edu.tum.cs.commons.enums.EnumUtils;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.commons.findings.EFindingType;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingCategory;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.location.CodeLineLocation;
import edu.tum.cs.conqat.commons.findings.location.CodeRegionLocation;
import edu.tum.cs.conqat.commons.findings.location.ELocationType;
import edu.tum.cs.conqat.commons.findings.location.FileLocation;
import edu.tum.cs.conqat.commons.findings.location.QualifiedNameLocation;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Code for reading finding reports. This is package visible and only used by
 * the {@link FindingReportIO} class.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 22035 $
 * @levd.rating YELLOW Rev: 22035
 */
/* package */class FindingReportReaderHandler extends DefaultHandler {

	/** Mapping from element names to element enum values */
	private static final Map<String, EFindingElements> ELEMENTS_BY_NAME = new HashMap<String, EFindingElements>();

	/** Mapping from attribute names to attribute enum values */
	private static final Map<String, EFindingAttributes> ATTRIBUTES_BY_NAME = new HashMap<String, EFindingAttributes>();

	static {
		for (EFindingElements element : EFindingElements.values()) {
			ELEMENTS_BY_NAME.put(FindingReportIO.XML_RESOLVER
					.resolveElementName(element), element);
		}
		for (EFindingAttributes attribute : EFindingAttributes.values()) {
			ATTRIBUTES_BY_NAME.put(FindingReportIO.XML_RESOLVER
					.resolveAttributeName(attribute), attribute);
		}
	}

	/** The report. */
	private FindingReport report;

	/** The current category. */
	private FindingCategory currentCategory;

	/** The current group. */
	private FindingGroup currentGroup;

	/** The current finding. */
	private Finding<?> currentFinding;

	/** The current key/value receiver (can be group or finding). */
	private IConQATNode keyValueReceiver;

	/** Current key for key/value data. */
	private String currentKey;

	/** Buffer for text content in a key/value pair. */
	private StringBuilder textContent = new StringBuilder();

	/** Returns the report. */
	/* package */FindingReport getReport() {
		return report;
	}

	/** {@inheritDoc} */
	@Override
	public void startElement(String uri, String localName, String name,
			Attributes attributes) throws SAXException {
		EFindingElements element = determineElement(localName);
		Map<EFindingAttributes, String> attributeMap = determineAttributes(attributes);

		try {
			switch (element) {
			case FINDING_REPORT:
				try {
					report = new FindingReport(FindingReportIO.DATE_FORMAT
							.parse(attributeMap.get(EFindingAttributes.TIME)));
				} catch (ParseException e) {
					throw new SAXException("Invalid date format: "
							+ attributeMap.get(EFindingAttributes.TIME), e);
				}
				break;

			case FINDING_CATEGORY:
				currentCategory = report
						.getOrCreateCategory(
								attributeMap.get(EFindingAttributes.NAME),
								EnumUtils
										.valueOfIgnoreCase(
												EFindingType.class,
												attributeMap
														.get(EFindingAttributes.FINDING_TYPE)),
								EnumUtils
										.valueOfIgnoreCase(
												ELocationType.class,
												attributeMap
														.get(EFindingAttributes.LOCATION_TYPE)));
				break;

			case FINDING_GROUP:
				currentGroup = currentCategory.createFindingGroup(attributeMap
						.get(EFindingAttributes.DESCRIPTION));
				keyValueReceiver = currentGroup;
				// as findings are after key/values, no reset of
				// keyValueReceiver is needed in endElement()
				break;

			case FINDING:
				currentFinding = currentGroup.createFinding(attributeMap
						.get(EFindingAttributes.ORIGIN_TOOL),
						parseValue(attributeMap.get(EFindingAttributes.VALUE)));
				keyValueReceiver = currentGroup;
				break;

			case KEY_VALUE_PAIR:
				currentKey = attributeMap.get(EFindingAttributes.KEY);
				textContent.setLength(0);
				break;

			case CODE_FILE:
				currentFinding.addLocation(new FileLocation(new CanonicalFile(
						attributeMap.get(EFindingAttributes.FILE))));
				break;

			case CODE_LINE:
				currentFinding.addLocation(new CodeLineLocation(
						new CanonicalFile(attributeMap
								.get(EFindingAttributes.FILE)), Integer
								.parseInt(attributeMap
										.get(EFindingAttributes.LINE_NUMBER))));
				break;

			case CODE_REGION:
				currentFinding.addLocation(new CodeRegionLocation(
						new CanonicalFile(attributeMap
								.get(EFindingAttributes.FILE)),
						Integer.parseInt(attributeMap
								.get(EFindingAttributes.START_LINE_NUMBER)),
						Integer.parseInt(attributeMap
								.get(EFindingAttributes.END_LINE_NUMBER)),
						Integer.parseInt(attributeMap
								.get(EFindingAttributes.START_POSITION)),
						Integer.parseInt(attributeMap
								.get(EFindingAttributes.END_POSITION))));
				break;

			case QUALIFIED_NAME:
				currentFinding.addLocation(new QualifiedNameLocation(
						attributeMap.get(EFindingAttributes.NAME)));
				break;

			default:
				CCSMAssert.fail("Unknown element!");
			}
		} catch (ConQATException e) {
			throw new SAXException("Inconsistent finding report!", e);
		} catch (NumberFormatException e) {
			throw new SAXException("Invalid number!", e);
		} catch (IOException e) {
			// problems from canonize
			throw new SAXException("Illegal file name in report!", e);
		}
	}

	/** {@inheritDoc} */
	@Override
	public void characters(char[] ch, int start, int length) {
		textContent.append(ch, start, length);
	}

	/** {@inheritDoc} */
	@Override
	public void endElement(String uri, String localName, String name)
			throws SAXException {
		EFindingElements element = determineElement(localName);
		if (element == EFindingElements.KEY_VALUE_PAIR) {
			keyValueReceiver.setValue(currentKey, textContent.toString());
		}
	}

	/**
	 * Parses the value for a finding based on the finding type of the
	 * {@link #currentCategory}.
	 */
	private Object parseValue(String value) {
		switch (currentCategory.getFindingType()) {
		case ASSESSMENT:
			return EnumUtils.valueOfIgnoreCase(ETrafficLightColor.class, value);
		case COLOR:
			return ColorUtils.fromString(value);
		case MESSAGE:
			return value;
		case METRIC:
			return Double.parseDouble(value);
		}
		CCSMAssert.fail("Unknown finding type: "
				+ currentCategory.getFindingType());
		return null;
	}

	/** Returns the element for the local name. */
	private static EFindingElements determineElement(String localName)
			throws SAXException {
		EFindingElements element = ELEMENTS_BY_NAME.get(localName);
		if (element == null) {
			throw new SAXException("Could not find element for " + localName);
		}
		return element;
	}

	/** Returns the attributes as a map from enum value to string. */
	private Map<EFindingAttributes, String> determineAttributes(
			Attributes attributes) throws SAXException {
		Map<EFindingAttributes, String> result = new EnumMap<EFindingAttributes, String>(
				EFindingAttributes.class);
		for (int i = 0; i < attributes.getLength(); ++i) {
			EFindingAttributes attribute = ATTRIBUTES_BY_NAME.get(attributes
					.getLocalName(i));
			if (attribute == null) {
				throw new SAXException("Could not find attribute for "
						+ attributes.getLocalName(i));
			}
			result.put(attribute, attributes.getValue(i));
		}
		return result;
	}

	/** {@inheritDoc} */
	@Override
	public void error(SAXParseException e) throws SAXException {
		throw e;
	}

	/** {@inheritDoc} */
	@Override
	public void fatalError(SAXParseException e) throws SAXException {
		throw e;
	}

	/** {@inheritDoc} */
	@Override
	public void warning(SAXParseException e) throws SAXException {
		throw e;
	}
}

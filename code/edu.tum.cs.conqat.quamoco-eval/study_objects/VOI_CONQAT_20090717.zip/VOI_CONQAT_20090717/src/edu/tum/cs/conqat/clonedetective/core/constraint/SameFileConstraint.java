/*--------------------------------------------------------------------------+
   $Id: SameFileConstraint.java 21705 2009-06-29 15:06:08Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 21705 $
 * @levd.rating YELLOW Rev: 21705
 */
@AConQATProcessor(description = ""
		+ "Constraint that is satisfied if at least 2 clones of the clone class are in the same file")
public class SameFileConstraint extends ConstraintBase {

	/**
	 * Constant that indicates that all clones need to be in the same file for
	 * the constraint to be satisfied
	 */
	public static final int ALL = -1;

	/** Number of clones that need to be in the same file */
	private int minCount = 2;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "min", description = "Number of clones that need to be in the same file for the constraint to be satisfied")
	public void setMinCount(
			@AConQATAttribute(name = "count", description = "Default is 2. Use -1 to indicate that all clones need to be in same file") int minCount) {
		this.minCount = minCount;
	}

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) {
		// count clones per file
		CounterSet<String> cloneCount = new CounterSet<String>();
		for (IClone clone : cloneClass.getClones()) {
			cloneCount.inc(clone.getOrigin());
		}

		// determine max count
		int maxClonesInSameFile = 0;
		for (String origin : cloneCount.getKeys()) {
			maxClonesInSameFile = Math.max(maxClonesInSameFile, cloneCount
					.getValue(origin));
		}

		return maxClonesInSameFile >= minCount;
	}
}

/*--------------------------------------------------------------------------+
   $Id: TokenNormalization.java 21476 2009-05-26 09:41:35Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.collections.IdManager;
import edu.tum.cs.commons.collections.TwoDimHashMap;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.normalization.UnitProviderBase;
import edu.tum.cs.conqat.clonedetective.normalization.token.configuration.ITokenConfiguration;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.regions.RegionSet;
import edu.tum.cs.conqat.filesystem.regions.RegionSetDictionary;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.ETokenType;
import edu.tum.cs.scanner.IStatementOracle;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.ETokenType.ETokenClass;

/**
 * According to the specified configuration, this class applies normalizing
 * transformations to the tokens. Some tokens can be swallowed entirely.
 * <p>
 * Additionally, this component performs the conversion from scanner tokens
 * {@link edu.tum.cs.scanner.IToken} to tokens units
 * {@link edu.tum.cs.conqat.clonedetective.normalization.token.TokenUnit}.
 * 
 * @author Uwe Hermann
 * @author Steffen Borgwardt
 * @author Florian Deissenboeck
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 21476 $
 * @levd.rating GREEN Rev: 21476
 */
public class TokenNormalization extends
		UnitProviderBase<ISourceCodeElement, TokenUnit> {

	/** Number of upcoming tokens that are to be ignored */
	private int ignoreNextTokens = 0;

	/** The provider that yields the tokens that get normalized. */
	private final ITokenProvider tokenProvider;

	/**
	 * The {@link ITokenConfiguration} that determines how normalization is
	 * performed per default
	 */
	private final ITokenConfiguration defaultConfig;

	/**
	 * List of configurations used for normalization. Order of configuration
	 * names determines preference, in case more than a one configuration
	 * matches a token.
	 */
	private final Map<String, ITokenConfiguration> configurations = new LinkedHashMap<String, ITokenConfiguration>();

	/**
	 * Maps from a {@link ISourceCodeElement} id and a configuration name to the
	 * {@link RegionSet} that determines for which parts of the
	 * {@link ISourceCodeElement} the configuration holds.
	 */
	private final TwoDimHashMap<String, String, RegionSet> configuationMap = new TwoDimHashMap<String, String, RegionSet>();

	/**
	 * The {@link IStatementOracle} used to detect statement boundaries. This is
	 * needed for identifier normalization.
	 */
	private IStatementOracle statementOracle;

	/** Index of unit in its file */
	private int indexInFile = 0;

	/** Maps from tokens to their normalized units. Used to write debug files */
	private final Map<IToken, TokenUnit> normalization = new LinkedHashMap<IToken, TokenUnit>();

	/**
	 * This manager is used for normalizing identifiers. Within a statement same
	 * identifiers are normalized with the same id. Example:
	 * 
	 * <pre>
	 * b = a * a;
	 * </pre>
	 * 
	 * becomes
	 * 
	 * <pre>
	 * id0 = id1 * id1;
	 * </pre>
	 */
	private final IdManager<String> identifierManager = new IdManager<String>();

	/**
	 * If this string is set to a non-empty value, a debug file (containing the
	 * normalized units) is written for each input file.
	 */
	private String debugFileExtension;

	/**
	 * Create new {@link TokenNormalization} that does not write debug
	 * information
	 */
	public TokenNormalization(ITokenProvider tokenProvider,
			List<ITokenConfiguration> configurationList,
			ITokenConfiguration defaultConfig) {
		this(tokenProvider, configurationList, defaultConfig, null);
	}

	/**
	 * Create new {@link TokenNormalization} that optionally writes debug
	 * information
	 */
	public TokenNormalization(ITokenProvider tokenProvider,
			List<ITokenConfiguration> configurationList,
			ITokenConfiguration defaultConfig, String debugFileExtension) {
		this.tokenProvider = tokenProvider;
		this.defaultConfig = defaultConfig;
		this.debugFileExtension = debugFileExtension;

		for (ITokenConfiguration configuration : configurationList) {
			configurations.put(configuration.getName(), configuration);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ISourceCodeElement root) throws CloneDetectionException {
		tokenProvider.init(root, getLogger());
		statementOracle = root.getLanguage().getStatementOracle();

		List<ISourceCodeElement> elements = TraversalUtils
				.listLeavesDepthFirst(root);
		for (ISourceCodeElement element : elements) {
			retrieveAndStoreRegions(element);
		}
	}

	/** Retrieve regions information and store in map */
	private void retrieveAndStoreRegions(ISourceCodeElement element) {
		try {
			RegionSetDictionary dictionary = RegionSetDictionary
					.retrieve(element);
			if (dictionary == null) {
				return;
			}
			for (RegionSet regions : dictionary) {
				String id = element.getId();
				configuationMap.putValue(id, regions.getName(), regions);
			}
		} catch (ConQATException e) {
			getLogger().warn(
					"Could not access regions for element '"
							+ element.getName() + "': " + e.getMessage());
		}
	}

	/**
	 * This method consumes a token from the token structure, transforms it and
	 * returns the transformed token. Tokens may be dropped.
	 */
	@Override
	protected TokenUnit provideNext() throws CloneDetectionException {
		// Determine next token that is not ignored
		IToken token = tokenProvider.getNext();
		while (token != null && isIgnored(token)) {
			handleEndOfFile(token);
			normalization.put(token, null);
			token = tokenProvider.getNext();
		}

		// no more tokens, done!
		if (token == null) {
			return null;
		}

		// update identifier normalization
		if (statementOracle.isEndOfStatementToken(token.getType())) {
			identifierManager.clear();
		}

		// update index in file
		int currentIndexInFile = indexInFile++;

		// create normalized token unit
		if (getConfigurationForToken(token).isNormalizeTypeKeywords()) {
			token = token.newToken(normalizeType(token), token.getOffset(),
					token.getLineNumber(), token.getText(), token.getOrigin());
		}

		TokenUnit unit = new TokenUnit(normalizeContent(token), token
				.getOffset(), token.getLineNumber(), token.getOrigin()
				.toString(), normalizeType(token), currentIndexInFile);
		normalization.put(token, unit);

		// handle case that token is last in file
		handleEndOfFile(token);

		return unit;
	}

	/** Check if next token if in other file and clean up */
	private void handleEndOfFile(IToken token) throws CloneDetectionException {
		if (!inSameFile(token, tokenProvider.lookahead(1))) {
			// write debug file if last unit of file reached
			if (!StringUtils.isEmpty(debugFileExtension)) {
				NormalizationDebugUtils.writeDebugFile(token.getOrigin()
						.toString(), normalization, getLogger(),
						debugFileExtension);
			}

			identifierManager.clear();
			indexInFile = 0;
			normalization.clear();
		}
	}

	/** Checks whether two tokens are in the same file */
	private boolean inSameFile(IToken token, IToken token2) {
		if (token == null || token2 == null) {
			return false;
		}
		return token.getOrigin().equals(token2.getOrigin());
	}

	/** Determines whether this token is to be ignored */
	private boolean isIgnored(IToken token) throws CloneDetectionException {
		if (ignoreNextTokens > 0) {
			ignoreNextTokens--;
			return true;
		}

		return isIgnoredComment(token) || isIgnoredDelimiter(token)
				|| isIgnoredPreprocessorDirective(token)
				|| isIgnoredThisReference(token) || isIgnoredFQNameHead(token)
				|| isIgnoredModifier(token);
	}

	/** Determines whether this token is an ignored comment */
	private boolean isIgnoredComment(IToken token) {
		if (!getConfigurationForToken(token).isIgnoreComments()) {
			return false;
		}
		return token.getType().getTokenClass() == ETokenClass.COMMENT;
	}

	/**
	 * Determines whether this token is an ignored delimiter
	 * <p>
	 * 
	 */
	private boolean isIgnoredDelimiter(IToken token) {
		if (!getConfigurationForToken(token).isIgnoreDelimiters()) {
			return false;
		}
		return token.getType() == ETokenType.LPAREN
				|| token.getType() == ETokenType.RPAREN
				|| token.getType() == ETokenType.LBRACK
				|| token.getType() == ETokenType.RBRACK;
	}

	/** Determines whether this token is an ignored preprocessor directive */
	private boolean isIgnoredPreprocessorDirective(IToken token) {
		if (!getConfigurationForToken(token).isIgnorePreprocessorDirectives()) {
			return false;
		}
		return token.getType() == ETokenType.PREPROCESSOR_DIRECTIVE;
	}

	/** Determines whether this token is an ignored <em>this</em> reference */
	private boolean isIgnoredThisReference(IToken token)
			throws CloneDetectionException {
		if (token.getType() != ETokenType.THIS
				|| !getConfigurationForToken(token).isIgnoreThis()) {
			return false;
		}
		if (tokenProvider.lookahead(1) == null
				|| tokenProvider.lookahead(1).getType() != ETokenType.DOT) {
			return false;
		}
		ignoreNextTokens = 1;
		return true;
	}

	/**
	 * Tests whether the token is the head of a fully qualified name. If so, the
	 * entire fq header is ignored in one step.
	 */
	private boolean isIgnoredFQNameHead(IToken token)
			throws CloneDetectionException {
		if (token.getType() != ETokenType.IDENTIFIER
				|| !getConfigurationForToken(token)
						.isNormalizeFullyQualifiedNames()) {
			return false;
		}

		// check whether next token is a dot
		if (!lookaheadTokenType(1, ETokenType.DOT)) {
			return false;
		}

		// look for end of fq header
		int position = 1;
		while (lookaheadTokenType(position + 1, ETokenType.IDENTIFIER)
				&& lookaheadTokenType(position + 2, ETokenType.DOT)) {
			position += 2;
		}
		ignoreNextTokens = position;

		return true;
	}

	/** Tests whether the token is an ignored visibility modifier. */
	private boolean isIgnoredModifier(IToken token) {
		if (!getConfigurationForToken(token).isIgnoreModifier()) {
			return false;
		}
		return token.getType() == ETokenType.PUBLIC
				|| token.getType() == ETokenType.PROTECTED
				|| token.getType() == ETokenType.INTERNAL
				|| token.getType() == ETokenType.PRIVATE
				|| token.getType() == ETokenType.FINAL;
	}

	/** Performs lookahead and checks whether the found token has a certain type */
	private boolean lookaheadTokenType(int index, ETokenType tokenType)
			throws CloneDetectionException {
		IToken token = tokenProvider.lookahead(index);
		if (token == null) {
			return false;
		}
		return token.getType() == tokenType;
	}

	/** Normalizes the content of the token */
	private String normalizeContent(IToken token) {
		String content = token.getText();
		ITokenConfiguration tokenConfig = getConfigurationForToken(token);

		switch (token.getType()) {
		case IDENTIFIER:
			if (tokenConfig.isNormalizeIdentifiers()) {
				content = "id" + identifierManager.obtainId(content);
			}
			break;

		case STRING_LITERAL:
			if (tokenConfig.isNormalizeStringLiterals()) {
				content = StringUtils.EMPTY_STRING;
			}
			break;

		case CHARACTER_LITERAL:
			if (tokenConfig.isNormalizeCharacterLiterals()) {
				content = "char";
			}
			break;

		case INTEGER_LITERAL:
			if (tokenConfig.isNormalizeNumberLiterals()) {
				content = "0";
			}
			break;

		case FLOATING_POINT_LITERAL:
			if (tokenConfig.isNormalizeNumberLiterals()) {
				content = "0.0";
			}
			break;

		case BOOLEAN_LITERAL:
			if (tokenConfig.isNormalizeBooleanLiterals()) {
				content = "true";
			}
			break;

		default:
			// All other tokens will not be altered.
		}

		return content;
	}

	/**
	 * Gets the {@link ITokenConfiguration} determining the normalization for
	 * this token. The token-based choice of a configuration allows for
	 * context-sensitive normalization.
	 */
	private ITokenConfiguration getConfigurationForToken(IToken token) {
		for (String configName : configurations.keySet()) {
			String elementId = token.getOrigin().toString();
			RegionSet regions = configuationMap.getValue(elementId, configName);
			if (regions != null && regions.contains(token.getOffset())) {
				return configurations.get(configName);
			}
		}

		// Return default configuration
		return defaultConfig;
	}

	/** Normalize the type of a token */
	private ETokenType normalizeType(IToken token) {
		if (!getConfigurationForToken(token).isNormalizeTypeKeywords()) {
			return token.getType();
		}

		switch (token.getType()) {
		case STRING:
			// fall-through
		case BOOL:
			// fall-through
		case BOOLEAN:
			// fall-through
		case DECIMAL:
			// fall-through
		case DOUBLE:
			// fall-through
		case FLOAT:
			// fall-through
		case SINGLE:
			// fall-through
		case CHAR:
			// fall-through
		case BYTE:
			// fall-through
		case OBJECT:
			// fall-through
		case INT:
			return ETokenType.IDENTIFIER;
		}

		return token.getType();
	}

}
/*--------------------------------------------------------------------------+
   $Id: ListBasedTokenProvider.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.utils;

import java.util.Iterator;
import java.util.List;

import edu.tum.cs.conqat.clonedetective.normalization.token.TokenProviderBase;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.IToken;

/**
 * Provides tokens from a list.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public class ListBasedTokenProvider extends TokenProviderBase {
	/** Iterator that keeps track of position in tokens list */
	private Iterator<IToken> tokenIterator;

	/** Constructor */
	public ListBasedTokenProvider(List<IToken> tokens) {
		this.tokenIterator = tokens.iterator();
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ISourceCodeElement root) {
		// Do nothing
	}

	/** {@inheritDoc} */
	@Override
	protected IToken provideNext() {
		if (tokenIterator != null && tokenIterator.hasNext()) {
			return tokenIterator.next();
		}

		tokenIterator = null;
		return null;
	}
}

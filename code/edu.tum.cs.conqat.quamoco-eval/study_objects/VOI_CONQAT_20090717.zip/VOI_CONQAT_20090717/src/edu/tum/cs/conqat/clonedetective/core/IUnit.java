/*--------------------------------------------------------------------------+
   $Id: IUnit.java 17002 2008-07-14 13:24:47Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

/**
 * During the normalization phase, all input data is structured in units
 * described by this interface.
 * 
 * @author Rainer Spitzhirn
 * @author Elmar Juergens
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * 
 * @version $Revision: 17002 $
 * @levd.rating GREEN Rev: 17002
 */
public interface IUnit {

	/** Textual content of the unit. */
	public String getContent();

	/** Id of the node this unit originates from. */
	public String getOriginId();

	/** Gets the line number of the start of the unit in the source file. */
	public int getStartLineInFile();

	/** Returns the number of lines this unit covers in the source file */
	public int getCoveredLines();

	/** Gets the index of the unit in the source file */
	public int getIndexInFile();

	/**
	 * Detection relies on implementation of {@link #hashCode()} and
	 * {@link #equals(Object)} methods.
	 */
	public int hashCode();

	/**
	 * Detection relies on implementation of {@link #hashCode()} and
	 * {@link #equals(Object)} methods.
	 */
	public boolean equals(Object otherUnit);

	/**
	 * Determines whether the unit stems from a file or is just a marker
	 * (synthetic).
	 */
	public boolean isSynthetic();
}

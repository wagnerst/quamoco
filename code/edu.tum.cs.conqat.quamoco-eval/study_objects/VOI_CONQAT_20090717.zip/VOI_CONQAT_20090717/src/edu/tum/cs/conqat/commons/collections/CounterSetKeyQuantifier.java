/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: CounterSetKeyQuantifier.java 21665 2009-06-24 15:12:33Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21665 $
 * @levd.rating YELLOW Rev: 21665
 */
@AConQATProcessor(description = "This processors processes a counter sets stored in keys and calculates a quantified string.")
public class CounterSetKeyQuantifier extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** Input key. */
	private String inputKey;

	/** Output key. */
	private String outputKey;

	/** Set of keys to ignore. */
	private final Set<String> ignore = new HashSet<String>();

	/** Add a key for reading an assessment. */
	@AConQATParameter(name = ConQATParamDoc.READKEY_NAME, minOccurrences = 1, description = ConQATParamDoc.READKEY_DESC)
	public void setReadKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC) String key) {
		inputKey = key;
	}

	/** Set the key used for writing. */
	@AConQATParameter(name = ConQATParamDoc.WRITEKEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.WRITEKEY_DESC)
	public void setWriteKey(
			@AConQATAttribute(name = ConQATParamDoc.WRITEKEY_KEY_NAME, description = ConQATParamDoc.WRITEKEY_KEY_DESC) String key) {
		outputKey = key;
	}

	/** Sets value to ignore. */
	@AConQATParameter(name = "ignore", minOccurrences = 0, description = "Adds a counter set key to the set of ignored values.")
	public void addIgnore(
			@AConQATAttribute(name = "cskey", description = "The counter set key to be ignored.") String key) {
		ignore.add(key);
	}

	/** Add output key to display list. */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		NodeUtils.addToDisplayList(root, outputKey);
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public void visit(IConQATNode node) throws ConQATException {
		Object value = node.getValue(inputKey);
		if (!(value instanceof CounterSet)) {
			throw new ConQATException("Value '" + value + "' stored for key '"
					+ inputKey + "' at node '" + node.getId()
					+ "' is not a CounterSet.");
		}

		List<ImmutablePair<Integer, String>> pairs = new ArrayList<ImmutablePair<Integer, String>>();
		int total = fillPairs((CounterSet<Object>) value, pairs);

		node.setValue(outputKey, getQuantifiedString(pairs, total));
	}

	/** Returns the string which summarizes the value. */
	private String getQuantifiedString(
			List<ImmutablePair<Integer, String>> pairs, int total) {
		if (pairs.size() == 0) {
			return "none";
		}
		if (pairs.size() == 1) {
			return "only " + pairs.get(0).getSecond();
		}

		// sort descending
		Collections.sort(pairs);
		Collections.reverse(pairs);

		if (pairs.get(0).getFirst() >= .9 * total) {
			return "mostly " + pairs.get(0).getSecond();
		}
		if (pairs.get(0).getFirst() > .5 * total) {
			return "majority of " + pairs.get(0).getSecond() + " followed by "
					+ pairs.get(1).getSecond();
		}

		return "mixed";
	}

	/**
	 * Fills a list of count/key pairs from a counter set, respecting the
	 * {@link #ignore} set. Returns the sum of values.
	 */
	private int fillPairs(CounterSet<Object> counterSet,
			List<ImmutablePair<Integer, String>> pairs) {
		int total = 0;
		for (Object key : counterSet.getKeys()) {
			if (!ignore.contains(key.toString())) {
				pairs.add(new ImmutablePair<Integer, String>(counterSet
						.getValue(key), key.toString()));
				total += counterSet.getValue(key);
			}
		}
		return total;
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.LEAVES;
	}

}

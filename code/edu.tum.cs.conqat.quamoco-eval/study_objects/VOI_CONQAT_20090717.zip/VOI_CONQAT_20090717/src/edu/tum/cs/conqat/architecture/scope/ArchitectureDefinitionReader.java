/*--------------------------------------------------------------------------+
   $Id: ArchitectureDefinitionReader.java 21411 2009-05-14 10:32:27Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.scope;

import static edu.tum.cs.conqat.architecture.format.EArchitectureIOAttribute.DIM;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOAttribute.ID;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOAttribute.NAME;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOAttribute.POLICY;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOAttribute.POS;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOAttribute.REGEX;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOElement.ALLOW;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOElement.CODE_MAPPING;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOElement.COMPONENT;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOElement.DENY;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOElement.ELEMENT;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOElement.POLICIES;
import static edu.tum.cs.conqat.architecture.format.EArchitectureIOElement.TOLERATE;
import static edu.tum.cs.conqat.architecture.format.ECodeMappingType.EXCLUDE;
import static edu.tum.cs.conqat.architecture.format.ECodeMappingType.INCLUDE;

import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import edu.tum.cs.commons.enums.EnumUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.commons.xml.IXMLElementProcessor;
import edu.tum.cs.commons.xml.IXMLResolver;
import edu.tum.cs.commons.xml.XMLReader;
import edu.tum.cs.conqat.architecture.BundleContext;
import edu.tum.cs.conqat.architecture.format.EArchitectureIOAttribute;
import edu.tum.cs.conqat.architecture.format.EArchitectureIOElement;
import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * This processor reads an architecture definition from an XML file and creates
 * a {@link ComponentNode} hierarchy that represents the architecture.
 * 
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 21411 $
 * @levd.rating YELLOW Rev: 20957
 */
@AConQATProcessor(description = "This processor reads an architecture "
		+ "definition from a given input file (using our proprietary XML format)")
public class ArchitectureDefinitionReader extends ConQATProcessorBase {

	/** Location of the schema used to validate the architecture file. */
	private static final String SCHEMA_NAME = "architecture.xsd";

	/** Input file containing the xml architecture description */
	private String filename;

	/** Mapping from component ID to component. */
	private final Map<String, ComponentNode> componentByID = new HashMap<String, ComponentNode>();

	/** Maps from element id to component */
	private ComponentResolver resolver;

	/** Root node of resulting architecture hierarchy */
	private ComponentNode result;

	/** Set input filename. */
	@AConQATParameter(name = "input", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Name of the input XML file describing the architecture.")
	public void setInputFile(
			@AConQATAttribute(name = "file", description = "The name of the XML file.") String filename) {
		this.filename = filename;
	}

	/** Read the architecture definition from the given file. */
	public ComponentNode process() throws ConQATException {

		getLogger().debug("Reading architecture definition file: " + filename);

		try {
			new Reader().read();
		} catch (MalformedURLException e) {
			throw new IllegalStateException(
					"This can only happen due to missing resources.", e);
		} catch (SAXException e) {
			throw new ConQATException("A parsing error occured!", e);
		} catch (ParserConfigurationException e) {
			throw new ConQATException("A parser configuration error occured!",
					e);
		} catch (IOException e) {
			throw new ConQATException("An i/o error occured!", e);
		}

		checkDependencies();

		return result;
	}

	/** Perform some sanity checks on dependencies. */
	private void checkDependencies() throws ConQATException {
		List<DependencyPolicy> policies = new ArrayList<DependencyPolicy>();
		result.collectPolicies(policies);

		checkTreeFollowing(policies);
		checkCrossing(policies);
	}

	/**
	 * Checks for policies that follow the hierarchy tree. These policies are
	 * unnecessary, since dependencies between parents and successors, or vice
	 * versa, are always allowed.
	 */
	private void checkTreeFollowing(List<DependencyPolicy> policies)
			throws ConQATException {
		for (DependencyPolicy policy : policies) {
			if (isTreeFollowing(policy)) {
				throw new ConQATException("Tree-following policy: "
						+ policy.getSource().getName() + " -> "
						+ policy.getTarget().getName());
			}
		}
	}

	/**
	 * Checks if the given policy is "tree-following", i.e. source or target is
	 * a parent of the other.
	 */
	private boolean isTreeFollowing(DependencyPolicy policy) {
		ComponentNode source = policy.getSource();
		ComponentNode target = policy.getTarget();
		return source.getPredecessorSet().contains(target)
				|| target.getPredecessorSet().contains(source);
	}

	/**
	 * Check for crossing edges. These edges have no clear semantics and are
	 * thus illegal.
	 */
	private void checkCrossing(List<DependencyPolicy> policies)
			throws ConQATException {
		for (DependencyPolicy policy : policies) {
			for (DependencyPolicy policy2 : policies) {
				if (policy != policy2) {
					checkNotSame(policy, policy2);
					checkNotCrossing(policy, policy2);
					checkNotCrossing(policy2, policy);
				}
			}
		}
	}

	/** Make sure the policies differ it at least source or target. */
	private void checkNotSame(DependencyPolicy policy, DependencyPolicy policy2)
			throws ConQATException {
		if (policy.getSource() == policy2.getSource()
				&& policy.getTarget() == policy2.getTarget()) {
			throw new ConQATException("Duplicate policy for "
					+ policy.getSource().getName() + " -> "
					+ policy.getTarget().getName());
		}
	}

	/** Make sure the two policies are not crossing. */
	private void checkNotCrossing(DependencyPolicy policy,
			DependencyPolicy policy2) throws ConQATException {
		boolean source2IsLower = policy.getSource().getPredecessorSet()
				.contains(policy2.getSource());
		boolean target2IsHigher = policy2.getSource().getPredecessorSet()
				.contains(policy.getTarget());

		if (source2IsLower && target2IsHigher) {
			String message = "The policies " + policy.getSource().getName()
					+ " -> " + policy.getTarget().getName() + " and "
					+ policy2.getSource().getName() + " -> "
					+ policy2.getTarget().getName()
					+ " are crossing each other!";
			throw new ConQATException(message);
		}
	}

	/**
	 * Insert single dependency rule into the component tree.
	 * 
	 * @throws ConQATException
	 */
	private DependencyPolicy insertPolicy(String sourceId, String targetId,
			EPolicyType policyType) throws ConQATException {
		ComponentNode source = null;
		ComponentNode target = null;
		boolean sourceIsElementComponent = false;
		boolean targetIsElementComponent = false;

		source = componentByID.get(sourceId);
		if (source == null) {
			source = createComponentForElement(sourceId);
			sourceIsElementComponent = true;
		}

		target = componentByID.get(targetId);
		if (target == null) {
			target = createComponentForElement(targetId);
			targetIsElementComponent = true;
		}

		// check for CR#1572: if both source and target have been created from a
		// type name, check if they have the same parent component. typically,
		// this is not intended, since types in the same component may depend on
		// each other anyway.
		if (target.getParent() == source.getParent()
				&& sourceIsElementComponent && targetIsElementComponent) {
			getLogger().warn(
					"Type components '" + sourceId + "' and '" + targetId
							+ "' have the same parent. Was this intended?");
		}

		return createPolicy(source, target, policyType);
	}

	/** Creates a policy */
	private DependencyPolicy createPolicy(ComponentNode source,
			ComponentNode target, EPolicyType policyType) {
		DependencyPolicy policy = new DependencyPolicy(source, target,
				policyType);
		policy.registerWithComponents();
		return policy;
	}

	/**
	 * Creates a ComponentNode for an element that is attached as a child to the
	 * {@link ComponentNode} to which the elementId matches.
	 * 
	 * @return {@link ComponentNode} for element, or null, if corresponding
	 *         component could not be determined unambiguously
	 * @throws ConQATException
	 */
	private ComponentNode createComponentForElement(String elementId)
			throws ConQATException {
		if (resolver == null) {
			resolver = new ComponentResolver(result, getLogger());
		}

		ComponentNode matchingComponent = resolver.findComponentFor(elementId);
		if (matchingComponent == null) {
			throw new ConQATException(
					"Could not create elementary component for '" + elementId
							+ "' as no unique component was found as parent!");
		}

		ComponentNode elementComponent = new ComponentNode(elementId + "_",
				EPolicyType.DENY_IMPLICIT, matchingComponent.getPosition());

		elementComponent.setDimension(matchingComponent.getDimension());

		elementComponent.addElement(elementId);

		matchingComponent.addChild(elementComponent);
		matchingComponent.excludeElement(elementId);

		componentByID.put(elementId, elementComponent);
		return elementComponent;
	}

	/** The reader class used. */
	private class Reader
			extends
			XMLReader<EArchitectureIOElement, EArchitectureIOAttribute, ConQATException> {

		/** Constructor. */
		public Reader() throws MalformedURLException {
			super(new File(filename), BundleContext.getInstance()
					.getResourceManager().getResourceAsURL(
							ArchitectureDefinitionReader.SCHEMA_NAME),
					new Resolver());
		}

		/** The reader's main method. */
		public void read() throws SAXException, ParserConfigurationException,
				IOException, ConQATException {
			parseFile();

			EPolicyType defaultPolicy = EnumUtils.valueOfIgnoreCase(
					EPolicyType.class, getStringAttribute(POLICY));

			// This is just a dummyParent, so we can give it a dummy Position of
			// 0,0 since it won't be rendered
			ComponentNode dummyParent = new ComponentNode("dummy_id",
					defaultPolicy, new Point());
			processChildElements(new ComponentProcessor(dummyParent,
					defaultPolicy));
			result = dummyParent.getChildren()[0];

			processChildElements(new PoliciesProcessor());

			// Unlink result from parent so that it is recognized as root
			result.remove();
		}

		/** Processor for components. */
		private final class ComponentProcessor implements
				IXMLElementProcessor<EArchitectureIOElement, ConQATException> {

			/** The parent node. */
			private final ComponentNode parent;

			/** The default policy used. */
			private final EPolicyType defaultPolicy;

			/** Constructor. */
			public ComponentProcessor(ComponentNode parent,
					EPolicyType defaultPolicy) {
				this.parent = parent;
				this.defaultPolicy = defaultPolicy;
			}

			/** {@inheritDoc} */
			public EArchitectureIOElement getTargetElement() {
				return COMPONENT;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				EPolicyType policy = defaultPolicy;
				if (!StringUtils.isEmpty(getStringAttribute(POLICY))) {
					policy = getEnumAttribute(POLICY, EPolicyType.class);
				}

				String name = getStringAttribute(NAME);
				// Backwards compatibility for id tag
				if (StringUtils.isEmpty(name)) {
					name = getStringAttribute(ID);
				}

				if (componentByID.containsKey(name)) {
					throw new ConQATException("Duplicate unique Name: " + name);
				}

				ComponentNode node = new ComponentNode(name, policy,
						ComponentNode
								.positionFromString(getStringAttribute(POS)));
				node.setDimension(getStringAttribute(DIM));

				componentByID.put(name, node);

				processChildElements(new ComponentProcessor(node, defaultPolicy));
				processChildElements(new ElementProcessor(node));
				processChildElements(new ElementGroupProcessor(node));
				processChildElements(new ExcludeGroupProcessor(node));

				parent.addChild(node);
			}
		}

		/** Processor for components. */
		private final class ElementProcessor implements
				IXMLElementProcessor<EArchitectureIOElement, ConQATException> {

			/** The parent node. */
			private final ComponentNode node;

			/** Constructor. */
			public ElementProcessor(ComponentNode node) {
				this.node = node;
			}

			/** {@inheritDoc} */
			public EArchitectureIOElement getTargetElement() {
				return ELEMENT;
			}

			/** {@inheritDoc} */
			public void process() {
				if (StringUtils.isEmpty(getStringAttribute(NAME))) {
					node.addElement(getStringAttribute(ID));
				} else {
					node.addElement(getStringAttribute(NAME));
				}
			}
		}

		/** Processor for components. */
		private final class ElementGroupProcessor implements
				IXMLElementProcessor<EArchitectureIOElement, ConQATException> {

			/** The parent node. */
			private final ComponentNode node;

			/** Constructor. */
			public ElementGroupProcessor(ComponentNode node) {
				this.node = node;
			}

			/** {@inheritDoc} */
			public EArchitectureIOElement getTargetElement() {
				return CODE_MAPPING;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				if (getStringAttribute(EArchitectureIOAttribute.TYPE)
						.equalsIgnoreCase(INCLUDE.toString())) {
					node.addElementRegex(getStringAttribute(REGEX));
				}
			}
		}

		// TODO (EJ) Remove redundancy
		/** Processor for components. */
		private final class ExcludeGroupProcessor implements
				IXMLElementProcessor<EArchitectureIOElement, ConQATException> {

			/** The parent node. */
			private final ComponentNode node;

			/** Constructor. */
			public ExcludeGroupProcessor(ComponentNode node) {
				this.node = node;
			}

			/** {@inheritDoc} */
			public EArchitectureIOElement getTargetElement() {
				return CODE_MAPPING;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				if (getStringAttribute(EArchitectureIOAttribute.TYPE)
						.equalsIgnoreCase(EXCLUDE.toString())) {
					node.addExcludeRegex(getStringAttribute(REGEX));
				}
			}
		}

		/** Processor for policies. */
		private final class PoliciesProcessor implements
				IXMLElementProcessor<EArchitectureIOElement, ConQATException> {

			/** {@inheritDoc} */
			public EArchitectureIOElement getTargetElement() {
				return POLICIES;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				processChildElements(new PolicyProcessor(ALLOW));
				processChildElements(new PolicyProcessor(DENY));
				processChildElements(new PolicyProcessor(TOLERATE));
			}
		}

		/** Processor for policies. */
		private final class PolicyProcessor implements
				IXMLElementProcessor<EArchitectureIOElement, ConQATException> {

			/** Target element */
			private final EArchitectureIOElement targetElement;

			/** Type of policy being read */
			private final EPolicyType policyType;

			/** Creates PolicyProcessor for a policy type */
			public PolicyProcessor(final EArchitectureIOElement targetElement) {
				this.targetElement = targetElement;
				String tagName = targetElement.toString();
				if (ALLOW.toString().equals(tagName)) {
					policyType = EPolicyType.ALLOW_EXPLICIT;
				} else if (DENY.toString().equals(tagName)) {
					policyType = EPolicyType.DENY_EXPLICIT;
				} else if (TOLERATE.toString().equals(tagName)) {
					policyType = EPolicyType.TOLERATE_EXPLICIT;
				} else {
					throw new AssertionError("Tag " + tagName
							+ " not implemented");
				}
			}

			/** {@inheritDoc} */
			public EArchitectureIOElement getTargetElement() {
				return targetElement;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				DependencyPolicy policy = insertPolicy(
						getStringAttribute(EArchitectureIOAttribute.SOURCE),
						getStringAttribute(EArchitectureIOAttribute.TARGET),
						policyType);
				if (policyType == EPolicyType.TOLERATE_EXPLICIT) {
					processChildElements(new ToleratePolicyProcessor(policy));
				}
			}
		}

		/** Processor for policies. */
		private final class ToleratePolicyProcessor implements
				IXMLElementProcessor<EArchitectureIOElement, ConQATException> {

			/** The parent policy we work on */
			private final DependencyPolicy policy;

			/**
			 * @param policy
			 */
			public ToleratePolicyProcessor(DependencyPolicy policy) {
				this.policy = policy;
			}

			/** {@inheritDoc} */
			public EArchitectureIOElement getTargetElement() {
				return EArchitectureIOElement.DEPENDENCY;
			}

			/** {@inheritDoc} */
			public void process() {
				policy.getTolerations().addToleration(
						getStringAttribute(EArchitectureIOAttribute.SOURCE),
						getStringAttribute(EArchitectureIOAttribute.TARGET));
			}
		}

	}

	/** The resolver class used. */
	private static class Resolver implements
			IXMLResolver<EArchitectureIOElement, EArchitectureIOAttribute> {

		/** {@inheritDoc} */
		public Class<EArchitectureIOAttribute> getAttributeClass() {
			return EArchitectureIOAttribute.class;
		}

		/** {@inheritDoc} */
		public String resolveAttributeName(EArchitectureIOAttribute attribute) {
			return attribute.toString();
		}

		/** {@inheritDoc} */
		public String resolveElementName(EArchitectureIOElement element) {
			return element.toString();
		}
	}
}

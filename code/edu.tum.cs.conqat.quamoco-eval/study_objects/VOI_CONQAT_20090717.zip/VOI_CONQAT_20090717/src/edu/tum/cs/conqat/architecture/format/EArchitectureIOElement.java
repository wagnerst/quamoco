/*--------------------------------------------------------------------------+
   $Id: EArchitectureIOElement.java 21602 2009-06-09 16:48:58Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.format;

/**
 * Enum of elements used in the architecture definition file and architecture
 * assessment file.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 21602 $
 * @levd.rating YELLOW Rev: 21602
 */
public enum EArchitectureIOElement {

	/** Element 'conqat-architecture'. */
	CONQAT_ARCHITECTURE,

	/** Assessment element */
	ASSESSMENT,

	/** Element 'component'. */
	COMPONENT,

	/** Element 'policies'. */
	POLICIES,

	/** Element 'allow'. */
	ALLOW,

	/** Element 'tolerate'. */
	TOLERATE,

	/** Element 'deny'. */
	DENY,

	/** Element 'element'. */
	ELEMENT,

	/** Element 'code-mapping'. */
	CODE_MAPPING,

	/** Element 'comment'. */
	COMMENT,

	/** Element 'dependency-groups'. */
	DEPENDENCY_GROUPS,

	/** Element 'dependency-group'. */
	DEPENDENCY_GROUP,

	/** Dependency element */
	DEPENDENCY,

	// TODO (EJ) This does not occur in XML. Its only here to be able to assign
	// colors to unknown dependency groups. Consolidate!
	/** Represents unknown states. */
	UNKNOWN,
	
	/** Matched type element */
	TYPE;

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return name().toLowerCase().replace('_', '-');
	}
}

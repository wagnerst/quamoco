package edu.tum.cs.conqat.clonedetective.core.constraint;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 22019 $
 * @levd.rating RED Rev: 
 */
@AConQATProcessor(description = ""
		+ "Constraint that is satisfied all clones in the clone class have the same fingerprint")
public class SameFingerprintsConstraint extends ConstraintBase {

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) {
		String fingerPrint = cloneClass.getFingerprint();
		for (IClone clone : cloneClass.getClones()) {
			if (!clone.getFingerprint().equals(fingerPrint)) {
				return false;
			}
		}
		return true;
	}

}

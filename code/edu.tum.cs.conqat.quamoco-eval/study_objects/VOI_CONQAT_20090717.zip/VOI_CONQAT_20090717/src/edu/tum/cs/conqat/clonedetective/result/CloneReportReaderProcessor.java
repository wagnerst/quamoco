/*--------------------------------------------------------------------------+
   $Id: CloneReportReaderProcessor.java 21674 2009-06-25 12:05:33Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.clonedetective.result.report.CloneReportReader;
import edu.tum.cs.conqat.clonedetective.result.report.SourceFileDescriptor;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.conqat.sourcecode.scope.SourceCodeElement;
import edu.tum.cs.conqat.sourcecode.scope.SourceCodeElementFactory;
import edu.tum.cs.scanner.ELanguage;

/**
 * Processor that reads clone reports and creates a
 * {@link CloneDetectionResultElement} that can be used just as the result of a
 * clone detection processor.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 21674 $
 * @levd.rating RED Rev: 
 */
@AConQATProcessor(description = ""
		+ "Processor that reads clone reports and creates a"
		+ "{@link CloneDetectionResultElement} that can be used just as the result of a"
		+ "clone detection processor.")
public class CloneReportReaderProcessor extends ConQATProcessorBase {

	/** Name of the report file */
	private File reportFile;

	/** ConQAT Parameter */
	@AConQATParameter(name = "report", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Name of the report file")
	public void setReportFile(
			@AConQATAttribute(name = "filename", description = "Name of the report file") File reportFile) {
		this.reportFile = reportFile;
	}

	/** {@inheritDoc} */
	public CloneDetectionResultElement process() throws ConQATException {
		CloneReportReader reader = new CloneReportReader(reportFile);

		IFileSystemElement root = createFileSystemTree(reader
				.getSourceFileDescriptors());
		List<CloneClass> cloneClasses = reader.getCloneClasses();

		// FIXME: Read timestamp from detection result
		CloneDetectionResultElement result = new CloneDetectionResultElement(
				new Date(), root, cloneClasses);

		return result;
	}

	/** Build a file system tree from the file information in the clone report */
	private ISourceCodeElement createFileSystemTree(
			List<SourceFileDescriptor> sourceFiles) {

		String rootName = commonRoot(sourceFiles);
		ELanguage language = ELanguage.fromFileExtension(sourceFiles.get(0)
				.getFilename());
		SourceCodeElement root = new SourceCodeElement(rootName, language);

		for (SourceFileDescriptor sourceFile : sourceFiles) {
			String filename = sourceFile.getFilename().substring(
					rootName.length());
			language = ELanguage.fromFileExtension(filename);
			FileLibrary.getInstance().insertFile(root, filename,
					new SourceCodeElementFactory(language));
		}

		return root;
	}

	/** Determines the common root directory for all source files */
	private String commonRoot(List<SourceFileDescriptor> sourceFiles) {
		List<String> sourceFileNames = new ArrayList<String>();
		for (SourceFileDescriptor sourceFile : sourceFiles) {
			sourceFileNames.add(sourceFile.getFilename());
		}

		String commonRoot = StringUtils.longestCommonPrefix(sourceFileNames);

		// the files originally stem from a file system element tree and as such
		// are expected to have a common root. if that is not the case,
		// something went wrong.
		CCSMAssert.isTrue(commonRoot.length() > 0,
				"Source files must have a common root");

		return commonRoot;
	}

}

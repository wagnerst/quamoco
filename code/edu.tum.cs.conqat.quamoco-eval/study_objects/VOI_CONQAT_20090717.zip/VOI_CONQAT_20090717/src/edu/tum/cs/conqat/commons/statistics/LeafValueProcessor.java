/*--------------------------------------------------------------------------+
   $Id: LeafValueProcessor.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.statistics;

import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor creates a KeyedData object by adding all leaves of a
 * {@link IConQATNode} tree and taking values stored at the leaves.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This processor creates a KeyedData object by "
		+ "adding all leaves of a IConQATNode-tree and taking values stored at the leaves, "
		+ "i.e. this creates a map from node ids to values.")
public class LeafValueProcessor extends ConQATProcessorBase implements
		INodeVisitor<IConQATNode, NeverThrownRuntimeException> {

	/** The root node. */
	private IConQATNode root;

	/** Key for the value. */
	private String key;

	/** Result object. */
	private final KeyedData<String> result = new KeyedData<String>();

	/** Set the root element to work on. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			IConQATNode root) {
		this.root = root;
	}

	/** Set key for value. */
	@AConQATParameter(name = ConQATParamDoc.READKEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Key pointing to the desired value.")
	public void setKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC)
			String key) {
		this.key = key;
	}

	/** {@inheritDoc} */
	public KeyedData<?> process() {
		TraversalUtils.visitLeavesDepthFirst(this, root);
		return result;
	}

	/**
	 * This method obtains the values from the node and stores them in
	 * {@link #result}.
	 */
	public void visit(IConQATNode node) {
		Object valueObject = node.getValue(key);
		if (valueObject == null) {
			getLogger().warn(
					"Null value for key " + key + "@" + node.getId()
							+ " ignored.");
			return;
		}
		if (!(valueObject instanceof Number)) {
			getLogger().warn(
					"Non-numeric value for key " + key + "@" + node.getId()
							+ " ignored: " + valueObject);
			return;
		}

		double value = ((Number) valueObject).doubleValue();
		result.add(node.getId(), value);
	}
}

/*--------------------------------------------------------------------------+
   $Id: IConQATGraphNode.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.nodes;

import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * This is the most general interface for ConQATNodes in the hierarchy of the
 * ConQAT graph. A {@link IConQATGraphNode} is either a
 * {@link IConQATGraphInnerNode} or an {@link IConQATGraphVertex}.
 * <p>
 * This does not introduce new methods but only makes some return values more
 * concrete.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public interface IConQATGraphNode extends IRemovableConQATNode {

	/** {@inheritDoc} */
	public IConQATGraphNode[] getChildren();

	/** {@inheritDoc} */
	public IConQATGraphInnerNode getParent();
}

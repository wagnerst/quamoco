/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: EFindingElements.java 21999 2009-07-15 20:43:23Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/

package edu.tum.cs.conqat.commons.findings.xml;

/**
 * Names of elements used in the finding XML format.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21999 $
 * @levd.rating YELLOW Rev: 21999
 */
public enum EFindingElements {

	/** Finding report root element. */
	FINDING_REPORT,

	/** Element for finding category. */
	FINDING_CATEGORY,

	/** Element for finding groups. */
	FINDING_GROUP,

	/** Element for single finding. */
	FINDING,

	/** A code line location. */
	CODE_LINE,

	/** A code region location. */
	CODE_REGION,

	/** A code file location. */
	CODE_FILE,

	/** A qualified name location. */
	QUALIFIED_NAME,

	/** Element in key/value list. */
	KEY_VALUE_PAIR,
}

package edu.tum.cs.conqat.architecture.graph;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.html.HTMLWriter;
import edu.tum.cs.commons.xml.IXMLResolver;
import edu.tum.cs.commons.xml.XMLWriter;
import edu.tum.cs.conqat.architecture.format.EArchitectureIOAttribute;
import edu.tum.cs.conqat.architecture.format.EArchitectureIOElement;
import edu.tum.cs.conqat.architecture.format.EAssessmentType;
import edu.tum.cs.conqat.graph.concentrate.GraphConcentrator;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.tum.cs.conqat.graph.nodes.IConQATGraphNode;
import edu.tum.cs.conqat.logging.IConQATLogger;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * Writes a {@link ConQATGraph} containing an architecture assessment to a file.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 21610 $
 * @levd.rating RED Rev:
 */
/* package */ class AssessmentFileWriter extends
		XMLWriter<EArchitectureIOElement, EArchitectureIOAttribute> {

	/** Graph that gets written to file */
	private final ConQATGraph graph;

	/** Logger */
	private final IConQATLogger logger;

	/**
	 * Constructor
	 * 
	 * @param file
	 *            Target file into which assessment results are written
	 * @param graph
	 *            Graph that gets written to file
	 */
	public AssessmentFileWriter(File file, ConQATGraph graph,
			IConQATLogger logger) throws FileNotFoundException {
		super(new PrintStream(file), new Resolver());
		this.graph = graph;
		this.logger = logger;
	}

	/** Write graph to file */
	public void writeGraph() {
		// add XML header with version and encoding information
		addHeader("1.0", "ISO-8859-1");

		openElement(EArchitectureIOElement.ASSESSMENT);
		writeComponents();
		writeDependencyGroups();
		closeElement(EArchitectureIOElement.ASSESSMENT);

		// close the underlying stream
		close();
	}

	/** Write components section */
	private void writeComponents() {
		openElement(EArchitectureIOElement.COMPONENT);

		IConQATGraphNode[] topLevelComponents = graph.getChildren();
		for (IConQATGraphNode topLevelComponent : topLevelComponents) {
			writeComponent(topLevelComponent);
		}

		closeElement(EArchitectureIOElement.COMPONENT);
	}

	/** Write a component and its descendants to XML */
	private void writeComponent(IConQATGraphNode component) {
		openElement(EArchitectureIOElement.COMPONENT);

		addAttribute(EArchitectureIOAttribute.NAME, component.getName());

		writeMatchedVertices(component);

		if (component.hasChildren()) {
			for (IConQATGraphNode childComponent : component.getChildren()) {
				writeComponent(childComponent);
			}
		}

		closeElement(EArchitectureIOElement.COMPONENT);
	}

	/** Writes the vertices contained in the component to XML */
	@SuppressWarnings("unchecked")
	private void writeMatchedVertices(IConQATGraphNode component) {

		Object matchedTypesObject = component
				.getValue(ArchitectureHierarchyBuilder.MATCHED_TYPES_KEY);

		if (matchedTypesObject == null) {
			return;
		}

		if (!(matchedTypesObject instanceof Collection)) {
			logger.warn("Unexpected type found for key "
					+ ArchitectureHierarchyBuilder.MATCHED_TYPES_KEY
					+ " at node " + component.getId());
			return;
		}
		Collection<String> matchedTypes = (Collection<String>) matchedTypesObject;

		for (String matchedType : CollectionUtils.sort(matchedTypes)) {
			openElement(EArchitectureIOElement.TYPE);
			addAttribute(EArchitectureIOAttribute.NAME, matchedType);
			closeElement(EArchitectureIOElement.TYPE);
		}
	}

	/** Write dependency groups section */
	private void writeDependencyGroups() {
		openElement(EArchitectureIOElement.DEPENDENCY_GROUPS);

		for (DirectedSparseEdge edge : graph.getEdges()) {
			writeDependencyGroup(edge);
		}

		closeElement(EArchitectureIOElement.DEPENDENCY_GROUPS);
	}

	/** Write a single dependency group */
	private void writeDependencyGroup(DirectedSparseEdge edge) {
		openElement(EArchitectureIOElement.DEPENDENCY_GROUP);

		writeDependencyGroupAttributes(edge);

		writeDependencies(edge);

		closeElement(EArchitectureIOElement.DEPENDENCY_GROUP);
	}

	/** Write attributes for a dependency group */
	private void writeDependencyGroupAttributes(DirectedSparseEdge edge)
			throws AssertionError {
		Object sourceComponentName = getComponentName(edge.getSource());
		addAttribute(EArchitectureIOAttribute.SOURCE, sourceComponentName);

		Object targetComponentName = getComponentName(edge.getDest());
		addAttribute(EArchitectureIOAttribute.TARGET, targetComponentName);

		// policy type is null for the "unknownNode" ("elements for component")
		if (edge.getUserDatum(ArchitectureEdgeAssessor.POLICY_TYPE_KEY) != null) {
			addAttribute(EArchitectureIOAttribute.POLICY_TYPE, edge
					.getUserDatum(ArchitectureEdgeAssessor.POLICY_TYPE_KEY));
			EAssessmentType policyAssessment = determinePolicyAssessment(edge);
			addAttribute(EArchitectureIOAttribute.ASSESSMENT_TYPE,
					policyAssessment);
		}
	}

	/** Determines the {@link EAssessmentType} for a policy */
	private EAssessmentType determinePolicyAssessment(DirectedSparseEdge edge)
			throws AssertionError {
		Assessment edgeAssessment = (Assessment) edge
				.getUserDatum(ArchitectureEdgeAssessor.ASSESSMENT_KEY);
		List<String> originalDependencies = getDependenciesList(edge);
		if (originalDependencies.size() == 0) {
			return EAssessmentType.UNNECESSARY;
		}

		if (edgeAssessment.getDominantColor() == ETrafficLightColor.GREEN) {
			return EAssessmentType.VALID;
		}

		if (edgeAssessment.getDominantColor() == ETrafficLightColor.RED) {
			return EAssessmentType.INVALID;
		}

		// TODO assessments needs to be determined, but no time atm
		if (edgeAssessment.getDominantColor() == ETrafficLightColor.YELLOW) {
			return EAssessmentType.INVALID;
		}

		throw new AssertionError("Not implemented");
	}

	/** Write dependencies list */
	private void writeDependencies(DirectedSparseEdge edge) {
		List<String> dependencies = getDependenciesList(edge);
		for (String dependency : dependencies) {
			openElement(EArchitectureIOElement.DEPENDENCY);

			String[] ends = dependency.split(" -> ");
			CCSMAssert.isTrue(ends.length == 2, "Invalid dependency format");

			addAttribute(EArchitectureIOAttribute.SOURCE, ends[0]);
			addAttribute(EArchitectureIOAttribute.TARGET, ends[1]);

			closeElement(EArchitectureIOElement.DEPENDENCY);
		}
	}

	/** Extracts the list of original dependencies stored in an edge */
	@SuppressWarnings("unchecked")
	private List<String> getDependenciesList(DirectedSparseEdge edge) {
		Object listObject = edge
				.getUserDatum(GraphConcentrator.ORIGINAL_EDGES_KEY);
		if (listObject == null) {
			return new ArrayList<String>();
		}

		CCSMPre.isTrue(listObject instanceof List, "Expecting a string list");

		List<String> dependencies = (List<String>) listObject;
		return dependencies;
	}

	/** Extracts the name from the id of a ConQATVertex */
	private Object getComponentName(Vertex obj) {
		if (!(obj instanceof ConQATVertex)) {
			CCSMPre.fail("ConQATVertex expected");
		}

		ConQATVertex vertex = (ConQATVertex) obj;
		String id = vertex.getId();

		if (id.endsWith("_")) {
			// cut of trailing "_"
			id.subSequence(0, id.length() - 1);
		}
		return id;
	}

	/** The resolver used for the {@link HTMLWriter}. */
	public static class Resolver implements
			IXMLResolver<EArchitectureIOElement, EArchitectureIOAttribute> {

		/** {@inheritDoc} */
		public String resolveAttributeName(EArchitectureIOAttribute attribute) {
			return attribute.toString();
		}

		/** {@inheritDoc} */
		public String resolveElementName(EArchitectureIOElement element) {
			return element.toString();
		}

		/** {@inheritDoc} */
		public Class<EArchitectureIOAttribute> getAttributeClass() {
			return EArchitectureIOAttribute.class;
		}
	}

}

/*--------------------------------------------------------------------------+
   $Id: ArchitectureDefinitionVisualizer.java 20892 2009-03-27 12:32:17Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.graph;

import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.architecture.scope.ComponentNode;
import edu.tum.cs.conqat.architecture.scope.DependencyPolicy;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphInnerNode;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.tum.cs.conqat.graph.nodes.DeepCloneCopyAction;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * This processor produces a {@link ConQATGraph} to graphically represent the
 * given architecture definition. For each dependency a colored edge is added.
 * The edge color depends on the edge rating.
 * 
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 20892 $
 * @levd.rating GREEN Rev: 20892
 */
@AConQATProcessor(description = "This processor produces a ConQAT graph to graphically represent the"
		+ "given architecture definition. For each dependency a colored edge is added.")
public class ArchitectureDefinitionVisualizer extends ConQATProcessorBase {

	/** String appended to make "artificial" inner nodes. */
	public static final String ARTIFICIAL_NODE_POSTFIX = "_";

	/** Key used to store assessments representing the policies at edges. */
	@AConQATKey(description = "The key used to store assessments representing the policies at edges.", type = "edu.tum.cs.commons.assessment.Assessment")
	public static final String POLICY_KEY = "policy";

	/** The key used to store the component's dimension. */
	@AConQATKey(description = "The key used to store the component's dimension.", type = "java.awt.Dimension")
	public static final String COMPONENT_DIMENSION = "dimension";

	/**
	 * The key used to store the component's position. This position is
	 * <b>absolute</b>!
	 */
	@AConQATKey(description = "The key used to store the component's position. This position is absolute.", type = "java.awt.Point")
	public static final String COMPONENT_POSITION = "position";

	/** Resulting graph */
	private ConQATGraph graph;

	/** Architecture definition */
	private ComponentNode arch;

	/** Set the input architecture. */
	@AConQATParameter(name = "architecture", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Set the architecture being visualized.")
	public void setArchitectureDef(
			@AConQATAttribute(name = "def", description = "Reference to the generating processor.") ComponentNode arch) {
		this.arch = arch;
	}

	/** {@inheritDoc} */
	public ConQATGraph process() throws ConQATException {
		createNodesFromComponents();
		createEdgesFromPolicies();

		return graph;
	}

	/**
	 * Creates the nodes of the architecture graph from the component hierarchy
	 * of the architecture description.
	 */
	private void createNodesFromComponents() throws ConQATException {
		graph = new ConQATGraph(arch.getName(), arch.getName()
				+ ARTIFICIAL_NODE_POSTFIX);

		if (arch.hasPolicies()) {
			graph.createVertex(arch.getName(), arch.getName(), graph);
		}

		for (ComponentNode comp : arch.getChildren()) {
			createNodesForComponent(comp, graph);
		}
	}

	/**
	 * Duplicate the component structure of the architecture as a hierarchical
	 * graph.
	 */
	private void createNodesForComponent(ComponentNode comp,
			ConQATGraphInnerNode parentNode) throws ConQATException {

		ConQATGraphInnerNode compNode = parentNode;
		if (comp.hasChildren()) {
			compNode = parentNode.createChildNode(comp.getName()
					+ ARTIFICIAL_NODE_POSTFIX, comp.getName()
					+ ARTIFICIAL_NODE_POSTFIX);

			for (ComponentNode child : comp.getChildren()) {
				createNodesForComponent(child, compNode);
			}

		}

		// Vertices will now be paint regardless of having policies or not.
		ConQATVertex vertex = graph.createVertex(comp.getName(),
				comp.getName(), compNode);

		Dimension dim = comp.getDimension();
		if (dim != null) {
			vertex.setValue(COMPONENT_DIMENSION, dim);
		}
		Point pos = comp.getAbsolutePosition();
		vertex.setValue(COMPONENT_POSITION, pos);

	}

	/**
	 * Creates the edges of the architecture graph from the policies of the
	 * architecture description.
	 */
	private void createEdgesFromPolicies() {
		List<DependencyPolicy> policies = new ArrayList<DependencyPolicy>();
		arch.collectPolicies(policies);

		for (DependencyPolicy policy : policies) {
			// create edge
			ConQATVertex from = graph.getVertexByID(policy.getSource()
					.getName());
			ConQATVertex to = graph.getVertexByID(policy.getTarget().getName());
			DirectedSparseEdge edge = graph.addEdge(from, to);

			// set color depending on policy
			ETrafficLightColor color = policy.getPolicyType()
					.toTrafficLightColor();

			// create assessment based on color
			edge.addUserDatum(POLICY_KEY, new Assessment(color),
					DeepCloneCopyAction.getInstance());
		}
	}

}

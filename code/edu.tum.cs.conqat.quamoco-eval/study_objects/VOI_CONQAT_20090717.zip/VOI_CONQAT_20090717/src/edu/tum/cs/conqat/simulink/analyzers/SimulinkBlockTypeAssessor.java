/*--------------------------------------------------------------------------+
   $Id: SimulinkBlockTypeAssessor.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import java.util.HashSet;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * This processor annotates blocks of specified types with warning messages.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This processor annotates blocks of "
		+ "specified types with warning messages.")
public class SimulinkBlockTypeAssessor extends
		SimulinkBlockTraversingProcessorBase {

	/** Key for messages. */
	@AConQATKey(description = "Key for messages", type = "edu.tum.cs.commons.collections.HashedListMap<String, String>")
	public static final String MESSAGES_KEY = "BlockMessages";

	/** Key for assessment. */
	@AConQATKey(description = "Key for assessment", type = "edu.tum.cs.commons.assessment.Assessment")
	public static final String ASSESSMENT_KEY = "BlockAssessment";

	/** Set of prohibited types. */
	private final HashSet<String> prohibitedTypes = new HashSet<String>();

	/** Add prohibited type. */
	@AConQATParameter(name = "prohibit", description = "Add prohibited type", minOccurrences = 1)
	public void addProhibitedType(
			@AConQATAttribute(name = "type", description = "Name of of prohibited "
					+ "type. Use 'Reference.<type>' for library types.") String blockType) {
		prohibitedTypes.add(blockType);
	}

	/** Add key to display list. */
	@Override
	protected void setUp(ISimulinkElement root) {
		NodeUtils.addToDisplayList(root, ASSESSMENT_KEY, MESSAGES_KEY);
	}

	/** Optimistically set model rating to green. */
	@Override
	protected void setUpModel(SimulinkModelElement modelNode) {
		modelNode.setValue(ASSESSMENT_KEY, new Assessment(
				ETrafficLightColor.GREEN));
	}

	/** Check if block has prohibited type. */
	@Override
	protected void visitBlock(SimulinkBlock block,
			SimulinkModelElement modelNode) throws ConQATException {

		String type = block.getResolvedType();

		if (prohibitedTypes.contains(type)) {
			NodeUtils.addMessage(modelNode, MESSAGES_KEY, block.getId(),
					"Prohibited type '" + type + "'.");
			modelNode.setValue(ASSESSMENT_KEY, new Assessment(
					ETrafficLightColor.RED));
		}
	}
}

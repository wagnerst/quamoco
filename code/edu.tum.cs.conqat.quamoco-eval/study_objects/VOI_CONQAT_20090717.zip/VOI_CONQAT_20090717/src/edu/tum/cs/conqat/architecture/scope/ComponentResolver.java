/*--------------------------------------------------------------------------+
   $Id: ComponentResolver.java 21358 2009-05-07 12:03:12Z heineman $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.scope;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.conqat.architecture.graph.ArchitectureEdgeAssessor;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Maps vertices from {@link ConQATGraph} to their corresponding architecture
 * components.
 * 
 * @author juergens
 * @author $Author: heineman $
 * @version $Rev: 21358 $
 * @levd.rating GREEN Rev: 20644
 */
public class ComponentResolver {

	/** The reference architecture. */
	private final ComponentNode arch;

	/** Logger used to issue warnings */
	private final IConQATLogger logger;

	/** Cache for element to component results. */
	private final Map<String, ComponentNode> elementLookup = new HashMap<String, ComponentNode>();

	/** Default constructor */
	public ComponentResolver(ComponentNode arch, IConQATLogger logger) {
		if (arch == null) {
			throw new IllegalArgumentException("Architecture must not be null");
		}
		this.arch = arch;
		this.logger = logger;
	}

	/**
	 * Tries to determine the architecture component corresponding to a
	 * {@link ConQATVertex}. If no or more than one component is found, a
	 * warning message is logged.
	 * 
	 * @return Correspondig component, or null, if no unambiguous match could be
	 *         found
	 */
	public ComponentNode findComponentFor(String vertexId) {
		return findComponentFor(vertexId, null);
	}

	/**
	 * Tries to determine the architecture component corresponding to a
	 * {@link ConQATVertex}. If no or more than one component is found, a
	 * warning message is logged.
	 * 
	 * @return Correspondig component, or null, if no unambiguous match could be
	 *         found
	 */
	public ComponentNode findComponentFor(ConQATVertex vertex) {
		return findComponentFor(vertex.getId(), vertex);
	}

	/** Performs the actual component resolution. */
	private ComponentNode findComponentFor(String vertexId, ConQATVertex vertex) {
		if (vertex != null && !vertex.getId().equals(vertexId)) {
			throw new IllegalStateException(
					"vertexId != vertex.getId(). This should never happen");
		}

		if (!elementLookup.containsKey(vertexId)) {

			List<ComponentNode> components = new ArrayList<ComponentNode>();
			arch.findMatchingComponents(vertexId, components);
			if (components.isEmpty()) {
				elementLookup.put(vertexId, null);
				logNoComponentFound(vertexId, vertex);
			} else if (components.size() > 1) {
				// components was filled by preorder traversal
				boolean hierarchy = true;
				for (int i = components.size() - 1; i > 0; i--) {
					if (!components.get(i).getParent().equals(
							components.get(i - 1))) {
						hierarchy = false;
						break;
					}
				}
				if (!hierarchy) {
					elementLookup.put(vertexId, null);
					logMultipleComponentsFound(vertexId, vertex, components);
				} else {
					elementLookup.put(vertexId, components.get(components
							.size() - 1));
				}
			} else {
				elementLookup.put(vertexId, components.get(0));
			}
		}

		return elementLookup.get(vertexId);
	}

	/** Create error logging messages if no component has been found */
	private void logNoComponentFound(String vertexId, ConQATVertex vertex) {
		if (logger != null) {
			logger.warn("Could find no component for " + vertexId);
		}
		if (vertex != null) {
			NodeUtils.getOrCreateStringList(vertex,
					ArchitectureEdgeAssessor.VIOLATION_KEY).add(
					"Unknown component!");
		}
	}

	/** Create error logging messages if multiple components have been found */
	private void logMultipleComponentsFound(String vertexId,
			ConQATVertex vertex, List<ComponentNode> components) {
		String compIDs = "";
		for (ComponentNode cnode : components) {
			compIDs += " " + cnode.getName();
		}

		if (logger != null) {
			logger.warn("Found multiple components for " + vertexId + ":"
					+ compIDs);
		}
		if (vertex != null) {
			NodeUtils.getOrCreateStringList(vertex,
					ArchitectureEdgeAssessor.VIOLATION_KEY).add(
					"Found multiple components!");
		}
	}

}

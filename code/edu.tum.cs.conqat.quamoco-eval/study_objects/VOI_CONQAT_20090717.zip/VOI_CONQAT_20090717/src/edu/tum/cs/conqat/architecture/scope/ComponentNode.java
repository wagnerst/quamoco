/*--------------------------------------------------------------------------+
   $Id: ComponentNode.java 21358 2009-05-07 12:03:12Z heineman $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.scope;

import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.collections.IdentityHashSet;
import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.commons.node.ConQATGeneralNodeBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * This is a node representing a component (which can in turn have sub
 * components). The elements of a system (usually these are classes) are mapped
 * onto these components.
 * 
 * @author Benjamin Hummel
 * @author $Author: heineman $
 * @version $Rev: 21358 $
 * @levd.rating YELLOW Rev: 20957
 */
public class ComponentNode extends ConQATGeneralNodeBase<ComponentNode> {

	/** Full unique name of this component. */
	private final String name;

	/**
	 * Position of this Component. The Position is relative to the parent
	 * Component!
	 */
	private Point pos;

	/** Dimension of this Component. */
	private Dimension dim;

	/**
	 * Policy defining whether child components may communicate with each other.
	 */
	private final EPolicyType defaultPolicy;

	/** Names of elements contained in this component. */
	private final Set<String> containedElementNames = new HashSet<String>();

	/** Patterns matching names of elements contained in this component. */
	private final PatternList containedElementPattern = new PatternList();

	/** Names of components that are explicitly not part of this component */
	private final Set<String> excludedElementNames = new HashSet<String>();

	/**
	 * Patterns matching names of elements explicitly excluded from this
	 * component. (Overrules containedElementPattern)
	 */
	private final PatternList excludedElementPattern = new PatternList();

	/** All policies for which this component is the from part. */
	private final Collection<DependencyPolicy> fromPolicies = new HashSet<DependencyPolicy>();

	/** All policies for which this component is the to part. */
	private final Collection<DependencyPolicy> toPolicies = new HashSet<DependencyPolicy>();

	/**
	 * Creates a new {@link ComponentNode}.
	 * 
	 * @param defaultPolicy
	 *            Default policy for this component. Default policy determines
	 *            whether, in absence of further policies, the child components
	 *            of this component are allowed to depend on each other.
	 * @param pos
	 *            Position of this component.
	 * 
	 * @throws IllegalArgumentException
	 *             if pos is null.
	 * 
	 */
	/* package */ComponentNode(String name, EPolicyType defaultPolicy, Point pos) {
		CCSMPre.isFalse(pos == null, "The position must not be null");

		this.name = name;
		this.defaultPolicy = defaultPolicy;
		this.pos = pos;
	}

	/** Copy constructor. */
	private ComponentNode(ComponentNode node) throws DeepCloneException {
		super(node);
		name = node.name;
		defaultPolicy = node.defaultPolicy;
		containedElementNames.addAll(node.containedElementNames);
		containedElementPattern.addAll(node.containedElementPattern);
		excludedElementPattern.addAll(node.excludedElementPattern);
		excludedElementNames.addAll(node.excludedElementNames);

		pos = node.getPosition();
		dim = node.getDimension();

		// cloning of dependency rules is initiated from the root node
		if (node.getParent() == null) {
			Collection<DependencyPolicy> policies = new ArrayList<DependencyPolicy>();
			node.collectPolicies(policies);
			Map<String, ComponentNode> nameLookup = new HashMap<String, ComponentNode>();
			fillNameLookup(nameLookup);

			for (DependencyPolicy policy : policies) {
				ComponentNode newFrom = nameLookup.get(policy.getSource()
						.getName());
				ComponentNode newTo = nameLookup.get(policy.getTarget()
						.getName());
				DependencyPolicy cloned = new DependencyPolicy(policy, newFrom,
						newTo);
				cloned.registerWithComponents();
			}
		}
	}

	/**
	 * Creates a lookup table from Names to components by traversing the nodes
	 * in DFS order and putting results into the provided map.
	 */
	private void fillNameLookup(Map<String, ComponentNode> nameLookup) {
		nameLookup.put(getName(), this);
		if (hasChildren()) {
			for (ComponentNode child : getChildren()) {
				child.fillNameLookup(nameLookup);
			}
		}
	}

	/**
	 * Collect all policies by traversing the tree in DFS order and using only
	 * fromPolicies, to avoid duplicate entries. Results are put into the
	 * provided collection.
	 */
	public void collectPolicies(Collection<DependencyPolicy> policies) {
		policies.addAll(fromPolicies);
		if (hasChildren()) {
			for (ComponentNode child : getChildren()) {
				child.collectPolicies(policies);
			}
		}
	}

	/** {@inheritDoc} */
	@Override
	protected ComponentNode[] allocateArray(int size) {
		return new ComponentNode[size];
	}

	/** deprecated, use getName() instead */
	@Deprecated
	public String getId() {
		return name;
	}

	/** {@inheritDoc} */
	public String getName() {
		return name;
	}

	/** {@inheritDoc} */
	public ComponentNode deepClone() throws DeepCloneException {
		return new ComponentNode(this);
	}

	/** Adds an element's name to the list of contained elements. */
	/* package */void addElement(String elementName) {
		containedElementNames.add(elementName);
	}

	/**
	 * Excludes an element from this {@link ComponentNode} and all is parent
	 * nodes.
	 */
	/* package */void excludeElement(String elementName) {
		containedElementNames.remove(elementName);
		excludedElementNames.add(elementName);

		// propagate removal up to root
		if (getParent() != null) {
			getParent().excludeElement(elementName);
		}
	}

	/** Adds an additional pattern to identify elements of this component. */
	/* package */void addElementRegex(String regex) throws ConQATException {
		try {
			containedElementPattern.add(Pattern.compile(regex));
		} catch (PatternSyntaxException e) {
			throw new ConQATException("Malformed regex pattern: " + regex, e);
		}
	}

	/**
	 * Adds an additional exclude pattern to explicitly exclude elements of this
	 * component. (Overrules patterhs added by {@link #addElementRegex(String)}
	 * ).
	 */
	/* package */void addExcludeRegex(String regex) throws ConQATException {
		try {
			excludedElementPattern.add(Pattern.compile(regex));
		} catch (PatternSyntaxException e) {
			throw new ConQATException("Malformed regex pattern: " + regex, e);
		}
	}

	/** Add a dependency policy to this component. */
	/* package */void addPolicy(DependencyPolicy policy) {
		if (policy.getSource() == this) {
			fromPolicies.add(policy);
		}
		if (policy.getTarget() == this) {
			toPolicies.add(policy);
		}
	}

	/** Returns whether any policies are assigned to this component. */
	public boolean hasPolicies() {
		return !(fromPolicies.isEmpty() && toPolicies.isEmpty());
	}

	/**
	 * Find all components (this plus child components) into which the given
	 * element name fits. They are put into the provided collection.
	 * The list of component nodes is filled by 'preorder' traversal.
	 */
	public void findMatchingComponents(String elementName,
			List<ComponentNode> result) {
		if (containedElementNames.contains(elementName)
				|| containedElementPattern.matchesAny(elementName)) {

			// explicitly check if elementName is excluded
			if (!excludedElementPattern.matchesAny(elementName)
					&& !excludedElementNames.contains(elementName)) {
				result.add(this);
			}
		}
		if (hasChildren()) {
			for (ComponentNode child : getChildren()) {
				child.findMatchingComponents(elementName, result);
			}
		}
	}

	/**
	 * Returns the policy type that governs the dependency between this node and
	 * its target.
	 */
	public EPolicyType getGoverningPolicyType(ComponentNode target) {
		DependencyPolicy policy = getGoverningPolicy(target);
		if (policy == null) {
			// See getGoverningPolicy(ComponentNode target) why allow this
			return EPolicyType.ALLOW_IMPLICIT;
		}

		return policy.getPolicyType();
	}

	/**
	 * Returns the policy that governs the dependency between this node and its
	 * target.
	 */
	public DependencyPolicy getGoverningPolicy(ComponentNode target) {
		// allow dependencies between components that are in a containment
		// relationship
		if (target.getPredecessorSet().contains(this)
				|| getPredecessorSet().contains(target)) {
			// (MP) We cannot deliver a
			// "new DependencyPolicy(this, target, EPolicyType.ALLOW_IMPLICIT)"
			// here since no self loops allowed! So null determines a an allowed
			// dependency here.
			return null;
		}
		return getNonContainmentPolicy(target);
	}

	/**
	 * Returns the policy type that governs the dependency between this node and
	 * its target. This method expects this node not to be in a containment
	 * relationship with the target node.
	 */
	private DependencyPolicy getNonContainmentPolicy(ComponentNode target) {
		Map<ComponentNode, Integer> targetParents = new HashMap<ComponentNode, Integer>();
		ComponentNode originalTarget = target;
		int prio = 0;
		do {
			targetParents.put(target, prio++);
			target = target.getParent();
		} while (target != null);

		ComponentNode source = this;
		while (source != null) {

			// found common ancestor, so use its policy
			if (targetParents.containsKey(source)) {
				return new DependencyPolicy(source, originalTarget,
						source.defaultPolicy);
			}

			DependencyPolicy bestPolicy = null;
			int bestPrio = Integer.MAX_VALUE;
			for (DependencyPolicy depPolicy : source.fromPolicies) {
				if (targetParents.containsKey(depPolicy.getTarget())) {
					prio = targetParents.get(depPolicy.getTarget());
					if (prio < bestPrio) {
						bestPrio = prio;
						bestPolicy = depPolicy;
					}
				}
			}
			if (bestPolicy != null) {
				return bestPolicy;
			}
			source = source.getParent();
		}

		throw new IllegalStateException(
				"This should never be reached as at least the root component "
						+ "should be a common ancestor for both.");
	}

	/**
	 * Returns a set containing this node and all predecessors of this node in
	 * the hierarchy!
	 */
	public Set<ComponentNode> getPredecessorSet() {
		Set<ComponentNode> result = new IdentityHashSet<ComponentNode>();
		ComponentNode node = this;
		while (node != null) {
			result.add(node);
			node = node.getParent();
		}
		return result;
	}

	/**
	 * Convenience method for setting the position from a comma separated
	 * string, i.e. "x,y".
	 */
	public void setPosition(String stringAttribute) {
		setPosition(positionFromString(stringAttribute));
	}

	/**
	 * Sets the position of this component.
	 */
	public void setPosition(Point pos) {
		if (pos != null) {
			this.pos = pos;
		}
	}

	/**
	 * Convenience method for setting the dimension from a comma separated
	 * string, i.e. "width,height".
	 */
	public void setDimension(String stringAttribute) {
		setDimension(dimensionFromString(stringAttribute));
	}

	/**
	 * Sets the position of this component.
	 */
	public void setDimension(Dimension dim) {
		if (dim != null) {
			this.dim = dim;
		}
	}

	/**
	 * Returns the relative Position of this Component.
	 */
	public Point getPosition() {
		return pos;
	}

	/**
	 * Returns the absolute Position of this Component.
	 */
	public Point getAbsolutePosition() {
		if (getPosition() == null) {
			return null;
		}

		Point parentPos;
		if (this.getParent() != null) {
			parentPos = this.getParent().getAbsolutePosition();
		} else {
			parentPos = new Point();
		}

		Point ret = new Point(getPosition());
		ret.translate(parentPos.x, parentPos.y);
		return ret;
	}

	/** Returns the Dimension of this Component. */
	public Dimension getDimension() {
		return dim;
	}

	/**
	 * Converts a comma separated String into a Position. If the string isn't
	 * comma separated an {@link IllegalArgumentException} is thrown.
	 */
	public static Point positionFromString(String str) {
		int[] pair = splitToIntPair(str);
		if (pair != null) {
			return new Point(pair[0], pair[1]);
		}
		return null;
	}

	/**
	 * Converts a comma separated String into a Dimension. If the string isn't
	 * comma separated an {@link IllegalArgumentException} is thrown.
	 */
	public static Dimension dimensionFromString(String str) {
		int[] pair = splitToIntPair(str);
		if (pair != null) {
			return new Dimension(pair[0], pair[1]);
		}
		return null;
	}

	/**
	 * Returns a two object integer array, created from the comma separated
	 * string or null if the string is not valid, i.e. not "x,y".
	 */
	private static int[] splitToIntPair(String str) {
		String[] sarr = str.split(",");

		if (sarr.length < 2) {
			return null;
		}

		int[] intarr = new int[2];
		intarr[0] = Integer.parseInt(sarr[0]);
		intarr[1] = Integer.parseInt(sarr[1]);

		return intarr;
	}

}

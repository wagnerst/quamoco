/*--------------------------------------------------------------------------+
   $Id: LeftRightOrientationAssessor.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;
import edu.tum.cs.simulink.model.SimulinkLine;
import edu.tum.cs.simulink.util.SimulinkUtils;

/**
 * This processor checks if the ratio of lines routed from right to left to all
 * linesdoes not cross a given threshold.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This processor checks if the "
		+ "ratio of lines routed from right to left to all lines"
		+ "does not cross a given threshold.")
public class LeftRightOrientationAssessor extends
		SimulinkBlockTraversingProcessorBase {

	/** Message key. */
	@AConQATKey(description = "Message Key", type = "java.lang.String")
	public static final String KEY = "OrientationMessage";

	/** Default threshold that is used if no threshold was specified. */
	private static final double DEFAULT_THRESHOLD = 0.2;

	/** Threshold. */
	private double threshold = DEFAULT_THRESHOLD;

	/** Total number of lines (per model). */
	private int totalLineCount;

	/** Number of lines with right-left orientation (per model). */
	private int rlLineCount;

	/** Set threshold */
	@AConQATParameter(name = "threshold", description = "Set threshold "
			+ "(ratio of line with right-left orienation to"
			+ "toal number of lines)", maxOccurrences = 1)
	public void setThreshold(
			@AConQATAttribute(name = "value", description = "Threshold value [default: "
					+ DEFAULT_THRESHOLD + "]")
			double value) {
		threshold = value;
	}

	/** Add key to display list. */
	@Override
	protected void setUp(ISimulinkElement root) {
		NodeUtils.addToDisplayList(root, KEY);
	}

	/** Reset counter values. */
	@Override
	protected void setUpModel(SimulinkModelElement modelNode) {
		totalLineCount = 0;
		rlLineCount = 0;
	}

	/** Evaluate result and create message if necessary. */
	@Override
	protected void finishModel(SimulinkModelElement model) {
		if (totalLineCount == 0) {
			return;
		}
		double ratio = (double) rlLineCount / totalLineCount;

		if (ratio > threshold) {
			model.setValue(KEY, rlLineCount + " of " + totalLineCount
					+ " lines have right to left orientation ("
					+ StringUtils.formatAsPercentage(ratio) + ")");
		}
	}

	/** Count lines and lines with left-right orientation. */
	@Override
	protected void visitBlock(SimulinkBlock block,
			SimulinkModelElement modelNode) {
		for (SimulinkLine line : block.getOutLines()) {
			totalLineCount++;
			if (isRightToLeft(line)) {
				rlLineCount++;
			}
		}
	}

	/** Checks if a line a has right to left orientation . */
	private boolean isRightToLeft(SimulinkLine line) {
		String srcPosition = line.getSrcPort().getBlock().getParameter(
				"Position");
		int srcX = SimulinkUtils.getIntParameterArray(srcPosition)[0];

		String dstPosition = line.getDstPort().getBlock().getParameter(
				"Position");
		int dstX = SimulinkUtils.getIntParameterArray(dstPosition)[0];

		return srcX > dstX;
	}
}

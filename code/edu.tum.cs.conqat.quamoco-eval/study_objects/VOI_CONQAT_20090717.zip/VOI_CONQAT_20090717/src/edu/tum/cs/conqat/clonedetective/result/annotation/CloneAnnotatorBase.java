/*--------------------------------------------------------------------------+
   $Id: CloneAnnotatorBase.java 16957 2008-07-04 15:21:40Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.List;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for processors that annotate the file tree with clone-related
 * information.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16957 $
 * @levd.rating GREEN Rev: 16957
 */
public abstract class CloneAnnotatorBase extends
		ConQATPipelineProcessorBase<CloneDetectionResultElement> implements
		INodeVisitor<IFileSystemElement, ConQATException> {

	/** Maps from element ids to a list of clones found in the element */
	private final HashedListMap<String, IClone> idToClones = new HashedListMap<String, IClone>();

	/**
	 * Performs annotation.
	 * <p>
	 * {@inheritDoc}
	 */
	@Override
	protected void processInput(CloneDetectionResultElement input)
			throws ConQATException {
		NodeUtils.addToDisplayList(input.getRoot(), getKeys());
		createMapping(input);
		TraversalUtils.visitLeavesDepthFirst(this, input.getRoot());
		checkLeftOverClones();
	}

	/**
	 * Template method that allows deriving classes to add Keys to the root
	 * node's display list
	 */
	protected String[] getKeys() {
		return new String[] {};
	}

	/**
	 * Creates mapping between element id and clone list, and between clones and
	 * their clone classes
	 */
	private void createMapping(CloneDetectionResultElement result) {
		for (CloneClass cloneClass : result.getList()) {
			for (IClone clone : cloneClass.getClones()) {
				idToClones.add(clone.getOrigin(), clone);
			}
		}
	}

	/** Perform annotation on an element */
	public void visit(IFileSystemElement element) throws ConQATException {
		String id = element.getId();
		List<IClone> clonesList = idToClones.getList(id);
		if (clonesList == null) {
			clonesList = CollectionUtils.emptyList();
		}

		annotateClones(element, CollectionUtils.asUnmodifiable(clonesList));
		idToClones.removeList(id);
	}

	/**
	 * Template method that deriving classes implement to perform their
	 * annotation.
	 * 
	 * @param element
	 *            Element to which clones are annotated
	 * @param clonesList
	 *            List of clones for this element, or empty list, if no clones
	 *            are present in this element
	 * 
	 */
	protected abstract void annotateClones(IFileSystemElement element,
			UnmodifiableList<IClone> clonesList) throws ConQATException;

	/**
	 * Check if any clones are left, for which no corresponding element has been
	 * found and generate warning messages accordingly. (This could happen, if
	 * the elements have been removed from the file tree after clone detection.)
	 */
	protected void checkLeftOverClones() {
		for (String filename : idToClones.getKeys()) {
			getLogger().warn(
					"No file system element found for file '" + filename + "'");
		}
	}

}

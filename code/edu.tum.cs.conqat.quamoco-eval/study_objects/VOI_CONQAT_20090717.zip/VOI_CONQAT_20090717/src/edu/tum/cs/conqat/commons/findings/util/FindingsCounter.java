/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingsCounter.java 21999 2009-07-15 20:43:23Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21999 $
 * @levd.rating YELLOW Rev: 21999
 */
@AConQATProcessor(description = ""
		+ "This processor counts the number of findings in a ConQAT node structure. "
		+ "Findings are counted both within the nodes and in finding lists "
		+ "stored in given keys. This way in can be used both for plain nodes as "
		+ "well as finding reports. The result is stored at the root.")
public class FindingsCounter extends NodeTraversingProcessorBase<IConQATNode> {

	/** The key to store the result in. */
	@AConQATKey(description = "The number of findings found.", type = "java.lang.Integer")
	public static final String KEY = "#findings";

	/** The number of findings found. */
	private int count = 0;

	/** The keys to look in for findings. */
	private final List<String> keys = new ArrayList<String>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "findings", description = "If keys are given, all findings stored at these keys are counted as well.")
	public void addKey(
			@AConQATAttribute(name = "key", description = "The key to look into.") String key) {
		keys.add(key);
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.ALL;
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) {
		if (node instanceof Finding) {
			++count;
		}
		for (String key : keys) {
			Object value = node.getValue(key);
			if (value instanceof Finding) {
				++count;
			} else if (value instanceof Collection) {
				for (Object o : (Collection<?>) value) {
					if (o instanceof Finding) {
						++count;
					}
				}
			}
		}
	}

	/** {@inheritDoc} */
	@Override
	protected void finish(IConQATNode root) {
		root.setValue(KEY, count);
	}
}

package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.algo.Diff;
import edu.tum.cs.commons.algo.Diff.Delta;
import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.collections.IdentityHashSet;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.EEditOperation;
import edu.tum.cs.conqat.clonedetective.core.GappedClone;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.clonedetective.core.IUnit;
import edu.tum.cs.conqat.clonedetective.core.IdProvider;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.database.DatabaseProcessorBase;

/**
 * {@ConQAT.doc}
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 22038 $
 * @levd.rating RED Rev:
 */
@AConQATProcessor(description = "Performs clone tracing")
public class CloneTracker extends DatabaseProcessorBase {

	/** Key under which tracked clone classes are marked as tracked */
	public static final String TRACKED = "tracked";

	/** List of old clone classes with updated positions */
	private List<CloneClass> updatedCloneClasses;

	/** New clone detection result */
	private CloneDetectionResultElement newDetectionResult;

	/** Minimal clone length threshold */
	private int minLength;

	/** IdProvider that creates ids unique for the entire system clone history */
	private IdProvider idProvider;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "updated", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Updated clone classes")
	public void setUpdatedClones(
			@AConQATAttribute(name = "cloneclasses", description = "Created by CloneUpdater") CloneDetectionResultElement updatedDetectionResult) {
		if (updatedDetectionResult == null) {
			updatedCloneClasses = new ArrayList<CloneClass>();
		} else {
			updatedCloneClasses = updatedDetectionResult.getList();
		}
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "detectionresult", description = "Clone detection result", minOccurrences = 1, maxOccurrences = 1)
	public void setNewDetectionResult(
			@AConQATAttribute(name = "new", description = "Clone detection result on source code of new system version") CloneDetectionResultElement newDetectionResult) {
		this.newDetectionResult = newDetectionResult;
	}

	/** Sets the unit list */
	@AConQATParameter(name = "clonelength", description = "Minimal length of Clone", minOccurrences = 1, maxOccurrences = 1)
	public void setMinLength(
			@AConQATAttribute(name = "min", description = "Minimal length of Clone") int minLength) {
		this.minLength = minLength;
	}

	/** {@inheritDoc} */
	public CloneDetectionResultElement process() throws ConQATException {
		initIdProvider();

		// create mapping from relative origins to updated clones
		HashedListMap<String, IClone> updatedClonesPerFile = new HashedListMap<String, IClone>();
		for (CloneClass updatedCloneClass : this.updatedCloneClasses) {
			for (IClone updatedClone : updatedCloneClass.getClones()) {
				updatedClonesPerFile
						.add(updatedClone.getOrigin(), updatedClone);
			}
		}

		List<CloneClass> untrackedNewCCs = new ArrayList<CloneClass>(
				newDetectionResult.getList());
		for (CloneClass newCloneClass : this.newDetectionResult.getList()) {
			CloneClass ancestorCloneClass = null;
			for (IClone newClone : newCloneClass.getClones()) {
				IClone ancestor = getAncestor(newClone, updatedClonesPerFile);

				if (ancestor != null) {
					// set ancestor clone class
					if (ancestorCloneClass == null
							|| ancestorCloneClass == ancestor.getCloneClass()) {
						ancestorCloneClass = ancestor.getCloneClass();
					} else {
						getLogger().warn(
								"Ancestors from different clone classes: "
										+ ancestorCloneClass.getId() + ", "
										+ ancestor.getCloneClass().getId());
						// TODO (EJ) Clean up
						// CCSMAssert.isTrue(ancestorCloneClass == ancestor
						// .getCloneClass(),
						// "Ancestors from different clone classes");
					}

					// create trace from new to ancestor
					setTracingInformation(newClone, ancestor);
				}
			}

			// add ghosts to clone result
			if (ancestorCloneClass != null) {
				untrackedNewCCs.remove(newCloneClass);
				IClone referenceClone = CollectionUtils.getAny(newCloneClass
						.getClones());
				for (IClone clone : ancestorCloneClass.getClones()) {
					if (!CloneTrackerUtils.getHasSuccessor(clone)) {
						// attempt fuzzy matching
						boolean matched = false;
						for (IClone newClone : newCloneClass.getClones()) {
							if (!CloneTrackerUtils.getHasAncestor(newClone)
									&& covers(newClone, clone)) {
								setTracingInformation(newClone, clone);
								CloneTrackerUtils.setFuzzyMatch(newClone, true);
								matched = true;
								break;
							}
						}

						if (!matched) {
							createGhost(newCloneClass, clone, referenceClone);
						}
					}
				}
			}
		}

		// attempt fuzzy matching of unmatched clone classes
		List<CloneClass> untrackedUpdatedCCs = new ArrayList<CloneClass>();
		for (CloneClass cloneClass : updatedCloneClasses) {
			if (allWithoutSuccessor(cloneClass)) {
				untrackedUpdatedCCs.add(cloneClass);
			}
		}
		for (CloneClass newCloneClass : untrackedNewCCs) {
			for (CloneClass updatedCloneClass : untrackedUpdatedCCs) {
				if (newCloneClass.size() == updatedCloneClass.size()) {
					boolean match = true;
					for (IClone newClone : newCloneClass.getClones()) {
						boolean cloneCovered = false;
						for (IClone updatedClone : updatedCloneClass
								.getClones()) {
							if (covers(newClone, updatedClone)) {
								cloneCovered = true;
							}
						}
						if (!cloneCovered) {
							match = false;
						}
					}

					if (match) {
						for (IClone newClone : newCloneClass.getClones()) {
							for (IClone updatedClone : updatedCloneClass
									.getClones()) {
								if (covers(newClone, updatedClone)) {
									setTracingInformation(newClone,
											updatedClone);
									CloneTrackerUtils.setFuzzyMatch(newClone,
											true);
								}
							}
						}
					}
				}
			}

		}

		// create ghosts for clone classes that are entirely lost
		for (CloneClass cloneClass : updatedCloneClasses) {
			if (allWithoutSuccessor(cloneClass)) {
				CloneClass newCloneClass = new CloneClass(cloneClass
						.getNormalizedLength(), idProvider.provideId());
				IClone referenceGhost = null;
				for (IClone clone : cloneClass.getClones()) {
					IClone ghost = createGhost(newCloneClass, clone,
							referenceGhost);
					if (referenceGhost == null) {
						referenceGhost = ghost;
					}
				}
				newDetectionResult.getList().add(newCloneClass);

				// mark as deleted if clones are consistent but too short
				if (newCloneClass.getMaxGapNumber() == 0
						&& CollectionUtils.getAny(cloneClass.getClones())
								.getLengthInUnits() < minLength) {
					CloneTrackerUtils.setTooShort(newCloneClass, true);
				}
			}
		}

		// compute coverage information for clones
		for (CloneClass cloneClass : newDetectionResult.getList()) {
			List<CloneClass> otherCloneClasses = new ArrayList<CloneClass>(
					newDetectionResult.getList());
			otherCloneClasses.remove(cloneClass);
			storeCoverageInformation(cloneClass, otherCloneClasses);
		}

		// clean up ghosts: remove consistent and covered ghosts and consistent
		// too short ghosts
		Set<IClone> deletedClones = new IdentityHashSet<IClone>();
		for (CloneClass cloneClass : new ArrayList<CloneClass>(
				newDetectionResult.getList())) {
			if (CloneTrackerUtils.getTooShort(cloneClass)
					|| consistentAndCoveredGhosts(cloneClass)) {
				for (IClone deletedClone : cloneClass.getClones()) {
					deletedClone.setDeath(newDetectionResult.getSystemDate());
					deletedClones.add(deletedClone);
				}
				newDetectionResult.getList().remove(cloneClass);
			}
		}

		CloneClassGateway cloneClassGateway = new CloneClassGateway(
				dbConnection, tableName);
		try {
			cloneClassGateway.storeClones(newDetectionResult);
			cloneClassGateway.getCloneGateway().storeDeaths(deletedClones);
		} catch (SQLException e) {
			throw new ConQATException("Problems with database:", e);
		}

		return newDetectionResult;
	}

	/** Initialize the {@link IdProvider} */
	private void initIdProvider() throws ConQATException {
		try {
			idProvider = new GlobalIdProvider(dbConnection, tableName);
		} catch (SQLException e) {
			throw new ConQATException("Problems with database:", e);
		}
	}

	/** Returns true, if all clones are ghosts, consistent and covered */
	private boolean consistentAndCoveredGhosts(CloneClass cloneClass) {
		return allGhosts(cloneClass) && allCovered(cloneClass)
				&& cloneClass.getMaxGapNumber() == 0;
	}

	/** Returns true, if all clones in the clone class are ghosts */
	private boolean allGhosts(CloneClass cloneClass) {
		for (IClone clone : cloneClass.getClones()) {
			if (!CloneTrackerUtils.getGhost(clone)) {
				return false;
			}
		}
		return true;
	}

	/** Returns true if all clones in the clone class are covered */
	private boolean allCovered(CloneClass cloneClass) {
		for (IClone clone : cloneClass.getClones()) {
			if (!CloneTrackerUtils.getCovered(clone)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Annotate clones in clone class with information on whether they are
	 * covered by another clone class
	 */
	private void storeCoverageInformation(CloneClass cloneClass,
			List<CloneClass> otherCloneClasses) {

		// determine best cover
		CloneClass bestCover = null;
		int maxCovered = 0;
		for (CloneClass otherCloneClass : otherCloneClasses) {
			int covered = 0;
			for (IClone clone : cloneClass.getClones()) {
				for (IClone cover : otherCloneClass.getClones()) {
					if (covers(cover, clone)) {
						covered++;
						break;
					}
				}
				if (covered > maxCovered) {
					bestCover = otherCloneClass;
					maxCovered = covered;
				}
			}
		}

		if (bestCover == null) {
			return;
		}

		// annotate cover flag
		for (IClone clone : cloneClass.getClones()) {
			for (IClone cover : bestCover.getClones()) {
				if (covers(cover, clone)) {
					CloneTrackerUtils.setCovered(clone, true);
				}
			}
		}
	}

	// TODO (EJ) Move into some utils class
	private boolean covers(IClone cover, IClone covered) {
		if (!cover.getOrigin().equals(covered.getOrigin())) {
			return false;
		}

		return cover.getStartLineInFile() <= covered.getStartLineInFile()
				&& cover.getLastLineInFile() >= covered.getLastLineInFile();
	}

	private GappedClone createGhost(CloneClass newCloneClass, IClone clone,
			IClone referenceClone) {
		// TODO (EJ) Use sensible value
		int deltaInUnits = -1;
		GappedClone ghost = new GappedClone(idProvider.provideId(),
				newCloneClass, clone.getOrigin(), clone.getStartLineInFile(),
				clone.getLengthInFile(), clone.getStartUnitIndexInFile(), clone
						.getLengthInUnits(), clone.getFingerprint(),
				deltaInUnits);
		CloneTrackerUtils.setGhost(ghost, true);
		CloneTrackerUtils.setUnits(ghost, CloneTrackerUtils.getUnits(clone));
		setTracingInformation(ghost, clone);
		newCloneClass.add(ghost);

		if (referenceClone != null) {
			List<IUnit> referenceUnits = CloneTrackerUtils
					.getUnits(referenceClone);
			CCSMAssert.isNotNull(referenceUnits,
					"No units stored at reference clone");
			List<IUnit> cloneUnits = CloneTrackerUtils.getUnits(ghost);
			CCSMAssert.isNotNull(cloneUnits, "No units stored at clone");

			Delta<IUnit> delta = Diff.computeDelta(referenceUnits, cloneUnits);
			fillGaps((GappedClone) referenceClone, referenceUnits, ghost,
					cloneUnits, delta);
		}

		return ghost;
	}

	/** Fills the gaps for the given clone. */
	private void fillGaps(GappedClone referenceClone,
			List<IUnit> referenceUnits, GappedClone clone, List<IUnit> units,
			Delta<IUnit> delta) {
		boolean firstNeedsGaps = !referenceClone.containsGaps();

		for (int i = 0; i < delta.getSize(); ++i) {
			int pos = delta.getPosition(i);
			if (pos > 0) {
				pos--;
				IUnit unit = units.get(pos);
				int offset = unit.getStartLineInFile()
						- clone.getStartLineInFile();
				for (int j = 0; j < unit.getCoveredLines(); ++j) {
					clone.addGap(offset + j, EEditOperation.INSERT);
				}
			} else if (firstNeedsGaps) {
				pos = -pos - 1;
				IUnit unit = referenceUnits.get(pos);
				int unitStartLine = unit.getStartLineInFile();
				int firstCloneStartLine = referenceClone.getStartLineInFile();
				int offset = unitStartLine - firstCloneStartLine;
				for (int j = 0; j < unit.getCoveredLines(); ++j) {
					referenceClone.addGap(offset + j, EEditOperation.DELETE);
				}
			}
		}
	}

	/** Set tracing information between a clone and its ancestor */
	private void setTracingInformation(IClone newClone, IClone ancestor) {
		CloneTrackerUtils.setHasSuccessor(ancestor, true);

		newClone.setBirth(ancestor.getBirth());
		CloneTrackerUtils.setAncestorId(newClone, ancestor.getId());
		CloneTrackerUtils.setHasAncestor(newClone, true);
		boolean fingerprintChanged = !newClone.getFingerprint().equals(
				ancestor.getFingerprint());
		CloneTrackerUtils.setFingerprintChanged(newClone, fingerprintChanged);
		if (fingerprintChanged) {
			newClone.setFingerprintLastModified(newDetectionResult
					.getSystemDate());
		}

		boolean startChanged = newClone.getStartLineInFile() != CloneTrackerUtils
				.getOriginalStartLine(ancestor);
		boolean endChanged = newClone.getLastLineInFile() != CloneTrackerUtils
				.getOriginalLastLine(ancestor);

		CloneTrackerUtils.setPositionChanged(newClone, startChanged
				|| endChanged);
	}

	/** Determines whether all clones in a {@link CloneClass} are ghosts */
	private boolean allWithoutSuccessor(CloneClass cloneClass) {
		for (IClone clone : cloneClass.getClones()) {
			if (CloneTrackerUtils.getHasSuccessor(clone)) {
				return false;
			}
		}
		return true;
	}

	/** Attempts to identify the ancestor of a clone */
	private IClone getAncestor(IClone newClone,
			HashedListMap<String, IClone> updatedClonesPerFile) {

		List<IClone> clones = updatedClonesPerFile
				.getList(newClone.getOrigin());
		if (clones != null) {
			int startUnitIndexInFile = newClone.getStartUnitIndexInFile();
			int lengthInUnits = newClone.getLengthInUnits();
			IClone match = match(clones, startUnitIndexInFile, lengthInUnits);
			if (match != null) {
				return match;
			}
		}

		return null;
	}

	private IClone match(List<IClone> clones, int startUnitIndexInFile,
			int lengthInUnits) {
		for (IClone updatedClone : clones) {
			if (updatedClone.getStartUnitIndexInFile() == startUnitIndexInFile
					&& updatedClone.getLengthInUnits() == lengthInUnits) {
				return updatedClone;
			}
		}
		return null;
	}
}

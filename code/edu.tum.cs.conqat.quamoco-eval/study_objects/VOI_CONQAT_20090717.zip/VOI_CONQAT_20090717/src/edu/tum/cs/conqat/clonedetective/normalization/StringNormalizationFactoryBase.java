/*--------------------------------------------------------------------------+
   $Id: StringNormalizationFactoryBase.java 18740 2009-03-07 08:15:00Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization;

import edu.tum.cs.conqat.clonedetective.lazyscope.IElementProvider;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.commons.pattern.PatternTransformationList;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for factories that create string normalizations.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 18740 $
 * @levd.rating GREEN Rev: 18740
 */
public abstract class StringNormalizationFactoryBase extends
		ConQATProcessorBase {

	/** Provides input elements on which line normalization works */
	protected IElementProvider<IFileSystemElement> inputProvider;

	/** Removal patterns for normalization */
	protected PatternList removeConfig = new PatternList();

	/** Replacement patterns for normalization */
	protected PatternTransformationList replaceConfig = new PatternTransformationList();

	/** Trim lines flag for normalization */
	protected boolean trimLines = false;

	/** Ignore empty lines flag for normalization */
	protected boolean ignoreEmptyLines = false;

	/** Remove all whitespace for normalization */
	protected boolean removeAllWhitespace = false;

	/** Sets removeConfig. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_REF_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setInputProvider(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			IElementProvider<IFileSystemElement> inputProvider) {
		this.inputProvider = inputProvider;
	}

	/** Sets removeConfig. */
	@AConQATParameter(name = "remove", description = "Removal patterns for normalization", minOccurrences = 0, maxOccurrences = 1)
	public void setRemoveConfig(
			@AConQATAttribute(name = "config", description = "Removal patterns for normalization")
			PatternList removeConfig) {
		this.removeConfig = removeConfig;
	}

	/** Sets replaceConfig. */
	@AConQATParameter(name = "replace", description = "Replacement patterns for normalization", minOccurrences = 0, maxOccurrences = 1)
	public void setReplaceConfig(
			@AConQATAttribute(name = "config", description = "Replacement patterns for normalization")
			PatternTransformationList replaceConfig) {
		this.replaceConfig = replaceConfig;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "lines", description = "Remove leading and trailing whitespace?", minOccurrences = 0, maxOccurrences = 1)
	public void setTrimLines(
			@AConQATAttribute(name = "trim", description = "Default value: false")
			boolean trimLines,
			@AConQATAttribute(name = "ignore-empty", description = "Default value: false")
			boolean ignoreEmptyLines,
			@AConQATAttribute(name = "remove-whitespace", description = "Default value: false")
			boolean removeAllWhitespace) {
		this.trimLines = trimLines;
		this.ignoreEmptyLines = ignoreEmptyLines;
		this.removeAllWhitespace = removeAllWhitespace;
	}

}
/*--------------------------------------------------------------------------+
   $Id: JavaElementBase.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.scope;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.scanner.ELanguage;

/**
 * A common super class for package and class elements. This offers a common
 * interface and a place for common implementation.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * 
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public abstract class JavaElementBase extends ConQATNodeBase implements
		IJavaElement {

	/** The name of this element. */
	private final String name;

	/** The parent of this node. */
	private JavaPackageElement parent = null;

	/**
	 * Caches the id, so that only a single id string resides in memory, even if
	 * the method {@link #getId()} gets called many times.
	 */
	private String id = null;

	/**
	 * Create a new Java Element.
	 * 
	 * @param name
	 *            local name of the element.
	 */
	public JavaElementBase(String name) {
		this.name = name;
	}

	/** Copy constructor. */
	protected JavaElementBase(JavaElementBase element)
			throws DeepCloneException {
		super(element);
		name = element.name;
	}

	/**
	 * Get fully qualified name of this java element, e.g. edu.tum.cs.
	 * <p>
	 * Since we expect the ids of all java elements to be their fully qualified
	 * names, this method is final. This avoids the necessity to test its
	 * correct implementation on all subclasses.
	 */
	public final String getId() {
		if (id == null) {
			if (parent == null) {
				id = StringUtils.EMPTY_STRING;
			} else if (parent.getParent() == null) {
				id = name;
			} else {
				id = parent.getId() + "." + name;
			}
		}
		return id;
	}

	/** {@inheritDoc} */
	public JavaPackageElement getParent() {
		return parent;
	}

	/** Set the parent of this node. */
	/* package */void setParent(JavaPackageElement parent) {
		this.parent = parent;
		id = null;
	}

	/** {@inheritDoc} */
	public String getName() {
		return name;
	}

	/** {@inheritDoc} */
	public ELanguage getLanguage() {
		return ELanguage.JAVA;
	}

	/** {@inheritDoc} */
	public void remove() {
		if (parent != null) {
			parent.removeNode(this);
			parent = null;
			id = null;
		}
	}

	/** {@inheritDoc} */
	public IJavaRootElement getRootElement() {
		if (parent != null) {
			return parent.getRootElement();
		}
		return null;
	}

	/** {@inheritDoc} */
	public abstract JavaElementBase deepClone() throws DeepCloneException;
}

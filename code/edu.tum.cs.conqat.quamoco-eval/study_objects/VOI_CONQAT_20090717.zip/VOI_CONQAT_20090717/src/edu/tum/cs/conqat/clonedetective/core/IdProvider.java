/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: IdProvider.java 22020 2009-07-16 09:36:36Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

/**
 * Creates fresh Ids.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 22020 $
 * @levd.rating YELLOW Rev: 22020
 */
public class IdProvider {

	/** Counter used to keep track of used ids */
	private int idCounter;

	/** Constructor */
	protected IdProvider(int lowestFreeId) {
		idCounter = lowestFreeId;
	}

	/**
	 * Create an IdProvider that returns 0 as its first id.
	 */
	public IdProvider() {
		this(0);
	}

	/** Returns next fresh id. */
	public int provideId() {
		return idCounter++;
	}

}

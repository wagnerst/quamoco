/*--------------------------------------------------------------------------+
   $Id: ELogLevel.java 18729 2009-03-06 21:17:41Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.logging;

import org.apache.log4j.Level;

/**
 * Log levels used by the ConQAT logging facility.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 18729 $
 * @levd.rating GREEN Rev: 18729
 */
public enum ELogLevel {
	/** Level debug. */
	DEBUG(Level.DEBUG),
	
	/** Level info. */
	INFO(Level.INFO),
	
	/** Level warn. */
	WARN(Level.WARN),
	
	/** Level error. */
	ERROR(Level.ERROR),
	
	/** Level fatal. */
	FATAL(Level.FATAL);

	/** The corresponding Log4J log level. */
	private final Level log4Jlevel;

	/** Create new level. */
	private ELogLevel(Level log4Level) {
		this.log4Jlevel = log4Level;
	}

	/** Get the corresponding Log4J log level. */
	/* package */Level getLog4JLevel() {
		return log4Jlevel;
	}

	/**
	 * Convert Log4J log level to {@link ELogLevel}.
	 * 
	 * @throws IllegalArgumentException
	 *             if an unknown Log4J log level was provided.
	 */
	@SuppressWarnings("static-access")
	/* package */static ELogLevel forLog4jLevel(Level level) {
		switch (level.toInt()) {
		case Level.DEBUG_INT:
			return DEBUG;
		case Level.WARN_INT:
			return WARN;
		case Level.ERROR_INT:
			return ERROR;
		case Level.INFO_INT:
			return INFO;
		case Level.FATAL_INT:
			return FATAL;
		default:
			throw new IllegalArgumentException("Unknown log level.");
		}

	}

}

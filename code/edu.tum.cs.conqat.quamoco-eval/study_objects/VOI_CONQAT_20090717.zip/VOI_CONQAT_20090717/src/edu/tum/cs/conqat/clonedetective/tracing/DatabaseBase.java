package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Base class for classes that access databases.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 22025 $
 * @levd.rating RED Rev:
 */
public abstract class DatabaseBase {

	/** Constant that denotes that no id is so far stored in the database */
	public static final int NO_ID_USED = -1;

	/**  */
	public static final String ID = "ID";

	/** Database connection. */
	protected final Connection dbConnection;

	/** Name of the database table. */
	protected final String tableName;

	/** Constructor */
	protected DatabaseBase(Connection dbConnection, String tableName) {
		this.dbConnection = dbConnection;
		this.tableName = tableName;

		// ensure table exists
		String createTableString = createCreateTableString();
		try {
			DatabaseUtils.executeUpdate(dbConnection, createTableString);
		} catch (SQLException e) {
			// swallow
		}
	}

	/** Create table creation SQL */
	protected abstract String createCreateTableString();

	/** Return the highest id used in this table */
	/* package */int getHighestUsedId() throws SQLException {
		String select = "Select Max(" + ID + ") as ID from " + tableName;
		ResultSet result = DatabaseUtils.executeQuery(dbConnection, select);
		result.next();
		return result.getInt(ID);
	}
}
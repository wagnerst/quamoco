/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: GlobalIdProvider.java 22025 2009-07-16 09:40:56Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.Connection;
import java.sql.SQLException;

import edu.tum.cs.conqat.clonedetective.core.IdProvider;

/**
 * Id provider that creates Ids that are unique for all clones stored in a data
 * base.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 22025 $
 * @levd.rating RED Rev:
 */
public class GlobalIdProvider extends IdProvider {

	/** Create global Id provider */
	public GlobalIdProvider(Connection dbConnection, String tableName)
			throws SQLException {
		super(highestStoredId(dbConnection, tableName) + 1);
	}

	/** Determine the highest id currently stored in the database */
	private static int highestStoredId(Connection dbConnection, String tableName)
			throws SQLException {
		CloneClassGateway ccGateway = new CloneClassGateway(dbConnection,
				tableName);
		int highestCCId = ccGateway.getHighestUsedId();
		int highestCloneId = ccGateway.getCloneGateway().getHighestUsedId();
		return Math.max(highestCCId, highestCloneId);
	}

}

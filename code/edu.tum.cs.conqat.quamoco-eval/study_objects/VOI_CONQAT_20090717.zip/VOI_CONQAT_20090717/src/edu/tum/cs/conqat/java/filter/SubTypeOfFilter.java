/*--------------------------------------------------------------------------+
   $Id: SubTypeOfFilter.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.filter;

import java.util.HashSet;
import java.util.Set;

import org.apache.bcel.classfile.JavaClass;

import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.java.library.JavaLibrary;
import edu.tum.cs.conqat.java.scope.IJavaClassElement;

/**
 * This processor filters types that are subtypes of a specific type.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This processor filters (discards) types that are subtypes of a specific type.")
public class SubTypeOfFilter extends JavaClassFilterBase {

	/** Single library instance. */
	private static final JavaLibrary javaLibrary = JavaLibrary.getInstance();

	/** Set of modifiers to include. */
	private final Set<String> typeNames = new HashSet<String>();

	/** Add modifier for included types. */
	@AConQATParameter(name = "type", description = "Super type to filter.")
	public void addInclude(
			@AConQATAttribute(name = "name", description = "Full qualified name of the type.")
			String modifierCode) {

		typeNames.add(modifierCode);
	}

	/** Check if a class is a subtype of one of the specified types. */
	@Override
	protected boolean isFiltered(IJavaClassElement classElement,
			JavaClass analyzedClass) {
		try {
			HashSet<JavaClass> superTypes = javaLibrary
					.getSuperClassesAndInterfaces(analyzedClass);

			for (JavaClass superType : superTypes) {
				if (typeNames.contains(superType.getClassName())) {
					return true;
				}
			}
			return false;

		} catch (ConQATException e) {
			getLogger().warn(e);
			return false;
		}
	}
}

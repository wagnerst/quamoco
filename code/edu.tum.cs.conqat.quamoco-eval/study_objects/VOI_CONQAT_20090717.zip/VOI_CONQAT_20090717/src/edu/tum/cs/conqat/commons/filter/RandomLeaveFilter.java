/*--------------------------------------------------------------------------+
   $Id: RandomLeaveFilter.java 17514 2008-10-30 17:05:13Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.filter;

import java.util.Collections;
import java.util.List;
import java.util.Random;

import edu.tum.cs.commons.collections.IdentityHashSet;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author deissenb
 * @author $Author: hummelb $
 * @version $Rev: 17514 $
 * @levd.rating GREEN Rev: 17514
 */
@AConQATProcessor(description = "This filter randomly shuffles the leaf nodes and "
		+ "filters all but the specified number of nodes. This can be used, e.g., "
		+ "to create samples for manual reviews.")
public class RandomLeaveFilter extends FilterBase<IRemovableConQATNode> {

	/** Leaves to be retained. */
	private final IdentityHashSet<IRemovableConQATNode> leavesToRetain = new IdentityHashSet<IRemovableConQATNode>();

	/** The seed for the random number generator used for shuffling. */
	private long seed = System.currentTimeMillis();

	/** Number of leaves to retain. */
	private int retainCount;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "retain-count", minOccurrences = 1, maxOccurrences = 1, description = "Number of leaves to retain.")
	public void setRetainCount(
			@AConQATAttribute(name = "value", description = "Number greater zero.") int retainCount)
			throws ConQATException {
		if (retainCount <= 0) {
			throw new ConQATException("Retain count must be greater zero.");
		}
		this.retainCount = retainCount;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "random-seed", maxOccurrences = 1, description = "Seed for the random number generator used for "
			+ "shuffling the leaves. If not specified the current time is used.")
	public void setRandomSeed(
			@AConQATAttribute(name = "value", description = "The initial seed") long seed) {
		this.seed = seed;
	}

	/** Prepare set {@link #leavesToRetain}. */
	@Override
	protected void preProcessInput(IRemovableConQATNode input) {
		getLogger().info("Seed used for random number generator: " + seed);
		List<IRemovableConQATNode> leaves = TraversalUtils
				.listLeavesDepthFirst(input);
		Collections.shuffle(leaves, new Random(seed));
		leavesToRetain.addAll(leaves.subList(0, Math.min(retainCount, leaves
				.size())));
	}

	/** {@inheritDoc} */
	@Override
	protected boolean isFiltered(IRemovableConQATNode node) {
		if (node.hasChildren()) {
			return false;
		}

		return !leavesToRetain.contains(node);
	}

}

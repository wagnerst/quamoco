/*--------------------------------------------------------------------------+
   $Id: SpannedFilesFilter.java 19092 2009-03-14 12:44:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection.filter;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Filters out all clone classes that don't span at least one file from a set of
 * files.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 19092 $
 * @levd.rating GREEN Rev: 19092
 */
@AConQATProcessor(description = "Filters out all clone classes that don't span at least one file "
		+ "from a set of files")
public class SpannedFilesFilter extends CloneClassFilterBase {

	/** Set of files of which at least one needs to be spanned */
	private final Set<File> fileSet = new HashSet<File>();

	/** Create file set from file system scope root */
	@AConQATParameter(name = "files", minOccurrences = 1, maxOccurrences = -1, description = ""
			+ "File system scope root that contains file set")
	public void setFileSetRoot(
			@AConQATAttribute(name = "ref", description = "Reference to producing processor") IFileSystemElement fileSetRoot) {

		List<IFileSystemElement> elements = TraversalUtils
				.listLeavesDepthFirst(fileSetRoot);
		for (IFileSystemElement element : elements) {
			File file = element.getFile();
			if (file != null && file.isFile()) {
				fileSet.add(file);
			}
		}
	}

	/** {@inheritDoc} */
	@Override
	protected boolean filteredOut(CloneClass cloneClass) {
		for (IClone clone : cloneClass.getClones()) {
			File cloneFile = new File(clone.getOrigin());
			if (fileSet.contains(cloneFile)) {
				return false;
			}
		}
		return true;
	}

}

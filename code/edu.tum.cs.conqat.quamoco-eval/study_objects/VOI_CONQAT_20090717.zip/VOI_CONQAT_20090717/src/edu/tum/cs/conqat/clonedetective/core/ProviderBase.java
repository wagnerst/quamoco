/*--------------------------------------------------------------------------+
   $Id: ProviderBase.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import java.util.LinkedList;

import edu.tum.cs.conqat.core.IConQATProcessor;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Base class for providers that work in a lazy fashion.
 * 
 * It provides lazy processors (called providers in this bundle) with a logger.
 * <p>
 * ConQAT processors typically work in an eager fashion: They perform their
 * entire task, when their {@link IConQATProcessor#process()} method is called.
 * This implementation potentially requires a lot of memory, since a processor's
 * input and output has to be present in main memory at the same time. This
 * approach is prohibitively expensive for the normalization steps, since
 * storage of both token and unit information requires excessive amounts of main
 * memory.
 * <p>
 * The alternative solution is to perform computation in a lazy fashion: a
 * processor performs its task in small steps, each time some
 * <code>getNext()</code> method is called.
 * 
 * @param <Element>
 *            Element type this provider works on
 * @param <Data>
 *            Type of data object provided by this provider
 * @param <X>
 *            Exception that gets thrown by {@link #getNext()} and
 *            {@link #init(IFileSystemElement, IConQATLogger)}
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * 
 * @version $Revision: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public abstract class ProviderBase<Element extends IFileSystemElement, Data, X extends Exception>
		implements IProvider<Element, Data, X> {

	/** Logger that can be used by this provider */
	private IConQATLogger logger;

	/** Returns the stored processor info. */
	protected IConQATLogger getLogger() {
		return logger;
	}

	/**
	 * This list stores tokens that have been accessed by
	 * {@link #lookahead(int)} but have not yet been retrieved using
	 * {@link #getNext()}
	 */
	private final LinkedList<Data> lookaheadBuffer = new LinkedList<Data>();

	/**
	 * Initializes the lazy processor.
	 * 
	 * @param root
	 *            {@link IFileSystemElement} this processor works on.
	 * @param logger
	 *            Logger from the processor that executes this provider.
	 */
	public void init(Element root, IConQATLogger logger) throws X {
		this.logger = logger;
		init(root);
	}

	/**
	 * Template method that allows deriving classes to perform their
	 * initialization
	 */
	protected abstract void init(Element root) throws X;

	/**
	 * Returns a token ahead of the current position, without actually
	 * retrieving it. The first token to be looked ahead at has index 1.
	 */
	public Data lookahead(int index) throws X {
		while (index > lookaheadBuffer.size()) {
			Data data = provideNext();
			if (data == null) {
				return null;
			}
			lookaheadBuffer.add(data);
		}

		return lookaheadBuffer.get(index - 1);
	}

	/** {@inheritDoc} */
	public Data getNext() throws X {
		if (lookaheadBuffer.size() > 0) {
			return lookaheadBuffer.poll();
		}
		return provideNext();
	}

	/** Template method that providers implement to yield elements */
	protected abstract Data provideNext() throws X;
}

/*--------------------------------------------------------------------------+
   $Id: CloneDetectorBase.java 22021 2009-07-16 09:37:29Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.digest.Digester;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionStatistics;
import edu.tum.cs.conqat.clonedetective.core.ECloneDetectionStatistic;
import edu.tum.cs.conqat.clonedetective.core.GappedClone;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.clonedetective.core.IUnit;
import edu.tum.cs.conqat.clonedetective.core.IUnitProvider;
import edu.tum.cs.conqat.clonedetective.core.IdProvider;
import edu.tum.cs.conqat.clonedetective.core.constraint.CardinalityConstraint;
import edu.tum.cs.conqat.clonedetective.core.constraint.ConstraintList;
import edu.tum.cs.conqat.clonedetective.core.constraint.ICloneClassConstraint;
import edu.tum.cs.conqat.clonedetective.detection.suffixtree.ICloneConsumer;
import edu.tum.cs.conqat.clonedetective.tracing.CloneTrackerUtils;
import edu.tum.cs.conqat.clonedetective.tracing.GlobalIdProvider;
import edu.tum.cs.conqat.clonedetective.tracing.UnitGateway;
import edu.tum.cs.conqat.clonedetective.utils.CloneUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for clone detection processors.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 22021 $
 * @levd.rating RED Rev: 
 */
public abstract class CloneDetectorBase extends ConQATProcessorBase {

	/** Key used for storing detection statistics */
	public static final String DETECTION_STATS = "Detection Statistics";

	/** Key that is used to store the number of units in an element */
	public static final String UNITS_KEY = "Units";

	/**
	 * Number of units that a clone must at least comprise. If it has less, it
	 * gets filtered out.
	 */
	protected int minLength;

	/** Stores clone detection statistics */
	private CloneDetectionStatistics statistics;

	/** Root of the input tree */
	private IFileSystemElement input;

	/**
	 * {@link IUnitProvider} that provides units on which the clone detection is
	 * performed. Serves as normalization strategy.
	 */
	private IUnitProvider<IFileSystemElement, IUnit> unitProvider;

	/** List of units retrieved from the units provider */
	protected List<IUnit> units;

	/**
	 * If this string is set to a non-empty value, a debug file (containing the
	 * normalized units) is written for each input file.
	 */
	private String debugFileExtension = null;

	/**
	 * Key that contains flag that determines whether file gets ignored.
	 * Influences log message generation, but not unit draining.
	 */
	private String ignoreKey;

	/** List of constraints that all detected clone classes must satisfy */
	private final ConstraintList constraints = new ConstraintList();

	/** Database connection used for tracing */
	private Connection connection;

	/** Name of the table in which clone information is stored in the data base */
	private String tableName;

	/** Timestamp at which detection started */
	private Date systemDate;

	/** {@link IdProvider} used to create Ids for clone classes and clones */
	protected IdProvider idProvider;

	/** ConQAT Parameter */
	@AConQATParameter(name = "debug", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "If this string is set to a non-empty value, a debug file is written for each input file")
	public void setDebugFileExtension(
			@AConQATAttribute(name = "extension", description = "File extension") String debugFileExtension) {
		if (StringUtils.isEmpty(debugFileExtension)) {
			throw new IllegalArgumentException(
					"Empty debug file extension not allowed, since it would overwrite existing files.");
		}
		if (!debugFileExtension.startsWith(".")) {
			debugFileExtension = "." + debugFileExtension;
		}
		this.debugFileExtension = debugFileExtension;
	}

	/** Sets the unit list */
	@AConQATParameter(name = "clonelength", description = "Minimal length of Clone", minOccurrences = 1, maxOccurrences = 1)
	public void setMinLength(
			@AConQATAttribute(name = "min", description = "Minimal length of Clone") int minLength) {
		this.minLength = minLength;
	}

	/** Sets the input */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setInput(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IFileSystemElement input) {
		this.input = input;
	}

	/**
	 * Sets normalization strategy.
	 * <p>
	 * In general, ConQAT load time type checking does not check generic
	 * parameters. This is no problem in this case, as
	 * {@link IFileSystemElement} and {@link IUnit} are the most general
	 * instantiations of the generic parameters for {@link IUnitProvider}
	 */
	@AConQATParameter(name = "normalization", description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setNormalization(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IUnitProvider<IFileSystemElement, IUnit> unitProvider) {
		this.unitProvider = unitProvider;
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "ignore", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Key under which ignore flag is stored.")
	public void setIgnoreKey(
			@AConQATAttribute(name = "key", description = "If no key is given, no files are ignored") String ignoreKey) {
		this.ignoreKey = ignoreKey;
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "constraint", minOccurrences = 0, maxOccurrences = -1, description = ""
			+ "Adds a constraint that each detected clone class must satisfy")
	public void addConstraint(
			@AConQATAttribute(name = "type", description = "Clone classes that do not match the constraint are filtered") ICloneClassConstraint constraint) {
		constraints.add(constraint);
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "database", description = "Database connection for clone tracing.", minOccurrences = 0, maxOccurrences = 1)
	public void setConnection(
			@AConQATAttribute(name = "connection", description = "If not set, no tracing is performed.") Connection connection,
			@AConQATAttribute(name = "tablename", description = "Name of the table in which the clones are stored") String tableName) {
		this.connection = connection;
		this.tableName = tableName;
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "system", minOccurrences = 0, maxOccurrences = 1, description = "Date denoting the system version on which clone detection is performed.")
	public void setSystemDate(
			@AConQATAttribute(name = "date", description = "If not set, system date is set to now") Date systemDate) {
		this.systemDate = systemDate;
	}

	/** Constructor */
	public CloneDetectorBase() {
		// only detect clone classes of cardinality 2 or greater.
		// (clone classes can have cardinality of 1, if all contained clones
		// are considered equal by the set that stores a clone classes'
		// clones. this can happen if clones only differ
		// in start and end units that are located on the same lines.)
		CardinalityConstraint constraint = new CardinalityConstraint();
		constraint.setMin(2);
		this.constraints.add(constraint);
	}

	/** Calls template method to perform clone detection in deriving class */
	public CloneDetectionResultElement process() throws ConQATException {
		// initialize id provider
		idProvider = initIdProvider();

		// create detection statistics object
		statistics = new CloneDetectionStatistics();
		input.setValue(DETECTION_STATS, statistics);

		UnitDrain drain = new UnitDrain(getLogger(), debugFileExtension,
				ignoreKey);
		units = drain.drainUnits(input, unitProvider);

		List<CloneClass> cloneClasses = detectClones();

		collectStatistics(cloneClasses);

		if (connection != null) {
			storeUnits();
		}

		// create detection result parameter object
		return new CloneDetectionResultElement(getSystemDate(), input,
				cloneClasses);
	}

	/**
	 * If the database connection is set, we use a {@link GlobalIdProvider},
	 * else a standard {@link IdProvider}.
	 */
	private IdProvider initIdProvider() throws ConQATException {
		if (connection == null) {
			return new IdProvider();
		}

		try {
			return new GlobalIdProvider(connection, tableName);
		} catch (SQLException e) {
			throw new ConQATException("Problems with database: ", e);
		}
	}

	/**
	 * Stores number of processed units and number of found clones in detection
	 * statistics object
	 */
	private void collectStatistics(List<CloneClass> cloneClasses) {
		int unitCount = units.size();
		int cloneCount = CloneUtils.countClones(cloneClasses);

		getLogger().info("# Units: " + unitCount);
		getLogger().info("# Clones: " + cloneCount);

		statistics.setStatistic(ECloneDetectionStatistic.PROCESSED_UNIT_COUNT,
				unitCount);
		statistics.setStatistic(ECloneDetectionStatistic.CLONE_COUNT,
				cloneCount);
	}

	/** Store units in a {@link UnitGateway} */
	private void storeUnits() throws ConQATException {
		// TODO (EJ) create unique table name
		UnitGateway gateway = new UnitGateway(connection,
				UnitGateway.TABLE_NAME);
		String rootOrigin = input.getId();

		HashedListMap<String, IUnit> unitsPerFile = new HashedListMap<String, IUnit>();
		for (IUnit unit : units) {
			String relativeOrigin = StringUtils.stripPrefix(rootOrigin, unit
					.getOriginId());
			// skip synthetic units, since they are not contained in the files
			if (!unit.isSynthetic()) {
				unitsPerFile.add(relativeOrigin, unit);
			}
		}

		try {
			gateway.storeUnits(getSystemDate(), unitsPerFile, input.getId());
		} catch (SQLException e) {
			throw new ConQATException("Problems with database", e);
		}
	}

	/**
	 * Template method that deriving classes override to implement their clone
	 * detection
	 */
	protected abstract List<CloneClass> detectClones();

	/** Getter */
	protected Date getSystemDate() {
		if (systemDate == null) {
			// if not set, set to now
			systemDate = new Date();
		}
		return systemDate;
	}

	/**
	 * Receives found clones found during clone detection and packages them into
	 * clone classes.
	 * <p>
	 * Since this class accesses the units list of the clone detector, it is
	 * internal.
	 */
	protected class CloneConsumer implements ICloneConsumer {

		/** List in which the created clone classes are stored */
		private final List<CloneClass> cloneClasses;

		/**
		 * Creates a CloneConsumer that writes the {@link CloneClass}es it
		 * creates into the given list
		 */
		public CloneConsumer(List<CloneClass> cloneClasses) {
			this.cloneClasses = cloneClasses;
		}

		/** {@link CloneClass} currently being filled */
		protected CloneClass currentCloneClass;

		/** Start new clone class */
		public void startCloneClass(int normalizedLength) {
			currentCloneClass = new CloneClass(normalizedLength, idProvider
					.provideId());
		}

		/** Adds a clone to the current {@link CloneClass} */
		public void addClone(int globalPosition, int length) {
			// compute length of clone in lines
			IUnit firstUnit = units.get(globalPosition);
			IUnit lastUnit = units.get(globalPosition + length - 1);
			List<IUnit> cloneUnits = units.subList(globalPosition,
					globalPosition + length);

			String originId = firstUnit.getOriginId();
			int startLineInFile = firstUnit.getStartLineInFile();
			int lengthInFile = lastUnit.getStartLineInFile()
					- firstUnit.getStartLineInFile()
					+ lastUnit.getCoveredLines();

			int startUnitIndexInFile = firstUnit.getIndexInFile();
			int endUnitIndexInFile = lastUnit.getIndexInFile();
			int lengthInUnits = endUnitIndexInFile - startUnitIndexInFile;
			String fingerprint = createFingerprint(globalPosition, length);

			// TODO (EJ) Use sensible value
			int deltaInUnits = -1;
			IClone clone = new GappedClone(idProvider.provideId(),
					currentCloneClass, originId, startLineInFile, lengthInFile,
					startUnitIndexInFile, lengthInUnits + 1, fingerprint,
					deltaInUnits);
			clone.setBirth(getSystemDate());

			// TODO (EJ) Only store units if some flag is set
			CloneTrackerUtils.setUnits(clone, cloneUnits);

			currentCloneClass.add(clone);
		}

		/** Create fingerprint for current clone */
		protected String createFingerprint(int globalPosition, int length) {
			StringBuilder fingerprintBase = new StringBuilder();
			for (int pos = globalPosition; pos < globalPosition + length; pos++) {
				fingerprintBase.append(units.get(pos).getContent());
			}
			return Digester.createMD5Digest(fingerprintBase.toString());
		}

		/** Check constraints */
		public boolean completeCloneClass() {
			boolean constraintsSatisfied = constraints
					.allSatisfied(currentCloneClass);

			if (constraintsSatisfied) {
				cloneClasses.add(currentCloneClass);
			}

			return constraintsSatisfied;
		}
	}

}
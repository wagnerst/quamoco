/*--------------------------------------------------------------------------+
   $Id: ArchitectureEdgeAssessor.java 21602 2009-06-09 16:48:58Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.graph;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.architecture.scope.ComponentNode;
import edu.tum.cs.conqat.architecture.scope.DependencyPolicy;
import edu.tum.cs.conqat.architecture.toleration.Tolerations;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.tum.cs.conqat.graph.nodes.DeepCloneCopyAction;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * This processor assesses the edges of a given graph according to an
 * architecture definition.
 * 
 * @author Benjamin Hummel
 * @author Tilman Seifert
 * @author $Author: deissenb $
 * @version $Rev: 21602 $
 * @levd.rating YELLOW Rev: 21602
 */
@AConQATProcessor(description = "This processor assesses the edges of the given graph "
		+ "according to the architecture definition.")
public class ArchitectureEdgeAssessor extends ArchGraphPipelineBase {

	/** Key for edge assessments. */
	@AConQATKey(description = "Key used for assessing both edges and vertices based on architecture policy violations.", type = "edu.tum.cs.commons.assessment.Assessment")
	public static final String ASSESSMENT_KEY = "assessment";

	/** Key for edge assessments. */
	@AConQATKey(description = "Key used for storing the policy type of an edge.", type = "edu.tum.cs.conqat.architecture.scope.EPolicyType")
	public static final String POLICY_TYPE_KEY = "policy type";

	/**
	 * Key used to store assessments representing the policy tolerations at
	 * edges.
	 */
	@AConQATKey(description = "The key used to store assessments representing the policiy tolerations at edges.", type = "edu.tum.cs.conqat.architecture.toleration.Tolerations")
	public static final String POLICY_TOLERATIONS_KEY = "policy-tolerations";

	/** Key for violating dependencies */
	@AConQATKey(description = "List of explicit violations for each vertex.", type = "java.util.List<String>")
	public static final String VIOLATION_KEY = "violation details";

	/** Tolerated dependencies */
	private Tolerations tolerations = new Tolerations();

	/** Stores assessments for vertices during edge rating */
	private final Map<ConQATVertex, Assessment> vertexAssessments = new HashMap<ConQATVertex, Assessment>();

	/** Set the tolerated dependencies */
	@AConQATParameter(name = "tolerated", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Tolerated architecture violations")
	public void setTolerations(
			@AConQATAttribute(name = "dependencies", description = "Reference to processor that defines tolerations") Tolerations tolerations) {

		this.tolerations = tolerations;
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) {
		NodeUtils.addToDisplayList(graph, ASSESSMENT_KEY, VIOLATION_KEY,
				POLICY_TYPE_KEY, ArchitectureHierarchyBuilder.MATCHED_TYPES_KEY);
		rateEdges(graph);
		rateVertices(graph);
	}

	/** Add assessments to the edges based on the given architecture. */
	private void rateEdges(ConQATGraph graph) {
		for (DirectedSparseEdge edge : graph.getEdges()) {
			ConQATVertex from = (ConQATVertex) edge.getSource();
			ConQATVertex to = (ConQATVertex) edge.getDest();

			ComponentNode compFrom = resolver.findComponentFor(from);
			ComponentNode compTo = resolver.findComponentFor(to);

			Assessment assessment = null;
			EPolicyType policyType = null;
			DependencyPolicy policy = null;
			if (tolerations.tolerated(from.getId(), to.getId())) {
				policyType = EPolicyType.TOLERATE_EXPLICIT;
				assessment = new Assessment(ETrafficLightColor.YELLOW);
			} else if (compFrom != null && compTo != null) {
				policyType = compFrom.getGoverningPolicyType(compTo);
				if (policyType == null) {
					policyType = EPolicyType.DENY_IMPLICIT;
				}
				assessment = policyType.toAssessment();

				policy = compFrom.getGoverningPolicy(compTo);
			}

			// Is null if the component is not resolvable
			if (assessment != null) {
				edge.addUserDatum(ASSESSMENT_KEY, assessment,
						DeepCloneCopyAction.getInstance());

				if (assessment.getDominantColor() != ETrafficLightColor.GREEN) {
					String violation = from.getId() + " -> " + to.getId();
					NodeUtils.getOrCreateStringList(from, VIOLATION_KEY).add(
							violation);

					storeVertexAssessment(from, assessment);
				}
			}

			// Is null if the component is not resolvable
			if (policyType != null) {
				edge.addUserDatum(POLICY_TYPE_KEY, policyType,
						DeepCloneCopyAction.getInstance());

				if (policy != null
						&& policyType == EPolicyType.TOLERATE_EXPLICIT) {
					// (MP) we add a userdatum containing the tolerated
					// dependencies defined in the architecture file. This list
					// needs to be accessed when adding the UNNECCESSARY, VALID,
					// INVALID assessments to the rendered policies.
					// (MP) It also seems that we don't get all tolerate
					// policies + dependencies i stored in the architecture file
					edge.addUserDatum(POLICY_TOLERATIONS_KEY, policy
							.getTolerations(), DeepCloneCopyAction
							.getInstance());
				}
			}
		}
	}

	/** Store assessment for vertex in map */
	private void storeVertexAssessment(ConQATVertex vertex,
			Assessment assessment) {
		if (vertexAssessments.containsKey(vertex)) {
			vertexAssessments.get(vertex).add(assessment);
		} else {
			vertexAssessments.put(vertex, assessment);
		}
	}

	/** Add assessments to the vertices based on existing violations. */
	private void rateVertices(ConQATGraph graph) {
		for (ConQATVertex vertex : graph.getVertices()) {
			if (NodeUtils.getStringList(vertex, VIOLATION_KEY) != null) {
				vertex.setValue(ASSESSMENT_KEY, new Assessment(
						ETrafficLightColor.RED));
			} else {
				vertex.setValue(ASSESSMENT_KEY, new Assessment(
						ETrafficLightColor.GREEN));
			}
		}
	}

}

/*--------------------------------------------------------------------------+
   $Id: IdentifiersExtractor.java 21644 2009-06-22 16:33:49Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.sourcecode.library.SourceCodeLibrary;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.ETokenType;
import edu.tum.cs.scanner.IToken;

/**
 * This processor extracts the set of identifiers from a source code tree.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 21644 $
 * @levd.rating GREEN Rev: 21644
 */
@AConQATProcessor(description = "This processor extracts the set of "
		+ "identifiers from a source code tree.")
public class IdentifiersExtractor extends ConQATProcessorBase implements
		INodeVisitor<ISourceCodeElement, NeverThrownRuntimeException> {

	/** Set of identifiers. */
	private final HashSet<String> identifiers = new HashSet<String>();

	/** The node we're working on */
	private ISourceCodeElement root;

	/** Set the root element to work on. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			ISourceCodeElement root) {
		this.root = root;
	}

	/** {@inheritDoc} */
	public Set<String> process() {
		TraversalUtils.visitLeavesDepthFirst(this, root);
		return identifiers;
	}

	/** Determine tokens and add identifiers to set. */
	public void visit(ISourceCodeElement element) {

		List<IToken> tokens;
		try {
			tokens = SourceCodeLibrary.getInstance().getTokens(element);
		} catch (Exception e) {
			getLogger().warn("Couldn't read " + element);
			return;
		}

		for (IToken token : tokens) {
			if (token.getType() == ETokenType.IDENTIFIER) {
				identifiers.add(token.getText());
			}
		}
	}
}

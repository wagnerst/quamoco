/*--------------------------------------------------------------------------+
   $Id: SimulinkBlockParameterAssessor.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.commons.collections.PairList;
import edu.tum.cs.commons.collections.TwoDimHashMap;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * This processor check if block parameters conform to a set of rules.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This processor checks if block parameters "
		+ "conform to a set of rules. For nodes that violate one of the rules, "
		+ "the processor creates RED assessment and an assessment message. "
		+ "For conforming nodes it creates a GREEN assessment. Message "
		+ "and assessment keys are <key_prefix>Assessment and <key_prefix>Messages "
		+ "where <key_prefix> is supplied as parameter.")
public class SimulinkBlockParameterAssessor extends
		SimulinkBlockTraversingProcessorBase {

	/** Key suffix for messages. */
	private static final String MESSAGES_KEY_SUFFIX = "Messages";

	/** Key suffix for assessment. */
	private static final String ASSESSMENT_KEY_SUFFIX = "Assessment";

	/** Type constant used if rule is specified for all block types. */
	/* package */static final String ALL_BLOCKS_TYPE = "_ALL_BLOCKS_";

	/**
	 * Constant that stand for a pattern that matches everything. Note: This
	 * pattern is not actually used, it serves as marker only.
	 */
	/* package */static final String ALLOW_EVERYTHING_PATTERN = ".*";

	/**
	 * Constant that stand for a pattern that matches nothing. Note: This
	 * pattern is not actually used, it serves as marker only.
	 */
	/* package */static final String DENY_EVERYTHING_PATTERN = "**";

	/**
	 * This map from (Block type X parameter name) to a list of pairs (allowed
	 * pattern, denied pattern). <code>null</code> values are stored to signal
	 * allow-all/deny-all patterns. Implementation would be way more elegant if
	 * there was pattern that match no string at all.
	 */
	private final TwoDimHashMap<String, String, PairList<Pattern, Pattern>> patterns = new TwoDimHashMap<String, String, PairList<Pattern, Pattern>>();

	/** Prefix for keys. */
	private String keyPrefix;

	/** Set the key prefix */
	@AConQATParameter(name = "key", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Set the prefix of the assessment and messages key.")
	public void setKeyPrefix(
			@AConQATAttribute(name = "value", description = "Key prefix") String keyPrefix) {
		this.keyPrefix = keyPrefix;
	}

	/**
	 * Add parameter rule.
	 */
	@AConQATParameter(name = "rule", description = "Add rule to be checked by the processor.", minOccurrences = 1)
	public void addRule(
			@AConQATAttribute(name = "type", description = "Defines block type "
					+ "this rule applies for. Use 'Reference.<type>' for library "
					+ "types. Omit attribute if rule "
					+ "applies for all block types.", defaultValue = ALL_BLOCKS_TYPE) String blockType,
			@AConQATAttribute(name = "param", description = "Defines parameter this "
					+ "rule applies for.") String parameterName,
			@AConQATAttribute(name = "allow", description = "Define legal expressions "
					+ "for this parameter. Omit attribute to allow "
					+ "all values. " + ConQATParamDoc.REGEX_PATTERN_DESC, defaultValue = ALLOW_EVERYTHING_PATTERN) String allowPatternString,
			@AConQATAttribute(name = "deny", description = "Define illegal expressions "
					+ "for this parameter. Omit attribute to deny "
					+ "no values. " + ConQATParamDoc.REGEX_PATTERN_DESC, defaultValue = DENY_EVERYTHING_PATTERN) String denyPatternString)
			throws ConQATException {

		PairList<Pattern, Pattern> pairList = patterns.getValue(blockType,
				parameterName);

		if (pairList == null) {
			pairList = new PairList<Pattern, Pattern>();
			patterns.putValue(blockType, parameterName, pairList);
		}

		Pattern allowPattern = createPattern(allowPatternString,
				ALLOW_EVERYTHING_PATTERN);

		Pattern denyPattern = createPattern(denyPatternString,
				DENY_EVERYTHING_PATTERN);

		pairList.add(allowPattern, denyPattern);
	}

	/**
	 * Create pattern from string. Returns <code>null</code> if the the
	 * pattern string equals the marker string.
	 */
	private Pattern createPattern(String patternString, String markerString)
			throws ConQATException {
		if (markerString.equals(patternString)) {
			return null;
		}

		try {
			return Pattern.compile(patternString);
		} catch (PatternSyntaxException ex) {
			throw new ConQATException("Illegal pattern: " + patternString);
		}
	}

	/** Add key to display list. */
	@Override
	protected void setUp(ISimulinkElement root) {
		NodeUtils.addToDisplayList(root, getAssessmentKey(), getMessagesKey());
	}

	/** Optimistically set model rating to green. */
	@Override
	protected void setUpModel(SimulinkModelElement modelNode) {
		modelNode.setValue(getAssessmentKey(), new Assessment(
				ETrafficLightColor.GREEN));
	}

	/** Check parameters of a block. */
	@Override
	protected void visitBlock(SimulinkBlock block,
			SimulinkModelElement modelNode) throws ConQATException {

		// getParameterNames() also returns default parameters
		for (String parameterName : block.getParameterNames()) {
			String parameterValue = block.getParameter(parameterName);
			String type = block.getResolvedType();

			if (!assessParameterValue(parameterValue, ALL_BLOCKS_TYPE,
					parameterName)
					|| !assessParameterValue(parameterValue, type,
							parameterName)) {

				String message = "Parameter '" + parameterName
						+ "' has illegal value '" + parameterValue + "'.";

				NodeUtils.addMessage(modelNode, getMessagesKey(),
						block.getId(), message);

				modelNode.setValue(getAssessmentKey(), new Assessment(
						ETrafficLightColor.RED));
			}
		}
	}

	/** Check if a parameter value is legal or not. */
	private boolean assessParameterValue(String value, String blockType,
			String parameterName) {

		PairList<Pattern, Pattern> patternList = patterns.getValue(blockType,
				parameterName);

		if (patternList == null) {
			return true;
		}

		for (int i = 0; i < patternList.size(); i++) {
			Pattern allowPattern = patternList.getFirst(i);
			Pattern denyPattern = patternList.getSecond(i);

			if (!isAllowed(allowPattern, value) || isDenied(denyPattern, value)) {
				return false;
			}

		}

		return true;
	}

	/** Checks if value is allowed. */
	private boolean isAllowed(Pattern allowPattern, String value) {
		if (allowPattern == null) {
			return true;
		}
		return allowPattern.matcher(value).matches();
	}

	/** Checks if value is denied. */
	private boolean isDenied(Pattern denyPattern, String value) {
		if (denyPattern == null) {
			return false;
		}
		return denyPattern.matcher(value).matches();
	}

	/** Get key for messages. This is mainly used for testing purposes. */
	/* package */String getMessagesKey() {
		return keyPrefix + MESSAGES_KEY_SUFFIX;
	}

	/** Get key for assessment. This is mainly used for testing purposes. */
	/* package */String getAssessmentKey() {
		return keyPrefix + ASSESSMENT_KEY_SUFFIX;
	}

}

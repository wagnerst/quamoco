/*--------------------------------------------------------------------------+
   $Id: Sentinelizer.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection;

import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.IUnit;
import edu.tum.cs.conqat.clonedetective.core.IUnitProvider;
import edu.tum.cs.conqat.clonedetective.normalization.UnitProviderBase;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Inserts sentinels between units that originate from different files.
 * <p>
 * This way, we cannot find clones that span several files.
 * 
 * @author Elmar Juergens
 * @author Benjamin Hummel
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
/* package */class Sentinelizer extends
		UnitProviderBase<IFileSystemElement, IUnit> {

	/** Flag that indicates that the last returned unit was a sentinel */
	private boolean lastUnitWasSentinel = false;

	/** Reference to unit that has been returned last */
	private IUnit lastReturnedUnit = null;

	/** Provides units without sentinels */
	private final IUnitProvider<IFileSystemElement, IUnit> unitPovider;

	/** Constructor */
	public Sentinelizer(IUnitProvider<IFileSystemElement, IUnit> unitPovider) {
		this.unitPovider = unitPovider;
	}

	/** Forward initialization to unit provider */
	@Override
	protected void init(IFileSystemElement root) throws CloneDetectionException {
		unitPovider.init(root, getLogger());
	}

	/** {@inheritDoc} */
	@Override
	protected IUnit provideNext() throws CloneDetectionException {
		IUnit next = unitPovider.lookahead(1);

		// no more units - return null
		if (next == null) {
			if (!lastUnitWasSentinel) {
				lastUnitWasSentinel = true;
				return createSentinel();
			}
			return null;
		}

		// if last unit was sentinel, simply return next unit
		if (lastUnitWasSentinel) {
			lastUnitWasSentinel = false;
			lastReturnedUnit = unitPovider.getNext();
			return lastReturnedUnit;
		}

		// if we are still in same file, simply return next unit
		if (stillInSameFile(next)) {
			lastReturnedUnit = unitPovider.getNext();
			return lastReturnedUnit;
		}

		// if we change files, return sentinel
		lastUnitWasSentinel = true;
		return createSentinel();
	}

	/** Creates a sentinel unit */
	private SentinelUnit createSentinel() {
		if (lastReturnedUnit == null) {
			return null;
		}
		return new SentinelUnit(lastReturnedUnit.getOriginId());
	}

	/** Returns true, if unit and last returned unit stem from same file */
	private boolean stillInSameFile(IUnit unit) {
		return lastReturnedUnit == null
				|| lastReturnedUnit.getOriginId().equals(unit.getOriginId());
	}

}

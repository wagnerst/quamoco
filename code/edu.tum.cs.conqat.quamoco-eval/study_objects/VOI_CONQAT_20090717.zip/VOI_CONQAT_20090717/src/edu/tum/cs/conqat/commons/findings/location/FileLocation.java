/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FileLocation.java 21999 2009-07-15 20:43:23Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.location;

import edu.tum.cs.commons.filesystem.CanonicalFile;

/**
 * Location for a file (without exact position).
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21999 $
 * @levd.rating YELLOW Rev: 21999
 */
public class FileLocation extends LocationBase {

	/** The file. */
	private final CanonicalFile file;

	/** Constructor. */
	public FileLocation(CanonicalFile file) {
		this.file = file;
	}

	/** Returns the file. */
	public CanonicalFile getFile() {
		return file;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return file.getName();
	}
}

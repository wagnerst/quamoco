package edu.tum.cs.conqat.architecture.format;

/**
 * Assessment result for edges in an architecture graph.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 21386 $
 * @levd.rating YELLOW Rev: 21386
 */
public enum EAssessmentType {

	/** Dependencies underlying this edge are valid w.r.t. policies */
	VALID,

	/** Dependencies underlying this edge are invalid w.r.t. policies */
	INVALID,

	/** No dependencies underly this edge. It is unnecessary. */
	UNNECESSARY,
	
	/** Assessment type unknown. (e.g. for edges to elements without component) */
	UNKNOWN

}

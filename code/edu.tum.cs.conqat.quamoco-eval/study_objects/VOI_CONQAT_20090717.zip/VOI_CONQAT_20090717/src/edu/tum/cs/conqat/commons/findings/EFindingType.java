/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: EFindingType.java 21887 2009-07-10 15:06:10Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.awt.Color;

import edu.tum.cs.commons.assessment.ETrafficLightColor;

/**
 * The finding type determines the kind of information carried in a finding. The
 * type has to be the same for all findings in a group and category to simplify
 * the handling of findings.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21887 $
 * @levd.rating YELLOW Rev: 21887
 */
public enum EFindingType {

	/** Metric findings. */
	METRIC(Double.class),

	/** Assessment findings (stored as traffic light color. */
	ASSESSMENT(ETrafficLightColor.class),

	/** Message findings. */
	MESSAGE(String.class),

	/** Color findings. */
	COLOR(Color.class);

	/** The java type used for values of this finding type. */
	private final Class<?> valueType;

	/** Constructor. */
	private EFindingType(Class<?> valueType) {
		this.valueType = valueType;
	}

	/** Returns the value type for this finding type. */
	public Class<?> getValueType() {
		return valueType;
	}
}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.text
 |                                                                       |
   $Id: LetterPairDistribution.java 21684 2009-06-25 20:41:56Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.language;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;

/**
 * Class for storing distributions of letter pairs.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21684 $
 * @levd.rating YELLOW Rev: 21684
 */
public class LetterPairDistribution {

	/** The distribution. */
	private final Map<String, Double> distribution = new HashMap<String, Double>();

	/** Hidden constructor. */
	private LetterPairDistribution() {
		// empty by design
	}

	/** Loads a distribution from a file. */
	public static LetterPairDistribution loadFromFile(File inputFile)
			throws IOException {
		LetterPairDistribution lpd = new LetterPairDistribution();

		FileInputStream in = new FileInputStream(inputFile);
		byte[] buffer = new byte[(int) inputFile.length()];
		in.read(buffer);
		in.close();

		for (String line : StringUtils.splitLines(new String(buffer, "UTF-8"))) {
			if (StringUtils.isEmpty(line) || line.startsWith("#")) {
				continue;
			}
			Scanner s = new Scanner(line);
			s.useLocale(Locale.US);
			String pair = s.next();
			if (pair.length() != 2 || !s.hasNextDouble()) {
				throw new IOException("Invalid file format!");
			}
			lpd.distribution.put(pair, s.nextDouble());
		}

		lpd.normalize();
		return lpd;
	}

	/** Calculates a new distribution from a long text file. */
	public static LetterPairDistribution calculateFromString(String text) {
		LetterPairDistribution lpd = new LetterPairDistribution();

		char[] chars = prepareText(text);
		for (int i = 1; i < chars.length; ++i) {
			if (chars[i - 1] != '.') {
				String s = new String(chars, i - 1, 2);
				lpd.insertPair(s);
			}
		}

		lpd.normalize();
		return lpd;
	}

	/**
	 * Prepares the text for pair identification by converting to lower case,
	 * replacing non-letters by a dot and returning the char array.
	 */
	private static char[] prepareText(String text) {
		char[] chars = new char[text.length()];
		text.toLowerCase().getChars(0, text.length(), chars, 0);
		for (int i = 0; i < chars.length; ++i) {
			if (!Character.isLetter(chars[i])) {
				chars[i] = '.';
			}
		}
		return chars;
	}

	/** Inserts a pair into the distribution table. */
	private void insertPair(String s) {
		Double value = distribution.get(s);
		if (value == null) {
			value = 0.;
		}
		distribution.put(s, value + 1);
	}

	/**
	 * Normalizes the table to 600, which is about the size of the english
	 * table.
	 */
	private void normalize() {
		double sum = 0;
		for (double v : distribution.values()) {
			sum += v;
		}
		if (sum == 0) {
			return;
		}
		for (Entry<String, Double> e : distribution.entrySet()) {
			e.setValue(600. * e.getValue() / sum);
		}
	}

	/**
	 * Calculates the value of a text according to this table. The value is the
	 * product of the value of letter pairs in the table, but small values are
	 * limited to 0.01 to not overly penalize non-existing pairs (which might be
	 * typos after all). The resulting (positive) number indicates confidence in
	 * the decision, but may not be interpreted on an absolute scale but
	 * relative to other measurements on the same text.
	 */
	public double calculateTextValue(String text) {
		double result = 1;
		char[] chars = prepareText(text);
		for (int i = 1; i < chars.length; ++i) {
			if (chars[i - 1] != '.') {
				String s = new String(chars, i - 1, 2);
				Double value = distribution.get(s);
				if (value == null)
					value = 0.;
				result *= Math.max(value, .01);
			}
		}
		return result;
	}

	/** Writes the table. */
	public void writeTable(Writer writer) throws IOException {
		StringBuilder sb = new StringBuilder();
		for (String key : CollectionUtils.sort(distribution.keySet())) {
			sb.append(key + " " + distribution.get(key) + StringUtils.CR);
		}
		writer.append(sb.toString());
	}

	/** Simple program for computing a table from one or more files. */
	public static void main(String[] args) throws IOException {
		if (args.length == 0) {
			System.err.println("Usage: provide files on command line!");
			System.exit(1);
		}
		StringBuilder sb = new StringBuilder();
		for (String arg : args) {
			sb.append(FileSystemUtils.readFile(new File(arg)));
			sb.append(StringUtils.CR);
		}
		OutputStreamWriter out = new OutputStreamWriter(System.out);
		calculateFromString(sb.toString()).writeTable(out);
		out.flush();
	}
}

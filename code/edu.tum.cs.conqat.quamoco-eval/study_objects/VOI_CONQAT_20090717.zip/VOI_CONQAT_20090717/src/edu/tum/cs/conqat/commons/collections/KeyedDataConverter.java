/*--------------------------------------------------------------------------+
   $Id: KeyedDataConverter.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.collections;

import java.util.Collection;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.statistics.KeyedData;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor converts a keyed data object to a simple tree of
 * <code>IConQATNode</code>s.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This processor converts a KeyedData object to a simple tree of IConQATNodes. "
		+ "If a tree is specified, values will be added, otherwise a new tree is created.")
public class KeyedDataConverter extends MapConverterBase {

	/** The data object. */
	private KeyedData<Comparable<?>> keyedData;

	/** The data object set defining the values. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "KeyedData object holding the values.")
	public void setKeyedData(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			KeyedData<Comparable<?>> keyedData) {
		this.keyedData = keyedData;
	}

	/** {@inheritDoc} */
	@Override
	protected Collection<?> getKeyElements() {
		return keyedData.getValues().keySet();
	}

	/** {@inheritDoc} */
	@Override
	protected Double getValue(Object key) {
		return keyedData.getValues().get(key);
	}
}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.archgraph
 |                                                                       |
   $Id: LayoutedGraphRenderer.java 21612 2009-06-10 20:56:51Z deissenb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.archgraph;

import static edu.tum.cs.commons.html.EHTMLAttribute.CLASS;
import static edu.tum.cs.commons.html.EHTMLAttribute.HREF;
import static edu.tum.cs.commons.html.EHTMLAttribute.SRC;
import static edu.tum.cs.commons.html.EHTMLElement.A;
import static edu.tum.cs.commons.html.EHTMLElement.IMG;
import static edu.tum.cs.conqat.archgraph.PaintableVertex.DUMMY_POINT;
import static edu.tum.cs.conqat.architecture.graph.ArchitectureHierarchyBuilder.ORPHANED_ELEMENTS_ID;
import static edu.tum.cs.conqat.html_presentation.CSSMananger.LIGHT_BLUE_BORDER;
import static java.awt.RenderingHints.KEY_ANTIALIASING;
import static java.awt.RenderingHints.VALUE_ANTIALIAS_ON;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.SVGGraphics2D;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.architecture.graph.ArchitectureHierarchyBuilder;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.graph.concentrate.GraphConcentrator;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphInnerNode;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.tum.cs.conqat.graph.nodes.IConQATGraphNode;
import edu.tum.cs.conqat.html_presentation.color.ColorizerBase;
import edu.tum.cs.conqat.html_presentation.util.ImageCreatingLayouterBase;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * {@ConQAT.doc}
 * 
 * @author kanis
 * @author $Author: deissenb $
 * @version $Rev: 21612 $
 * @levd.rating YELLOW Rev: 21612
 */
@AConQATProcessor(description = "A processor to output bitmap and vector graphics of an architecture analysis.")
public class LayoutedGraphRenderer extends ImageCreatingLayouterBase {

	/** Name of the graph icon: {@value} */
	private static final String GRAPH_ICON_NAME = "graph.gif";

	/** The style definitions used when rendering. */
	private final Style style = Style.getDefault();

	/** The graph we will render. */
	private ConQATGraph architectureGraph;

	/** Holds the bounds of the image, i.e. it's offset and it's size. */
	private Rectangle imageBounds;

	/** Key in which colors for nodes and edges are stored */
	private String colorKey = ColorizerBase.COLOR_KEY_DEFAULT;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "graph", minOccurrences = 1, maxOccurrences = 1, description = "Architecture graph to visualize.")
	public void setInput(
			@AConQATAttribute(name = "ref", description = "Reference to layouted graph generating processor.") ConQATGraph graph) {
		this.architectureGraph = graph;
		computeImageBounds();
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(description = "The styleset to use for the graphic.", name = "style")
	public void setStyle(
			@AConQATAttribute(name = Style.RED_COLOR_KEY, description = "Color for red edges.") Color redColor,
			@AConQATAttribute(name = Style.YELLOW_COLOR_KEY, description = "Color for yellow edges.") Color yellowColor,
			@AConQATAttribute(name = Style.GREEN_COLOR_KEY, description = "Color for green edges.") Color greenColor) {
		style.put(Style.RED_COLOR_KEY, redColor);
		style.put(Style.YELLOW_COLOR_KEY, yellowColor);
		style.put(Style.GREEN_COLOR_KEY, greenColor);
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "color", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Set key in which colors for keys and nodes are stored")
	public void setColorKey(
			@AConQATAttribute(name = "key", description = "Name of the key") String colorKey) {
		this.colorKey = colorKey;
	}

	/** {@inheritDoc} */
	@Override
	protected String getIconName() {
		return GRAPH_ICON_NAME;
	}

	/** {@inheritDoc} */
	@Override
	protected void layoutPage() throws ConQATException {
		CCSMPre.isTrue(architectureGraph != null, "Graph may not be null");

		try {
			createImages();
		} catch (IOException e) {
			throw new ConQATException(e);
		}

		createHtmlContent();
	}

	/** Create bitmap and vector graphics file from graph. */
	private void createImages() throws IOException {

		// Create an instance of org.w3c.dom.Document.
		DOMImplementation domImpl = GenericDOMImplementation
				.getDOMImplementation();
		String svgNS = "http://www.w3.org/2000/svg";
		Document document = domImpl.createDocument(svgNS, "svg", null);

		File svgFile = getFile("svg");
		File pngFile = getFile("png");
		FileSystemUtils.ensureParentDirectoryExists(svgFile);

		// create svg
		SVGGraphics2D svgGenerator = new SVGGraphics2D(document);
		paint(svgGenerator);
		svgGenerator.stream(svgFile.getAbsolutePath(), true);

		// create png
		BufferedImage img = new BufferedImage(
				imageBounds.width - imageBounds.x, imageBounds.height
						- imageBounds.y, BufferedImage.TYPE_INT_ARGB);
		paint(img.createGraphics());
		ImageIO.write(img, "png", pngFile);
	}

	/** Paints the graph to the given graphics context. */
	private void paint(Graphics2D graphics) {
		graphics.translate(-imageBounds.x, -imageBounds.y);
		graphics.setColor(Color.BLACK);

		paintVertices(graphics, architectureGraph);

		// turn on anti-aliasing for edges
		graphics.setRenderingHint(KEY_ANTIALIASING, VALUE_ANTIALIAS_ON);
		paintEdges(graphics);
	}

	/** Paints the edges to the given {@link Graphics2D} context. */
	private void paintEdges(Graphics2D graphics) {

		// red edges are painted last so they are on top: they are the most
		// important

		List<DirectedSparseEdge> edges = new ArrayList<DirectedSparseEdge>(
				architectureGraph.getEdges());
		Collections.sort(edges, new EdgeColorComparator());

		for (DirectedSparseEdge edge : edges) {
			PaintableVertex source = new PaintableVertex((ConQATVertex) edge
					.getSource());
			PaintableVertex dest = new PaintableVertex((ConQATVertex) edge
					.getDest());

			new PaintableEdge(source, dest, (Color) edge.getUserDatum(colorKey))
					.paint(graphics);
		}
	}

	/** Paints the vertices to the given {@link Graphics2D} context. */
	private void paintVertices(Graphics2D g2d, ConQATGraphInnerNode root) {

		// paint all leaves of the current "root" node
		for (ConQATVertex leaf : getZOrderedVertices(root)) {
			paintVertex(g2d, leaf);
		}

		for (ConQATGraphInnerNode node : root.getInnerNodes()) {
			paintVertex(g2d, node);
			paintVertices(g2d, node);
		}

	}

	/**
	 * This method make sure, the dummy leaf element that describes the inner
	 * node, appears first and, hence, is painted first. Otherwise it would
	 * cover the leaves that were drawn before it. This quite a hack since the
	 * whole data structure we are using is quite a hack.
	 */
	private List<ConQATVertex> getZOrderedVertices(ConQATGraphInnerNode root) {
		ArrayList<ConQATVertex> vertices = new ArrayList<ConQATVertex>(root
				.getChildVertices());

		for (int i = 0; i < vertices.size(); i++) {
			ConQATVertex vertex = vertices.get(i);
			if ((vertex.getName() + "_").equals(root.getName())) {
				Collections.swap(vertices, 0, i);
				return vertices;
			}
		}

		return vertices;
	}

	/**
	 * Paints one node, which can be an inner node ({@link ConQATGraphInnerNode}
	 * ) or a leaf node ({@link ConQATVertex}).
	 */
	@SuppressWarnings("null")
	private void paintVertex(Graphics2D g2d, IConQATGraphNode node) {
		PaintableVertex vertex = new PaintableVertex(node);

		Point position = getComponentPosition(vertex);

		CCSMAssert.isFalse(position == null,
				"Position may not be null in any vertex.");

		// Compiler warns about potential null access here, therefore
		// @SuppressWarnings("null")
		g2d.translate(position.x, position.y);
		g2d.setClip(0, 0, vertex.getDimension().width + 1, vertex
				.getDimension().height + 1);
		vertex.paint(g2d);
		g2d.translate(-position.x, -position.y);

		// reset the clip, so we don't interfere with later renderings
		g2d.setClip(null);
	}

	/**
	 * Returns the position to paint a given component vertex at. This includes
	 * the {@link ArchitectureHierarchyBuilder#ORPHANED_ELEMENTS_ID} component,
	 * that has no "natural" position and is calculated to be at the lower
	 * border of the image. This also updates the vertex object's position.
	 */
	private Point getComponentPosition(PaintableVertex vertex) {
		Point position = vertex.getPosition();
		if (position == DUMMY_POINT
				&& vertex.getModel().getId().equals(
						GraphConcentrator.extendedName(ORPHANED_ELEMENTS_ID))) {
			position = new Point(imageBounds.width / 2
					- vertex.getDimension().width / 2, imageBounds.height
					+ Style.BORDER_WIDTH);
			vertex.setPosition(position);

			// for the "unknown" vertex make the image bigger
			imageBounds.height += Style.COMPONENT_MINIMUM_HEIGHT
					+ Style.BORDER_WIDTH;
		}
		return position;
	}

	/**
	 * Calculates the boundaries of the image with left/top offset and Dimension
	 * to right/bottom. Needs only to be called once, right after setting the
	 * graph.
	 */
	private void computeImageBounds() {
		if (imageBounds == null) {
			imageBounds = new Rectangle(new Point(Integer.MAX_VALUE,
					Integer.MAX_VALUE));

			ArrayList<IConQATGraphNode> allNodes = new ArrayList<IConQATGraphNode>();

			allNodes.addAll(architectureGraph.getInnerNodes());
			allNodes.addAll(architectureGraph.getVertices());

			for (IConQATGraphNode node : allNodes) {
				PaintableVertex vertex = new PaintableVertex(node);
				if (vertex.getPosition() == PaintableVertex.DUMMY_POINT) {
					continue;
				}

				fitBounds(imageBounds, vertex);
			}

			imageBounds.x -= Style.BORDER_WIDTH;
			imageBounds.y -= Style.BORDER_WIDTH;
			imageBounds.width += Style.BORDER_WIDTH;
			imageBounds.height += Style.BORDER_WIDTH;
		}
	}

	/**
	 * Check if the given vertex fits into the rectangle and, if not, widen the
	 * rectangle so that it does.
	 */
	private void fitBounds(Rectangle bounds, PaintableVertex vertex) {
		if (vertex.getPosition().x + vertex.getDimension().width + 1 > bounds.width) {
			bounds.width = vertex.getPosition().x + vertex.getDimension().width
					+ 1;
		}
		if (vertex.getPosition().y + vertex.getDimension().height + 1 > bounds.height) {
			bounds.height = vertex.getPosition().y
					+ vertex.getDimension().height + 1;
		}

		if (vertex.getPosition().x < bounds.x) {
			bounds.x = vertex.getPosition().x;
		}
		if (vertex.getPosition().y < bounds.y) {
			bounds.y = vertex.getPosition().y;
		}
	}

	/** Create HTML content. */
	private void createHtmlContent() {
		writer.openElement(A, HREF, getHRef("svg"));
		writer.addClosedElement(IMG, CLASS, LIGHT_BLUE_BORDER, SRC,
				getHRef("png"));
		writer.closeElement(A);
	}

	/** Sorts {@link DirectedSparseEdge}s according to there color. */
	private class EdgeColorComparator implements Comparator<DirectedSparseEdge> {
		/**
		 * We need to sort the edges by color, so yellow is above red, above
		 * green, above black. This can be done <b>very</b> easily by comparing
		 * their RGB int values.
		 */
		public int compare(DirectedSparseEdge e1, DirectedSparseEdge e2) {
			Color c1 = (Color) e1.getUserDatum(colorKey);
			Color c2 = (Color) e2.getUserDatum(colorKey);

			if (c1 == null || c2 == null) {
				return 0;
			}

			return new Integer(c1.getRGB()).compareTo(c2.getRGB());
		}
	}
}

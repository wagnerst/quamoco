/*--------------------------------------------------------------------------+
   $Id: ArchGraphPipelineBase.java 21601 2009-06-09 16:37:17Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.graph;

import edu.tum.cs.conqat.architecture.scope.ComponentNode;
import edu.tum.cs.conqat.architecture.scope.ComponentResolver;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;

/**
 * Base class for processors working with a given graph based on a provided
 * architecture.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 21601 $
 * @levd.rating GREEN Rev: 21601
 */
public abstract class ArchGraphPipelineBase extends
		ConQATPipelineProcessorBase<ConQATGraph> {

	/** The reference architecture. */
	protected ComponentNode arch;

	/** Maps from element to corresponding component */
	protected ComponentResolver resolver;

	/** Set the architecture definition to work with. */
	@AConQATParameter(name = "architecture", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The architecture definition used as a reference.")
	public void setArchitectureDef(
			@AConQATAttribute(name = "def", description = "Reference to the architecture definition.")
			ComponentNode arch) {

		this.arch = arch;
		resolver = new ComponentResolver(arch, getLogger());
	}
}

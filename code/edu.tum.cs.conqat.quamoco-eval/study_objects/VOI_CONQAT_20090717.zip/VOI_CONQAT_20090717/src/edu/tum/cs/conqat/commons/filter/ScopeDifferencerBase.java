/*--------------------------------------------------------------------------+
   $Id: ScopeDifferencerBase.java 18544 2009-02-23 09:58:03Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.filter;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for scope differencing processors. The functionality of class
 * {@link ScopeDifferencer} is not implemented directly in this class because we
 * cannot use generic classes as processors.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 18544 $
 * @levd.rating GREEN Rev: 18544
 */
public abstract class ScopeDifferencerBase<T extends IRemovableConQATNode>
		extends ConQATPipelineProcessorBase<T> {

	/** Description of the processor. Can be used by subclasses. */
	public static final String PROCESSOR_DESCRIPTION = "Subtracts the elements of one scope from a second scope.";

	/** Root file system element whose children get subtracted */
	private T subtract;

	/**
	 * Flag that determines whether for each file that occurs in the subtract
	 * scope, but is missing in the input scope, a warning is issued.
	 */
	private boolean warnMissingFiles = true;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "subtract", description = ""
			+ "Root of the scope that gets subtracted", minOccurrences = 1, maxOccurrences = 1)
	public void setSubtract(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) T subtract) {
		this.subtract = subtract;
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "warn", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Flag that determines whether for each file that occurs in the subtract "
			+ "scope, but is missing in the input scope, a warning is issued.")
	public void setWarnMissingFiles(
			@AConQATAttribute(name = "missingFiles", description = "Default behaviour is to issue warnings.") boolean warnMissingFiles) {
		this.warnMissingFiles = warnMissingFiles;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws ConQATException
	 */
	@Override
	protected void processInput(T input) throws ConQATException {
		// create map of input scope elements
		Map<String, T> inputElementsMap = new HashMap<String, T>();
		for (T element : TraversalUtils.listLeavesDepthFirst(input)) {
			inputElementsMap.put(obtainId(element), element);
		}

		// iterate elements from subtract scope
		for (T subtractElement : TraversalUtils.listLeavesDepthFirst(subtract)) {
			String subtractElementId = obtainId(subtractElement);
			if (!inputElementsMap.containsKey(subtractElementId)) {
				if (warnMissingFiles) {
					getLogger().warn(
							"Element '" + subtractElementId
									+ "' not found in input");
				}
			} else {
				inputElementsMap.get(subtractElementId).remove();
			}
		}

	}

	/**
	 * Obtain id of the element. Sub classes must override this method to define
	 * new mechanisms for obtaining the id.
	 */
	protected abstract String obtainId(T element) throws ConQATException;

}

/*--------------------------------------------------------------------------+
   $Id: IClone.java 22020 2009-07-16 09:36:36Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import java.util.Date;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Interface for clones.
 * 
 * @author Florian Deissenboeck
 * @author $Author: juergens $
 * 
 * @version $Revision: 22020 $
 * @levd.rating YELLOW Rev: 22020
 */
public interface IClone extends IKeyValueStore {

	/** Returns birth timestamp. */
	public Date getBirth();

	/** Returns death timestamp. */
	public Date getDeath();

	/** {@link CloneClass} this clone belongs to */
	public CloneClass getCloneClass();

	/**
	 * Origin of the clone.
	 * <p>
	 * This is usually the filename or the Id of the {@link IFileSystemElement}
	 * that represents the clone's file.
	 */
	public String getOrigin();

	/** Position of the first line of the clone in its file */
	public int getStartLineInFile();

	/** Position of the last line of the clone in its file */
	public int getLastLineInFile();

	/** Length of the clone in lines in its file. */
	public int getLengthInFile();

	/** Position of the first unit of the clone in its file */
	public int getStartUnitIndexInFile();

	/** Length of the clone in units. */
	public int getLengthInUnits();

	/** Position of the last unit of the clone in its file */
	public int getLastUnitInFile();

	/**
	 * Fingerprint of clone. A clone fingerprint characterizes the piece of
	 * cloned code after normalization. All ungapped clones inside a single
	 * clone class have the same fingerprint.
	 */
	public String getFingerprint();

	/**
	 * Gets the gap type at a line offset. Returns {@link EEditOperation#NONE}
	 * if the clone does not contain a gap at that position
	 */
	public EEditOperation getGapTypeAt(int lineOffset);

	/** Determines whether the clone contains gaps */
	public boolean containsGaps();

	/** Return number of gaps, or 0, if clone has no gaps */
	public int gapCount();

	/** Edit distance to first clone in clone class */
	public int getDeltaInUnits();

	/**
	 * Returns a list of the gap positions, or empty list, if clone has no gaps.
	 */
	public UnmodifiableList<Integer> getGapPositions();

	/** Set birth */
	public void setBirth(Date birth);

	/** Set birth */
	public void setDeath(Date death);

	/** Set timestamp fingerprint was last modified */
	public void setFingerprintLastModified(Date timestamp);

	/** Get timestamp fingerprint was last modified */
	public Date getFingerprintLastModified();
}

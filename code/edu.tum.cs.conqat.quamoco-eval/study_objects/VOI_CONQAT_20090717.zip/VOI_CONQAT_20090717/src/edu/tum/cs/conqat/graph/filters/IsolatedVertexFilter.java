/*--------------------------------------------------------------------------+
   $Id: IsolatedVertexFilter.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.filters;

import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;

/**
 * This filter deletes all isolated vertices.
 * 
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This filter removes all isolated vertices, i.e. "
		+ "those which are not connected to any other vertex.")
public class IsolatedVertexFilter extends VertexFilterBase {

	/** Filters out vertexes that have no incoming or outgoing edges */
	@Override
	protected boolean isFiltered(ConQATVertex vertex) {
		return vertex.numNeighbors() == 0;
	}
}

/*--------------------------------------------------------------------------+
   $Id: StatementNormalization.java 22022 2009-07-16 09:38:18Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.statement;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.IUnit;
import edu.tum.cs.conqat.clonedetective.core.IUnitProvider;
import edu.tum.cs.conqat.clonedetective.detection.SentinelUnit;
import edu.tum.cs.conqat.clonedetective.normalization.UnitProviderBase;
import edu.tum.cs.conqat.clonedetective.normalization.token.ITokenProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.TokenNormalization;
import edu.tum.cs.conqat.clonedetective.normalization.token.TokenUnit;
import edu.tum.cs.conqat.clonedetective.normalization.token.configuration.ITokenConfiguration;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.ETokenType;
import edu.tum.cs.scanner.IStatementOracle;

/**
 * The {@link StatementNormalization} wraps the token normalization but
 * concatenates multiples tokens to statements.
 * 
 * @author Florian Deissenboeck
 * @author $Author: juergens $
 * 
 * @version $Revision: 22022 $
 * @levd.rating YELLOW Rev: 21494
 */
public class StatementNormalization extends
		UnitProviderBase<ISourceCodeElement, IUnit> {

	/** Normalizes tokens before the creation of statement units. */
	private final IUnitProvider<ISourceCodeElement, TokenUnit> normalization;

	/** The statement oracle used to detect statement boundaries. */
	private IStatementOracle statementOracle;

	/** Flag that determines whether the tokens of a statement are stored */
	private final boolean storeTokens;

	/** Index of the unit in its file */
	private int indexInFile;

	/**
	 * Creates a new {@link StatementNormalization} that does not store the
	 * underlying tokens in the StatementUnit
	 */
	public StatementNormalization(ITokenProvider tokenProvider,
			List<ITokenConfiguration> configurationList,
			ITokenConfiguration defaultConfig) {

		this(tokenProvider, configurationList, defaultConfig, false, null);
	}

	/**
	 * Create a new {@link StatementNormalization}.
	 * 
	 * @param storeTokens
	 *            If this flag is set, the underlying tokens are stored in the
	 *            {@link StatementUnit}. Be careful: This can have a tremendous
	 *            impact on memory consumption during clone detection!!
	 */
	public StatementNormalization(ITokenProvider tokenProvider,
			List<ITokenConfiguration> configurationList,
			ITokenConfiguration defaultConfig, boolean storeTokens,
			String debugFileExtension) {
		normalization = new TokenNormalization(tokenProvider,
				configurationList, defaultConfig, debugFileExtension);
		this.storeTokens = storeTokens;
	}

	/**
	 * Create a new {@link StatementNormalization}.
	 * 
	 * @param storeTokens
	 *            If this flag is set, the underlying tokens are stored in the
	 *            {@link StatementUnit}. Be careful: This can have a tremendous
	 *            impact on memory consumption during clone detection!!
	 */
	public StatementNormalization(
			IUnitProvider<ISourceCodeElement, TokenUnit> normalization,
			boolean storeTokens) {
		this.normalization = normalization;
		this.storeTokens = storeTokens;
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ISourceCodeElement root) throws CloneDetectionException {
		normalization.init(root, getLogger());
		statementOracle = root.getLanguage().getStatementOracle();
	}

	/** {@inheritDoc} */
	@Override
	protected IUnit provideNext() throws CloneDetectionException {
		List<TokenUnit> statementTokens = new ArrayList<TokenUnit>();

		// determine first token in statement
		TokenUnit firstToken = findStartOfStatement();
		if (firstToken == null) {
			return null;
		}

		// handle sentinels
		if (isSentinel(firstToken)) {
			return new SentinelUnit(firstToken.getOriginId());
		}

		// now that first non-sentinel token is found, determine statement index
		int currentIndexInFile = indexInFile++;

		statementTokens.add(firstToken);

		// determine rest of statement tokens
		TokenUnit nextToken = normalization.lookahead(1);
		while (inSameStatement(firstToken, nextToken)) {
			statementTokens.add(getNextToken());
			nextToken = normalization.lookahead(1);
		}

		return new StatementUnit(statementTokens, storeTokens,
				currentIndexInFile);
	}

	/**
	 * Retrieves the next token from the normalization and and resets counters,
	 * if token is last in file.
	 * 
	 * Use this method to access retrieve next token to keep statement index in
	 * file up to date.
	 */
	private TokenUnit getNextToken() throws CloneDetectionException {
		TokenUnit nextToken = normalization.getNext();
		if (!inSameFile(nextToken, normalization.lookahead(1))) {
			indexInFile = 0;
		}
		return nextToken;
	}

	/** Checks whether a token is a sentinel token */
	private boolean isSentinel(TokenUnit firstToken) {
		return firstToken.getType() == ETokenType.SENTINEL;
	}

	/**
	 * Finds the next token that starts a statement
	 * 
	 * @return {@link TokenUnit} that starts next statement, or null, if no
	 *         statement start can be found
	 */
	private TokenUnit findStartOfStatement() throws CloneDetectionException {
		TokenUnit firstToken = getNextToken();
		while (firstToken != null
				&& statementOracle.isEndOfStatementToken(firstToken.getType())
				&& !firstToken.getType().equals(ETokenType.SENTINEL)) {
			firstToken = getNextToken();
		}
		return firstToken;
	}

	/** Checks whether two tokens are part of the same statement */
	private boolean inSameStatement(TokenUnit firstUnit, TokenUnit nextUnit) {
		return nextUnit != null
				&& !statementOracle.isEndOfStatementToken(nextUnit.getType())
				&& inSameFile(firstUnit, nextUnit);
	}

	/** Checks whether two tokens units stem from the same file */
	private boolean inSameFile(TokenUnit unit1, TokenUnit unit2) {
		if (unit2 == null) {
			return false;
		}
		return unit1.getOriginId().equals(unit2.getOriginId());
	}
}
/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingUtils.java 21999 2009-07-15 20:43:23Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.util;

import java.util.Collection;
import java.util.HashSet;

import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingCategory;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.location.FileLocation;
import edu.tum.cs.conqat.commons.findings.location.LocationBase;

/**
 * Utility methods for findings.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21999 $
 * @levd.rating YELLOW Rev: 21999
 */
public class FindingUtils {

	/**
	 * Returns findings grouped by the (absolute) file they are referencing.
	 * Findings with a non-file related location are ignored.
	 */
	public static HashedListMap<CanonicalFile, Finding<?>> getFindingsByAbsoluteFile(
			FindingReport report) {
		HashedListMap<CanonicalFile, Finding<?>> result = new HashedListMap<CanonicalFile, Finding<?>>();
		for (FindingCategory category : report.getChildren()) {
			for (FindingGroup group : category.getChildren()) {
				for (Finding<?> finding : group.getChildren()) {
					for (CanonicalFile file : getAffectedFiles(finding)) {
						result.add(file, finding);
					}
				}
			}
		}
		return result;
	}

	/** Returns all (absolute) file names which are affected by a finding. */
	private static Collection<CanonicalFile> getAffectedFiles(Finding<?> finding) {
		Collection<CanonicalFile> result = new HashSet<CanonicalFile>();
		for (LocationBase location : finding.getLocations()) {
			if (location instanceof FileLocation) {
				result.add(((FileLocation) location).getFile());
			}
		}
		return result;
	}

}

/*--------------------------------------------------------------------------+
   $Id: AssessmentFrequencyProcessor.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.statistics;

import java.util.HashSet;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor counts the number of RED warnings stored at different keys and
 * creats a KeyedData object.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This processor counts the number of RED "
		+ "assessments stored at different keys and creates a KeyedData object, "
		+ "i.e. a map that maps from each key to the number of RED leaves found for the key.")
public class AssessmentFrequencyProcessor extends ConQATProcessorBase implements
		INodeVisitor<IConQATNode, NeverThrownRuntimeException> {

	/** Set of keys to check for collections. */
	private final HashSet<String> keys = new HashSet<String>();

	/** The input this processor works on. */
	private IConQATNode root;

	/** The counter. */
	private final CounterSet<String> counter = new CounterSet<String>();

	/** Flag signaling relative results. */
	private boolean relative = false;

	/** Number of leaves counter for relative results. */
	private int leaveCount = 0;

	/** Set the root element to work on. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			IConQATNode root) {
		this.root = root;
	}

	/** Set relative flag. */
	@AConQATParameter(name = "relative", maxOccurrences = 1, description = "Flag for relative results.")
	public void setRelative(
			@AConQATAttribute(name = "value", description = "If set to true, the number of RED assessed leaves is put into "
					+ "relation with the total number of leaves [false].")
			boolean relative) {
		this.relative = relative;
	}

	/** Set the key to use. */
	@AConQATParameter(name = ConQATParamDoc.READKEY_NAME, minOccurrences = 1, description = ConQATParamDoc.READKEY_DESC)
	public void addKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC)
			String key) {

		keys.add(key);
	}

	/** Does the actual processing. */
	public KeyedData<String> process() {
		TraversalUtils.visitLeavesDepthFirst(this, root);
		KeyedData<String> data = new KeyedData<String>();
		for (String key : keys) {
			data.add(key, getValue(key));
		}
		return data;
	}

	/** Get value for key. */
	private double getValue(String key) {
		double value = counter.getValue(key);
		if (!relative) {
			return value;
		}
		return value / leaveCount;
	}

	/**
	 * Count number of red assessed leaves.
	 */
	public void visit(IConQATNode node) {
		leaveCount++;
		for (String key : keys) {
			Object valueObject = node.getValue(key);
			if (valueObject instanceof Assessment) {
				Assessment assessment = (Assessment) valueObject;
				if (assessment.getDominantColor() == ETrafficLightColor.RED) {
					counter.inc(key);
				}
			}
		}
	}
}

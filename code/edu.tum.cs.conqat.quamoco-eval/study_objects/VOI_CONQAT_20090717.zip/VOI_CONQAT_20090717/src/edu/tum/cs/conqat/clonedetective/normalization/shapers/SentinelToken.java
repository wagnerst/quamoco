/*--------------------------------------------------------------------------+
   $Id: SentinelToken.java 19092 2009-03-14 12:44:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.shapers;

import edu.tum.cs.scanner.ELanguage;
import edu.tum.cs.scanner.ETokenType;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.Token;

/**
 * Sentinel Token. Sentinels tokens have a unique textual content and are thus
 * unequal to any other tokens.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 19092 $
 * @levd.rating GREEN Rev: 19092
 */
/* package */class SentinelToken extends Token {

	/**
	 * Creates a sentinel token whose origin information is copied from the
	 * token after which the sentinel is to be inserted
	 */
	public static SentinelToken createSentinelAfter(IToken token) {
		return new SentinelToken(ETokenType.SENTINEL, token.getOffset(), token
				.getLineNumber(), "�" + counter++, token.getOrigin(), token
				.getLanguage());
	}

	/** Counter used to create unique sentinel texts */
	private static int counter = 0;

	/** Stores language */
	private final ELanguage language;

	/** Constructor */
	protected SentinelToken(ETokenType type, int offset, int lineNumber,
			String text, Object origin, ELanguage language) {
		super(type, offset, lineNumber, text, origin);
		this.language = language;
	}

	/** {@inheritDoc} */
	public ELanguage getLanguage() {
		return language;
	}

	/** {@inheritDoc} */
	public IToken newToken(ETokenType type, int offset, int lineNumber,
			String text, Object origin) {
		return new SentinelToken(type, offset, lineNumber, text, origin,
				language);
	}

}
/*--------------------------------------------------------------------------+
   $Id: CompositeClone.java 22020 2009-07-16 09:36:36Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.utils.CloneStartPositionComparator;
import edu.tum.cs.conqat.clonedetective.utils.CloneUtils;

/**
 * A composite clone logically groups several consecutive clones with small gaps
 * into a single clone. Gap information is preserved.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 22020 $
 * @levd.rating YELLOW Rev: 22020
 */
public class CompositeClone extends CloneBase {

	/**
	 * Clones contained in this composite clone ordered by start position in
	 * file
	 */
	private final List<IClone> clones;

	/** Set of gap positions. */
	private final Set<Integer> gapPositions;

	/**
	 * Creates a composite clone from a list of clones.
	 * 
	 * @param cloneClass
	 *            Clone class to which this composite clone will belong to.
	 * 
	 * @param clones
	 *            List of clones contained in this composite clone. All clones
	 *            need to share the same origin.
	 */
	public CompositeClone(int id, CloneClass cloneClass, List<IClone> clones) {
		super(id, cloneClass, assertCommonOrigin(clones), CloneUtils
				.createFingerprint(clones));
		this.clones = CollectionUtils.sort(clones, CloneStartPositionComparator
				.getInstance());
		this.gapPositions = computeGapPositions();
	}

	/**
	 * Gets the number of lines spanned by the composite clone.
	 * <p>
	 * Remark: This length metric includes the gaps.
	 */
	public int getLengthInFile() {
		int lastLineNumber = getLastClone().getStartLineInFile()
				+ getLastClone().getLengthInFile();
		int firstLineNumber = getStartLineInFile();
		return lastLineNumber - firstLineNumber + 1;
	}

	/**
	 * Gets the sum of the lengths in units of the contained clones
	 * <p>
	 * Remark: This length metric does NOT include the gaps.
	 */
	public int getLengthInUnits() {
		int unitLengthSum = 0;
		for (IClone clone : clones) {
			unitLengthSum += clone.getLengthInUnits();
		}
		return unitLengthSum;
	}

	/** {@inheritDoc} */
	public int getStartLineInFile() {
		return getFirstClone().getStartLineInFile();
	}

	/** {@inheritDoc} */
	public int getStartUnitIndexInFile() {
		return getFirstClone().getStartUnitIndexInFile();
	}

	/** Gets the first contained clone */
	private IClone getFirstClone() {
		return clones.get(0);
	}

	/** Gets the last contained clone */
	private IClone getLastClone() {
		return clones.get(clones.size() - 1);
	}

	/** {@inheritDoc} */
	@Override
	public UnmodifiableList<Integer> getGapPositions() {
		return CollectionUtils.asSortedUnmodifiableList(gapPositions);
	}

	/** A composite clone returns {@link EEditOperation#CHANGE} for all gaps */
	@Override
	public EEditOperation getGapTypeAt(int lineOffset) {
		if (getGapPositions().contains(lineOffset)) {
			return EEditOperation.CHANGE;
		}
		return EEditOperation.NONE;
	}

	/** Add gap information to {@link #toString()} method */
	@Override
	protected String toStringHook(String indent) {
		return indent + "Gaps: " + getGapPositions() + StringUtils.CR;
	}

	/** Computes the gap positions for the clone */
	private Set<Integer> computeGapPositions() {
		Set<Integer> gaps = new HashSet<Integer>();

		int lineOffset = getFirstClone().getLengthInFile() - 1;
		int lastCoveredLineInFile = lastLineCoveredByClone(getFirstClone());

		// Skip first clone
		for (int i = 1; i < clones.size(); i++) {
			IClone clone = clones.get(i);
			int gapSize = clone.getStartLineInFile() - lastCoveredLineInFile
					- 1;

			for (int gapPosition = 0; gapPosition < gapSize; gapPosition++) {
				lineOffset++;
				gaps.add(lineOffset);
			}

			lastCoveredLineInFile = lastLineCoveredByClone(clone);
			lineOffset += clone.getLengthInFile();
		}

		return gaps;
	}

	/**
	 * Asserts that all clones have a common origin and returns it.
	 * 
	 * @param clones
	 *            clones from which common origin is asserted
	 * @throws IllegalArgumentException
	 *             if the list of clones is empty or the clones do not have the
	 *             same origin
	 */
	@SuppressWarnings("null")
	private static String assertCommonOrigin(List<IClone> clones) {
		CCSMPre.isFalse(clones == null || clones.isEmpty(),
				"Clones list must not be empty");

		String origin = clones.get(0).getOrigin();
		for (IClone clone : clones) {
			CCSMPre.isTrue(origin.equals(clone.getOrigin()),
					"All clones must have same origin!");
		}

		return origin;
	}

	/** Computes last line in a file covered by a clone */
	private int lastLineCoveredByClone(IClone clone) {
		return clone.getStartLineInFile() + clone.getLengthInFile() - 1;
	}

}

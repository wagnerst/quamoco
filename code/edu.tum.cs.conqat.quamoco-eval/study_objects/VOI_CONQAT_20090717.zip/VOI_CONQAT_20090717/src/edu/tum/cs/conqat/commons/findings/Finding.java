/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: Finding.java 21887 2009-07-10 15:06:10Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.commons.findings.location.ELocationType;
import edu.tum.cs.conqat.commons.findings.location.LocationBase;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * A single finding which represents a single issue found during an analysis.
 * Findings are nearly immutable. While they can be modified using the
 * {@link #getValue(String)}/{@link #setValue(String, Object)} methods, all
 * other fields are read-only. Furthermore, deepcloning is implemented as
 * identiity (i.e. does not produce new objects).
 * 
 * @param <T>
 *            the value type of this finding.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21887 $
 * @levd.rating YELLOW Rev: 21887
 */
public class Finding<T> extends ConQATNodeBase implements IRemovableConQATNode {

	/** The locations. */
	private final List<LocationBase> locations = new ArrayList<LocationBase>();

	/** The finding group this finding belongs to. */
	private final FindingGroup findingGroup;

	/** The originating tool. */
	private final String originTool;

	/** The id which is unique within the findings group. */
	private final int id;

	/** The value. */
	private final T value;

	/** Hidden constructor. Use factory methods in {@link FindingGroup} instead. */
	/* package */Finding(FindingGroup findingGroup, String originTool, int id,
			T value) {
		this.findingGroup = findingGroup;
		this.originTool = originTool;
		this.id = id;
		this.value = value;
	}

	/** Copy constructor. */
	/* package */Finding(Finding<T> other, FindingGroup findingGroup)
			throws DeepCloneException {
		super(other);
		this.findingGroup = findingGroup;
		this.originTool = other.originTool;
		this.id = other.id;
		this.value = other.value;
		this.locations.addAll(other.locations);
	}

	/** Returns the value of this finding. */
	public T getValue() {
		return value;
	}

	/** Returns the locations for this finding. */
	public UnmodifiableList<LocationBase> getLocations() {
		return CollectionUtils.asUnmodifiable(locations);
	}

	/** Adds a location. */
	public void addLocation(LocationBase location) {
		CCSMPre.isTrue(location != null
				&& getLocationType().getLocationClass().isAssignableFrom(
						location.getClass()),
				"Location instance does not fit with location type!");
		locations.add(location);
	}

	/** Returns the finding type of this finding. */
	public EFindingType getFindingType() {
		return findingGroup.getFindingType();
	}

	/** Returns the location type of this finding. */
	public ELocationType getLocationType() {
		return findingGroup.getLocationType();
	}

	/** Returns the origin tool. */
	public String getOriginTool() {
		return originTool;
	}

	/** {@inheritDoc} */
	public IRemovableConQATNode[] getChildren() {
		return null;
	}

	/** {@inheritDoc} */
	public void remove() {
		findingGroup.remove(this);
	}

	/** {@inheritDoc} */
	public String getId() {
		return findingGroup.getId() + ":" + getName();
	}

	/** {@inheritDoc} */
	public String getName() {
		return originTool + " finding " + id;
	}

	/** {@inheritDoc} */
	public FindingGroup getParent() {
		return findingGroup;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Returns false.
	 */
	public boolean hasChildren() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Returns <code>this</code> as findings are immutable.
	 */
	public Finding<T> deepClone() {
		return this;
	}
}

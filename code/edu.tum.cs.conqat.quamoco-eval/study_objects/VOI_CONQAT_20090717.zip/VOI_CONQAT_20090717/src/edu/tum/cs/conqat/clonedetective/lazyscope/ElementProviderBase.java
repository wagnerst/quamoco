/*--------------------------------------------------------------------------+
   $Id: ElementProviderBase.java 18555 2009-02-23 11:30:28Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.clonedetective.core.ProviderBase;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.filesystem.scope.AbsoluteFilenameComparator;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * Returns the elements from a scope one by one in a lazy fashion. (Difference
 * between this class and <code>ProviderBase</code>: The data objects provided
 * by classes deriving from {@link ElementProviderBase} are required to be
 * elements, whereas the data objects returned by classes deriving from
 * {@link ProviderBase} can be of arbitrary type.)
 * <p>
 * This class has package visibility in order to enforce the use of its
 * subclasses from outside this package.
 * <p>
 * Since this class is generic, it should not be used as a return type in a
 * ConQAT processor, since the ConQAT load time type checking mechanism cannot
 * handle generic types.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Revision: 18555 $
 * @levd.rating GREEN Rev: 18555
 */
public abstract class ElementProviderBase<Element extends IFileSystemElement>
		extends ProviderBase<Element, Element, NeverThrownRuntimeException>
		implements IElementProvider<Element> {

	/** Key that contains flag that determines whether file gets ignored */
	private final String ignoreKey;

	/**
	 * Iterator that keeps track of the {@link ISourceCodeElement} that gets
	 * returned for the next call to {@link #getNext()}
	 */
	private Iterator<Element> elementsIterator;

	/** Constructor. */
	protected ElementProviderBase(String ignoreKey) {
		this.ignoreKey = ignoreKey;
	}

	/** {@inheritDoc} */
	@Override
	public void init(Element root) {
		List<Element> elements = TraversalUtils.listLeavesDepthFirst(root);
		Collections.sort(elements, new AbsoluteFilenameComparator());
		if (ignoreKey != null) {
			elements = filter(elements);
		}

		elementsIterator = elements.iterator();
	}

	/** Filters out ignored elements */
	private List<Element> filter(List<Element> elements) {
		List<Element> filtered = new ArrayList<Element>();
		for (Element element : elements) {
			boolean isIgnored = NodeUtils.getValue(element, ignoreKey,
					Boolean.class, false);
			if (!isIgnored) {
				filtered.add(element);
			}
		}
		return filtered;
	}

	/** {@inheritDoc} */
	@Override
	protected Element provideNext() {
		// no more elements to return
		if (elementsIterator == null) {
			return null;
		}

		// if more elements present, return next element
		if (elementsIterator.hasNext()) {
			return elementsIterator.next();
		}

		// no more elements: delete iterator and return null
		elementsIterator = null;
		return null;
	}

}

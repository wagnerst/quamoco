/*--------------------------------------------------------------------------+
   $Id: EProjectFileXmlElement.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.project;

/**
 * Enumeration of XML elements required to read VS.NET project files.
 * <p>
 * Consult package documentation to understand where they occur in VS.NET
 * project files.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
/* package */enum EProjectFileXmlElement {

	/** ItemGroup element */
	ItemGroup,

	/** Compile element */
	Compile,

	/** CSHARP element */
	CSHARP,

	/** Files */
	Files,

	/** Include */
	Include,

	/** File */
	File;
}

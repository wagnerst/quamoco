/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: QualifiedNameLocation.java 21936 2009-07-13 14:01:50Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.location;

/**
 * Location identified by a qualified name, which usually is some kind of path
 * expression.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21936 $
 * @levd.rating YELLOW Rev: 21936
 */
public class QualifiedNameLocation extends LocationBase {

	/** The qualified name. */
	private final String qualifiedName;

	/** Constructor. */
	public QualifiedNameLocation(String qualifiedName) {
		this.qualifiedName = qualifiedName;
	}

	/** Returns the qualified name. */
	public String getQualifiedName() {
		return qualifiedName;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return qualifiedName;
	}
}

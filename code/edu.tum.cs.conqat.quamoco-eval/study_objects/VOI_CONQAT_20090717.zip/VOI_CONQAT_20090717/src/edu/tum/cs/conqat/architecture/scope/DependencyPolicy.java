/*--------------------------------------------------------------------------+
   $Id: DependencyPolicy.java 21410 2009-05-14 10:31:55Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.scope;

import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.architecture.toleration.Tolerations;

/**
 * This describes the policy for dependencies between two components.
 * 
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 21410 $
 * @levd.rating RED Rev: 
 */
public class DependencyPolicy {

	/**
	 * The map we store our tolerated dependencies. This Object is null for all
	 * DependencyPolicies but TOLERATED_POLICY
	 */
	private Tolerations tolerations;

	/** Source component. */
	private final ComponentNode from;

	/** Target component. */
	private final ComponentNode to;

	/** Policy type. */
	private final EPolicyType policyType;

	/** Create new policy. */
	/* package */DependencyPolicy(ComponentNode from, ComponentNode to,
			EPolicyType policyType) {
		if (from == null || to == null) {
			throw new IllegalArgumentException("Nodes must not be null");
		}
		if (from == to) {
			throw new IllegalArgumentException("No self loops allowed!");
		}

		this.from = from;
		this.to = to;
		this.policyType = policyType;

		if (policyType == EPolicyType.TOLERATE_EXPLICIT) {
			this.tolerations = new Tolerations();
		} else {
			this.tolerations = null;
		}
	}

	/**
	 * Copy constructor using another DependencyPolicy as reference but new from
	 * and to components. Used for cloning component node hierarchies.
	 */
	/* package */DependencyPolicy(DependencyPolicy depPolicy,
			ComponentNode newFrom, ComponentNode newTo) {
		this(newFrom, newTo, depPolicy.policyType);

		this.tolerations = depPolicy.tolerations;
	}

	/** Returns the source for the policy. */
	public ComponentNode getSource() {
		return from;
	}

	/** Returns the policy. */
	public EPolicyType getPolicyType() {
		return policyType;
	}

	/** Returns the target for the policy. */
	public ComponentNode getTarget() {
		return to;
	}

	/** Insert this policy in the referenced components. */
	/* package */void registerWithComponents() {
		from.addPolicy(this);
		to.addPolicy(this);
	}

	// TODO (EJ) Offer an add method instead of passing the map out.
	/** returns the tolderations map */
	public Tolerations getTolerations() {
		return tolerations;
	}
}

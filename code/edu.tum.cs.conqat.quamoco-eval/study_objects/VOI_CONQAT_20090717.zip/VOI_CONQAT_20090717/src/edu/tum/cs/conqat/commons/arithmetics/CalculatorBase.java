/*--------------------------------------------------------------------------+
   $Id: CalculatorBase.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.arithmetics;

import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for analyzers performing arithmetic on keys.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public abstract class CalculatorBase extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** The key to store the result. */
	private String resultKey;

	/** The key for the first argument. */
	private String argument1Key;

	/** The key for the second argument. */
	private String argument2Key;

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.ALL;
	}

	/** Set the key to be used. */
	@AConQATParameter(name = "keys", minOccurrences = 1, maxOccurrences = 1, description = "The keys to read from and write to.")
	public void setKeys(
			@AConQATAttribute(name = "arg1", description = "Name of the key for the first argument.")
			String arg1,
			@AConQATAttribute(name = "arg2", description = "Name of the key for the second argument.")
			String arg2,
			@AConQATAttribute(name = "result", description = "Name of the key for the result.")
			String result) {

		this.resultKey = result;
		this.argument1Key = arg1;
		this.argument2Key = arg2;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		NodeUtils.addToDisplayList(root, resultKey);
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) {
		double arg1 = getDoubleValue(node, argument1Key);
		double arg2 = getDoubleValue(node, argument2Key);

		// propagate non-standard doubles as NaN
		if (Double.isNaN(arg1) || Double.isNaN(arg2) || Double.isInfinite(arg1)
				|| Double.isInfinite(arg2)) {
			node.setValue(resultKey, Double.NaN);
		} else {
			node.setValue(resultKey, calculate(arg1, arg2));
		}
	}

	/**
	 * Performs the actual calculation on the numbers provided. The method may
	 * also return {@link Double#NaN} or infinity in case of errors, however the arguments are
	 * guaranteed to be "normal" doubles.
	 */
	protected abstract double calculate(double arg1, double arg2);

	/**
	 * Obtains the double stored at the given key. Returns {@link Double#NaN} if
	 * value is null or not a number.
	 */
	private double getDoubleValue(IConQATNode node, String key) {
		Object o = node.getValue(key);
		if (!(o instanceof Number)) {
			return Double.NaN;
		}
		return ((Number) o).doubleValue();
	}

}
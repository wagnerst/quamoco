/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.archgraph
 |                                                                       |
   $Id: PaintableEdge.java 20949 2009-03-27 13:44:54Z kanis $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.archgraph;

import static edu.tum.cs.conqat.archgraph.Style.ARROW_BARB;
import static edu.tum.cs.conqat.archgraph.Style.ARROW_PHI;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.GeneralPath;

import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * An edge that can be painted by {@link LayoutedGraphRenderer}.
 * 
 * @author kanis
 * @author $Author: kanis $
 * @version $Rev: 20949 $
 * @levd.rating YELLOW Rev: 20949
 */
public class PaintableEdge {

	/** The start point. */
	private final PaintableVertex source;

	/** The end point. */
	private final PaintableVertex dest;

	/** The assessment result for the edge. */
	private final Color color;

	/** Constructor. */
	public PaintableEdge(PaintableVertex source, PaintableVertex dest,
			Color color) {
		this.color = color;
		this.dest = dest;
		this.source = source;
	}

	/** Paints the vertex to the given {@link Graphics2D} context. */
	public void paint(Graphics2D graphics) {
		graphics.setColor(color);
		graphics.setStroke(new BasicStroke(Style.LINE_WIDTH));

		Point startPoint = source.getChopboxAnchor(dest.getCenter());
		Point endPoint = dest.getChopboxAnchor(source.getCenter());

		// shorten the line a bit, so the arrow doesn't look ugly (==>=)
		double theta = Math.atan2(endPoint.y - startPoint.y, endPoint.x
				- startPoint.x);
		int x = (int) (endPoint.x + ARROW_BARB * 0.5
				* Math.cos(theta + Math.PI));
		int y = (int) (endPoint.y + ARROW_BARB * 0.5
				* Math.sin(theta + Math.PI));

		// two connections are possible at max, because no two connections can
		// have the same source and direction at the same time
		if (getConnectionCount() == 1) {
			graphics.drawLine(startPoint.x, startPoint.y, x, y);
			graphics.fill(getArrowHead(startPoint, endPoint));
		} else {
			// add a bend to the line if there's a reverse connection
			double alpha = Math.PI * 0.5 + theta;

			// middle point between start and end point
			x = (endPoint.x - startPoint.x) / 2 + startPoint.x;
			y = (endPoint.y - startPoint.y) / 2 + startPoint.y;

			// add a point 7 px upright to the connection line
			x += 7 * Math.cos(alpha);
			y += 7 * Math.sin(alpha);

			graphics.drawPolyline(new int[] { startPoint.x, x, endPoint.x },
					new int[] { startPoint.y, y, endPoint.y }, 3);
			graphics.fill(getArrowHead(new Point(x, y), endPoint));
		}

	}

	/** Returns a path for the barb at the end of an edge. */
	private GeneralPath getArrowHead(Point p1, Point p2) {
		double theta = Math.atan2(p2.y - p1.y, p2.x - p1.x);

		GeneralPath path = new GeneralPath();

		// Add an arrow head at p2
		double x = p2.x + ARROW_BARB * Math.cos(theta + Math.PI - ARROW_PHI);
		double y = p2.y + ARROW_BARB * Math.sin(theta + Math.PI - ARROW_PHI);
		path.moveTo((float) x, (float) y);
		path.lineTo(p2.x, p2.y);
		x = p2.x + ARROW_BARB * Math.cos(theta + Math.PI + ARROW_PHI);
		y = p2.y + ARROW_BARB * Math.sin(theta + Math.PI + ARROW_PHI);
		path.lineTo((float) x, (float) y);

		return path;
	}

	/**
	 * Returns the total amount of connections between this connection's source
	 * and target.
	 */
	private int getConnectionCount() {
		int connections = 1;

		// it seems there is no way of getting the edges of
		// ConQATGraphInnerNodes, so we can only bend connections for
		// ConQATVertex
		if ((source.getModel() instanceof ConQATVertex)
				&& (dest.getModel() instanceof ConQATVertex)) {

			for (Object obj : ((ConQATVertex) source.getModel()).getInEdges()) {
				if (((DirectedSparseEdge) obj).getSource() == dest.getModel()) {
					connections++;
				}
			}
		}

		return connections;
	}
}

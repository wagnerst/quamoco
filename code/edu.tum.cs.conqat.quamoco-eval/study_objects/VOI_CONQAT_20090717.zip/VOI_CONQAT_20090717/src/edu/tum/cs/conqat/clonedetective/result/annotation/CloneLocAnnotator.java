/*--------------------------------------------------------------------------+
   $Id: CloneLocAnnotator.java 16957 2008-07-04 15:21:40Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.List;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.regions.Region;
import edu.tum.cs.conqat.filesystem.regions.RegionSet;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Annotates an element with the number of LOC that are part of at least one
 * clone.
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * 
 * @version $Revision: 16957 $
 * @levd.rating GREEN Rev: 16957
 */
@AConQATProcessor(description = "Computes the number of lines of code of a class that are part of at "
		+ "least one clone.")
public class CloneLocAnnotator extends CloneAnnotatorBase {

	/** Key which is used to store the Clone LoC value. */
	@AConQATKey(description = "Key that stores clone LoC value", type = "java.lang.Double")
	public final static String CLONE_LOC_KEY = "Clone LoC";

	/** Makes CLONE_LOC_KEY visible */
	@Override
	protected String[] getKeys() {
		return new String[] { CLONE_LOC_KEY };
	}

	/** Annotates CloneLoc metric at element */
	@Override
	protected void annotateClones(IFileSystemElement element,
			UnmodifiableList<IClone> clonesList) {
		element.setValue(CLONE_LOC_KEY, calcCloneLoc(clonesList));
	}

	/**
	 * Computes the lines of code of an element that are covered by at least one
	 * clone. This corresponds to the non-overlapping sum of the length of the
	 * clones annotated to this class.
	 */
	private int calcCloneLoc(List<IClone> clones) {
		RegionSet regions = new RegionSet("clones");

		for (IClone clone : clones) {
			Region region = new Region(clone.getStartLineInFile(), clone
					.getStartLineInFile()
					+ clone.getLengthInFile() - 1, "clone");
			regions.add(region);
		}

		return regions.getPositionCount();
	}

}

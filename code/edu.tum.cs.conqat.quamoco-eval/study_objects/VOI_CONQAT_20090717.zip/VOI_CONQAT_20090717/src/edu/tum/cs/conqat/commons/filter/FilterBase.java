/*--------------------------------------------------------------------------+
   $Id: FilterBase.java 18139 2009-01-19 16:56:19Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.filter;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for filters, which are processors pruning
 * {@link IRemovableConQATNode} trees.
 * 
 * @author Benjamin Hummel
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 18139 $
 * @levd.rating GREEN Rev: 18139
 * 
 * @param <N>
 *            the type of node being filtered.
 */
public abstract class FilterBase<N extends IRemovableConQATNode> extends
		ConQATPipelineProcessorBase<N> {

	/** Flag that determines whether filter is inverted */
	private boolean invert = false;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "invert", description = "If set to true, filter is inverted.", minOccurrences = 0, maxOccurrences = 1)
	public void setInvert(
			@AConQATAttribute(name = "value", description = "Default: false") boolean invert) {
		this.invert = invert;
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(N input) throws ConQATException {
		preProcessInput(input);
		filterNodes(input);
	}

	/**
	 * Template method for pre processing the input before filtering. Default
	 * implementation does nothing.
	 */
	@SuppressWarnings("unused")
	protected void preProcessInput(N input) throws ConQATException {
		// nothing to do
	}

	/**
	 * This method traverses the {@link IRemovableConQATNode} tree depth first,
	 * possibly removing elements.
	 */
	@SuppressWarnings("unchecked")
	private void filterNodes(N node) throws ConQATException {
		if (node.hasChildren()) {
			for (IRemovableConQATNode child : NodeUtils
					.getRemovableSortedChildren(node)) {
				filterNodes((N) child);
			}
		}

		boolean filtered = isFiltered(node);
		if (invert) {
			filtered = !filtered;
		}
		if (filtered) {
			node.remove();
		}
	}

	/**
	 * If this returns true, the provided node will not be included in the
	 * result (i.e. filtered away).
	 */
	protected abstract boolean isFiltered(N node) throws ConQATException;
}
/*--------------------------------------------------------------------------+
   $Id: GraphConcentrator.java 22009 2009-07-16 08:26:01Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.concentrate;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.collections.TwoDimHashMap;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphInnerNode;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.tum.cs.conqat.graph.nodes.DeepCloneCopyAction;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * This processor concentrates a graph, i.e. it collapses leaves and infers
 * edges for the collapsed graph.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 22009 $
 * @levd.rating RED Rev: 
 */
@AConQATProcessor(description = "This processor concentrates a ConQATGraph by folding all vertices "
		+ "of an inner node into a single vertex and combining edges accordingly. Optionally an "
		+ "assessment which is present at the edges can be combined for the new edge.")
public class GraphConcentrator extends ConQATPipelineProcessorBase<ConQATGraph> {

	/** Key that is used for storing the original edges */
	@AConQATKey(description = "Maps from edges in concentrated graph to list of original edges (before concentration)", type = "java.util.List<String>")
	public static final String ORIGINAL_EDGES_KEY = "original edges";

	/** Flag that determines whether the original edges get stored */
	private boolean storeOriginalEdges = false;

	/** Extension used to prolong the id. */
	public static final String EXT = "_";

	/** The key to read the assessment from. */
	private String assessmentKey = null;

	/** Storage for the new edges (with assessment). */
	private final TwoDimHashMap<String, String, Assessment> newEdgeAssessments = new TwoDimHashMap<String, String, Assessment>();

	/** Storage for the new edges (with assessment). */
	private final TwoDimHashMap<String, String, List<String>> newEdgeOriginalEdges = new TwoDimHashMap<String, String, List<String>>();

	/** Stores old edges to be able to copy values to new edges */
	private final TwoDimHashMap<String, String, DirectedSparseEdge> oldEdges = new TwoDimHashMap<String, String, DirectedSparseEdge>();

	/** Flag for loop filtering. */
	private boolean loopsFilter = true;

	/** Set the assessment key. */
	@AConQATParameter(name = "assessment", maxOccurrences = 1, description = ""
			+ "The key to read the assessment from. If not key is given, no assessment is created for the edges.")
	public void setAssessmentKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC) String key) {
		assessmentKey = key;
	}

	/** Set the assessment key. */
	@AConQATParameter(name = "loops", maxOccurrences = 1, description = ""
			+ "Filter self-loops [true]")
	public void setLoopsFilter(
			@AConQATAttribute(name = "filter", description = "Enable/disable loop filter") boolean loopsFilter) {
		this.loopsFilter = loopsFilter;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "original-edges", description = "Flag that determines whether original edges are stored")
	public void setStoreOriginalEdges(
			@AConQATAttribute(name = "store", description = "Flag that determines whether original edges are stored") boolean storeOriginalEdges) {
		this.storeOriginalEdges = storeOriginalEdges;
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) throws ConQATException {
		calculateNewEdges(graph);
		discardEmptyInnerNodes(graph);
		createRepresentativeNodes(graph, graph);
		insertNewEdges(graph);

		getLogger().info(
				"Concentrated graph has " + graph.getVertices().size()
						+ " vertices and " + graph.getEdges().size()
						+ " edges.");
	}

	/** Calculates the new edges for the graph. */
	private void calculateNewEdges(ConQATGraph graph) {
		for (DirectedSparseEdge edge : graph.getEdges()) {
			ConQATVertex source = (ConQATVertex) edge.getSource();
			ConQATVertex dest = (ConQATVertex) edge.getDest();
			insertEdge(source.getParent().getId(), dest.getParent().getId(),
					edge);
		}
	}

	/**
	 * Inserts an edge between the given nodes (if it does not already exist)
	 * and handles merging the assessment (if required).
	 */
	private void insertEdge(String sourceID, String targetID,
			DirectedSparseEdge originalEdge) {

		if (loopsFilter && sourceID.equals(targetID)) {
			return;
		}

		// deal with assessment
		if (assessmentKey == null) {
			newEdgeAssessments.putValue(sourceID, targetID, null);
		} else {
			Assessment origAssessment = (Assessment) originalEdge
					.getUserDatum(assessmentKey);
			if (origAssessment == null) {
				origAssessment = new Assessment();
			}

			Assessment newAssessment = newEdgeAssessments.getValue(sourceID,
					targetID);
			if (newAssessment == null) {
				newEdgeAssessments.putValue(sourceID, targetID, origAssessment);
			} else {
				newAssessment.add(origAssessment);
			}
		}

		// store originalEdge
		if (storeOriginalEdges) {
			addOriginalEdge(sourceID, targetID, originalEdge);
		}
	}

	/** Stores an original edge. */
	private void addOriginalEdge(String sourceID, String targetID,
			DirectedSparseEdge originalEdge) {
		// make sure that list for this synthesized edge exists
		if (newEdgeOriginalEdges.getValue(sourceID, targetID) == null) {
			newEdgeOriginalEdges.putValue(sourceID, targetID,
					new ArrayList<String>());
		}
		List<String> originalEdges = newEdgeOriginalEdges.getValue(sourceID,
				targetID);

		// add original edge to list
		String originalSource = ((ConQATVertex) originalEdge.getSource())
				.getId();
		String originalDest = ((ConQATVertex) originalEdge.getDest()).getId();
		originalEdges.add(originalSource + " -> " + originalDest);

		oldEdges.putValue(sourceID, targetID, originalEdge);
	}

	/** Removes all empty inner nodes. */
	private void discardEmptyInnerNodes(ConQATGraphInnerNode node) {
		if (!node.hasChildren()) {
			node.remove();
		} else {
			for (ConQATGraphInnerNode child : new ArrayList<ConQATGraphInnerNode>(
					node.getInnerNodes())) {
				discardEmptyInnerNodes(child);
			}
		}
	}

	/** Creates the representative nodes for all graphs having vertices. */
	private void createRepresentativeNodes(ConQATGraphInnerNode node,
			ConQATGraph graph) throws ConQATException {
		// erase child vertices
		boolean createRep = !node.getChildVertices().isEmpty();
		for (ConQATVertex vertex : new ArrayList<ConQATVertex>(node
				.getChildVertices())) {
			vertex.remove();
		}

		// handle children
		for (ConQATGraphInnerNode child : new ArrayList<ConQATGraphInnerNode>(
				node.getInnerNodes())) {
			createRepresentativeNodes(child, graph);
		}

		// create representative if needed
		if (createRep) {
			ConQATGraphInnerNode parent = node.getParent();
			ConQATVertex vertex = null;
			if (node.hasChildren() || parent == null) {
				vertex = graph.createVertex(extendedName(node.getId()),
						extendedName(node.getName()), node);
			} else {
				node.remove();
				vertex = graph.createVertex(extendedName(node.getId()), node
						.getName(), parent);
			}

			NodeUtils.copyValues(NodeUtils.getDisplayList(graph), node, vertex);
		}
	}

	/** Inserts all new edges into the graph. */
	private void insertNewEdges(ConQATGraph graph) {
		for (String source : newEdgeAssessments.getFirstKeys()) {
			for (String target : newEdgeAssessments.getSecondKeys(source)) {
				DirectedSparseEdge edge = graph.addEdge(graph
						.getVertexByID(extendedName(source)), graph
						.getVertexByID(extendedName(target)));
				if (assessmentKey != null) {
					edge.addUserDatum(assessmentKey, newEdgeAssessments
							.getValue(source, target), DeepCloneCopyAction
							.getInstance());
				}
				if (storeOriginalEdges) {
					edge.addUserDatum(ORIGINAL_EDGES_KEY, newEdgeOriginalEdges
							.getValue(source, target), DeepCloneCopyAction
							.getInstance());
				}

				DirectedSparseEdge oldEdge = oldEdges.getValue(source, target);
				// TODO (FD): oldEdge can be null
				List<String> keyList = NodeUtils.getDisplayList(graph);
				for (String key : keyList) {
					Object value = oldEdge.getUserDatum(key);
					if (value != null) {
						edge.setUserDatum(key, value, DeepCloneCopyAction
								.getInstance());
					}
				}
			}
		}
	}

	/** Create extended name for a vertex name */
	public static String extendedName(String name) {
		return name + EXT;
	}

}

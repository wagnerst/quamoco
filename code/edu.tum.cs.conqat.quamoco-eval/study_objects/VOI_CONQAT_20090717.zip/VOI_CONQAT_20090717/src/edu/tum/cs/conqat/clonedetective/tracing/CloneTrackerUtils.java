package edu.tum.cs.conqat.clonedetective.tracing;

import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.clonedetective.core.IKeyValueStore;
import edu.tum.cs.conqat.clonedetective.core.IUnit;

/**
 * Utility functions that allow storage and retrieval of values computed during
 * clone tracking.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 22025 $
 * @levd.rating RED Rev:
 */
public class CloneTrackerUtils {

	/** Key under which has ancestor flag is stored */
	public static final String HAS_ANCESTOR = "has_ancestor";

	/** Key under which has successor flag is stored */
	public static final String HAS_SUCCESSOR = "has_successor";

	/** Key under which ghost flag is stored */
	public static final String GHOST = "ghost";

	/** Key under which ghost flag is stored */
	public static final String ANCESTOR_ID = "ancestor_id";

	/** Key under which fingerprint changed flag is stored */
	public static final String FINGERPRINT_CHANGED = "fingerprint_changed";

	/** Key under which fuzzy match flag is stored */
	public static final String FUZZY_MATCH = "fuzzy_match";

	/** Key under which position changed flag is stored */
	public static final String POSITION_CHANGED = "position_changed";

	/** Key under which start line of clone before update is stored */
	public static final String ORIGINAL_START_LINE = "original_start_line";

	/** Key under which last line of clone before update is stored */
	public static final String ORIGINAL_LAST_LINE = "original_last_line";

	/** Key under which list of units is stored */
	public static final String UNIT_LIST = "unit_list";

	/** Key under which deleted flag is stored */
	public static final String TOO_SHORT = "too_short";

	/** Key under which covered flag is stored */
	private static final String COVERED = "covered";

	/** Value used to denote that no ancestor id is stored */
	private static final int NO_ANCESTOR_ID = -1;

	/** Set has ancestor flag */
	public static void setHasAncestor(IClone clone, boolean ancestor) {
		clone.setValue(HAS_ANCESTOR, ancestor);
	}

	/** Returns has ancestor flag, or false, if none was found */
	public static boolean getHasAncestor(IClone clone) {
		return booleanFor(clone, HAS_ANCESTOR);
	}

	/** Set has successor flag */
	public static void setHasSuccessor(IClone clone, boolean successor) {
		clone.setValue(HAS_SUCCESSOR, successor);
	}

	/** Returns has successor flag, or false, if none was found */
	public static boolean getHasSuccessor(IClone clone) {
		return booleanFor(clone, HAS_SUCCESSOR);
	}

	/** Set ghost flag */
	public static void setGhost(IClone clone, boolean ghost) {
		clone.setValue(GHOST, ghost);
	}

	/** Returns ghost flag, or false, if none was found */
	public static boolean getGhost(IClone clone) {
		return booleanFor(clone, GHOST);
	}

	/** Set unique id of ancestor */
	public static void setAncestorId(IClone clone, int ancestorId) {
		clone.setValue(ANCESTOR_ID, ancestorId);
	}

	/** Returns true, if an ancestor id is stored for a clone */
	public static boolean hasAncestorId(IClone clone) {
		return getAncestorId(clone) != NO_ANCESTOR_ID;
	}

	/** Returns unique id of ancestor, or null, if none was found */
	public static int getAncestorId(IClone clone) {
		if (clone.containsValue(ANCESTOR_ID)) {
			return intFor(clone, ANCESTOR_ID);
		}
		return NO_ANCESTOR_ID;
	}

	/** Set fingerprint changed flag */
	public static void setFingerprintChanged(IClone clone,
			boolean fingerprintChanged) {
		clone.setValue(FINGERPRINT_CHANGED, fingerprintChanged);
	}

	/** Returns fingerprint changed flag, or false, if none was found */
	public static boolean getFingerprintChanged(IClone clone) {
		return booleanFor(clone, FINGERPRINT_CHANGED);
	}

	/** Set fuzzy match flag */
	public static void setFuzzyMatch(IClone clone, boolean fuzzyMatch) {
		clone.setValue(FUZZY_MATCH, fuzzyMatch);
	}

	/** Returns fuzzy match flag, or false, it none was found */
	public static boolean getFuzzyMatch(IClone clone) {
		return booleanFor(clone, FUZZY_MATCH);
	}

	/** Set position changed flag */
	public static void setPositionChanged(IClone clone, boolean positionChanged) {
		clone.setValue(POSITION_CHANGED, positionChanged);
	}

	/** Returns position changed flag, or false, if none was found */
	public static boolean getPositionChanged(IClone clone) {
		return booleanFor(clone, POSITION_CHANGED);
	}

	/** Set original start line */
	public static void setOriginalStartLine(IClone clone, int originalStartLine) {
		clone.setValue(ORIGINAL_START_LINE, originalStartLine);
	}

	/** Returns original start line, or -1, if none was found */
	public static int getOriginalStartLine(IClone clone) {
		return intFor(clone, ORIGINAL_START_LINE);
	}

	/** Set original start line */
	public static void setOriginalLastLine(IClone clone, int originalLastLine) {
		clone.setValue(ORIGINAL_LAST_LINE, originalLastLine);
	}

	/** Returns original last line, or -1, if none was found */
	public static int getOriginalLastLine(IClone clone) {
		return intFor(clone, ORIGINAL_LAST_LINE);
	}

	/** Get boolean value stored at clone */
	private static boolean booleanFor(IKeyValueStore clone, String key) {
		if (clone.containsValue(key)) {
			return Boolean.valueOf(clone.getValue(key).toString());
		}
		return false;
	}

	/** Get int value stored at clone */
	private static int intFor(IClone clone, String key) {
		if (clone.containsValue(key)) {
			return Integer.valueOf(clone.getValue(key).toString());
		}
		return -1;
	}

	/** Return list of clone units, or <code>null</code>, if no list was stored */
	@SuppressWarnings("unchecked")
	public static List<IUnit> getUnits(IClone clone) {
		return (List<IUnit>) clone.getValue(UNIT_LIST);
	}

	/** Store list of units at a clone */
	public static void setUnits(IClone clone, List<IUnit> cloneUnits) {
		clone.setValue(UNIT_LIST, cloneUnits);
		clone.setTransient(UNIT_LIST, true);
	}

	/** Set deleted flag */
	public static void setTooShort(CloneClass cloneClass, boolean value) {
		cloneClass.setValue(TOO_SHORT, value);
	}

	/** Get deleted flag */
	public static boolean getTooShort(CloneClass cloneClass) {
		return booleanFor(cloneClass, TOO_SHORT);
	}

	/** Get covered flag */
	public static boolean getCovered(IClone clone) {
		return booleanFor(clone, COVERED);
	}

	/** Set covered flag */
	public static void setCovered(IClone clone, boolean value) {
		clone.setValue(COVERED, value);
	}

	/** Returns true, if the {@link CloneClass} contains at least one ghost */
	public static boolean containsGhost(CloneClass cloneClass) {
		for (IClone clone : cloneClass.getClones()) {
			if (getGhost(clone)) {
				return true;
			}
		}
		return false;
	}

	/** Returns true, if all clones in the clone class are marked as covered */
	public static boolean allCovered(CloneClass cloneClass) {
		for (IClone clone : cloneClass.getClones()) {
			if (!CloneTrackerUtils.getCovered(clone)) {
				return false;
			}
		}
		return true;
	}

}

package edu.tum.cs.conqat.database;

import java.sql.Connection;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;

/**
 * Base class for processors that work on a database table.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 21520 $
 * @levd.rating YELLOW Rev: 21520
 */
public abstract class DatabaseProcessorBase extends ConQATProcessorBase {

	/** Database connection. */
	protected Connection dbConnection;

	/** Name of the database table. */
	protected String tableName;

	/** Set database details. */
	@AConQATParameter(name = "database", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Describes the database and table used for storing the value.")
	public void setTable(
			@AConQATAttribute(name = "connection", description = "Database connection.") Connection dbConnection,
			@AConQATAttribute(name = "table", description = "The name of the table.") String tableName) {
		this.dbConnection = dbConnection;
		this.tableName = tableName;
	}

}
package edu.tum.cs.conqat.architecture.graph;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.collections.TwoDimHashMap;
import edu.tum.cs.conqat.architecture.scope.DependencyPolicy;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.graph.concentrate.GraphConcentrator;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphInnerNode;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;
import edu.tum.cs.conqat.graph.nodes.DeepCloneCopyAction;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;

/**
 * {@ConQAT.doc}
 * 
 * @author Elmar Juergens
 * @author $Author: kanis $
 * @version $Rev: 20950 $
 * @levd.rating YELLOW Rev: 20950
 */
@AConQATProcessor(description = "Adds policies from the architecture specification "
		+ "that are not necessary w.r.t. the dependencies actually present in the system "
		+ "to the architecture graph")
public class UnnecessaryPolicyAnnotator extends ArchGraphPipelineBase {

	/** Key for reference to proxy component. */
	public static final String PROXY_KEY = "proxy";

	/** Key for reference to proxied component. */
	public static final String PROXY_FOR_KEY = "proxyfor";

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) {
		TwoDimHashMap<String, String, DirectedSparseEdge> existingEdges = initExistingEdgesMap(graph);

		List<DependencyPolicy> policies = new ArrayList<DependencyPolicy>();
		arch.collectPolicies(policies);

		for (DependencyPolicy policy : policies) {
			String sourceCompName = policy.getSource().getName();
			String targetCompName = policy.getTarget().getName();
			if (noEdgeInGraph(existingEdges, sourceCompName, targetCompName)) {
				addEdgeForPolicy(graph, policy, sourceCompName, targetCompName);
			}
		}
	}

	/** Create a map containing existing edges */
	private TwoDimHashMap<String, String, DirectedSparseEdge> initExistingEdgesMap(
			ConQATGraph graph) {
		TwoDimHashMap<String, String, DirectedSparseEdge> existingEdges = new TwoDimHashMap<String, String, DirectedSparseEdge>();

		for (DirectedSparseEdge edge : graph.getEdges()) {
			String sourceCompName = graph.getVertexId(edge.getSource());
			String targetCompName = graph.getVertexId(edge.getDest());
			existingEdges.putValue(sourceCompName, targetCompName, edge);
		}

		return existingEdges;
	}

	/**
	 * Returns true, if no edge from a source to a target component exists in
	 * the graph
	 */
	private boolean noEdgeInGraph(
			TwoDimHashMap<String, String, DirectedSparseEdge> existingEdges,
			String sourceCompName, String targetCompName) {
		// we perform two checks, since the GraphConcentrator appends an
		// extension to nodes that have been concentrated.
		// However, we don't know whether concentration took place
		return !existingEdges.containsKey(sourceCompName, targetCompName)
				&& !existingEdges.containsKey(GraphConcentrator
						.extendedName(sourceCompName), GraphConcentrator
						.extendedName(targetCompName));
	}

	/**
	 * Insert an edge into the graph for a policy that is not backed up by
	 * dependencies.
	 */
	private void addEdgeForPolicy(ConQATGraph graph, DependencyPolicy policy,
			String sourceCompName, String targetCompName) {
		ConQATVertex sourceVertex = resolveVertex(graph, sourceCompName);
		ConQATVertex targetVertex = resolveVertex(graph, targetCompName);

		if (sourceVertex != null && targetVertex != null) {
			DirectedSparseEdge edge = graph.addEdge(sourceVertex, targetVertex);
			edge.addUserDatum(ArchitectureEdgeAssessor.POLICY_TYPE_KEY, policy
					.getPolicyType(), DeepCloneCopyAction.getInstance());
		}
	}

	/**
	 * Resolve {@link ConQATVertex} for a component. For
	 * {@link ConQATGraphInnerNode}s this creates and returns a proxy object,
	 * because there can not be connections with an end being an inner node.
	 * <p>
	 * The name and id of the proxy are the name of it's "parent", suffixed with
	 * an underscore.
	 */
	private ConQATVertex resolveVertex(ConQATGraph graph, String compName) {
		// do a lookup with the given name as is
		ConQATVertex result = graph.getVertexByID(compName);

		// do a lookup with the name extended by "_"
		if (result == null) {
			result = graph.getVertexByID(GraphConcentrator
					.extendedName(compName));
		}

		return result;
	}
}

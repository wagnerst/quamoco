package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import edu.tum.cs.commons.reflect.TypeConversionException;
import edu.tum.cs.conqat.clonedetective.core.IKeyValueStore;
import edu.tum.cs.conqat.clonedetective.core.LazyKeyValueStoreBase;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Gateway for {@link IKeyValueStore}s.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 22025 $
 * @levd.rating RED Rev:
 */
public class KeyValueGateway extends DatabaseBase {

	/**  */
	private static final String STORE_ID = "STORE_ID";
	/**  */
	private static final String KEY = "KEY";
	/**  */
	private static final String VALUE = "VALUE";
	/**  */
	private static final String TYPE = "TYPE";

	/** Constructor */
	protected KeyValueGateway(Connection dbConnection, String tableName) {
		super(dbConnection, tableName);
	}

	/** {@inheritDoc} */
	@Override
	protected String createCreateTableString() {
		StringBuilder result = new StringBuilder();
		result.append("CREATE TABLE " + tableName);
		result.append(" (" + STORE_ID + " INT, " + KEY + " VARCHAR, " + VALUE
				+ " VARCHAR, " + TYPE + " VARCHAR" + ");");
		return result.toString();
	}

	/** Store values in database */
	public void store(IKeyValueStore store) throws SQLException,
			ConQATException {
		Statement stmt = dbConnection.createStatement();
		createBatch(store, stmt);
		DatabaseUtils.executeStatement(stmt);
	}

	/** Create batch insert statements and add them to stmt */
	public void createBatch(IKeyValueStore store, Statement stmt)
			throws SQLException {
		for (String key : store.getKeyList()) {
			if (!store.getTransient(key)) {
				stmt.addBatch(createInsertValueSql(store.getId(), key, store
						.getValue(key)));
			}
		}
	}

	/** Create SQL string to insert a clone class into the database */
	public String createInsertValueSql(int storeId, String key, Object value) {
		StringBuilder result = new StringBuilder();
		result.append("INSERT INTO " + tableName + " (");

		result.append(STORE_ID);
		result.append(", " + KEY);
		result.append(", " + VALUE);
		result.append(", " + TYPE);

		result.append(") VALUES (");

		result.append("'" + storeId + "'");
		result.append(", '" + key + "'");
		result.append(", '" + value + "'");
		result.append(", '" + value.getClass().getName() + "'");

		result.append(")");
		return result.toString();
	}

	/** Select all clones classes of a timestamp from the database */
	public void loadValuesInto(LazyKeyValueStoreBase store) throws SQLException {

		ResultSet result = DatabaseUtils.executeQuery(dbConnection,
				createSelectValues(store.getId()));

		while (result.next()) {
			String key = result.getString(KEY);
			String valueString = result.getString(VALUE);
			String type = result.getString(TYPE);
			try {
				store.setValue(key, valueString, type);
			} catch (ClassNotFoundException e) {
				throwAssertionError(valueString, type, e);
			} catch (TypeConversionException e) {
				throwAssertionError(valueString, type, e);
			}
		}
	}

	/**
	 * Throw assertion error indicating type conversion problem. We use an
	 * assertion error here, since this problem only ocurrs if the storage
	 * contains a bug.
	 */
	private void throwAssertionError(String valueString, String type,
			Throwable t) throws AssertionError {
		throw new AssertionError("Problems converting '" + valueString
				+ "' into type '" + type + "':" + t.getMessage());
	}

	/** Creates SQL string to select clone classes for a timestamp */
	private String createSelectValues(int storeId) {
		StringBuilder result = new StringBuilder();
		result.append("SELECT * from " + tableName);
		result.append(" WHERE " + STORE_ID + " = '" + storeId + "'");
		return result.toString();
	}

}

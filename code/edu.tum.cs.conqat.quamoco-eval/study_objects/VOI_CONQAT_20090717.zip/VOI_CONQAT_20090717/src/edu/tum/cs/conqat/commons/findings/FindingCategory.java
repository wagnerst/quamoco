/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingCategory.java 21887 2009-07-10 15:06:10Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.Collection;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.collections.IdentityHashSet;
import edu.tum.cs.conqat.commons.findings.location.ELocationType;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * A finding category collects finding groupd from the same context (often the
 * same detection tool). All {@link FindingGroup}s and {@link Finding}s
 * contained share the same {@link EFindingType}.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21887 $
 * @levd.rating YELLOW Rev: 21887
 */
public class FindingCategory extends ConQATNodeBase implements
		IRemovableConQATNode {

	/** The finding groups in this category. */
	private final Collection<FindingGroup> findingGroups = new IdentityHashSet<FindingGroup>();

	/** The report this belongs to. */
	private final FindingReport report;

	/** The name of this category. */
	private final String name;

	/** The finding type for this category. */
	private final EFindingType findingType;

	/** The location type for this category. */
	private final ELocationType locationType;

	/** Hidden constructor. Use factory method in {@link FindingReport} instead. */
	/* package */FindingCategory(FindingReport report, String name,
			EFindingType findingType, ELocationType locationType) {
		this.report = report;
		this.name = name;
		this.findingType = findingType;
		this.locationType = locationType;
	}

	/** Copy constructor. */
	/* package */FindingCategory(FindingCategory other,
			FindingReport findingReport) throws DeepCloneException {
		super(other);
		this.report = findingReport;
		this.name = other.name;
		this.findingType = other.findingType;
		this.locationType = other.locationType;
		for (FindingGroup group : other.findingGroups) {
			findingGroups.add(new FindingGroup(group, this));
		}
	}

	/** {@inheritDoc} */
	public String getName() {
		return name;
	}

	/** Returns the finding type of this category. */
	public EFindingType getFindingType() {
		return findingType;
	}

	/** Returns the location type of this category. */
	public ELocationType getLocationType() {
		return locationType;
	}

	/**
	 * Creates a new finding group with the given description. The description
	 * should be unique within this category.
	 */
	public FindingGroup createFindingGroup(String description) {
		FindingGroup findingGroup = new FindingGroup(description, this);
		findingGroups.add(findingGroup);
		return findingGroup;
	}

	/** {@inheritDoc} */
	public FindingGroup[] getChildren() {
		return findingGroups.toArray(new FindingGroup[findingGroups.size()]);
	}

	/** {@inheritDoc} */
	public void remove() {
		report.remove(this);
	}

	/** {@inheritDoc} */
	public String getId() {
		return name;
	}

	/** {@inheritDoc} */
	public FindingReport getParent() {
		return report;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !findingGroups.isEmpty();
	}

	/** Removes the given finding group from the category. */
	/* package */void remove(FindingGroup findingGroup) {
		findingGroups.remove(findingGroup);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Throws an exception as we do not support cloning at this level.
	 */
	public IRemovableConQATNode deepClone() {
		throw new UnsupportedOperationException(
				"Deep cloning not supported at this level.");
	}
}

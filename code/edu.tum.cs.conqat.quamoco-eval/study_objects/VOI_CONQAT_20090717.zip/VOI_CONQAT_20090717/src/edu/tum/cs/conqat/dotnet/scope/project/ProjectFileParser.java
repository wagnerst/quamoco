/*--------------------------------------------------------------------------+
   $Id: ProjectFileParser.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.project;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import edu.tum.cs.commons.xml.IXMLElementProcessor;
import edu.tum.cs.commons.xml.XMLReader;
import edu.tum.cs.commons.xml.XMLResolver;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.scope.solution.SolutionFileParser.EFormatVersion;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;

/**
 * Base class for parsers of VS.NET project files.
 * <p>
 * Since different versions of the Visual Studio generate different project file
 * formats, different project file parsers exist. This class serves as factory
 * to create a {@link ProjectFileParser} for a specific VS.NET version.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public abstract class ProjectFileParser {

	/**
	 * Encoding that gets used for parsing of VS.NET project files, or
	 * <code>null</code>, if default encoding is to be used
	 */
	private String encoding = null;

	/** Extracts the code files that are part of the project */
	public List<String> parse(File projectFile) throws ConQATException {
		ProjectFileReaderBase reader = createReader(projectFile, encoding);
		List<String> sourceFilenames = new ArrayList<String>();
		for (String relativeSourceFilename : reader
				.readRelativeSourceFileNames()) {
			sourceFilenames.add(FileLibrary.absoluteFilenameFrom(projectFile
					.getAbsolutePath(), relativeSourceFilename));
		}
		return sourceFilenames;
	}

	/**
	 * Template factory name that returns the project-file version specific
	 * XMLReader
	 */
	protected abstract ProjectFileReaderBase createReader(File projectFile,
			String encoding);

	/** Getter */
	public String getEncoding() {
		return encoding;
	}

	/** Sets encoding of XML file. */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	/**
	 * Factory name that creates a project file reader according to the solution
	 * file version
	 */
	public static ProjectFileParser create(EFormatVersion version) {
		switch (version) {
		case VERSION_10:
			// fall through, since no relevant changes in form version 9 to 10
		case VERSION_9:
			return new ProjectFileParser9_10();
		case VERSION_8:
			return new ProjectFileParser8();
		default:
			throw new RuntimeException(
					"No reader for this project file format implemented!");
		}
	}

	/** Xml reader that performs actual XML processing. */
	protected abstract class ProjectFileReaderBase
			extends
			XMLReader<EProjectFileXmlElement, EProjectFileXmlAttribute, ConQATException> {

		/** The list of relative source filename. */
		protected final List<String> relativeSourceFilenames = new ArrayList<String>();

		/** The name of the project file */
		private final String projectFilename;

		/** Constructor */
		public ProjectFileReaderBase(File projectFile) {
			super(
					projectFile,
					encoding,
					new XMLResolver<EProjectFileXmlElement, EProjectFileXmlAttribute>(
							EProjectFileXmlAttribute.class));
			this.projectFilename = projectFile.getAbsolutePath();
		}

		/**
		 * Reads the relative names of the included code files from the project
		 * file
		 */
		public List<String> readRelativeSourceFileNames()
				throws ConQATException {
			parseProjectFile();
			processDecendantElements(createProcessor());
			return relativeSourceFilenames;
		}

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createProcessor();

		/** Parse XML file */
		private void parseProjectFile() throws ConQATException {
			try {
				parseFile();
			} catch (SAXParseException e) {
				throw new ConQATException("XML parsing exception at line "
						+ e.getLineNumber() + ", colum " + e.getColumnNumber()
						+ " (" + e.getMessage() + ")");
			} catch (SAXException e) {
				throw new ConQATException("XML parsing exception)");
			} catch (IOException e) {
				throw new ConQATException("File " + projectFilename
						+ " could not be read");
			} catch (ParserConfigurationException e) {
				throw new ConQATException("XML parser configuration error");
			}
		}
	}
}

package edu.tum.cs.conqat.clonedetective.tracing;

import edu.tum.cs.commons.algo.Diff.Delta;
import edu.tum.cs.conqat.clonedetective.core.IUnit;

/**
 * Updates region information according to edit operations to source code.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 21464 $
 * @levd.rating YELLOW Rev: 21464
 */
public class RegionTracker {

	/** Flag that indicates deletion */
	private static final int DELETED = -1;

	/** Start position */
	private int startPosition;

	/** End position */
	private int endPosition;

	/** Flag that indicates whether region was ever entirely deleted */
	private boolean deleted = false;

	/** Constructor */
	public RegionTracker(int startPosition, int endPosition) {
		this.startPosition = startPosition;
		this.endPosition = endPosition;
	}

	/** Update position to edit operations */
	public void track(Delta<IUnit> delta) {

		int oldCount = delta.getN();

		// compute position mapping
		int[] positionMap = computePositionMap(delta, oldCount);

		// update start position
		while (startPosition < oldCount - 1
				&& positionMap[startPosition] == DELETED) {
			startPosition++;
		}
		startPosition = positionMap[startPosition];

		// update end position
		while (endPosition > 1 && positionMap[endPosition] == DELETED) {
			endPosition--;
		}
		endPosition = positionMap[endPosition];

		// compute deletion
		if (startPosition == DELETED || startPosition > endPosition
				|| (startPosition == DELETED && endPosition == DELETED)) {
			deleted = true;
		}
	}

	/** Compute mapping from old to new position */
	private int[] computePositionMap(Delta<IUnit> delta, int oldCount) {

		// init position map
		int[] positionMap = new int[oldCount];
		for (int i = 0; i < oldCount; i++) {
			positionMap[i] = i;
		}

		for (int editOperation = 0; editOperation < delta.getSize(); editOperation++) {

			int editPosition = delta.getPosition(editOperation);
			if (editPosition > 0) {
				editPosition -= 1; // correct inc. of 1 of all pos. >0

				// shift right
				for (int i = 0; i < oldCount; i++) {
					int value = positionMap[i];
					if (value >= editPosition && value != DELETED) {
						positionMap[i] = value + 1;
					}
				}

			} else {
				editPosition = Math.abs(editPosition);
				editPosition -= 1;

				// mark deleted
				positionMap[editPosition] = DELETED;

				// shift all positions behind to the left
				for (int i = editPosition + 1; i < oldCount; i++) {
					int value = positionMap[i];
					if (value != DELETED) {
						positionMap[i] = value - 1;
					}
				}
			}
		}

		return positionMap;
	}

	/** Get updated start position */
	public int getStartPosition() {
		return startPosition;
	}

	/** Get updated end position */
	public int getEndPosition() {
		return endPosition;
	}

	/** Gets whether region has been deleted */
	public boolean getDeleted() {
		return deleted;
	}

}

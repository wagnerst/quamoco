/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: EFindingAttributes.java 22035 2009-07-16 10:28:06Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/

package edu.tum.cs.conqat.commons.findings.xml;

/**
 * Names of attributes used in the finding XML format.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 22035 $
 * @levd.rating YELLOW Rev: 22035
 */
public enum EFindingAttributes {

	/** Time attribute of the finding report. */
	TIME,

	/** Name attribute. */
	NAME,

	/** Location type attribute. */
	LOCATION_TYPE,

	/** Finding type attribute. */
	FINDING_TYPE,

	/** Description attribute. */
	DESCRIPTION,

	/** Origin tool attribute. */
	ORIGIN_TOOL,

	/** File name attribute. */
	FILE,

	/** Line number attribute. */
	LINE_NUMBER,

	/** Start line number attribute. */
	START_LINE_NUMBER,

	/** End line number attribute. */
	END_LINE_NUMBER,

	/** Start position (in line) attribute. */
	START_POSITION,

	/** End position (in line) attribute. */
	END_POSITION,

	/** Key for key value pairs. */
	KEY,

	/** Value of a finding. */
	VALUE,

	/** Attribute for namespace. */
	XMLNS
}

package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.GappedClone;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Gateway for clones
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 22038 $
 * @levd.rating RED Rev:
 */
public class CloneGateway extends DatabaseBase {

	/**  */
	private static final String TIMESTAMP = "TIMESTAMP";
	/**  */
	private static final String FINGERPRINT = "FINGERPRINT";
	/**  */
	private static final String FINGERPRINT_LASTMODIFIED = "FINGERPRINT_LASTMODIFIED";
	/**  */
	private static final String LENGTH_IN_UNITS = "LENGTH_IN_UNITS";
	/**  */
	private static final String START_UNIT_INDEX_IN_FILE = "START_UNIT_INDEX_IN_FILE";
	/**  */
	private static final String LENGTH_IN_FILE = "LENGTH_IN_FILE";
	/**  */
	private static final String START_LINE_IN_FILE = "START_LINE_IN_FILE";
	/**  */
	private static final String ORIGIN = "ORIGIN";
	/**  */
	private static final String CLONE_CLASS_ID = "CLONE_CLASS_ID";
	/**  */
	private static final String BIRTH = "BIRTH";
	/**  */
	private static final String DEATH = "DEATH";

	/** Underlying {@link KeyValueGateway} */
	private final KeyValueGateway keyValueGateway;

	/** Constructor */
	protected CloneGateway(Connection dbConnection, String tableName,
			KeyValueGateway keyValueGateway) {
		super(dbConnection, tableName);
		this.keyValueGateway = keyValueGateway;
	}

	/** {@inheritDoc} */
	@Override
	protected String createCreateTableString() {
		StringBuilder result = new StringBuilder();
		result.append("CREATE TABLE " + tableName);
		result.append(" (" + ID + " INT, " + TIMESTAMP + " BIGINT, "
				+ FINGERPRINT + " VARCHAR, " + FINGERPRINT_LASTMODIFIED
				+ " BIGINT, " + LENGTH_IN_UNITS + " INT, "
				+ START_UNIT_INDEX_IN_FILE + " INT, " + LENGTH_IN_FILE
				+ " INT, " + START_LINE_IN_FILE + " INT, " + ORIGIN
				+ " VARCHAR, " + CLONE_CLASS_ID + " INT, " + BIRTH
				+ " BIGINT, " + DEATH + " BIGINT " + ");");
		return result.toString();
	}

	/**
	 * Select all clones for a timestamp. The selected clones are added to the
	 * clone classes
	 */
	public void selectClones(Date timestamp,
			Map<Integer, CloneClass> cloneClasses) throws SQLException {
		ResultSet result = DatabaseUtils.executeQuery(dbConnection,
				createSelectClonesSql(timestamp));

		while (result.next()) {
			int id = result.getInt(ID);
			String fingerPrint = result.getString(FINGERPRINT);
			Date fingerPrintLastModified = getNullDate(result,
					FINGERPRINT_LASTMODIFIED);
			int lengthInUnits = result.getInt(LENGTH_IN_UNITS);
			int startUnitIndexInFile = result.getInt(START_UNIT_INDEX_IN_FILE);
			int lengthInFile = result.getInt(LENGTH_IN_FILE);
			int startLineInFile = result.getInt(START_LINE_IN_FILE);
			String origin = result.getString(ORIGIN);
			int cloneClassId = result.getInt(CLONE_CLASS_ID);
			Date birth = getNullDate(result, BIRTH);
			Date death = getNullDate(result, DEATH);
			// TODO (EJ) Use sensible value here
			int deltaInUnits = -1;

			// TODO (EJ) Replace with isNotNull
			CCSMAssert.isFalse(birth == null, "Birth must not be null");

			CloneClass cloneClass = cloneClasses.get(cloneClassId);
			if (cloneClass == null) {
				throw new AssertionError("Clone class not found");
			}

			GappedClone clone = new GappedClone(id, cloneClass, origin,
					startLineInFile, lengthInFile, startUnitIndexInFile,
					lengthInUnits, fingerPrint, deltaInUnits);
			cloneClass.add(clone);

			clone.setBirth(birth);
			clone.setDeath(death);
			clone.setFingerprintLastModified(fingerPrintLastModified);

			// load key-value pairs
			keyValueGateway.loadValuesInto(clone);
		}

	}

	/** Reads date from result set. If no date is stored, null is returned. */
	private Date getNullDate(ResultSet result, String columnName)
			throws SQLException {
		long birthTime = result.getLong(columnName);
		if (birthTime == 0) {
			return null;
		}
		return new Date(birthTime);
	}

	/** Create SQL string to select clones from database */
	private String createSelectClonesSql(Date timestamp) {
		StringBuilder result = new StringBuilder();
		result.append("SELECT * from " + tableName);
		result.append(" WHERE TIMESTAMP = " + timestamp.getTime());
		return result.toString();
	}

	/** Store all clones in the database */
	public void storeClones(Date timestamp, List<CloneClass> cloneClasses,
			String rootOrigin) throws SQLException, ConQATException {
		Statement stmt = dbConnection.createStatement();

		for (CloneClass cloneClass : cloneClasses) {
			for (IClone clone : cloneClass.getClones()) {
				stmt
						.addBatch(createInsertCloneSql(timestamp, clone,
								rootOrigin));
				keyValueGateway.createBatch(clone, stmt);
			}
		}

		DatabaseUtils.executeStatement(stmt);
	}

	/** Create SQL string to insert clone into database */
	private String createInsertCloneSql(Date timestamp, IClone clone,
			String rootOrigin) {
		StringBuilder result = new StringBuilder();
		result.append("INSERT INTO " + tableName + " (");

		result.append(ID);
		result.append(", " + TIMESTAMP);
		result.append(", " + FINGERPRINT);
		result.append(", " + FINGERPRINT_LASTMODIFIED);
		result.append(", " + LENGTH_IN_UNITS);
		result.append(", " + START_UNIT_INDEX_IN_FILE);
		result.append(", " + LENGTH_IN_FILE);
		result.append(", " + START_LINE_IN_FILE);
		result.append(", " + ORIGIN);
		result.append(", " + CLONE_CLASS_ID);
		result.append(", " + BIRTH);
		result.append(", " + DEATH);

		result.append(") VALUES (");

		result.append(clone.getId());
		result.append(", " + timestamp.getTime());
		result.append(", '" + clone.getFingerprint() + "'");
		// TODO (EJ) Extract nulldate -> long conversion into method
		long fpLastModifiedTime = 0;
		if (clone.getFingerprintLastModified() != null) {
			fpLastModifiedTime = clone.getFingerprintLastModified().getTime();
		}
		result.append(", " + fpLastModifiedTime);
		result.append(", " + clone.getLengthInUnits());
		result.append(", " + clone.getStartUnitIndexInFile());
		result.append(", " + clone.getLengthInFile());
		result.append(", " + clone.getStartLineInFile());
		String origin = StringUtils.stripPrefix(rootOrigin, clone.getOrigin());
		result.append(", '" + origin + "'");
		result.append(", " + clone.getCloneClass().getId());
		long birthTime = 0;
		if (clone.getBirth() != null) {
			birthTime = clone.getBirth().getTime();
		}
		result.append(", " + birthTime);
		long deathTime = 0;
		if (clone.getDeath() != null) {
			deathTime = clone.getDeath().getTime();
		}
		result.append(", " + deathTime);

		result.append(")");
		return result.toString();
	}

	/** Store death information of all clones in the database */
	public void storeDeaths(Set<IClone> deletedClones) throws SQLException,
			ConQATException {
		Statement stmt = dbConnection.createStatement();

		for (IClone deletedClone : deletedClones) {
			stmt.addBatch(createUpdateCloneDeathSql(deletedClone));
		}

		DatabaseUtils.executeStatement(stmt);
	}

	/** Create SQL statement to update clone death value */
	private String createUpdateCloneDeathSql(IClone deletedClone) {
		CCSMAssert.isNotNull(deletedClone.getDeath(),
				"No death value set for clone!");
		return "Update " + tableName + " Set " + DEATH + "="
				+ deletedClone.getDeath().getTime() + " Where " + ID + "="
				+ deletedClone.getId();
	}
}

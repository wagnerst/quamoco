package edu.tum.cs.conqat.clonedetective.tracing;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import edu.tum.cs.commons.algo.Diff;
import edu.tum.cs.commons.algo.Diff.Delta;
import edu.tum.cs.conqat.clonedetective.core.IUnit;

/**
 * Oracle that resolves renames of elements
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 21465 $
 * @levd.rating RED Rev:
 */
public class FileRenameOracle {

	/** Mapping from old to new filenames */
	private final Map<String, String> nameMapping = new HashMap<String, String>();

	/** Minimal distance threshold up to which files are considered similar */
	public static final double MIN_SIMILARITY = 0.8;

	// TODO (EJ) Currently returns old name, if no new name could be found
	/** Return new element name. */
	public String newNameFor(String oldFilename) {
		if (!nameMapping.containsKey(oldFilename)) {
			return oldFilename;
		}

		return nameMapping.get(oldFilename);
	}

	/** Constructs a rename oracle from old and new unit arrays. */
	public FileRenameOracle(Map<String, IUnit[]> oldFileUnits,
			Map<String, IUnit[]> newFileUnits) {

		// copy maps
		Map<String, IUnit[]> oldFiles = new HashMap<String, IUnit[]>(
				oldFileUnits);
		Map<String, IUnit[]> newFiles = new HashMap<String, IUnit[]>(
				newFileUnits);

		// initialize mapping for names that appear in both sets
		for (String name : new HashSet<String>(oldFiles.keySet())) {
			if (newFiles.containsKey(name)) {
				nameMapping.put(name, name);
				oldFiles.remove(name);
				newFiles.remove(name);
			}
		}

		// Greedy procedure to map stuff
		for (String oldName : oldFiles.keySet()) {
			double bestSimilarity = 0;
			String bestMatch = null;
			for (String newName : new HashSet<String>(newFiles.keySet())) {
				IUnit[] oldContent = oldFiles.get(oldName);
				IUnit[] newContent = newFiles.get(newName);

				// we already matched this to another old name
				if (newContent == null) {
					continue;
				}

				Delta<IUnit> delta = Diff.computeDelta(oldContent, newContent);
				double similarity = 1 - ((double) delta.getSize() / (oldContent.length + newContent.length));

				if (similarity > bestSimilarity) {
					bestSimilarity = similarity;
					bestMatch = newName;
				}
			}

			if (bestSimilarity > MIN_SIMILARITY) {
				nameMapping.put(oldName, bestMatch);
				newFiles.remove(bestMatch);
			} else {
				nameMapping.put(oldName, null);
			}

		}

	}
}

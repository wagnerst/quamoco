/*--------------------------------------------------------------------------+
   $Id: SimulinkLayouter.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.output;

import java.io.File;
import java.io.IOException;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.graph.EGraphvizOutputFormat;
import edu.tum.cs.commons.graph.GraphvizException;
import edu.tum.cs.commons.graph.GraphvizGenerator;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.html_presentation.util.HTMLLink;
import edu.tum.cs.conqat.html_presentation.util.ResourcesManager;
import edu.tum.cs.conqat.simulink.clones.normalize.ISimulinkNormalizer;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkModel;

/**
 * This processor layouts all simulink models in the given simulink scope and
 * appends links to these images to the model nodes.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "This processor layouts all simulink models in the given simulink "
		+ "scope and appends links to these images to the model nodes.")
public class SimulinkLayouter extends
		NodeTraversingProcessorBase<ISimulinkElement> {

	/** A link to the layouted model graph. */
	@AConQATKey(description = "A link to the layouted model graph.", type = "edu.tum.cs.conqat.html_presentation.util.HTMLLink")
	public static final String LAYOUT_KEY = "Layouted Model";

	/** The output directory of the HTML presentation. */
	private File outputDirectory;

	/** The (optional) normalizer used to determine block weights. */
	private ISimulinkNormalizer normalizer = null;

	/** Whether to show the hierarchy using clusters. */
	private boolean showHierarchy = true;

	/** Whether to suppress the names in the block labels. */
	private boolean suppressNames = false;

	/** Set the output directory. */
	@AConQATParameter(name = "output", minOccurrences = 1, maxOccurrences = 1, description = "The directory to write the M-files into.")
	public void setOutputDirectory(
			@AConQATAttribute(name = "dir", description = "The name of the directory.")
			String dir) throws ConQATException {
		outputDirectory = new File(dir);
		try {
			FileSystemUtils.ensureDirectoryExists(outputDirectory);
		} catch (IOException e) {
			throw new ConQATException("Could not create output directory!", e);
		}
		if (!outputDirectory.isDirectory()) {
			throw new ConQATException("Could not create output directory!");
		}
	}

	/** Set normalization. */
	@AConQATParameter(name = "norm", maxOccurrences = 1, description = ""
			+ "If provided this normalizer is used to append the weight to the block labels.")
	public void setNormalizer(
			@AConQATAttribute(name = "ref", description = "Reference to the normalizer")
			ISimulinkNormalizer normalizer) {
		this.normalizer = normalizer;
	}

	/** Determines whether to show the hierarchy. */
	@AConQATParameter(name = "hierarchy", maxOccurrences = 1, description = ""
			+ "Whether to show the hierarchy using clusters or not. Default is true.")
	public void setShowHierarchy(
			@AConQATAttribute(name = "show", description = "Whether to display hierarchy or not.")
			boolean showHierarchy) {
		this.showHierarchy = showHierarchy;
	}

	/** Determines whether to suppress names. */
	@AConQATParameter(name = "suppress", maxOccurrences = 1, description = ""
			+ "Whether to suppress names of blocks in labels or not. Default is false.")
	public void setSuppressNames(
			@AConQATAttribute(name = "names", description = "Whether to suppress names or not.")
			boolean suppressNames) {
		this.suppressNames = suppressNames;
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(ISimulinkElement root) throws ConQATException {
		super.setUp(root);
		NodeUtils.addToDisplayList(root, LAYOUT_KEY);
	}

	/** Performs the layouting of the model. */
	public void visit(ISimulinkElement node) throws ConQATException {
		if (!(node instanceof SimulinkModelElement)) {
			return;
		}

		String filename = getProcessorInfo().getName() + "-"
				+ node.getId().replaceAll("[:/\\\\]", "_") + "."
				+ EGraphvizOutputFormat.PNG.getFileExtension();

		File outputFile = FileSystemUtils.newFile(outputDirectory,
				ResourcesManager.IMAGES_DIRECTORY_NAME, filename);
		try {
			createGraph(((SimulinkModelElement) node).getModel(), outputFile);
		} catch (IOException e) {
			throw new ConQATException(e);
		} catch (GraphvizException e) {
			throw new ConQATException(e);
		}

		node.setValue(LAYOUT_KEY, new HTMLLink("graph",
				ResourcesManager.IMAGES_DIRECTORY_NAME + "/" + filename));
	}

	/** Create the graph. */
	private void createGraph(SimulinkModel model, File outputFile)
			throws ConQATException, IOException, GraphvizException {
		FileSystemUtils.ensureParentDirectoryExists(outputFile);

		String dotSource = SimulinkDotVisualizer.visualize(model, normalizer,
				showHierarchy, suppressNames);

		GraphvizGenerator generator = new GraphvizGenerator();
		generator
				.generateFile(dotSource, outputFile, EGraphvizOutputFormat.PNG);
	}
}

package edu.tum.cs.conqat.clonedetective.core.constraint;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.tracing.CloneTrackerUtils;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * @version $Rev: 22030 $
 * @levd.rating RED Rev:
 */
@AConQATProcessor(description = "Constraint that is satisfied if not all contained clones are marked as covered.")
public class NotAllCoveredConstraint extends ConstraintBase {

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) {
		return !CloneTrackerUtils.allCovered(cloneClass);
	}

}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingReportIO.java 22035 2009-07-16 10:28:06Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.xml;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.Locale;
import java.util.zip.GZIPInputStream;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import edu.tum.cs.commons.xml.IXMLResolver;
import edu.tum.cs.commons.xml.LowercaseResolver;
import edu.tum.cs.commons.xml.XMLUtils;
import edu.tum.cs.conqat.commons.findings.FindingReport;

/**
 * Class used for performing input and output of {@link FindingReport}s.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 22035 $
 * @levd.rating RED Rev:
 */
public class FindingReportIO {

	/** The encoding used for the XML file. */
	/* package */static final String ENCODING = "UTF-8";

	/** The date format used. */
	/* package */static final DateFormat DATE_FORMAT = DateFormat
			.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT, Locale.US);

	/** Resolver used for element and attribute names. */
	/* package */static final IXMLResolver<EFindingElements, EFindingAttributes> XML_RESOLVER = new LowercaseResolver<EFindingElements, EFindingAttributes>(
			EFindingAttributes.class);

	/** The name of the schema used for validation. */
	private static final String SCHEMA_NAME = "findings.xsd";

	/** Writes a report to a file. */
	public static void writeReport(FindingReport report, File file)
			throws IOException {
		writeReport(report, new FileOutputStream(file));
	}

	/** Writes a report to a stream. */
	public static void writeReport(FindingReport report, OutputStream out) {
		new FindingReportWriter(out).write(report);
	}

	/** Reads a report from a file. */
	public static FindingReport readReport(File file) throws IOException {
		return readReport(new FileInputStream(file));
	}

	/**
	 * Transparently creates a stream for decompression if the provided stream
	 * is compressed. Otherwise the stream is just handed through. Currently the
	 * following compression methods are supported:
	 * <ul>
	 * <li>GZIP via {@link GZIPInputStream}</li>
	 * </ul>
	 */
	// TODO (BH): Move to commons
	public static InputStream autoDecompressStream(InputStream in)
			throws IOException {
		if (!in.markSupported()) {
			in = new BufferedInputStream(in);
		}
		in.mark(2);
		// check first two bytes
		// (http://www.gzip.org/zlib/rfc-gzip.html#file-format)
		boolean isGZIP = in.read() == 0x1f && in.read() == 0x8b;
		in.reset();
		if (isGZIP) {
			return new GZIPInputStream(in);
		}
		return in;
	}

	/** Writes a report to a stream. */
	public static FindingReport readReport(InputStream in) throws IOException {
		try {
			FindingReportReaderHandler handler = new FindingReportReaderHandler();
			XMLUtils.parseSAX(new InputSource(autoDecompressStream(in)),
					FindingReportIO.class.getResource(SCHEMA_NAME), handler);
			return handler.getReport();
		} catch (ParserConfigurationException e) {
			throw new IOException("Parser missconfiguration: " + e.getMessage());
		} catch (SAXException e) {
			throw new IOException("Parsing error: " + e.getMessage());
		}
	}
}

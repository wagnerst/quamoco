/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: ELocationType.java 21887 2009-07-10 15:06:10Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.location;

/**
 * Enumeration of locations types for findings.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21887 $
 * @levd.rating YELLOW Rev: 21887
 */
public enum ELocationType {

	/** Code line location. */
	CODE_LINE(CodeLineLocation.class),

	/** Code region location. */
	CODE_REGION(CodeRegionLocation.class),

	/** Code file location. */
	CODE_FILE(FileLocation.class),

	/** Qualified name location. */
	QUALIFIED_NAME(QualifiedNameLocation.class);

	/** The associated location class. */
	private final Class<? extends LocationBase> locationClass;

	/** Constructor. */
	private ELocationType(Class<? extends LocationBase> locationClass) {
		this.locationClass = locationClass;
	}

	/** Returns the associated location class. */
	public Class<? extends LocationBase> getLocationClass() {
		return locationClass;
	}
}

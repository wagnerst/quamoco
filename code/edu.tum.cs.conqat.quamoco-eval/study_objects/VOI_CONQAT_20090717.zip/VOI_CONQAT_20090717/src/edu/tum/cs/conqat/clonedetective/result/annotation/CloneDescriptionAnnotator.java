/*--------------------------------------------------------------------------+
   $Id: CloneDescriptionAnnotator.java 18959 2009-03-12 08:24:16Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.clonedetective.utils.CloneUtils;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.regions.Region;
import edu.tum.cs.conqat.filesystem.regions.RegionSet;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Annotates each element in a file system tree with a human-readable
 * description of its clones.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 18959 $
 * @levd.rating GREEN Rev: 18959
 */
@AConQATProcessor(description = "Annotates each element in a file system tree with a human-readable "
		+ "description of its clones.")
public class CloneDescriptionAnnotator extends CloneAnnotatorBase {

	/** Key for clone descriptions */
	@AConQATKey(description = "Contains human-readable descriptions of the clones of this elements, "
			+ "or empty list, if element has no clone", type = "java.util.List<String>")
	public static final String CLONES_DESCRIPTION_KEY = "Cloned Lines";

	/** Makes clone description visible */
	@Override
	protected String[] getKeys() {
		return new String[] { CLONES_DESCRIPTION_KEY };
	}

	/** Store description of clones at element */
	@Override
	protected void annotateClones(IFileSystemElement element,
			UnmodifiableList<IClone> clonesList) {
		element.setValue(CLONES_DESCRIPTION_KEY, prettyPrint(clonesList));
	}

	/** Creates a human readable representation of a list of clones */
	private List<String> prettyPrint(List<IClone> clones) {
		Map<String, RegionSet> cloneRegions = initializeCloneRegions(clones);

		List<String> descriptions = new ArrayList<String>();
		for (String origin : CollectionUtils.sort(cloneRegions.keySet())) {
			int clonedLines = cloneRegions.get(origin).getPositionCount();
			String description = origin + ": " + clonedLines;
			descriptions.add(description);
		}

		return descriptions;
	}

	/** Create mapping from origin to clone region sets */
	private Map<String, RegionSet> initializeCloneRegions(List<IClone> clones) {
		Map<String, RegionSet> cloneRegions = new HashMap<String, RegionSet>();

		for (IClone clone : clones) {
			for (IClone sibling : CloneUtils.getSiblings(clone)) {
				String origin = sibling.getOrigin();
				RegionSet regions = getOrCreate(cloneRegions, origin);
				regions.add(new Region(sibling.getStartLineInFile(), sibling
						.getLastLineInFile()));
			}
		}

		return cloneRegions;
	}

	/**
	 * Retrieves the {@link RegionSet} for a clone origin. If no
	 * {@link RegionSet} is stored for an origin, a new {@link RegionSet} is
	 * created.
	 */
	private RegionSet getOrCreate(Map<String, RegionSet> cloneRegions,
			String origin) {
		if (!cloneRegions.containsKey(origin)) {
			cloneRegions.put(origin, new RegionSet());
		}
		return cloneRegions.get(origin);
	}

}

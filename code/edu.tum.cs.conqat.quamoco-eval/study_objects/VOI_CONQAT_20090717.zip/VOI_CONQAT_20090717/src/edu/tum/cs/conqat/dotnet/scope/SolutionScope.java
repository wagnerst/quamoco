/*--------------------------------------------------------------------------+
   $Id: SolutionScope.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope;

import java.io.File;
import java.util.List;

import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Creates a source code scope of the files contained in one single VS.NET
 * solution file. If any file is contained in multiple included projects, it
 * only occurs once in the scope.
 * <p>
 * Currently, only a single language is supported for the entire scope.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "Creates a source code scope of the files contained in one single VS.NET"
		+ "solution file. If any file is contained in multiple included projects, it"
		+ "only occurs once in the scope."
		+ "Currently, only a single language is supported for the entire scope.")
public class SolutionScope extends SolutionScopeBase {

	/** Solution file name */
	private File solutionFile;

	/** ConQAT Parameter */
	@AConQATParameter(name = "solution", description = "VS.NET solution", minOccurrences = 1, maxOccurrences = 1)
	public void setSolutionFile(
			@AConQATAttribute(name = "file", description = "Name of the solution file") String solutionFilename) {
		solutionFile = new File(solutionFilename);
	}

	/**
	 * Template method that allows deriving classes to return the root directory
	 * under which all solution files reside
	 * 
	 * @throws ConQATException
	 *             if root directory cannot be determined
	 */
	@Override
	protected File determineRootDirectory() throws ConQATException {
		if (solutionFile.exists()) {
			getLogger().debug("Reading solution file: " + solutionFile);
		} else {
			throw new ConQATException("Solution file " + solutionFile
					+ " not found");
		}

		return solutionFile.getParentFile();
	}

	/**
	 * Template method that allows deriving classes the return the list of
	 * source files
	 */
	@Override
	protected List<String> determineSourceFiles() throws ConQATException {
		return parseSolutionFile(solutionFile);
	}

}

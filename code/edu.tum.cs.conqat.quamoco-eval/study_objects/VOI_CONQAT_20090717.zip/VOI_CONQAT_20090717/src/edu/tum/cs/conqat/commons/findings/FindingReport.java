/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingReport.java 21887 2009-07-10 15:06:10Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.commons.findings.location.ELocationType;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * A finding report is a collection of finding categories.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21887 $
 * @levd.rating YELLOW Rev: 21887
 */
public class FindingReport extends ConQATNodeBase implements
		IRemovableConQATNode {

	/** The time this report was created. */
	private final Date time;

	/** The categories. */
	private final Map<String, FindingCategory> categories = new HashMap<String, FindingCategory>();

	/** Constructor. */
	public FindingReport() {
		this(new Date());
	}

	/** Constructor. */
	public FindingReport(Date time) {
		this.time = (Date) time.clone();
	}

	/** Copy constructor. */
	/* package */FindingReport(FindingReport other) throws DeepCloneException {
		super(other);
		this.time = (Date) other.time.clone();
		for (FindingCategory category : other.categories.values()) {
			categories.put(category.getName(), new FindingCategory(category,
					this));
		}
	}

	/** Returns the category with the given name or null. */
	public FindingCategory getCategory(String name) {
		return categories.get(name);
	}

	/**
	 * Returns the category with the given name or creates one using the finding
	 * and location types.
	 * 
	 * @throws ConQATException
	 *             if the finding exists but has wrong finding or location
	 *             types.
	 */
	public FindingCategory getOrCreateCategory(String name,
			EFindingType findingType, ELocationType locationType)
			throws ConQATException {
		FindingCategory category = categories.get(name);
		if (category == null) {
			category = new FindingCategory(this, name, findingType,
					locationType);
			categories.put(name, category);
		} else {
			if (category.getFindingType() != findingType
					|| category.getLocationType() != locationType) {
				throw new ConQATException(
						"Finding category with given name already exists but has different finding type or location type!");
			}
		}
		return category;
	}

	/** Returns the time when the report was created. */
	public Date getTime() {
		return time;
	}

	/** {@inheritDoc} */
	public FindingCategory[] getChildren() {
		return categories.values().toArray(
				new FindingCategory[categories.size()]);
	}

	/** {@inheritDoc} */
	public void remove() {
		// does nothing
	}

	/** Removes the given category. */
	/* package */void remove(FindingCategory findingCategory) {
		categories.remove(findingCategory.getName());
	}

	/** {@inheritDoc} */
	public String getId() {
		return getName();
	}

	/** {@inheritDoc} */
	public String getName() {
		return "";
	}

	/** {@inheritDoc} */
	public IConQATNode getParent() {
		return null;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !categories.isEmpty();
	}

	/** {@inheritDoc} */
	public IRemovableConQATNode deepClone() throws DeepCloneException {
		return new FindingReport(this);
	}

}

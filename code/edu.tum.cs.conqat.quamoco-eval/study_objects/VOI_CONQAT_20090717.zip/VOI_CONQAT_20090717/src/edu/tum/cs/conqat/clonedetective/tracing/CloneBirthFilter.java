package edu.tum.cs.conqat.clonedetective.tracing;

import java.util.Date;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.filter.CloneClassFilterBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 21499 $
 * @levd.rating RED Rev: 
 */
@AConQATProcessor(description = ""
		+ "Filters all clones that are older then a specified date.")
public class CloneBirthFilter extends CloneClassFilterBase {

	/** Barrier date. All clones before this date are filtered */
	private Date filterBefore;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "filter", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "All clones that were born before this date are filtered")
	public void SetBarrierDate(
			@AConQATAttribute(name = "before", description = "Example for date formar: 01-Jun-2008 00:00:01") Date filterBefore) {
		this.filterBefore = filterBefore;
	}

	/** {@inheritDoc} */
	@Override
	protected boolean filteredOut(CloneClass cloneClass) {
		Date birth = CollectionUtils.getAny(cloneClass.getClones()).getBirth();
		return filterBefore.after(birth);
	}
}

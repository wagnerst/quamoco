/*--------------------------------------------------------------------------+
   $Id: GappedClone.java 22020 2009-07-16 09:36:36Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;

/**
 * Gapped clone.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 22020 $
 * @levd.rating YELLOW Rev: 22020
 */
public class GappedClone extends Clone {

	/** Array that contains the gap types in the clone. */
	private final Map<Integer, EEditOperation> gaps = new HashMap<Integer, EEditOperation>(
			0);

	/** Delta */
	private final int delta;

	/** Constructor */
	public GappedClone(int id, CloneClass cloneClass, String origin,
			int startLineInFile, int lengthInFile, int startUnitIndexInFile,
			int lengthInUnits, String fingerprint, int delta) {
		super(id, cloneClass, origin, startLineInFile, lengthInFile,
				startUnitIndexInFile, lengthInUnits, fingerprint);
		this.delta = delta;
	}

	/**
	 * Adds a gap position.
	 * 
	 * @param lineOffset
	 *            Position of the gap as line number offset from the start of
	 *            the clone.
	 * @param gapType
	 *            Type of the gap
	 */
	public void addGap(int lineOffset, EEditOperation gapType) {
		gaps.put(lineOffset, gapType);
	}

	/** {@inheritDoc} */
	@Override
	public EEditOperation getGapTypeAt(int lineOffset) {
		EEditOperation gapType = gaps.get(lineOffset);
		if (gapType == null) {
			return EEditOperation.NONE;
		}
		return gapType;
	}

	/** {@inheritDoc} */
	@Override
	public boolean containsGaps() {
		return gaps.size() > 0;
	}

	/** {@inheritDoc} */
	@Override
	public int gapCount() {
		return gaps.size();
	}

	/** {@inheritDoc} */
	@Override
	public UnmodifiableList<Integer> getGapPositions() {
		return CollectionUtils.asSortedUnmodifiableList(gaps.keySet());
	}

	/** {@inheritDoc} */
	@Override
	public int getDeltaInUnits() {
		return delta;
	}
}

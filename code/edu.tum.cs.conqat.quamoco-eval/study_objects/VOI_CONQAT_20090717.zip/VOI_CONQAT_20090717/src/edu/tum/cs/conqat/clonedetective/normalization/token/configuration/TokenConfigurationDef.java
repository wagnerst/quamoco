/*--------------------------------------------------------------------------+
   $Id: TokenConfigurationDef.java 21476 2009-05-26 09:41:35Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token.configuration;

import edu.tum.cs.commons.clone.IDeepCloneable;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Creates {@link ITokenConfiguration}s.
 * <p>
 * In order to avoid redundancy, this processor implements
 * {@link ITokenConfiguration} and simply returns a self reference in
 * {@link #process()};
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 21476 $
 * @levd.rating GREEN Rev: 21476
 */
@AConQATProcessor(description = "Creates ITokenConfigurations.")
public class TokenConfigurationDef extends ConQATProcessorBase implements
		ITokenConfiguration, IDeepCloneable {

	/** Configuration name */
	private String name = "default";

	/** Ignore comments? */
	private boolean ignoreComments = true;

	/** Ignore delimiters? */
	private boolean ignoreDelimiters = true;

	/** Ignore preprocessor directives? */
	private boolean ignorePreprocessorDirectives = true;

	/** Normalize identifiers? */
	private boolean normalizeIdentifiers = false;

	/** Normalize fully qualified names? */
	public boolean normalizeFullyQualifiedNames = false;

	/** Normalize type keywords? */
	public boolean normalizeTypeKeywords = true;

	/** Normalize boolean literals? */
	private boolean normalizeBooleanLiterals = true;

	/** Normalize character literals? */
	private boolean normalizeCharacterLiterals = true;

	/** Normalize number literals? */
	private boolean normalizeNumberLiterals = true;

	/** Normalize string literals? */
	private boolean normalizeStringLiterals = true;

	/** Ignore this reference? */
	private boolean ignoreThis = true;

	/** Ignore this reference? */
	private boolean ignoreVisibilityModifier = true;

	/** Default constructor */
	public TokenConfigurationDef() {
		// nothing to do
	}

	/** Copy constructor */
	private TokenConfigurationDef(TokenConfigurationDef def) {
		this.ignoreComments = def.ignoreComments;
		this.ignoreDelimiters = def.ignoreDelimiters;
		this.ignorePreprocessorDirectives = def.ignorePreprocessorDirectives;
		this.normalizeIdentifiers = def.normalizeIdentifiers;
		this.normalizeFullyQualifiedNames = def.normalizeFullyQualifiedNames;
		this.normalizeTypeKeywords = def.normalizeTypeKeywords;
		this.normalizeBooleanLiterals = def.normalizeBooleanLiterals;
		this.normalizeCharacterLiterals = def.normalizeCharacterLiterals;
		this.normalizeNumberLiterals = def.normalizeNumberLiterals;
		this.normalizeStringLiterals = def.normalizeStringLiterals;
		this.ignoreThis = def.ignoreThis;
		this.ignoreVisibilityModifier = def.ignoreVisibilityModifier;
	}

	/** {@inheritDoc} */
	public IDeepCloneable deepClone() {
		return new TokenConfigurationDef(this);
	}

	/** Turns on all normalization parameters */
	public void setAll() {
		ignoreComments = true;
		ignoreDelimiters = true;
		ignorePreprocessorDirectives = true;
		normalizeIdentifiers = true;
		normalizeFullyQualifiedNames = true;
		normalizeTypeKeywords = true;
		normalizeBooleanLiterals = true;
		normalizeCharacterLiterals = true;
		normalizeNumberLiterals = true;
		normalizeStringLiterals = true;
		ignoreThis = true;
		ignoreVisibilityModifier = true;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "configuration", description = "Name of the configuration", minOccurrences = 0, maxOccurrences = 1)
	public void setName(
			@AConQATAttribute(name = "name", description = "Default value: 'default'", defaultValue = "default")
			String name) {
		this.name = name;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "comments", description = "Ignore comments?", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnoreComments(
			@AConQATAttribute(name = "ignore", description = "Default value: true", defaultValue = "true")
			boolean ignoreComments) {
		this.ignoreComments = ignoreComments;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "delimiters", description = "Ignore delimiters?", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnoreDelimiters(
			@AConQATAttribute(name = "ignore", description = "Default value: true")
			boolean ignoreDelimiters) {
		this.ignoreDelimiters = ignoreDelimiters;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "preprocessordirectives", description = "Ignore preprocessor directives?", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnorePreprocessorDirectives(
			@AConQATAttribute(name = "ignore", description = "Default value: true")
			boolean ignorePreprocessorDirectives) {
		this.ignorePreprocessorDirectives = ignorePreprocessorDirectives;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "identifiers", description = "Normalize identifiers?", minOccurrences = 0, maxOccurrences = 1)
	public void setNormalizeIdentifiers(
			@AConQATAttribute(name = "normalize", description = "Default value: false")
			boolean normalizeIdentifiers) {
		this.normalizeIdentifiers = normalizeIdentifiers;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "fq-names", description = "Normalize fully qualified names?", minOccurrences = 0, maxOccurrences = 1)
	public void setNormalizeFullyQualifiedNames(
			@AConQATAttribute(name = "normalize", description = "Default value: false")
			boolean normalizeFullyQualifiedNames) {
		this.normalizeFullyQualifiedNames = normalizeFullyQualifiedNames;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "type-keywords", description = "Normalize type keywords?", minOccurrences = 0, maxOccurrences = 1)
	public void setNormalizeTypeKeywords(
			@AConQATAttribute(name = "normalize", description = "Default value: false")
			boolean normalizeTypeKeywords) {
		this.normalizeTypeKeywords = normalizeTypeKeywords;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "booleanliterals", description = "Normalize boolean literals?", minOccurrences = 0, maxOccurrences = 1)
	public void setNormalizenBooleanLiterals(
			@AConQATAttribute(name = "normalize", description = "Default value: true")
			boolean normalizeBooleanLiterals) {
		this.normalizeBooleanLiterals = normalizeBooleanLiterals;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "characterliterals", description = "Normalize character literals?", minOccurrences = 0, maxOccurrences = 1)
	public void setNormalizenCharacterLiterals(
			@AConQATAttribute(name = "normalize", description = "Default value: true")
			boolean normalizeCharacterLiterals) {
		this.normalizeCharacterLiterals = normalizeCharacterLiterals;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "numberliterals", description = "Normalize number literals?", minOccurrences = 0, maxOccurrences = 1)
	public void setNormalizeNumberLiterals(
			@AConQATAttribute(name = "normalize", description = "Default value: true")
			boolean normalizeNumberLiterals) {
		this.normalizeNumberLiterals = normalizeNumberLiterals;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "stringliterals", description = "Normalize string literals?", minOccurrences = 0, maxOccurrences = 1)
	public void setNormalizeStringLiterals(
			@AConQATAttribute(name = "normalize", description = "Default value: true")
			boolean normalizeStringLiterals) {
		this.normalizeStringLiterals = normalizeStringLiterals;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "this", description = "Ignore this reference?", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnoreThis(
			@AConQATAttribute(name = "ignore", description = "Default value: true")
			boolean ignoreThis) {
		this.ignoreThis = ignoreThis;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "visibility-modifier", description = "Ignore visibility modifier?", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnoreVisibilityModifier(
			@AConQATAttribute(name = "ignore", description = "Default value: false")
			boolean ignoreVisibilityModifier) {
		this.ignoreVisibilityModifier = ignoreVisibilityModifier;
	}

	/** Returns an ITokenConfiguration according to the processor parameters */
	public ITokenConfiguration process() {
		return this;
	}

	/** Getter */
	public String getName() {
		return name;
	}

	/** Getter */
	public boolean isIgnoreComments() {
		return ignoreComments;
	}

	/** Getter */
	public boolean isIgnoreDelimiters() {
		return ignoreDelimiters;
	}

	/** Getter */
	public boolean isIgnorePreprocessorDirectives() {
		return ignorePreprocessorDirectives;
	}

	/** Getter */
	public boolean isNormalizeBooleanLiterals() {
		return normalizeBooleanLiterals;
	}

	/** Getter */
	public boolean isNormalizeCharacterLiterals() {
		return normalizeCharacterLiterals;
	}

	/** Getter */
	public boolean isNormalizeIdentifiers() {
		return normalizeIdentifiers;
	}

	/** Getter */
	public boolean isNormalizeFullyQualifiedNames() {
		return normalizeFullyQualifiedNames;
	}

	/** Getter */
	public boolean isNormalizeTypeKeywords() {
		return normalizeTypeKeywords;
	}

	/** Getter */
	public boolean isNormalizeNumberLiterals() {
		return normalizeNumberLiterals;
	}

	/** Getter */
	public boolean isNormalizeStringLiterals() {
		return normalizeStringLiterals;
	}

	/** Getter */
	public boolean isIgnoreThis() {
		return ignoreThis;
	}

	/** Getter */
	public boolean isIgnoreModifier() {
		return ignoreVisibilityModifier;
	}

}

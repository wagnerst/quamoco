/*--------------------------------------------------------------------------+
   $Id: CloneReportWriterProcessor.java 21700 2009-06-29 12:25:14Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.digest.Digester;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.clonedetective.result.report.CloneReportWriter;
import edu.tum.cs.conqat.clonedetective.result.report.SourceFileDescriptor;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Processor that writes a clone detection result file in xml format.
 * <p>
 * The actual xml processing is performed in the class {@link CloneReportWriter}
 * . The main job of this class is to make {@link CloneReportWriter} accessible
 * in a ConQAT clone detection configuration. This separation allows for the use
 * of {@link CloneReportWriter} outside of ConQAT.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Revision: 21700 $
 * @levd.rating RED Rev:
 */
@AConQATProcessor(description = "Writes a clone detection result file in xml format.")
public class CloneReportWriterProcessor extends ConQATProcessorBase {

	/** File into which report gets written */
	private File targetFile;

	/** Clone detection result for which report gets written */
	private CloneDetectionResultElement detectionResult;

	/** Instance of the file library used to access file content. */
	private static final FileLibrary fileCache = FileLibrary.getInstance();

	/** Creates the target file from directory and filename parameters */
	@AConQATParameter(name = "output", minOccurrences = 1, maxOccurrences = 1, description = "Name of the output directory")
	public void setOutputDirectory(
			@AConQATAttribute(name = "dir", description = "Name of the output directory") String outputDir,
			@AConQATAttribute(name = "report-name", description = "Name of the report file that gets written") String reportName) {

		targetFile = new File(outputDir, reportName);
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "detection-result", description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setDetectionResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) CloneDetectionResultElement detectionResult) {

		this.detectionResult = detectionResult;
	}

	// TODO (EJ) Write empty report instead? Or use null object pattern?
	/** {@inheritDoc} */
	public Object process() throws ConQATException {
		// check for empty input
		if (detectionResult == null) {
			getLogger()
					.warn(
							"Did not write report since null-detection result was encountered.");
			return null;
		}

		writeReport(detectionResult.getList(), detectionResult.getRoot(),
				detectionResult.getSystemDate(), targetFile, getLogger());

		return targetFile;
	}

	/**
	 * Writes a clone report file using a {@link CloneReportWriter}.
	 * 
	 * @param cloneClasses
	 *            Result clone classes that get written to the report
	 * @param root
	 *            Root of the file tree on which detection has been performed
	 * @param systemDate
	 *            Date denoting the system version on which clone detection was
	 *            performed.
	 * @param targetFile
	 *            File into which report gets written
	 * @param logger
	 *            Logger used to log errors occurring during report writing
	 * 
	 * @throws ConQATException
	 *             If report creation fails.
	 */
	public static void writeReport(List<CloneClass> cloneClasses,
			IFileSystemElement root, Date systemDate, File targetFile,
			IConQATLogger logger) throws ConQATException {
		CloneReportWriter.writeReport(cloneClasses,
				createSourceFileDescriptors(root, logger), systemDate,
				targetFile);
	}

	/**
	 * Creates a Map from Clone origins to {@link SourceFileDescriptor}s. The
	 * clone origin is the id of a {@link IFileSystemElement} which can differ
	 * from the absolute path. It is not sufficient to simply assume that an
	 * {@link IFileSystemElement}s id corresponds to its filename, since this is
	 * not true for all classes implementing {@link IFileSystemElement}.
	 */
	private static Map<String, SourceFileDescriptor> createSourceFileDescriptors(
			IFileSystemElement root, IConQATLogger logger) {
		Map<String, SourceFileDescriptor> sourceFileInfos = new HashMap<String, SourceFileDescriptor>();

		int sourceFileIdCounter = 0;
		for (IFileSystemElement element : TraversalUtils
				.listLeavesDepthFirst(root)) {
			// skip elements that have no file
			File file = element.getFile();
			if (file == null || !file.isFile()) {
				continue;
			}

			String filename = FileSystemUtils.canonize(file).getPath();
			int length = -1;
			String fingerprint = StringUtils.EMPTY_STRING;
			try {
				length = CloneReportWriterProcessor.fileCache.getLines(file).length;
				fingerprint = Digester
						.createMD5Digest(CloneReportWriterProcessor.fileCache
								.getContent(file));
			} catch (ConQATException e) {
				logger.warn("Could not read file " + file.getAbsolutePath()
						+ " in order to compute length and fingerprint: "
						+ e.getMessage());
			}

			sourceFileInfos.put(element.getId(), new SourceFileDescriptor(
					sourceFileIdCounter++, filename, length, fingerprint));
		}
		return sourceFileInfos;
	}

}

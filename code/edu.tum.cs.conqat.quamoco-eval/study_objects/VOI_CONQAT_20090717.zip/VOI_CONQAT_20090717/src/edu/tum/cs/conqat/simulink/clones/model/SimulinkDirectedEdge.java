/*--------------------------------------------------------------------------+
   $Id: SimulinkDirectedEdge.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.clones.model;

import edu.tum.cs.conqat.model_clones.model.IDirectedEdge;
import edu.tum.cs.conqat.model_clones.model.INode;
import edu.tum.cs.simulink.model.SimulinkLine;

/**
 * Implementation of the {@link IDirectedEdge} interface for Simulink.
 * 
 * @author hummelb
 * @author $Author:hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public class SimulinkDirectedEdge implements IDirectedEdge {

	/** The corresponding simulink line. */
	private final SimulinkLine line;

	/** The normalized representation. */
	private final String normalized;

	/** The source node. */
	private final SimulinkNode source;

	/** The target node. */
	private final SimulinkNode target;

	/** Constructor. */
	/* package */SimulinkDirectedEdge(SimulinkLine line, String normalized,
			SimulinkNode source, SimulinkNode target) {
		this.line = line;
		this.normalized = normalized;
		this.source = source;
		this.target = target;
	}

	/** {@inheritDoc} */
	public INode getSourceNode() {
		return source;
	}

	/** {@inheritDoc} */
	public INode getTargetNode() {
		return target;
	}

	/** Returns the line. */
	public SimulinkLine getLine() {
		return line;
	}

	/** {@inheritDoc} */
	public String getEquivalenceClassRepresentative() {
		return normalized;
	}

}

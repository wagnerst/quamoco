/*--------------------------------------------------------------------------+
   $Id: TolerationsDef.java 18861 2009-03-10 11:22:07Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.toleration;

import java.io.File;
import java.io.IOException;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Creates a {@link Tolerations} list. Tolerated dependencies can be specified
 * either via parameters or via an external files. Both variants can also be
 * combined.
 * 
 * @author juergens
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * @version $Rev: 18861 $
 * @levd.rating GREEN Rev: 18861
 */
@AConQATProcessor(description = "Creates a list of tolerations.")
public class TolerationsDef extends ConQATProcessorBase {

	/** {@link Tolerations} object that is created by this processor */
	private final Tolerations tolerations = new Tolerations();

	/** ConQAT Parameter */
	@AConQATParameter(name = "tolerated", minOccurrences = 0, description = "Tolerated dependencies")
	public void addTolerations(
			@AConQATAttribute(name = "dependency", description = "Dependency of the form 'org.ns.classA -> org.ns.classB'") String toleratedDependency) {
		processToleration(toleratedDependency);
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "toleration", minOccurrences = 0, description = "List of tolerated dependencies")
	public void addTolerationFile(
			@AConQATAttribute(name = "file", description = "File that contains tolerated dependencies") String filename) {
		try {
			String content = FileSystemUtils.readFile(new File(filename));
			String[] tolerations = StringUtils.splitLines(content);
			for (String toleration : tolerations) {
				processToleration(toleration);
			}
		} catch (IOException e) {
			getLogger().error(
					"Could not read tolerated dependencies from file: "
							+ filename + ": " + e.getMessage());
		}
	}

	/** Process tolerations string */
	private void processToleration(String toleratedDependency) {
		if (!ignored(toleratedDependency)) {
			String[] elementIds = toleratedDependency.split("->");
			if (elementIds.length != 2) {
				throw new IllegalArgumentException(
						"Toleration dependency must be of the form 'source -> target', but was: "
								+ toleratedDependency);
			}
			tolerations.addToleration(elementIds[0].trim(), elementIds[1]
					.trim());
		}
	}

	/** Determines whether a line is to be parsed */
	private boolean ignored(String line) {
		return StringUtils.isEmpty(line) || line.trim().startsWith("#")
				|| line.trim().startsWith("//") || line.trim().startsWith("%");
	}

	/** {@inheritDoc} */
	public Tolerations process() {
		return tolerations;
	}
}

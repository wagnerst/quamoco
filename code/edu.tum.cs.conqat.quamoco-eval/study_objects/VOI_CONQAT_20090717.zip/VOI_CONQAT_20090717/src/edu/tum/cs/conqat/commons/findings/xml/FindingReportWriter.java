/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingReportWriter.java 22035 2009-07-16 10:28:06Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.xml;

import java.awt.Color;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.xml.XMLWriter;
import edu.tum.cs.conqat.commons.findings.EFindingType;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingCategory;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.location.CodeLineLocation;
import edu.tum.cs.conqat.commons.findings.location.CodeRegionLocation;
import edu.tum.cs.conqat.commons.findings.location.FileLocation;
import edu.tum.cs.conqat.commons.findings.location.LocationBase;
import edu.tum.cs.conqat.commons.findings.location.QualifiedNameLocation;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.NodeConstants;

/**
 * Code for writing finding reports. This is package visible and only used by
 * the {@link FindingReportIO} class.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 22035 $
 * @levd.rating YELLOW Rev: 22035
 */
/* package */class FindingReportWriter {

	/**
	 * Set of keys which are omitted during the export as they have no meaning
	 * for findings but may be added by other processors.
	 */
	private static final Set<String> FILTERED_KEYS = new HashSet<String>(Arrays
			.asList(NodeConstants.COMPARATOR, NodeConstants.HIDE_ROOT,
					NodeConstants.DISPLAY_LIST, NodeConstants.SUMMARY));

	/** The XML writer. */
	private final XMLWriter<EFindingElements, EFindingAttributes> writer;

	/** Constructor. */
	/* package */FindingReportWriter(OutputStream out) {
		this.writer = new XMLWriter<EFindingElements, EFindingAttributes>(
				new PrintWriter(new OutputStreamWriter(out, Charset
						.forName(FindingReportIO.ENCODING))),
				FindingReportIO.XML_RESOLVER);
	}

	/** Writes the report into the writer. */
	/* package */void write(FindingReport report) {
		try {
			writer.addHeader("1.0", FindingReportIO.ENCODING);
			String time = FindingReportIO.DATE_FORMAT.format(report.getTime());
			writer.openElement(EFindingElements.FINDING_REPORT,
					EFindingAttributes.TIME, time, EFindingAttributes.XMLNS,
					"http://conqat.cs.tum.edu/ns/findings");

			for (FindingCategory category : report.getChildren()) {
				writeCategory(category);
			}

			writer.closeElement(EFindingElements.FINDING_REPORT);
		} finally {
			writer.close();
		}
	}

	/** Writes the category into the writer. */
	private void writeCategory(FindingCategory category) {
		writer.openElement(EFindingElements.FINDING_CATEGORY,
				EFindingAttributes.NAME, category.getName(),
				EFindingAttributes.LOCATION_TYPE, category.getLocationType()
						.name(), EFindingAttributes.FINDING_TYPE, category
						.getFindingType().name());

		for (FindingGroup group : category.getChildren()) {
			writeGroup(group);
		}

		writer.closeElement(EFindingElements.FINDING_CATEGORY);
	}

	/** Writes the group into the writer. */
	private void writeGroup(FindingGroup group) {
		writer.openElement(EFindingElements.FINDING_GROUP,
				EFindingAttributes.DESCRIPTION, group.getName());

		writeKeyValues(group);

		for (Finding<?> finding : group.getChildren()) {
			writeFinding(finding);
		}

		writer.closeElement(EFindingElements.FINDING_GROUP);
	}

	/** Writes the finding into the writer. */
	private void writeFinding(Finding<?> finding) {
		String value;
		if (finding.getFindingType() == EFindingType.COLOR) {
			Color c = (Color) finding.getValue();
			value = String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c
					.getBlue());
		} else {
			value = finding.getValue().toString();
		}

		writer.openElement(EFindingElements.FINDING,
				EFindingAttributes.ORIGIN_TOOL, finding.getOriginTool(),
				EFindingAttributes.VALUE, value);

		writeKeyValues(finding);

		for (LocationBase location : finding.getLocations()) {
			writeLocation(location);
		}

		writer.closeElement(EFindingElements.FINDING);
	}

	/** Writes key/value pairs. */
	private void writeKeyValues(ConQATNodeBase node) {
		for (String key : node.getKeys()) {
			if (FILTERED_KEYS.contains(key)) {
				continue;
			}

			Object value = node.getValue(key);
			if (value != null) {
				writer.addClosedTextElement(EFindingElements.KEY_VALUE_PAIR,
						value.toString(), EFindingAttributes.KEY, key);
			}
		}
	}

	/** Writes the location to the writer. */
	private void writeLocation(LocationBase location) {
		if (location instanceof QualifiedNameLocation) {
			writer.addClosedElement(EFindingElements.QUALIFIED_NAME,
					EFindingAttributes.NAME, ((QualifiedNameLocation) location)
							.getQualifiedName());
		} else if (location instanceof CodeRegionLocation) {
			CodeRegionLocation crl = (CodeRegionLocation) location;
			writer.addClosedElement(EFindingElements.CODE_REGION,
					EFindingAttributes.FILE, crl.getFile().getPath(),
					EFindingAttributes.START_LINE_NUMBER, Integer.toString(crl
							.getFirstLine()),
					EFindingAttributes.END_LINE_NUMBER, Integer.toString(crl
							.getLastLine()), EFindingAttributes.START_POSITION,
					Integer.toString(crl.getFirstPosition()),
					EFindingAttributes.END_POSITION, Integer.toString(crl
							.getLastPosition()));

		} else if (location instanceof CodeLineLocation) {
			CodeLineLocation cll = (CodeLineLocation) location;
			writer.addClosedElement(EFindingElements.CODE_LINE,
					EFindingAttributes.FILE, cll.getFile().getPath(),
					EFindingAttributes.LINE_NUMBER, Integer.toString(cll
							.getFirstLine()));
		} else if (location instanceof FileLocation) {
			writer.addClosedElement(EFindingElements.CODE_FILE,
					EFindingAttributes.FILE, ((FileLocation) location)
							.getFile().getPath());
		} else {
			CCSMAssert.fail("Unknown subclass of LocationBase!");
		}
	}

}

/*--------------------------------------------------------------------------+
   $Id: JavaPackageElement.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.scope;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.clone.DeepCloneException;

/**
 * An element representing a Java package. A package is a mere organizational
 * structure that is not manifested in file system.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * 
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public class JavaPackageElement extends JavaElementBase {

	/** Children storage. */
	private final Map<String, JavaElementBase> children = new HashMap<String, JavaElementBase>();

	/**
	 * Create a new package.
	 * 
	 * @param name
	 *            local name of the package (i.e. just 'util').
	 */
	public JavaPackageElement(String name) {
		super(name);
	}

	/** Copy constructor. */
	protected JavaPackageElement(JavaPackageElement element)
			throws DeepCloneException {
		super(element);

		for (JavaElementBase child : element.children.values()) {
			addChild(child.deepClone());
		}
	}

	/** {@inheritDoc} */
	public JavaElementBase[] getChildren() {
		return children.values().toArray(new JavaElementBase[children.size()]);
	}

	/** Add a child element. */
	/* package */void addChild(JavaElementBase element) {
		children.put(element.getName(), element);
		element.setParent(this);
	}

	/** Returns the child of the given name, or null if not found. */
	public JavaElementBase getChild(String name) {
		return children.get(name);
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !children.isEmpty();
	}

	/** {@inheritDoc} */
	@Override
	public JavaPackageElement deepClone() throws DeepCloneException {
		return new JavaPackageElement(this);
	}

	/**
	 * As packages are not represented in the file system, this always returns
	 * <code>null</code>.
	 */
	public File getFile() {
		return null;
	}

	/** Remove the given node from the child list. */
	/* package */void removeNode(JavaElementBase node) {
		children.remove(node.getName());
	}
}

/*--------------------------------------------------------------------------+
   $Id: IdentifierCounter.java 21644 2009-06-22 16:33:49Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import java.util.List;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.sourcecode.library.SourceCodeLibrary;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.ETokenType.ETokenClass;

/**
 * This processor analyzes source code for identifiers and determines their
 * frequency.
 * 
 * @author Tobias Simon
 * @author $Author: hummelb $
 * @version $Revision: 21644 $
 * @levd.rating GREEN Rev: 21644
 */
@AConQATProcessor(description = "This processor counts the "
		+ "occurrences of identifiers from a source code tree. The result is a counterset that stores "
		+ "the frequency of each identifier")
public class IdentifierCounter extends ConQATProcessorBase implements
		INodeVisitor<ISourceCodeElement, NeverThrownRuntimeException> {

	/** The node we're working on */
	private ISourceCodeElement root;

	/** Maps the identifier text to the number of occurrences. */
	private final CounterSet<String> counter = new CounterSet<String>();

	/** Set the root element to work on. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			ISourceCodeElement root) {
		this.root = root;
	}

	/** {@inheritDoc} */
	public CounterSet<String> process() {
		TraversalUtils.visitLeavesDepthFirst(this, root);
		return counter;
	}

	/**
	 * Analyze a single source element. All identifiers of the source code file
	 * will be extracted. If a identifier is encountered the number of
	 * occurrences of the literal is incremented by 1.
	 */
	public void visit(ISourceCodeElement element) {

		// get a list of all tokens
		List<IToken> tokens;
		try {
			tokens = SourceCodeLibrary.getInstance().getTokens(element);
		} catch (Exception e) {
			getLogger().warn("Couldn't read " + element);
			return;
		}

		for (IToken token : tokens) {
			if (token.getType().getTokenClass() == ETokenClass.IDENTIFIER) {
				counter.inc(token.getText());
			}
		}
	}
}

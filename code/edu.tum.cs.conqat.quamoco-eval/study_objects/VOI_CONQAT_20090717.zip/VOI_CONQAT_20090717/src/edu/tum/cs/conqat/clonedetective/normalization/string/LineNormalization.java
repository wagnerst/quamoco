/*--------------------------------------------------------------------------+
   $Id: LineNormalization.java 18740 2009-03-07 08:15:00Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.string;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.lazyscope.IElementProvider;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.commons.pattern.PatternTransformationList;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Split input files into lines and return them one by one. Provides basic
 * normalization capabilities by a set of regular expressions that define
 * replacements on the input file before splitting into lines.
 * <p>
 * This uses class {@link edu.tum.cs.commons.string.LineSplitter} from the
 * commons project.
 * 
 * @author Uwe Hermann
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Revision: 18740 $
 * @levd.rating GREEN Rev: 18740
 */
public class LineNormalization extends StringNormalizationBase {

	/**
	 * Create a new line provider.
	 * 
	 * @param removeConfig
	 *            List of patterns; matches are removed in a layout preserving
	 *            manner
	 * @param replacements
	 *            List of replacements. Take care to be layout preserving.
	 * @param trimLines
	 *            Flag that determines whether lines are trimmed during
	 *            normalization
	 * @param ignoreEmptyLines
	 *            Flag that determines whether empty lines are ignored by
	 *            normalization
	 */
	public LineNormalization(
			IElementProvider<IFileSystemElement> inputProvider,
			PatternList removeConfig, PatternTransformationList replacements,
			boolean trimLines, boolean ignoreEmptyLines,
			boolean removeAllWhitespace) {
		super(inputProvider, removeConfig, replacements, trimLines,
				ignoreEmptyLines, removeAllWhitespace);
	}

	/** Determines next line that has not been ignored */
	@Override
	protected String findNextUnignoredInFile() {
		String lineString = getNextLine();
		while (lineString != null && isIgnored(lineString)) {
			lineString = getNextLine();
		}
		return lineString;
	}

	/** Returns true, if line is ignored */
	private boolean isIgnored(String lineString) {
		if (!ignoreEmptyLines) {
			return false;
		}

		return StringUtils.isEmpty(lineString.trim());
	}

	/** Normalizes the line string */
	@Override
	protected String normalize(String lineString) {
		if (trimLines) {
			lineString = lineString.trim();
		}
		if (removeAllWhitespace) {
			lineString = lineString.replaceAll("\\s+", "");
		}
		return lineString;
	}
}

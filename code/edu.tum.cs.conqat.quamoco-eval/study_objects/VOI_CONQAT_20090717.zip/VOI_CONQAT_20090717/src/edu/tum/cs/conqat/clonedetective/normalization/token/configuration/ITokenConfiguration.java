/*--------------------------------------------------------------------------+
   $Id: ITokenConfiguration.java 21476 2009-05-26 09:41:35Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token.configuration;

/**
 * Configuration for token-based normalization.
 * <p>
 * Determines, how normalization is performed.
 * 
 * @author Florian Deissenboeck
 * @author $Author: juergens $
 * @version $Rev: 21476 $
 * @levd.rating GREEN Rev: 21476
 */
public interface ITokenConfiguration {

	/** Get name of this token configuration. */
	public String getName();

	/** Ignore delimiters? */
	public boolean isIgnoreDelimiters();

	/** Ignore comments? */
	public boolean isIgnoreComments();

	/** Ignore pre-processor directives? */
	public boolean isIgnorePreprocessorDirectives();
	
	/** Normalize identifiers? */
	public boolean isNormalizeIdentifiers();
	
	/** Normalize fully qualified names? */
	public boolean isNormalizeFullyQualifiedNames();
	
	/** Normalize type keywords? */
	public boolean isNormalizeTypeKeywords();

	/** Normalize string literals? */
	public boolean isNormalizeStringLiterals();

	/** Normalize char literals? */
	public boolean isNormalizeCharacterLiterals();

	/** Normalize number literals? */
	public boolean isNormalizeNumberLiterals();

	/** Normalize boolean literals? */
	public boolean isNormalizeBooleanLiterals();
	
	/** Ignore this reference? */
	public boolean isIgnoreThis();
	
	/** Ignore visibility modifier? */
	public boolean isIgnoreModifier();

}

/*--------------------------------------------------------------------------+
   $Id: TreeFlattener.java 18913 2009-03-11 13:54:26Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.util;

import java.util.List;

import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor flattens tree structures by adding all leaves directly to a
 * dummy root node.
 * 
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 18913 $
 * @levd.rating GREEN Rev: 18913
 */
@AConQATProcessor(description = "This processor flattens tree structures by "
		+ "adding all leaves directly to a dummy root node. Only values included "
		+ "in the display list will be copied to the flat result structure.")
public class TreeFlattener extends ConQATProcessorBase implements
		INodeVisitor<IConQATNode, NeverThrownRuntimeException> {

	/** Input node. */
	private IConQATNode input;

	/** Result node. */
	private ListNode result;

	/** The display list of the key being copied. */
	private List<String> displayList;

	/** Set the root element to work on. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setInput(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IConQATNode input) {
		this.input = input;
	}

	/** {@inheritDoc} */
	public ListNode process() {
		result = new ListNode(input.getId());
		displayList = NodeUtils.getDisplayList(input);
		result.setValue(NodeConstants.DISPLAY_LIST, displayList);
		result.setValue(NodeConstants.HIDE_ROOT, true);

		TraversalUtils.visitLeavesDepthFirst(this, input);
		return result;
	}

	/** Create child node, copy values and add to result root. */
	public void visit(IConQATNode node) {
		ListNode child = new ListNode(node.getId());
		for (String key : displayList) {
			child.setValue(key, node.getValue(key));
		}
		result.addChild(child);
	}

}

/*--------------------------------------------------------------------------+
   $Id: CollectionSizeProcessor.java 18913 2009-03-11 13:54:26Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.collections;

import java.util.Collection;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * A simple processor that creates a dummy ConQATNode and attaches the size of a
 * collection as value.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 18913 $
 * @levd.rating GREEN Rev: 18913
 */
@AConQATProcessor(description = "A simple processor that creates a dummy ConQATNode and attaches "
		+ "the size of a collection as value.")
public class CollectionSizeProcessor extends ConQATProcessorBase {

	/** The key to write the result into. */
	private String key;

	/** The collection. */
	private Collection<?> collection;

	/** Set the collection to measure. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The collection to measure.")
	public void setCollection(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			Collection<?> list) {
		this.collection = list;
	}

	/** Set the key used for writing the result. */
	@AConQATParameter(name = ConQATParamDoc.WRITEKEY_KEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The key to write the size into.")
	public void setWriteKey(
			@AConQATAttribute(name = ConQATParamDoc.WRITEKEY_KEY_NAME, description = ConQATParamDoc.WRITEKEY_KEY_DESC)
			String key) {
		this.key = key;
	}

	/** {@inheritDoc} */
	public IConQATNode process() {
		IConQATNode result = new ListNode();
		NodeUtils.addToDisplayList(result, key);
		result.setValue(key, collection.size());
		return result;
	}
}

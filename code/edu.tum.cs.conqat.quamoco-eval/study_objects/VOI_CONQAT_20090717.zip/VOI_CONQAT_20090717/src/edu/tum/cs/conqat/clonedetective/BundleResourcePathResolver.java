/*--------------------------------------------------------------------------+
   $Id: BundleResourcePathResolver.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective;

import edu.tum.cs.conqat.bundle.BundleResourceManager;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Resolves a bundle-relative resource path to an absolute path.
 * <p>
 * If no relative path (or the empty string) is given, the absolute path to the
 * resources directory of the bundle is returned.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "Resolves a path which is relative to the clonedetective bundle to an absolute path")
public class BundleResourcePathResolver extends ConQATProcessorBase {

	/** Relative path that gets resolved to an absolute path */
	private String relativePath = "";

	/** ConQAT Parameter */
	@AConQATParameter(name = "bundle-relative", description = "Bundle relative path", minOccurrences = 0, maxOccurrences = 1)
	public void setRelativePath(
			@AConQATAttribute(name = "path", description = "Bundle relative path")
			String relativePath) {
		this.relativePath = relativePath;
	}

	/** {@inheritDoc} */
	public String process() {
		BundleResourceManager rm = BundleContext.getInstance()
				.getResourceManager();

		return rm.getAbsoluteResourcePath(relativePath);
	}

}

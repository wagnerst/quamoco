/*--------------------------------------------------------------------------+
   $Id: CloneUnitsAnnotator.java 16957 2008-07-04 15:21:40Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.List;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.regions.Region;
import edu.tum.cs.conqat.filesystem.regions.RegionSet;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Annotates an element with the number of units that are part of at least one
 * clone.
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * 
 * @version $Revision: 16957 $
 * @levd.rating GREEN Rev: 16957
 */
@AConQATProcessor(description = "Computes the number of units of a class that are part of at "
		+ "least one clone.")
public class CloneUnitsAnnotator extends CloneAnnotatorBase {

	/** Key which is used to store the Clone Units value. */
	@AConQATKey(description = "Key that stores Clone units", type = "java.lang.Integer")
	public final static String CLONE_UNITS_KEY = "Clone Units";

	/** Makes CLONE_UNITS_KEY visible */
	@Override
	protected String[] getKeys() {
		return new String[] { CLONE_UNITS_KEY };
	}

	/** Annotates Clone Units metric at element */
	@Override
	protected void annotateClones(IFileSystemElement element,
			UnmodifiableList<IClone> clonesList) {
		element.setValue(CLONE_UNITS_KEY, calcCloneUnits(clonesList));
	}

	/**
	 * Computes the number of units of an element that are covered by at least
	 * one clone. This corresponds to the non-overlapping sum of the length of
	 * the clones annotated to this class, measured in units.
	 */
	private int calcCloneUnits(List<IClone> clones) {
		RegionSet regions = new RegionSet("clones");

		for (IClone clone : clones) {
			Region region = new Region(clone.getStartUnitIndexInFile(), clone
					.getStartUnitIndexInFile()
					+ clone.getLengthInUnits() - 1, "clone");
			regions.add(region);
		}

		return regions.getPositionCount();
	}

}

/*--------------------------------------------------------------------------+
   $Id: ConQATNodeBase.java 21942 2009-07-13 21:23:39Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.node;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.clone.CloneUtils;
import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableCollection;
import edu.tum.cs.conqat.commons.sorting.NameSorter;

/**
 * This is a base class to simplify the creation of new IConQATNode
 * implementations. Key value pairs are handled here and a copy constructor to
 * ease cloning exists.
 * 
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 21942 $
 * @levd.rating YELLOW Rev: 21942
 */
public abstract class ConQATNodeBase implements IConQATNode {

	/** value storage. */
	private final Map<String, Object> values = new HashMap<String, Object>();

	/** Constructor, sets comparator to name comparator. */
	protected ConQATNodeBase() {
		setValue(NodeConstants.COMPARATOR, NameSorter.NameComparator
				.getInstance());
	}

	/** Copy constructor. */
	protected ConQATNodeBase(ConQATNodeBase node) throws DeepCloneException {
		CloneUtils.cloneMapEntries(node.values, values);
	}

	/** Returns the ID of this node. */
	@Override
	public String toString() {
		return getId();
	}

	/** {@inheritDoc} */
	public Object getValue(String key) {
		return values.get(key);
	}

	/** {@inheritDoc} */
	public void setValue(String key, Object value) {
		values.put(key, value);
	}

	/** Returns the keys which are used for this node. */
	public UnmodifiableCollection<String> getKeys() {
		return CollectionUtils.asUnmodifiable(values.keySet());
	}
}

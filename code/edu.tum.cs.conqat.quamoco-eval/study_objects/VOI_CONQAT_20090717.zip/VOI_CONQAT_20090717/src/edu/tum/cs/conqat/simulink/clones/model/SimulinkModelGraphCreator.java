/*--------------------------------------------------------------------------+
   $Id: SimulinkModelGraphCreator.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.clones.model;

import java.util.IdentityHashMap;
import java.util.Map;

import edu.tum.cs.commons.visitor.IVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.simulink.clones.normalize.ISimulinkNormalizer;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;
import edu.tum.cs.simulink.model.SimulinkLine;
import edu.tum.cs.simulink.util.SimulinkUtils;

/**
 * Class used to create a {@link SimulinkModelGraph} from a
 * {@link ISimulinkElement}. This is not a processor, but instead called by a
 * processor directly.
 * 
 * @author hummelb
 * @author $Author:hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public class SimulinkModelGraphCreator implements
		IVisitor<SimulinkBlock, ConQATException> {

	/** The input being processed. */
	private final ISimulinkElement input;

	/** The normalizer. */
	private final ISimulinkNormalizer normalizer;

	/** The result. */
	private final SimulinkModelGraph result = new SimulinkModelGraph();

	/** Lookup from blocks to nodes. */
	private final Map<SimulinkBlock, SimulinkNode> blockMap = new IdentityHashMap<SimulinkBlock, SimulinkNode>();

	/** Constructor. */
	private SimulinkModelGraphCreator(ISimulinkElement rootNode,
			ISimulinkNormalizer normalizer) {
		input = rootNode;
		this.normalizer = normalizer;
	}

	/** Create and return the model graph. */
	private SimulinkModelGraph create() throws ConQATException {
		for (ISimulinkElement model : TraversalUtils
				.listLeavesDepthFirst(input)) {
			if (model instanceof SimulinkModelElement) {
				SimulinkUtils.visitDepthFirst(((SimulinkModelElement) model)
						.getModel(), this);
			}
		}

		for (SimulinkBlock block : blockMap.keySet()) {
			convertEdges(block);
		}
		return result;
	}

	/**
	 * Converts the given block to a {@link SimulinkNode} and registers it with
	 * {@link #blockMap}.
	 */
	public void visit(SimulinkBlock block) throws ConQATException {
		// only convert leaf blocks
		if (block.hasSubBlocks()) {
			return;
		}

		SimulinkNode node = new SimulinkNode(block, normalizer
				.normalizeBlock(block), normalizer.determineWeight(block));
		blockMap.put(block, node);
		result.addNode(node);
	}

	/** Convert the edges of the given block. */
	private void convertEdges(SimulinkBlock block) throws ConQATException {
		// we are using only outgoing lines to avoid duplication here
		for (SimulinkLine line : block.getOutLines()) {
			SimulinkNode sourceNode = blockMap
					.get(line.getSrcPort().getBlock());
			SimulinkNode targetNode = blockMap
					.get(line.getDstPort().getBlock());

			if (sourceNode == null || targetNode == null) {
				throw new ConQATException("Incomplete line: " + line);
			}
			result.addEdge(new SimulinkDirectedEdge(line, normalizer
					.normalizeLine(line), sourceNode, targetNode));
		}
	}

	/**
	 * Create the model graph from the given Simulink root node using the
	 * provided normalizations.
	 */
	public static SimulinkModelGraph createModelGraph(
			ISimulinkElement rootNode, ISimulinkNormalizer normalizer)
			throws ConQATException {
		return new SimulinkModelGraphCreator(rootNode, normalizer).create();
	}

}

package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.tum.cs.commons.algo.Diff;
import edu.tum.cs.commons.algo.Diff.Delta;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.collections.IdentityHashSet;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.GappedClone;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.clonedetective.core.IUnit;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.database.DatabaseProcessorBase;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * {@ConQAT.doc}
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 22038 $
 * @levd.rating RED Rev:
 */
@AConQATProcessor(description = "Updates clone positions according to edit operations")
public final class CloneUpdater extends DatabaseProcessorBase {

	/** Maps from source code element to contained clones */
	private final HashedListMap<String, IClone> clonesPerFile = new HashedListMap<String, IClone>();

	/** Root element of source code of new system version */
	private ISourceCodeElement newRoot;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "input", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "New root element")
	public void setRoot(
			@AConQATAttribute(name = "newRoot", description = "New root element") ISourceCodeElement newRoot) {
		this.newRoot = newRoot;
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = ConQATParamDoc.PREDECESSOR_NAME, description = ConQATParamDoc.PREDECESSOR_NAME_DESC)
	public void addPredecessor(
			@SuppressWarnings("unused") @AConQATAttribute(name = ConQATParamDoc.PREDECESSOR_REF_NAME, description = ConQATParamDoc.PREDECESSOR_REF_DESC) Object predecessor) {
		// do nothing
	}

	/** {@inheritDoc} */
	public CloneDetectionResultElement process() throws ConQATException {
		try {
			// get old and new timestamp from database
			UnitGateway unitGateway = new UnitGateway(dbConnection,
					UnitGateway.TABLE_NAME);
			Date oldTimestamp = unitGateway.getSecondLatestTimestamp();
			if (oldTimestamp == null) {
				return null;
			}

			Date newTimestamp = unitGateway.getLatestTimestamp();

			// load clones from database
			CloneClassGateway cloneClassGateway = new CloneClassGateway(
					dbConnection, tableName);
			List<CloneClass> oldCloneClasses = cloneClassGateway
					.selectClones(oldTimestamp);
			for (CloneClass oldCloneClass : oldCloneClasses) {
				for (IClone oldClone : oldCloneClass.getClones()) {
					clonesPerFile.add(oldClone.getOrigin(), oldClone);
				}
			}

			// create empty shells for all new clone classes
			Map<CloneClass, CloneClass> old2newCloneClass = createNewCloneClassesMap(oldCloneClasses);

			// compute new clones positions
			Map<String, IUnit[]> oldUnits = unitGateway
					.getUnitsFor(oldTimestamp);
			Map<String, IUnit[]> newUnits = unitGateway
					.getUnitsFor(newTimestamp);
			Set<IClone> deletedClones = createAdaptedClones(old2newCloneClass,
					oldUnits, newUnits, newTimestamp);

			// store death information of deleted clones
			if (!deletedClones.isEmpty()) {
				cloneClassGateway.getCloneGateway().storeDeaths(deletedClones);
			}

			// create new clone detection result
			ArrayList<CloneClass> cloneClasses = new ArrayList<CloneClass>(
					old2newCloneClass.values());
			ArrayList<CloneClass> filteredCloneClasses = new ArrayList<CloneClass>();
			for (CloneClass cloneClass : cloneClasses) {
				if (cloneClass.getClones().size() >= 2) {
					filteredCloneClasses.add(cloneClass);
				} else {
					System.err.println("Removed clone class: "
							+ cloneClass.getId());
				}
			}

			// store units in clones
			storeUnits(newUnits, filteredCloneClasses);

			return new CloneDetectionResultElement(oldTimestamp, newRoot,
					filteredCloneClasses);
		} catch (SQLException e) {
			throw new ConQATException("Problems with database:", e);
		}
	}

	/** Annotates each clone with a list of its units */
	private void storeUnits(Map<String, IUnit[]> newUnits,
			List<CloneClass> cloneClasses) {

		for (CloneClass cloneClass : cloneClasses) {
			for (IClone clone : cloneClass.getClones()) {
				String origin = StringUtils.stripPrefix(newRoot.getId(), clone
						.getOrigin());
				IUnit[] originUnits = newUnits.get(origin);
				List<IUnit> cloneUnits = Arrays.asList(originUnits).subList(
						clone.getStartUnitIndexInFile(),
						clone.getLastUnitInFile() + 1);
				CloneTrackerUtils.setUnits(clone, cloneUnits);
			}
		}

	}

	/** Computes new clones adapted to edit operations */
	private Set<IClone> createAdaptedClones(
			Map<CloneClass, CloneClass> old2newCloneClass,
			Map<String, IUnit[]> oldUnits, Map<String, IUnit[]> newUnits,
			Date newTimestamp) {

		FileRenameOracle oracle = new FileRenameOracle(oldUnits, newUnits);
		Set<IClone> deletedClones = new IdentityHashSet<IClone>();

		for (String oldOrigin : oldUnits.keySet()) {

			IUnit[] oldOriginUnits = oldUnits.get(oldOrigin);
			String newOrigin = oracle.newNameFor(oldOrigin);
			IUnit[] newOriginUnits = newUnits.get(newOrigin);

			if (newOriginUnits != null) {
				deletedClones.addAll(adaptClones(old2newCloneClass,
						oldOriginUnits, newOriginUnits, oldOrigin, newOrigin,
						newTimestamp));
			}
		}

		return deletedClones;
	}

	/** Adapt clone positions */
	private Set<IClone> adaptClones(
			Map<CloneClass, CloneClass> old2newCloneClass,
			IUnit[] oldOriginUnits, IUnit[] newOriginUnits, String oldOrigin,
			String newOrigin, Date newTimestamp) {

		Set<IClone> deletedClones = new IdentityHashSet<IClone>();

		Delta<IUnit> delta = Diff.computeDelta(oldOriginUnits, newOriginUnits);

		List<IClone> oldClones = clonesPerFile.getList(oldOrigin);
		if (oldClones != null) {
			for (IClone oldClone : oldClones) {
				try {
					CloneClass newCloneClass = old2newCloneClass.get(oldClone
							.getCloneClass());

					int newStartUnitIndexInFile = oldClone
							.getStartUnitIndexInFile();
					int lastUnitIndexInFile = newStartUnitIndexInFile
							+ oldClone.getLengthInUnits() - 1;

					RegionTracker tracker = new RegionTracker(
							newStartUnitIndexInFile, lastUnitIndexInFile);
					tracker.track(delta);
					if (tracker.getDeleted()) {
						// clone has been deleted
						oldClone.setDeath(newTimestamp);
						deletedClones.add(oldClone);
						continue;
					}

					newStartUnitIndexInFile = tracker.getStartPosition();
					lastUnitIndexInFile = tracker.getEndPosition();

					int newLengthInUnits = lastUnitIndexInFile
							- newStartUnitIndexInFile + 1;

					int newStartLineInFile = newOriginUnits[newStartUnitIndexInFile]
							.getStartLineInFile();
					int lastLine = newOriginUnits[lastUnitIndexInFile]
							.getStartLineInFile()
							+ newOriginUnits[lastUnitIndexInFile]
									.getCoveredLines();
					int newLengthInFile = lastLine - newStartLineInFile;
					String newFingerPrint = oldClone.getFingerprint();

					String fullOrigin = newRoot.getId() + newOrigin;
					// TODO (EJ) Compute sensible value
					int deltaInUnits = -1;
					GappedClone newClone = new GappedClone(oldClone.getId(),
							newCloneClass, fullOrigin, newStartLineInFile,
							newLengthInFile, newStartUnitIndexInFile,
							newLengthInUnits, newFingerPrint, deltaInUnits);
					newClone.setBirth(oldClone.getBirth());
					newClone.setDeath(oldClone.getDeath());
					CloneTrackerUtils.setOriginalStartLine(newClone, oldClone
							.getStartLineInFile());
					CloneTrackerUtils.setOriginalLastLine(newClone, oldClone
							.getLastLineInFile());
					newCloneClass.add(newClone);

				} catch (Throwable t) {
					System.err.println("Problems with: " + newOrigin
							+ ": Delta size: " + delta.getSize() + " message: "
							+ t.getMessage());
				}
			}
		}

		return deletedClones;
	}

	/**
	 * Create map from old to new clone classes. New clone classes are still
	 * empty.
	 */
	private Map<CloneClass, CloneClass> createNewCloneClassesMap(
			List<CloneClass> oldCloneClasses) {
		Map<CloneClass, CloneClass> old2newCloneClass = new IdentityHashMap<CloneClass, CloneClass>();
		for (CloneClass oldCloneClass : oldCloneClasses) {
			CloneClass newCloneClass = new CloneClass(oldCloneClass
					.getNormalizedLength(), oldCloneClass.getId());
			old2newCloneClass.put(oldCloneClass, newCloneClass);
		}
		return old2newCloneClass;
	}
}

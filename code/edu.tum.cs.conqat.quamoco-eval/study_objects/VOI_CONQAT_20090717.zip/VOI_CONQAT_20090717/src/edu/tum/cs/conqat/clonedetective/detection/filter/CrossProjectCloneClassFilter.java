/*--------------------------------------------------------------------------+
   $Id: CrossProjectCloneClassFilter.java 18905 2009-03-11 10:49:31Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection.filter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * This clone class filter can be used to determine clone classes that span
 * several projects. All clone classes that span less than a certain number of
 * projects are filtered out.
 * <p>
 * Membership of a clone in a project is determined by project-specific id
 * prefixes.
 * <p>
 * This processor can work on element ids or on filenames. By default, it works
 * on element ids (filenames for FileSystemElements, fully qualified class names
 * for JavaElements). It can set to work on file names by setting parameter
 * <code>workOnFilenames</code> to true.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 18905 $
 * @levd.rating GREEN Rev: 18905
 */
@AConQATProcessor(description = "Filters out clone classes that do not span a minimum number of different projects")
public class CrossProjectCloneClassFilter extends CloneClassFilterBase {

	/** List of project-specific prefixes */
	private final List<String> projectPrefixes = new ArrayList<String>();

	/** Minimum number of spanned projects */
	private int requiredProjectsCount = 2;

	/** Maps from element id to filename */
	private final Map<String, String> idToFilename = new HashMap<String, String>();

	/**
	 * Flag that determines whether filtering is performed on filenames instead
	 * of on ids.
	 */
	private boolean workOnFilenames = false;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "project", minOccurrences = 2, description = ""
			+ "Prefix of all file paths or ids of this project (typically project root directory or package)")
	public void addProjectPathPrefix(
			@AConQATAttribute(name = "prefix", description = "Prefix of all file paths or ids of this project") String projectPathPrefix) {
		this.projectPrefixes.add(projectPathPrefix);
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "workOnFilenames", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Flag that determines whether filtering is performed on filenames instead of on ids")
	public void setWorkOnFilenames(
			@AConQATAttribute(name = "value", description = "Default is to work on ids.") boolean workOnFilenames) {
		this.workOnFilenames = workOnFilenames;
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "projects", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Number of required projects")
	public void setRequiredProjectsCount(
			@AConQATAttribute(name = "count", description = "Number of required projects (default is 2)") int requiredProjectsCount) {
		this.requiredProjectsCount = requiredProjectsCount;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(CloneDetectionResultElement input) {
		if (workOnFilenames) {
			initIdToFilenameMapping(input);
		}
	}

	/** Initialize {@link #idToFilename} mapping */
	private void initIdToFilenameMapping(CloneDetectionResultElement input) {
		for (IFileSystemElement element : TraversalUtils
				.listLeavesDepthFirst(input)) {
			if (element.getFile().isFile()) {
				idToFilename.put(element.getId(), element.getFile()
						.getAbsolutePath());
			}
		}
	}

	/** Filters out clone classes that do not span enough projects */
	@Override
	protected boolean filteredOut(CloneClass cloneClass) {
		return computeSpannedProjects(cloneClass).size() < requiredProjectsCount;
	}

	/**
	 * Determines the set of projects spanned by a clone class. Projects are
	 * identified by their prefix.
	 */
	@SuppressWarnings("null")
	private Set<String> computeSpannedProjects(CloneClass cloneClass) {
		Set<String> spannedProjects = new HashSet<String>();

		for (IClone clone : cloneClass.getClones()) {
			String fileId = clone.getOrigin();
			if (workOnFilenames) {
				fileId = idToFilename.get(fileId);
				CCSMAssert.isTrue(fileId != null,
						"Clone origin not found in scope");
			}

			for (String projectPrefix : projectPrefixes) {
				if (fileId.startsWith(projectPrefix)) {
					spannedProjects.add(projectPrefix);
				}
			}
		}

		return spannedProjects;
	}

}

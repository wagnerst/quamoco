/*--------------------------------------------------------------------------+
   $Id: SourceFileDescriptor.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.report;

/**
 * Collects information about a source file that was analyzed during clone
 * detection. This class is immutable.
 * 
 * @author juergens
 * @author aswolins
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public class SourceFileDescriptor {

	/** The id that is used by clones to reference the file. */
	private final int id;

	/** The name of the file. */
	private final String filename;

	/** Length of the file */
	private final int length;

	/** String that identifies content of source file during detection */
	private final String fingerprint;

	/**
	 * @param id
	 *            Used to identify the source file.
	 * @param filename
	 *            Path of the file
	 * @param length
	 *            Char length of the file
	 */
	public SourceFileDescriptor(int id, String filename, int length,
			String fingerprint) {
		this.id = id;
		this.filename = filename;
		this.length = length;
		this.fingerprint = fingerprint;
	}

	/** The name of the file. */
	public String getFilename() {
		return filename;
	}

	/** The length of the file */
	public int getLength() {
		return length;
	}

	/** Id of the file. */
	public int getId() {
		return id;
	}

	/** Fingerprint of source file */
	public String getFingerprint() {
		return fingerprint;
	}
}

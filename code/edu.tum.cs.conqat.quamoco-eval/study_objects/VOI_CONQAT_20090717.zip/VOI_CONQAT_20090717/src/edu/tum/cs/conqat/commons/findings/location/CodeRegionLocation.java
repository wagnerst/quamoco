/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: CodeRegionLocation.java 21999 2009-07-15 20:43:23Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.location;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.filesystem.CanonicalFile;

/**
 * Location for code regions.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21999 $
 * @levd.rating YELLOW Rev: 21999
 */
public class CodeRegionLocation extends CodeLineLocation {

	/** The last line for the region (inclusive). */
	private final int lastLine;

	/** The position in the first line (zero based). */
	private final int firstPosition;

	/** The position in the last line (zero based) */
	private final int lastPosition;

	/** Constructor. */
	public CodeRegionLocation(CanonicalFile file, int firstLine, int lastLine) {
		this(file, firstLine, lastLine, 0, 0);
	}

	/** Constructor. */
	public CodeRegionLocation(CanonicalFile file, int firstLine, int lastLine,
			int firstPosition, int lastPosition) {
		super(file, firstLine);
		CCSMPre.isTrue(firstLine <= lastLine,
				"Invalid region with negative length!");
		this.lastLine = lastLine;
		this.firstPosition = firstPosition;
		this.lastPosition = lastPosition;
	}

	/** Returns the last line for the region (inclusive). */
	public int getLastLine() {
		return lastLine;
	}

	/** Returns the position in the first line (zero based). */
	public int getFirstPosition() {
		return firstPosition;
	}

	/** Returns the position in the last line (zero based) */
	public int getLastPosition() {
		return lastPosition;
	}

	/** Returns the length in lines. */
	public int getLengthInLines() {
		return lastPosition - firstPosition + 1;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return super.toString() + "-" + lastLine;
	}
}

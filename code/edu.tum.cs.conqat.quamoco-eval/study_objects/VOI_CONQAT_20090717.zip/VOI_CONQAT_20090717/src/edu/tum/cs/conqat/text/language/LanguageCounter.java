/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.text
 |                                                                       |
   $Id: LanguageCounter.java 21666 2009-06-24 15:13:22Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.language;

import java.util.EnumSet;
import java.util.List;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.analysis.FileAnalyzerBase;
import edu.tum.cs.conqat.sourcecode.library.SourceCodeLibrary;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.ETokenType.ETokenClass;

/**
 * {@ConQAT.doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21666 $
 * @levd.rating YELLOW Rev: 21666
 */
@AConQATProcessor(description = "This processor counts how often which language is used in selected token types.")
public class LanguageCounter extends FileAnalyzerBase<ISourceCodeElement> {

	/** Key for languages. */
	@AConQATKey(description = "Distribution of languages.", type = "edu.tum.cs.commons.collections.CounterSet<String>")
	public static final String KEY_LANG = "Lang";

	/** Set of token classes to include in analysis. */
	private final EnumSet<ETokenClass> tokenClasses = EnumSet
			.noneOf(ETokenClass.class);

	/** List of tokens to be ignored. */
	private PatternList ignorePattern;

	/** Add token class. */
	@AConQATParameter(name = "token", minOccurrences = 1, description = "Add a token class.")
	public void addTokenClass(
			@AConQATAttribute(name = "class", description = "Specifies "
					+ "token class.") ETokenClass tokenClass) {
		tokenClasses.add(tokenClass);
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "ignore", minOccurrences = 0, maxOccurrences = 1, description = "Set list of tokens to ignore.")
	public void setIgnorePattern(
			@AConQATAttribute(name = "list", description = "List of pattern which describes ignored tokens.") PatternList list) {
		ignorePattern = list;
	}

	/** {@inheritDoc} */
	@Override
	protected void analyzeFile(ISourceCodeElement element) {
		List<IToken> tokens;
		try {
			tokens = SourceCodeLibrary.getInstance().getTokens(element);
		} catch (ConQATException e) {
			getLogger().warn("Empty source element: " + element);
			return;
		}

		CounterSet<String> languages = new CounterSet<String>();
		for (IToken token : tokens) {
			if (tokenClasses.contains(token.getType().getTokenClass())) {
				if (ignorePattern == null
						|| !ignorePattern.matchesAny(token.getText())) {
					languages.inc(LanguageDecider.decideLanguage(token
							.getText()));
				}
			}
		}
		element.setValue(KEY_LANG, languages);
	}

	/** {@inheritDoc} */
	@Override
	protected String[] getKeys() {
		return new String[] { KEY_LANG };
	}

}

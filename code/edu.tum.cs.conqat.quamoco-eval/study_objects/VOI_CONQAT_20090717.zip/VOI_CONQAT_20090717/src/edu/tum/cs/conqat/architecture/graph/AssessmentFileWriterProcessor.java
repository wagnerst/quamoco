package edu.tum.cs.conqat.architecture.graph;

import java.io.File;
import java.io.IOException;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;

/**
 * {@ConQAT.doc}
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 21621 $
 * @levd.rating GREEN Rev: 21621
 */
@AConQATProcessor(description = "Writes a ConQATGraph containing architecture assessments to a file.")
public class AssessmentFileWriterProcessor extends
		ConQATPipelineProcessorBase<ConQATGraph> {

	/** File that gets written */
	private File targetFile;

	/** {@ConqAT.doc} */
	@AConQATParameter(name = "output", minOccurrences = 0, maxOccurrences = 1, description = "Name of the output directory")
	public void setOutputDirectory(
			@AConQATAttribute(name = "dir", description = "Name of the output directory") String outputDir,
			@AConQATAttribute(name = "filename", description = "Name of the file that gets written") String reportName) {

		targetFile = new File(outputDir, reportName);
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) throws ConQATException {
		// return if no file set
		if (targetFile == null) {
			return;
		}

		// write graph
		try {
			FileSystemUtils.ensureParentDirectoryExists(targetFile);
			new AssessmentFileWriter(targetFile, graph, getLogger())
					.writeGraph();
		} catch (IOException e) {
			throw new ConQATException("Could not write file", e);
		}
	}

}

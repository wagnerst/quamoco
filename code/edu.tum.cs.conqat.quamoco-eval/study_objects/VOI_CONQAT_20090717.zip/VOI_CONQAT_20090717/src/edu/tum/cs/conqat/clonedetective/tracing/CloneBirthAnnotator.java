package edu.tum.cs.conqat.clonedetective.tracing;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.IClone;
import edu.tum.cs.conqat.clonedetective.result.annotation.CloneAnnotatorBase;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Annotates each class with the creation date of its youngest clone.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 21499 $
 * @levd.rating RED Rev: 
 */
@AConQATProcessor(description = "Annotates each class with the creation date of its youngest clone.")
public class CloneBirthAnnotator extends CloneAnnotatorBase {

	/** Key */
	@AConQATKey(description = "Date at which the youngest clone in this file was born", type = "java.util.Date")
	private static final String KEY = "Latest clone";

	/** {@inheritDoc} */
	@Override
	protected void annotateClones(IFileSystemElement element,
			UnmodifiableList<IClone> clonesList) {

		List<Date> births = new ArrayList<Date>();
		for (IClone clone : clonesList) {
			Date birth = clone.getBirth();
			births.add(birth);
		}

		Date latestBirth = getLatest(births);
		element.setValue(KEY, latestBirth);
	}

	// TODO (EJ) Move this into some commons library?
	/** Returns the latest date in a list of dates */
	private Date getLatest(List<Date> dates) {
		if (dates == null || dates.isEmpty()) {
			return null;
		}

		Date latest = dates.get(0);
		for (Date date : dates) {
			if (date.after(latest)) {
				latest = date;
			}
		}

		return latest;
	}

	/** {@inheritDoc} */
	@Override
	protected String[] getKeys() {
		return new String[] { KEY };
	}
}

/*--------------------------------------------------------------------------+
   $Id: UnitDrain.java 21683 2009-06-25 20:41:05Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.IUnit;
import edu.tum.cs.conqat.clonedetective.core.IUnitProvider;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Drains units from an {@link IUnitProvider} into a list.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 21683 $
 * @levd.rating YELLOW Rev: 21683
 */
/* package */class UnitDrain {

	/** Logger used to issue status messages */
	private final IConQATLogger logger;

	/**
	 * If this string is set to a non-empty value, a debug file (containing the
	 * normalized units) is written for each input file.
	 */
	private final String debugFileExtension;

	/**
	 * Key that contains flag that determines whether file gets ignored.
	 * Influences log message generation, but not unit draining.
	 */
	private final String ignoreKey;

	/**
	 * Constructor
	 * 
	 * @param logger
	 *            logger of the processor that executes the {@link UnitDrain}.
	 */
	/* package */UnitDrain(IConQATLogger logger, String debugFileExtension,
			String ignoreKey) {
		this.logger = logger;
		this.debugFileExtension = debugFileExtension;
		this.ignoreKey = ignoreKey;
	}

	/** Determines all units used for clone detection */
	public List<IUnit> drainUnits(IFileSystemElement input,
			IUnitProvider<IFileSystemElement, IUnit> unitProvider)
			throws CloneDetectionException {
		// include sentinelizer
		unitProvider = new Sentinelizer(unitProvider);

		// read units from unit provider
		logger.debug("Before unit drain...");
		List<IUnit> units = drainUnitProvider(input, unitProvider);
		logger.debug("Units drained:" + units.size());

		// write debug files
		if (!StringUtils.isEmpty(debugFileExtension)) {
			writeDebugFiles(units);
		}

		// mark files without units
		logEmptyFiles(input);

		return units;
	}

	/**
	 * Writes a debug file for each input file. The debug file contains the
	 * units after normalization (in the same line numbers as in the original
	 * file). The name of the debug file is the name of the original file with
	 * the debugFileExtension.
	 */
	private void writeDebugFiles(List<IUnit> units) {
		HashedListMap<String, IUnit> fileUnits = new HashedListMap<String, IUnit>();
		for (IUnit unit : units) {
			fileUnits.add(unit.getOriginId(), unit);
		}

		for (String origin : fileUnits.getKeys()) {
			List<IUnit> unitsInFile = fileUnits.getList(origin);
			File debugFile = new File(origin + debugFileExtension);
			writeDebugFile(debugFile, unitsInFile);
		}
	}

	/**
	 * Writes a single debug file.
	 * 
	 * @param debugFile
	 *            Debug file to write
	 * @param unitsInFile
	 *            List of units that gets written into the file
	 */
	private void writeDebugFile(File debugFile, List<IUnit> unitsInFile) {
		int line = 0;
		StringBuilder content = new StringBuilder();
		for (IUnit unit : unitsInFile) {
			while (unit.getStartLineInFile() > line) {
				content.append(StringUtils.CR);
				line++;
			}
			content.append(unit.getContent());
		}

		try {
			FileSystemUtils.writeFile(debugFile, content.toString());
		} catch (IOException e) {
			logger.warn("Could not write debug file: " + debugFile + ": "
					+ e.getMessage());
		}
	}

	/**
	 * Searches for files with 0 units used for clone detection and creates log
	 * messages accordingly. The underlying assumption is that a file that is
	 * included in clone detection, yet does not contain a single unit that gets
	 * used for clone detection, can potentially indicate a configuration
	 * problem.
	 * <p>
	 * If a file is marked as ignore, no warning is created
	 */
	private void logEmptyFiles(IFileSystemElement input) {
		List<IFileSystemElement> elements = TraversalUtils
				.listLeavesDepthFirst(input);

		for (IFileSystemElement element : elements) {
			if (element.getValue(CloneDetectorBase.UNITS_KEY) == null) {
				element.setValue(CloneDetectorBase.UNITS_KEY, 0);

				if (element.getFile() != null && !ignored(element)) {
					logger.debug("File " + element.getFile().getAbsolutePath()
							+ " has 0 non-ignored units.");
				}
			}
		}
	}

	/** Determines whether a file is marked as ignored */
	private boolean ignored(IFileSystemElement element) {
		Object ignore = element.getValue(ignoreKey);
		return ignore != null && Boolean.valueOf(ignore.toString()) == true;
	}

	/**
	 * Retrieves all units from the unitProvider and stores them in a list
	 * <p>
	 * Additionally, the number of units encountered in a file is stored at the
	 * corresponding element. However, no unit count value is stored at file
	 * elements that don't contain a single unit.
	 */
	private List<IUnit> drainUnitProvider(IFileSystemElement input,
			IUnitProvider<IFileSystemElement, IUnit> unitProvider)
			throws CloneDetectionException {

		// initialize lazy pipeline with input
		unitProvider.init(input, logger);

		// drain units into list
		List<IUnit> units = new ArrayList<IUnit>();
		IUnit unit = unitProvider.getNext();

		int unitsInFileCount = 0;
		Map<String, IFileSystemElement> elementsMap = TraversalUtils
				.createIdToNodeMap(input);
		while (unit != null) {
			units.add(unit);
			// ignore synthetic units, since they are not part of the file
			if (!unit.isSynthetic()) {
				unitsInFileCount++;
			}
			IUnit nextUnit = unitProvider.getNext();
			if (lastUnitInFile(unit, nextUnit)) {
				elementsMap.get(unit.getOriginId()).setValue(
						CloneDetectorBase.UNITS_KEY, unitsInFileCount);
				unitsInFileCount = 0;
			}

			unit = nextUnit;
		}

		// check if any units were found
		if (units.size() == 0) {
			throw new CloneDetectionException(
					"Empty input encountered! Clone detection aborted.");
		}

		// return units
		return units;
	}

	/** Checks whether a unit is the last unit from its file */
	private boolean lastUnitInFile(IUnit unit, IUnit nextUnit) {
		return nextUnit == null
				|| !unit.getOriginId().equals(nextUnit.getOriginId());
	}

}

/*--------------------------------------------------------------------------+
   $Id: IProvider.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import edu.tum.cs.conqat.clonedetective.lazyscope.IElementProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.ITokenProvider;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Base interface for components that work on {@link IFileSystemElement} trees
 * and provide data objects in a stepwise, lazy fashion.
 * <p>
 * The root of the {@link IFileSystemElement} tree from which data objects are
 * provided is set in the
 * {@link IProvider#init(IFileSystemElement, IConQATLogger)} method. It must be
 * called before the first call to {@link IProvider#getNext()}.
 * <p>
 * See {@link IElementProvider}, {@link ITokenProvider} or
 * {@link IUnitProvider} for examples of provided data elements.
 * 
 * @param <Element>
 *            Element type this processor works on.
 * 
 * @param <Data>
 *            Data type returned by {@link #getNext()}.
 * 
 * @param <X>
 *            Exception that gets thrown by {@link #getNext()} and
 *            {@link #init(IFileSystemElement, IConQATLogger)}
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public interface IProvider<Element extends IFileSystemElement, Data, X extends Exception> {

	/**
	 * Get next data object.
	 * 
	 * @return The next unit or <code>null</code> if all data objects have
	 *         been returned.
	 */
	public Data getNext() throws X;

	/**
	 * Offers the ability to perform lookahead in the provider. Returned
	 * elements remain in the provider and are still accessible via
	 * {@link #getNext()}
	 * 
	 * @param index
	 *            Number of elements that are looked ahead
	 * 
	 * @return Element at index, or null, if the provider doesn't contain that
	 *         many elements anymore
	 */
	public Data lookahead(int index) throws X;

	/**
	 * Initialize the {@link IProvider} with the root of the
	 * {@link IFileSystemElement} tree it works on.
	 * 
	 * @param root
	 *            root of tree from which data objects are provided.
	 * @param logger
	 *            Logger from the processor that executes this provider
	 */
	public void init(Element root, IConQATLogger logger) throws X;

}

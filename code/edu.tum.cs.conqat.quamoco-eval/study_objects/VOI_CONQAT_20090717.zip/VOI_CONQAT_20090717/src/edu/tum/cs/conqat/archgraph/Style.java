/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.archgraph
 |                                                                       |
   $Id: Style.java 20651 2009-03-26 14:25:44Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.archgraph;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

/**
 * Style settings used for rendering graphs. Contains constants for all
 * rendering aspects. The three colors for assessments can be configured by
 * putting {@link java.awt.Color} objects with the keys {@link #RED_COLOR_KEY},
 * {@link #YELLOW_COLOR_KEY} and {@link #GREEN_COLOR_KEY} respectively.
 * 
 * @author kanis
 * @author $Author: juergens $
 * @version $Rev: 20651 $
 * @levd.rating GREEN Rev: 20651
 */
public class Style extends HashMap<String, Object> {

	/** Key constant for "red" color. */
	public static final String RED_COLOR_KEY = "red-color";

	/** Key constant for "yellow" color. */
	public static final String YELLOW_COLOR_KEY = "yellow-color";

	/** Key constant for "green" color. */
	public static final String GREEN_COLOR_KEY = "green-color";

	/** Distance from the image border to it's contents. */
	/* package */static final int BORDER_WIDTH = 10;

	/** The radius in pixels for RoundRect vertices. */
	/* package */static final int CORNER_RADIUS = 10;

	/** The font size for the label of vertices. */
	/* package */static final float FONT_SIZE = 11f;

	/** The left/right margin of labels. */
	/* package */static final int HORIZONTAL_LABEL_MARGIN = 8;

	/** Pixels to place a label below the a border. */
	/* package */static final int VERTICAL_LABEL_MARGIN = 5;

	/** The size of the barb on the end of edges. */
	/* package */static final int ARROW_BARB = 12;

	/** The angle for the barb on the end of edges. */
	/* package */static final double ARROW_PHI = Math.toRadians(20);

	/** The minimum width of a component */
	/* package */static final int COMPONENT_MINIMUM_WIDTH = 120;

	/** The minimum height of a component */
	/* package */static final int COMPONENT_MINIMUM_HEIGHT = 40;

	/** The width to draw connections with. */
	/* package */static final float LINE_WIDTH = 1;

	/** The default red from the palette of the Tango project. */
	private static final Color DEFAULT_RED_COLOR = new Color(0xcc0000);

	/** The default yellow from the palette of the Tango project. */
	private static final Color DEFAULT_YELLOW_COLOR = new Color(0xedd400);

	/** The default green from the palette of the Tango project. */
	private static final Color DEFAULT_GREEN_COLOR = new Color(0x4e9a06);

	/** Holds all the default settings. */
	private static final Map<String, Object> DEFAULTS = new HashMap<String, Object>();

	static {
		DEFAULTS.put(Style.RED_COLOR_KEY, DEFAULT_RED_COLOR);
		DEFAULTS.put(Style.YELLOW_COLOR_KEY, DEFAULT_YELLOW_COLOR);
		DEFAULTS.put(Style.GREEN_COLOR_KEY, DEFAULT_GREEN_COLOR);
	}

	/**
	 * {@link Style#getDefault()} says more clearly what the new Style really
	 * is.
	 */
	private Style() {
		// do nothing
	}

	/** Returns a new style object with all settings set to default values. */
	public static Style getDefault() {
		return new Style();
	}

	/** {@inheritDoc} */
	@Override
	public Object get(Object key) {
		Object value = super.get(key);
		if (value != null) {
			return value;
		}

		value = DEFAULTS.get(key);
		if (value != null) {
			return value;
		}

		throw new IllegalArgumentException(key + " is no valid style setting.");
	}
}

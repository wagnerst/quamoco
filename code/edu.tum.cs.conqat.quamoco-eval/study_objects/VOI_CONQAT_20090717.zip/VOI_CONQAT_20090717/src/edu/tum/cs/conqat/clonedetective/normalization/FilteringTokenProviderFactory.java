/*--------------------------------------------------------------------------+
   $Id: FilteringTokenProviderFactory.java 18738 2009-03-07 07:57:52Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization;

import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.conqat.clonedetective.normalization.token.FilteringTokenProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.ITokenProvider;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.regions.RegionSet;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Filters the tokens provided by another token provider according to the filter
 * regions stored in the corresponding {@link IFileSystemElement}.
 * 
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * 
 * @version $Revision: 18738 $
 * @levd.rating GREEN Rev: 18738
 */
@AConQATProcessor(description = "Creates an ITokenProvider that only returns tokens that are not contained in a filtered region.")
public class FilteringTokenProviderFactory extends ConQATProcessorBase {

	/** Token provider whose tokens are filtered */
	private ITokenProvider tokenProvider;

	/**
	 * Names of the {@link RegionSet}s that for which matching tokens are
	 * filtered out.
	 */
	private final Set<String> ignoreRegionSetNames = new HashSet<String>();

	/** Token ignore patters. */
	private PatternList ignorePatterns = new PatternList();

	/** {@ConQAT.doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setTokenProvider(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			ITokenProvider tokenProvider) {
		this.tokenProvider = tokenProvider;
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "ignore-region-set", minOccurrences = 1, description = ""
			+ "Adds the name of a region set for which tokens are filtered out")
	public void addFilteredRegionsName(
			@AConQATAttribute(name = "name", description = "Name of the region set")
			String ignoreRegionSetName) {
		ignoreRegionSetNames.add(ignoreRegionSetName);
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "ignore-patterns", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Tokens that are matched by one of the patterns are ignored")
	public void setIgnorePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			PatternList ignorePatterns) {
		this.ignorePatterns = ignorePatterns;
	}

	/** Creates a FilteringTokenProvider */
	public ITokenProvider process() {
		return new FilteringTokenProvider(tokenProvider, ignoreRegionSetNames,
				ignorePatterns);
	}

}

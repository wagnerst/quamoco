/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.architecture
 |                                                                       |
   $Id: ECodeMappingType.java 21403 2009-05-13 07:07:05Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.format;

/**
 * An enumeration for code mapping types.
 * 
 * @author poehlmann
 * @author $Author: juergens $
 * @version $Rev: 21403 $
 * @levd.rating GREEN Rev: 21403
 */
public enum ECodeMappingType {

	/** Value 'include'. */
	INCLUDE,

	/** Value 'exclude'. */
	EXCLUDE;

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return name().toLowerCase();
	}
}

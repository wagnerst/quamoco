/*--------------------------------------------------------------------------+
   $Id: SourceCodeElementProviderFactory.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * Creates a {@link SourceCodeElementProvider}.
 * <p>
 * This class could be unified with {@link FileSystemElementProvider} using
 * generics. However, since the ConQAT load time type checking mechanism cannot
 * deal with generics, this was deliberately not done.
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * 
 * @version $Revision: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "Creates a SourceCodeElementProvider")
public class SourceCodeElementProviderFactory extends ConQATProcessorBase {

	/** Key under which ignore flag is stored */
	private String ignoreKey;

	/** ConQAT Parameter */
	@AConQATParameter(name = "ignore", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Key under which ignore flag is stored.")
	public void setIgnoreKey(
			@AConQATAttribute(name = "key", description = "If no key is given, no files are ignored")
			String ignoreKey) {
		this.ignoreKey = ignoreKey;
	}

	/** Creates a {@link SourceCodeElementProvider} */
	public ElementProviderBase<ISourceCodeElement> process() {
		return new SourceCodeElementProvider(ignoreKey);
	}
}

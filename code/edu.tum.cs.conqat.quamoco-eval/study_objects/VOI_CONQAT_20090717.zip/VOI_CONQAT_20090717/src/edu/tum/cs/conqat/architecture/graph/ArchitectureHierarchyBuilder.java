/*--------------------------------------------------------------------------+
   $Id: ArchitectureHierarchyBuilder.java 21602 2009-06-09 16:48:58Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import edu.tum.cs.conqat.architecture.scope.ComponentNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphInnerNode;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphUtils;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;

/**
 * This processor rebuilds the hierarchy of a ConQATGraph according to a given
 * architecture.
 * <p>
 * It is used to condense the actual dependency graph of a project according to
 * an architecture definition.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 21602 $
 * @levd.rating YELLOW Rev: 21602
 */
@AConQATProcessor(description = "This processor rebuilds the hierarchy of a "
		+ "ConQATGraph according to a given architecture.")
public class ArchitectureHierarchyBuilder extends ArchGraphPipelineBase {

	/** Lookup from component nodes to corresponding graph nodes. */
	private final Map<ComponentNode, ConQATGraphInnerNode> nodeLookup = new HashMap<ComponentNode, ConQATGraphInnerNode>();

	/**
	 * ID for elements w/o a component. Used for unknown dependencies. This one
	 * need to be long enough to represent a unique id.
	 */
	public static final String ORPHANED_ELEMENTS_ID = "elements without component";

	/**
	 * Name for elements w/o a component. Used for unknown dependencies. This
	 * one needs to be short in order to be displayed in the default rendered
	 * component.
	 */
	public static final String ORPHANED_ELEMENTS_NAME = "unknown";

	/** Key under which the set of matched types is stored */
	public static final String MATCHED_TYPES_KEY = "matched_types";

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) throws ConQATException {
		NodeUtils.addToDisplayList(graph,
				ArchitectureDefinitionVisualizer.COMPONENT_DIMENSION,
				ArchitectureDefinitionVisualizer.COMPONENT_POSITION);

		// flatten hierarchy
		ConQATGraphUtils.collapseHierarchy(graph);
		// build hierarchy defined by architecture
		createGraphHierarchyFromArchitecture(arch, graph);

		ConQATGraphInnerNode unknownNode = null;
		for (ConQATVertex vertex : new ArrayList<ConQATVertex>(graph
				.getVertices())) {
			ComponentNode comp = resolver.findComponentFor(vertex);

			ConQATGraphInnerNode targetNode;
			if (comp == null) {
				if (unknownNode == null) {
					unknownNode = graph.createChildNode(ORPHANED_ELEMENTS_ID,
							ORPHANED_ELEMENTS_NAME);
				}
				targetNode = unknownNode;
			} else {
				targetNode = nodeLookup.get(comp);
			}
			annotateMatchedVertex(vertex, targetNode);
			vertex.relocate(targetNode);
		}
	}

	/**
	 * Stores information that vertex was matched to component in component for
	 * later retrieval
	 */
	@SuppressWarnings("unchecked")
	private void annotateMatchedVertex(ConQATVertex vertex,
			ConQATGraphInnerNode targetNode) throws ConQATException {
		if (targetNode.getValue(MATCHED_TYPES_KEY) == null) {
			targetNode.setValue(MATCHED_TYPES_KEY, new HashSet<String>());
		}

		Set<String> vertices = NodeUtils.getValue(targetNode,
				MATCHED_TYPES_KEY, Set.class);
		vertices.add(vertex.getId());
	}

	/** Recreate the arch hierarchy for the graph. */
	private void createGraphHierarchyFromArchitecture(ComponentNode comp,
			ConQATGraphInnerNode node) throws ConQATException {
		nodeLookup.put(comp, node);
		if (comp.hasChildren()) {
			for (ComponentNode child : comp.getChildren()) {
				ConQATGraphInnerNode childNode = node.createChildNode(child
						.getName(), child.getName());

				// copy layout keys
				childNode.setValue(
						ArchitectureDefinitionVisualizer.COMPONENT_POSITION,
						child.getAbsolutePosition());
				childNode.setValue(
						ArchitectureDefinitionVisualizer.COMPONENT_DIMENSION,
						child.getDimension());

				createGraphHierarchyFromArchitecture(child, childNode);
			}
		}
	}
}

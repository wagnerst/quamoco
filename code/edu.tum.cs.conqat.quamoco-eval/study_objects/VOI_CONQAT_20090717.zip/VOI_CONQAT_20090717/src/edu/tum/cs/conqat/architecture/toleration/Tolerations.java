/*--------------------------------------------------------------------------+
   $Id: Tolerations.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.toleration;

import java.util.List;

import edu.tum.cs.commons.collections.HashedListMap;

/**
 * List of Tolerations.
 * 
 * @author juergens
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public class Tolerations {

	/**
	 * Maps from tolerated source IDs to lists of target IDs. We use a list map,
	 * although a set would be better for lookup, as we expect the number of
	 * tolerations to be relatively low.
	 */
	private final HashedListMap<String, String> tolerations = new HashedListMap<String, String>();

	/** Adds a Toleration to the list */
	public void addToleration(String sourceId, String targetId) {
		tolerations.add(sourceId, targetId);
	}

	/** Returns true, if the dependency from sourceId to targetId is tolerated. */
	public boolean tolerated(String sourceId, String targetId) {
		List<String> toleratedFromSource = tolerations.getList(sourceId);
		return toleratedFromSource != null
				&& toleratedFromSource.contains(targetId);
	}
}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.archgraph
 |                                                                       |
   $Id: PaintableVertex.java 21612 2009-06-10 20:56:51Z deissenb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.archgraph;

import static edu.tum.cs.conqat.architecture.graph.ArchitectureDefinitionVisualizer.COMPONENT_DIMENSION;
import static edu.tum.cs.conqat.architecture.graph.ArchitectureDefinitionVisualizer.COMPONENT_POSITION;
import static edu.tum.cs.conqat.architecture.graph.UnnecessaryPolicyAnnotator.PROXY_FOR_KEY;
import static java.awt.RenderingHints.KEY_ANTIALIASING;
import static java.awt.RenderingHints.VALUE_ANTIALIAS_OFF;
import static java.awt.RenderingHints.VALUE_ANTIALIAS_ON;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Rectangle;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.graph.nodes.IConQATGraphNode;

/**
 * A Vertex that can be painted by {@link LayoutedGraphRenderer}. Uses some code
 * from org.eclipse.draw2d.ChopboxAnchor.
 * 
 * @author kanis
 * @author $Author: deissenb $
 * @version $Rev: 21612 $
 * @levd.rating YELLOW Rev: 21612
 */
public class PaintableVertex {

	/** Dummy point for vertices that have no real position information. */
	/* package */static final Point DUMMY_POINT = new Point(-1, -1);

	/** The model for this graphical vertex. */
	private final IConQATGraphNode model;

	/** Constructor. */
	public PaintableVertex(IConQATGraphNode model) {
		this.model = model;
	}

	/** Paints the vertex to the given {@link Graphics2D} context. */
	public void paint(Graphics2D g2d) {
		// bail out, if the vertex has no real position information
		if (getPosition() == DUMMY_POINT) {
			return;
		}

		// also don't paint proxy components
		if (model.getValue(PROXY_FOR_KEY) != null) {
			return;
		}

		// draw rect with AA disabled as it looks weird for some reason
		g2d.setRenderingHint(KEY_ANTIALIASING, VALUE_ANTIALIAS_OFF);

		Paint oldPaint = g2d.getPaint();
		g2d.setPaint(new GradientPaint(0, 0, Color.white, 0,
				getDimension().height, new Color(230, 230, 255)));

		g2d.fillRoundRect(0, 0, getDimension().width, getDimension().height,
				Style.CORNER_RADIUS, Style.CORNER_RADIUS);
		g2d.setPaint(oldPaint);

		g2d.drawRoundRect(0, 0, getDimension().width, getDimension().height,
				Style.CORNER_RADIUS, Style.CORNER_RADIUS);

		if (getName() != null) {
			g2d.setRenderingHint(KEY_ANTIALIASING, VALUE_ANTIALIAS_ON);

			g2d.setFont(g2d.getFont().deriveFont(Style.FONT_SIZE));

			FontMetrics metrics = g2d.getFontMetrics();
			int vMargin = metrics.getAscent() + Style.VERTICAL_LABEL_MARGIN;

			g2d.drawString(stripName(getName(), metrics),
					Style.HORIZONTAL_LABEL_MARGIN, vMargin);
			g2d.drawLine(Style.HORIZONTAL_LABEL_MARGIN, vMargin + 2,
					getDimension().width - Style.HORIZONTAL_LABEL_MARGIN,
					vMargin + 2);
		}
	}
	
	/** Strip name if required. */
	private String stripName(String name, FontMetrics metrics) {
		if (fitsDimensions(name, metrics)) {
			return name;
		}
		return abbrName(name, metrics);
	}

	
	/** Abbreviate the name until it fits the vertex. */
	private String abbrName(String name, FontMetrics metrics) {
		// cannot abbreviate
		if (StringUtils.isEmpty(name)) {
			return name;
		}
		String abbrName = name + "...";
		if (fitsDimensions(abbrName, metrics)) {
			return abbrName;
		}
		return abbrName(name.substring(0, name.length() - 1), metrics);
	}
	
	/** Checks if a string fits the dimensions of this vertex. */
	private boolean fitsDimensions(String name, FontMetrics metrics) {
		return metrics.stringWidth(name) < getDimension().width
				- Style.HORIZONTAL_LABEL_MARGIN;
	}

	/** Returns the position retrieved from the model. */
	public Point getPosition() {
		if (model.getValue(COMPONENT_POSITION) == null) {
			return DUMMY_POINT;
		}
		return (Point) model.getValue(COMPONENT_POSITION);
	}

	/**
	 * Convenience method for setting the position in this PaintableVertex'
	 * model.
	 */
	public void setPosition(Point position) {
		CCSMPre.isFalse(position == null,
				"Position my not be null for paintable vertices.");
		model.setValue(COMPONENT_POSITION, position);
	}

	/** Returns the dimension retrieved from the model. */
	public Dimension getDimension() {
		Dimension dim = (Dimension) model.getValue(COMPONENT_DIMENSION);
		if (dim == null) {
			dim = new Dimension(Style.COMPONENT_MINIMUM_WIDTH,
					Style.COMPONENT_MINIMUM_HEIGHT);
		}
		return dim;
	}

	/** Returns model. */
	public IConQATGraphNode getModel() {
		return model;
	}

	/** Convenience method for getting the name from the model. */
	private String getName() {
		return model.getName();
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return PaintableVertex.class.getName() + " (" + getName() + " "
				+ getPosition().toString() + ", " + getDimension().toString()
				+ ")";
	}

	/**
	 * The ChopboxAnchor's location is found by calculating the intersection of
	 * a line drawn from the center point of to a reference point on that box.
	 * Code borrowed from org.eclipse.draw2d.ChopboxAnchor.
	 */
	public Point getChopboxAnchor(Point reference) {
		Rectangle rectangle = new Rectangle(getDimension());
		rectangle.setSize(rectangle.width + 1, rectangle.height + 1);
		rectangle.translate(getPosition().x - 1, getPosition().y - 1);

		Point center = getCenter();

		if (rectangle.isEmpty()
				|| (reference.x == center.x && reference.y == center.y)) {
			// This avoids divide-by-zero
			return new Point(center.x, center.y);
		}

		float dx = reference.x - center.x;
		float dy = reference.y - center.y;

		// r.width, r.height, dx, and dy are guaranteed to be non-zero.
		float scale = 0.5f / Math.max(Math.abs(dx) / rectangle.width, Math
				.abs(dy)
				/ rectangle.height);

		dx *= scale;
		dy *= scale;
		center.x += dx;
		center.y += dy;

		return new Point(Math.round(center.x), Math.round(center.y));
	}

	/** Returns the center of this vertex's shape. */
	public Point getCenter() {
		Point p = new Point(getDimension().width / 2, getDimension().height / 2);
		p.translate(getPosition().x, getPosition().y);
		return p;
	}
}

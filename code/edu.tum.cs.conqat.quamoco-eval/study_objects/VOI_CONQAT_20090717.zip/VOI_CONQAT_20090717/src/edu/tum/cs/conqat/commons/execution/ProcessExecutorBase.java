/*--------------------------------------------------------------------------+
   $Id: ProcessExecutorBase.java 21972 2009-07-15 09:51:51Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.execution;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.io.ProcessUtils;
import edu.tum.cs.commons.io.ProcessUtils.ExecutionResult;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.logging.ELogLevel;

/**
 * Base class for processors that execute external processes.
 * 
 * 
 * @author deissenb
 * @author $Author: deissenb $
 * @version $Rev: 21972 $
 * @levd.rating YELLOW Rev: 21972
 */
public abstract class ProcessExecutorBase extends ConQATProcessorBase {

	/** Documentation to be reused in subclasses. */
	protected static final String PROCESSOR_DESCRIPTION = "The argument that "
			+ "specifies the output file must be provided via the 'output-file-argument' "
			+ "parameter. Care needs to be taken if the order of the arguments matters "
			+ "for the executed process as this nees to reflected in the order of the "
			+ "parameters.";

	/** Name of the output file argument parameter. */
	protected static final String PARAMETER_OUTPUT_FILE_ARG_NAME = "output-file-argument";

	/** Description of the output file argument parameter. */
	protected static final String PARAMETER_OUTPUT_FILE_ARG_DESCRIPTION = "The argument specified here is "
			+ "passed to the process just like the other arguments. However, the output of this "
			+ "processor is specified by this parameter.";

	/**
	 * Working directory of the executed process. If <code>null</code>, the
	 * current directory is used.
	 */
	private File workingDirectory = null;

	/** Flag that steers if the processor fails if the executed process fails. */
	private boolean failOnError = false;

	/** List of arguments handed to the process. */
	protected final List<String> arguments = new ArrayList<String>();

	/** Name of the output file. */
	protected String outputFile;

	/**
	 * Log level for std out. If <code>null</code>, std out is not logged at
	 * all.
	 */
	private ELogLevel stdOutLevel = null;

	/**
	 * Log level for std err. If <code>null</code>, std err is not logged at
	 * all.
	 */
	private ELogLevel stdErrLevel = null;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "working-directory", description = "Working directory for the execution "
			+ "[if unspecified, ConQAT's working directory will be used]", maxOccurrences = 1)
	public void setWorkingDirectory(
			@AConQATAttribute(name = "value", description = "Working directory") String workingDirectory) {
		this.workingDirectory = new File(workingDirectory);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "fail-on-error", description = "If set to true, the processor will fail if "
			+ "the executed process has an exit value != 0 [default is false]", maxOccurrences = 1)
	public void setFailOnError(
			@AConQATAttribute(name = "value", description = "Fail on error") boolean failOnError) {
		this.failOnError = failOnError;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "std-out-log", description = "Specifies the level used for "
			+ "loggin std-out. If not set, output is ignored.", maxOccurrences = 1)
	public void setStdOutLogLevel(
			@AConQATAttribute(name = "level", description = "Log level for std-out") ELogLevel level) {
		stdOutLevel = level;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "std-err-log", description = "Specifies the level used for "
			+ "logging std-err. If not set, output is ignored.", maxOccurrences = 1)
	public void setStdErrLogLevel(
			@AConQATAttribute(name = "level", description = "Log level for std-out") ELogLevel level) {
		stdErrLevel = level;
	}

	/** Add an argument. */
	protected void addArgument(String argument) {
		arguments.add(argument);
	}

	/**
	 * Set output file argument. This also adds the argument to
	 * {@link #arguments}.
	 */
	protected void setOutputFileArgument(String outputFile) {
		arguments.add(outputFile);
		this.outputFile = outputFile;
	}

	/** {@inheritDoc} */
	public String process() throws ConQATException {

		try {
			FileSystemUtils.ensureParentDirectoryExists(new File(outputFile));
			execute();
			return outputFile;
		} catch (IOException e) {
			throw new ConQATException("Could not execute process: "
					+ e.getMessage(), e);
		}

	}

	/** Execute process. */
	private void execute() throws IOException, ConQATException {

		List<String> command = getCommand();

		getLogger().info("Command: " + StringUtils.concat(command));

		ProcessBuilder builder = new ProcessBuilder(command);

		if (workingDirectory != null) {
			builder.directory(workingDirectory);
		}

		ExecutionResult result = ProcessUtils.execute(builder);

		if (stdOutLevel != null) {
			getLogger().log(stdOutLevel, result.getStdout());
		}

		if (stdErrLevel != null) {
			getLogger().log(stdErrLevel, result.getStderr());
		}

		int exitValue = result.getReturnCode();

		if (failOnError && exitValue != 0) {
			throw new ConQATException("Process failed with exit value "
					+ exitValue);
		}

	}

	/** Template method to get command to be executed. */
	protected abstract List<String> getCommand();

}
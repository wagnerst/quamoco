/*--------------------------------------------------------------------------+
   $Id: MultipleSolutionsScope.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Creates a source code scope of all VS.NET solution files contained in a file
 * system tree. If any file is contained in multiple included projects, it only
 * occurs once in the scope.
 * <p>
 * Currently, only a single language is supported for the entire scope.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "Creates a source code scope of all VS.NET solution files contained in a file"
		+ "system tree. If any file is contained in multiple included projects, it only"
		+ "occurs once in the scope."
		+ "Currently, only a single language is supported for the entire scope.")
public class MultipleSolutionsScope extends SolutionScopeBase {

	/** Root of file system tree that contains solution files */
	private IFileSystemElement solutionFilesRoot;

	/** ConQAT Parameter */
	@AConQATParameter(name = "solution", description = "File system tree containing VS.NET solution files", minOccurrences = 1, maxOccurrences = 1)
	public void setSolutionFiles(
			@AConQATAttribute(name = "files", description = "Typically produced by a file system scope processor") IFileSystemElement solutionFilesRoot) {
		this.solutionFilesRoot = solutionFilesRoot;
	}

	/**
	 * Returns the root directory of the file system tree containing the
	 * solution files.
	 */
	@Override
	protected File determineRootDirectory() {
		return solutionFilesRoot.getFile();
	}

	/**
	 * Template method that allows deriving classes the return the list of
	 * source files
	 */
	@Override
	protected List<String> determineSourceFiles() throws ConQATException {
		List<String> sourceFiles = new ArrayList<String>();

		List<IFileSystemElement> solutionFiles = TraversalUtils
				.listLeavesDepthFirst(solutionFilesRoot);
		for (IFileSystemElement solutionElement : solutionFiles) {
			sourceFiles.addAll(parseSolutionFile(solutionElement.getFile()));
		}

		return sourceFiles;
	}

}

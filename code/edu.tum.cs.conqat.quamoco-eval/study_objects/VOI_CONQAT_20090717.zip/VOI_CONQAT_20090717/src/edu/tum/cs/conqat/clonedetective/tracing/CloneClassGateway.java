package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Gateway for {@link CloneClass}es.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 22025 $
 * @levd.rating RED Rev:
 */
public class CloneClassGateway extends DatabaseBase {

	/**  */
	private static final String TIMESTAMP = "TIMESTAMP";
	/**  */
	private static final String NORMALIZED_LENGTH = "NORMALIZED_LENGTH";

	/** Underlying {@link KeyValueGateway} */
	private final KeyValueGateway keyValueGateway;

	/** Underlying {@link CloneGateway} */
	private final CloneGateway cloneGateway;

	/** Constructor */
	protected CloneClassGateway(Connection dbConnection, String tableName) {
		super(dbConnection, tableName);
		this.keyValueGateway = new KeyValueGateway(dbConnection, tableName
				+ "_KEYVALUES");
		this.cloneGateway = new CloneGateway(dbConnection, tableName
				+ "_CLONES", keyValueGateway);
	}

	/** {@inheritDoc} */
	@Override
	protected String createCreateTableString() {
		StringBuilder result = new StringBuilder();
		result.append("CREATE TABLE " + tableName);
		result.append(" (" + TIMESTAMP + " BIGINT, " + ID + " INT, "
				+ NORMALIZED_LENGTH + " INT" + ");");
		return result.toString();
	}

	/** Store clones in database */
	public void storeClones(CloneDetectionResultElement detectionResult)
			throws SQLException, ConQATException {
		Date timestamp = detectionResult.getSystemDate();
		List<CloneClass> cloneClasses = detectionResult.getList();
		String rootOrigin = detectionResult.getRoot().getId();

		storeCloneClasses(timestamp, cloneClasses, rootOrigin);
	}

	/** Store clone classes in database */
	public void storeCloneClasses(Date timestamp,
			List<CloneClass> cloneClasses, String rootOrigin)
			throws SQLException, ConQATException {
		Statement stmt = dbConnection.createStatement();
		for (CloneClass cloneClass : cloneClasses) {
			stmt.addBatch(createInsertCloneClassSql(cloneClass, timestamp));
			keyValueGateway.createBatch(cloneClass, stmt);
		}
		DatabaseUtils.executeStatement(stmt);

		cloneGateway.storeClones(timestamp, cloneClasses, rootOrigin);
	}

	/** Create SQL string to insert a clone class into the database */
	private String createInsertCloneClassSql(CloneClass cloneClass,
			Date timestamp) {
		StringBuilder result = new StringBuilder();
		result.append("INSERT INTO " + tableName + " (");

		result.append(TIMESTAMP);
		result.append(", " + ID);
		result.append(", " + NORMALIZED_LENGTH);

		result.append(") VALUES (");

		result.append(timestamp.getTime());
		result.append(", " + cloneClass.getId());
		result.append(", " + cloneClass.getNormalizedLength());

		result.append(")");
		return result.toString();
	}

	/** Select all clones classes of a timestamp from the database */
	public List<CloneClass> selectClones(Date timestamp) throws SQLException {
		Map<Integer, CloneClass> cloneClasses = new HashMap<Integer, CloneClass>();

		// load clone classes
		ResultSet result = DatabaseUtils.executeQuery(dbConnection,
				createSelectCloneClassesSql(timestamp));
		while (result.next()) {
			int id = result.getInt(ID);
			int normalizedLength = result.getInt(NORMALIZED_LENGTH);
			CloneClass cloneClass = new CloneClass(normalizedLength, id);
			cloneClasses.put(id, cloneClass);

			keyValueGateway.loadValuesInto(cloneClass);
		}

		// load clones into clone classes
		cloneGateway.selectClones(timestamp, cloneClasses);

		return new ArrayList<CloneClass>(cloneClasses.values());
	}

	/** Creates SQL string to select clone classes for a timestamp */
	private String createSelectCloneClassesSql(Date timeStamp) {
		StringBuilder result = new StringBuilder();
		result.append("SELECT * from " + tableName);
		result.append(" WHERE TIMESTAMP = " + timeStamp.getTime());
		return result.toString();
	}

	/** Get the clone gateway */
	/* package */CloneGateway getCloneGateway() {
		return cloneGateway;
	}
}

/*--------------------------------------------------------------------------+
   $Id: RepetitiveStatementsRegionMarker.java 21248 2009-04-23 05:51:50Z juergens $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.repetition;

import java.util.List;

import edu.tum.cs.conqat.clonedetective.normalization.statement.StatementUnit;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.regions.RegionMarkerBase;
import edu.tum.cs.conqat.filesystem.regions.RegionSet;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * Marks regions of repetitive statements. Just as holds for other region
 * markers, region information can then be used to steer normalization. Regions
 * of repetitive code can e.g. be normalized more conservatively.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 21248 $
 * @levd.rating GREEN Rev: 21248
 */
@AConQATProcessor(description = ""
		+ "Marks regions of repetitive statements. Works only for languages for which a"
		+ "{@link TokenOracleFactory} is available. Just as holds for other region"
		+ "markers, region information can then be used to steer normalization. Regions"
		+ "of repetitive code can e.g. be normalized more conservatively.")
public class RepetitiveStatementsRegionMarker extends
		RegionMarkerBase<ISourceCodeElement> {

	/** Minimal length of repetition in units */
	private int minLength;

	/** Length of shortest repetition motif being searched for */
	private int minMotifLength;

	/** Length of longest repetition motif being searched for */
	private int maxMotifLength;

	/** Minimal required number of motive instances in repetition */
	private int minMotifInstances;

	/** ConQAT Parameter */
	@AConQATParameter(name = "min", description = "Minimal size of repetition", minOccurrences = 1, maxOccurrences = 1)
	public void setMinLength(
			@AConQATAttribute(name = "length", description = "Minimal number of statements contained in repetition") int minLength,
			@AConQATAttribute(name = "instances", description = "Minimal required number of motif instances in repetition.") int minMotifInstances) {
		this.minLength = minLength;
		this.minMotifInstances = minMotifInstances;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "motiflength", description = "Length of repetition motifs (number of statements) being searched for", minOccurrences = 1, maxOccurrences = 1)
	public void setMotifLength(
			@AConQATAttribute(name = "min", description = "Length of shortest repetition motif being searched for") int minMotifLength,
			@AConQATAttribute(name = "max", description = "Length of longest repetition motif being searched for") int maxMotifLength) {
		this.minMotifLength = minMotifLength;
		this.maxMotifLength = maxMotifLength;
	}

	/**
	 * Creates regions marking repetitions with motifs of length between 1 and
	 * max motif length
	 */
	@Override
	protected void findRegionsForElement(ISourceCodeElement element,
			RegionSet result) throws ConQATException {
		StatementUnit[] sequence = RepetitionUtils.getStatements(element,
				getLogger());

		RepetitionFinder<StatementUnit> detector = new RepetitionFinder<StatementUnit>(
				sequence, new StatementEquator(), minLength, minMotifInstances);
		List<Repetition<StatementUnit>> repetitions = detector.findRepetitions(
				minMotifLength, maxMotifLength);

		for (Repetition<StatementUnit> repetition : repetitions) {
			result.add(RepetitionUtils.regionFor(repetition));
		}
	}

}

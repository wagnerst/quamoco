/*--------------------------------------------------------------------------+
   $Id: CloneUtils.java 18959 2009-03-12 08:24:16Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.digest.Digester;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IClone;

/**
 * This class offers utility methods useful in the context of clone detection.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 18959 $
 * @levd.rating GREEN Rev: 18959
 */
public class CloneUtils {

	/** Count the clones contained in a list of clone classes. */
	public static int countClones(List<CloneClass> cloneClasses) {
		int count = 0;
		for (CloneClass cloneClass : cloneClasses) {
			count += cloneClass.size();
		}
		return count;
	}

	/** Gets the siblings of a clone in its clone class */
	public static ArrayList<IClone> getSiblings(IClone clone) {
		ArrayList<IClone> siblings = new ArrayList<IClone>();
	
		for (IClone sibling : clone.getCloneClass().getClones()) {
			if (clone != sibling) {
				siblings.add(sibling);
			}
		}
	
		return siblings;
	}

	/**
	 * Computes the fingerprint for a collection of clones. If the clones have
	 * different fingerprints, a new fingerprint is created, else the common
	 * fingerprint is returned.
	 */
	public static String createFingerprint(Collection<IClone> clones) {
		CCSMAssert.isFalse(clones.isEmpty(),
				"Cannot create fingerprint for empty collection of clones");

		if (allFingerprintsEqual(clones)) {
			return CollectionUtils.getAny(clones).getFingerprint();
		}

		// as long as the fingerprints of the individual clones do not change,
		// we need to assure that the clone class fingerprint does not change
		// either. in order to compute a stable fingerprint for a clone class,
		// we thus need to establish a stable order in which clone fingerprints
		// are added to the clone class fingerprint. since we want to be
		// independent of clone filenames or clone positions in files, we
		// compute this order directly on the fingerprints.
		Set<String> fingerprints = new HashSet<String>();
		for (IClone clone : clones) {
			fingerprints.add(clone.getFingerprint());
		}

		return Digester.createMD5Digest(fingerprints);
	}

	/** Determines whether the fingerprints of all clones are equal. */
	private static boolean allFingerprintsEqual(Collection<IClone> clones) {
		String commonFingerprint = CollectionUtils.getAny(clones)
				.getFingerprint();
		for (IClone clone : clones) {
			if (!commonFingerprint.equals(clone.getFingerprint())) {
				return false;
			}
		}

		return true;
	}

}

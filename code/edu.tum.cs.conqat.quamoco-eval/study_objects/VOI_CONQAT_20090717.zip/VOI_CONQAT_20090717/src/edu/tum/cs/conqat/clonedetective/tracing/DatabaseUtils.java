package edu.tum.cs.conqat.clonedetective.tracing;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import edu.tum.cs.conqat.core.ConQATException;

/**
 * Utility methods for database handling
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 21458 $
 * @levd.rating RED Rev:
 */
public class DatabaseUtils {

	/** Executes an update query */
	public static void executeUpdate(Connection dbConnection, String query)
			throws SQLException {
		Statement statement = dbConnection.createStatement();
		statement.executeUpdate(query);
		statement.close();
	}

	/** Executes a select query */
	public static ResultSet executeQuery(Connection dbConnection,
			String selectString) throws SQLException {
		Statement statement = dbConnection.createStatement(
				ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);

		ResultSet result = statement.executeQuery(selectString);
		statement.close();

		return result;
	}

	/** Executes a statement */
	public static void executeStatement(Statement stmt) throws SQLException, ConQATException {
		int[] results = stmt.executeBatch();
		for (int result : results) {
			if (result == Statement.EXECUTE_FAILED) {
				throw new ConQATException(
						"Execution of insert statement failed");
			}
		}

		stmt.close();
	}
}

package edu.tum.cs.conqat.clonedetective.core;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.reflect.ReflectionUtils;
import edu.tum.cs.commons.reflect.TypeConversionException;

/**
 * Base class that implements a lazily instantiated associative key-value
 * mechanism. Lazy instantiation saves memory in case the store is not used.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 22020 $
 * @levd.rating YELLOW Rev: 22020
 */
public abstract class LazyKeyValueStoreBase implements IKeyValueStore {

	/**
	 * Integer that identifies this value store. The scope of the id depends on
	 * the id provider used.
	 */
	private final int id;

	/** Map that stores key-value pairs */
	private Map<String, Object> values;

	/** Map that stores transient flags */
	private Map<String, Boolean> transientFlags;

	/** Construct store with set id */
	protected LazyKeyValueStoreBase(int id) {
		this.id = id;
	}

	/** Return the id of the store */
	public int getId() {
		return id;
	}

	/** {@inheritDoc} */
	public void setValue(String key, Object value) {
		ensureValuesMapInitialized();
		values.put(key, value);
	}

	/** Set value using reflection to resolve types */
	public void setValue(String key, String valueString, String typeString)
			throws ClassNotFoundException, TypeConversionException {
		// Type of the value
		Class<?> type = ReflectionUtils.resolveType(typeString);

		// Make sure we really got the right type
		CCSMAssert.isTrue(type.getName().equals(typeString),
				"Type was not converted correctly.");

		// Convert value string to actual value
		Object value = ReflectionUtils.convertString(valueString, type);

		// Make sure we really got the right type
		CCSMAssert.isTrue(type.isInstance(value),
				"Value was not converted correctly.");

		setValue(key, value);
	}

	/** {@inheritDoc} */
	public Object getValue(String key) {
		if (values == null) {
			return null;
		}
		return values.get(key);
	}

	/** {@inheritDoc} */
	public boolean containsValue(String key) {
		if (values == null) {
			return false;
		}
		return values.containsKey(key);
	}

	/** {@inheritDoc} */
	public UnmodifiableList<String> getKeyList() {
		if (values == null) {
			return CollectionUtils.emptyList();
		}
		return CollectionUtils.asSortedUnmodifiableList(values.keySet());
	}

	/** {@inheritDoc} */
	public int getInt(String key) {
		return (Integer) getValue(key);
	}

	/** {@inheritDoc} */
	public String getString(String key) {
		return (String) getValue(key);
	}

	/** Ensures that the values map is initialized */
	private void ensureValuesMapInitialized() {
		if (values == null) {
			values = new HashMap<String, Object>();
		}
	}

	/** Ensures that the values map is initialized */
	private void ensureTransientFlagsMapInitialized() {
		if (transientFlags == null) {
			transientFlags = new HashMap<String, Boolean>();
		}
	}

	/** {@inheritDoc} */
	public boolean getTransient(String key) {
		if (transientFlags == null || !transientFlags.containsKey(key)) {
			return false;
		}
		return transientFlags.get(key);
	}

	/** {@inheritDoc} */
	public void setTransient(String key, boolean value) {
		ensureTransientFlagsMapInitialized();
		transientFlags.put(key, value);
	}
}
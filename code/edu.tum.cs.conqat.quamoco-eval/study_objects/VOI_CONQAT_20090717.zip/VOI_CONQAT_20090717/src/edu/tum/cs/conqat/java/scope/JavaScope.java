/*--------------------------------------------------------------------------+
   $Id: JavaScope.java 22011 2009-07-16 08:30:09Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.scope;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.bcel.classfile.ClassFormatException;
import org.apache.bcel.classfile.ClassParser;
import org.apache.bcel.classfile.JavaClass;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.java.library.JavaLibrary;

/**
 * {@ConQAT.Doc}
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Rev: 22011 $
 * @levd.rating GREEN Rev: 22011
 */
@AConQATProcessor(description = "This scope is meant for analyzing"
		+ " Java systems in a package-structure oriented way. It allows the "
		+ " definition of multiple source folders containing the Java source "
		+ " files and multiple binary folders containing the Java class files."
		+ " Scope creation fails if one or more class files are missing."
		+ " For the source folders include and exclude patterns may be specified. "
		+ " The default include pattern is '**/*.java'. Excluding files from"
		+ " source folders decreases processing time since these files are not touched"
		+ " at all. Additionally a class name exclusion pattern can be specified"
		+ " to exclude classes in certain packages from the scope regardless of"
		+ " the location of their source files. Inner classes are never included.")
public class JavaScope extends ConQATProcessorBase {

	/** Used if no include pattern was specified. */
	private static final String DEFAULT_INCLUDE_PATTERN = "**/*.java";

	/** The classpath. A linked list because we want to add front. */
	private final List<String> classpath = new LinkedList<String>();

	/** The patterns that are included in this scope. */
	private final List<String> includePatterns = new ArrayList<String>();

	/** The patterns that are excluded from this scope. */
	private final List<String> excludePatterns = new ArrayList<String>();

	/** Class prefixes to exclude from the scope. */
	private final List<String> classExcludePrefixes = new ArrayList<String>();

	/** The list of source directories to search. */
	private final List<String> sourceDirectories = new ArrayList<String>();

	/** The list of binary directories to search. */
	private final List<String> byteCodeDirectories = new ArrayList<String>();

	/**
	 * Flag that indicates if the path matching should be case-sensitive or not.
	 */
	private boolean caseSensitive = true;

	/**
	 * A complete list of all source files. A hash map is used to avoid files to
	 * be listed multiple times if overlapping directories were specified.
	 */
	private final Set<String> sourceFiles = new HashSet<String>();

	/** A complete list of all binary files. */
	private final Set<String> byteCodeFiles = new HashSet<String>();

	/**
	 * A mapping from fully qualified class names to the path of their source
	 * files.
	 */
	private final Map<String, String> sourceClasses = new HashMap<String, String>();

	/**
	 * A mapping from fully qualified class names to the path of their bytecode
	 * files.
	 */
	private final Map<String, String> byteCodeClasses = new HashMap<String, String>();

	/** Flag indicating if processor is run in lenient mode. */
	private boolean lenientMode = false;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "source", minOccurrences = 1, description = ""
			+ "Path to source directory.")
	public void addSourceDirectory(
			@AConQATAttribute(name = "dir", description = "source directory") String srcDir,
			@AConQATAttribute(name = "optional", defaultValue = "false", description = ""
					+ "Whether the directory is optional (i.e. no error is thrown if it doen not exist).") boolean optional) {

		// second part of condition is false if directory does not exist
		if (optional && !new File(srcDir).isDirectory()) {
			getLogger().info("Skipping optional source directory " + srcDir);
		} else {
			sourceDirectories.add(srcDir);
		}
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "byte-code", minOccurrences = 1, description = ""
			+ "Path to binary directory.")
	public void addByteCodeDirectory(
			@AConQATAttribute(name = "dir", description = "byte code directory") String byteCodeDir,
			@AConQATAttribute(name = "optional", defaultValue = "false", description = ""
					+ "Whether the directory is optional (i.e. no error is thrown if it doen not exist).") boolean optional) {

		// second part of condition is false if directory does not exist
		if (optional && !new File(byteCodeDir).isDirectory()) {
			getLogger().info(
					"Skipping optional byte-code directory " + byteCodeDir);
		} else {
			byteCodeDirectories.add(byteCodeDir);
		}
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "classpath", description = ""
			+ "Add an element to the classpath.")
	public void addClasspathElement(
			@AConQATAttribute(name = "element", description = ""
					+ "The directory or JAR file ot add to the classpath.") String filename) {

		if (!new File(filename).exists()) {
			getLogger().warn(
					"Classpath element " + filename + " not found. Skipped!");
		} else {
			classpath.add(filename);
		}
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "include-source", description = ""
			+ "Add a pattern for files to include in this scope."
			+ " The default include pattern is '**/*.java'.")
	public void addIncludePattern(
			@AConQATAttribute(name = ConQATParamDoc.ANT_PATTERN_NAME, description = ConQATParamDoc.ANT_PATTERN_DESC) String pattern) {
		includePatterns.add(pattern);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "exclude-source", description = ""
			+ "Add a pattern for files to exclude from this scope.")
	public void addExcludePattern(
			@AConQATAttribute(name = ConQATParamDoc.ANT_PATTERN_NAME, description = ConQATParamDoc.ANT_PATTERN_DESC) String pattern) {
		excludePatterns.add(pattern);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "case-sensitive", minOccurrences = 0, maxOccurrences = 1, description = "Set case-sensitivity for "
			+ "file scanning [case-sensitive by default].")
	public void setCaseSensitivity(
			@AConQATAttribute(name = "value", description = "true for case-sensitive, "
					+ "false for case-insensitive") boolean caseSensitive) {
		this.caseSensitive = caseSensitive;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "exclude-class", description = ""
			+ "Add a class name prefix for classes to exclude from this scope.")
	public void addClassExcludePattern(
			@AConQATAttribute(name = "prefix", description = "A class name prefix.") String pattern) {
		classExcludePrefixes.add(pattern);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "lenient-mode", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "If run in lenient mode, source files for which the class files are missing are "
			+ "excluded from the scope. In normal mode the processor fails when source files "
			+ "without class files are encountered. By default the processor runs in normal mode.")
	public void setLenientMode(
			@AConQATAttribute(name = "enable", description = "true for lenient mode") boolean lenientMode) {
		this.lenientMode = lenientMode;

	}

	/**
	 * Calling this method triggers the actual scope generation. This method
	 * returns the same object on every subsequent call.
	 */
	public IJavaRootElement process() throws ConQATException {
		if (includePatterns.isEmpty()) {
			includePatterns.add(DEFAULT_INCLUDE_PATTERN);
		}

		collectFiles(sourceDirectories, includePatterns, excludePatterns,
				sourceFiles);
		// exclude inner classes for byte code
		collectFiles(byteCodeDirectories, Arrays.asList("**/*.class"), Arrays
				.asList("**/*$*"), byteCodeFiles);

		extractClassNames();
		return buildTree();
	}

	/**
	 * Collect all files in a list of directories that are matched by a specific
	 * pattern.
	 * 
	 * @param directories
	 *            list of root directories to search
	 * @param includePatterns
	 *            a list of patterns to include
	 * @param excludePatterns
	 *            a list of patterns to exclude
	 * @param files
	 *            set to add the found files to. Hash set avoid duplicates.
	 * @throws ConQATException
	 */
	private void collectFiles(List<String> directories,
			List<String> includePatterns, List<String> excludePatterns,
			Set<String> files) throws ConQATException {

		for (String directory : directories) {
			List<String> includedFiles = FileLibrary.getInstance()
					.scanDirectory(directory, caseSensitive, includePatterns,
							excludePatterns);

			if (!directory.endsWith(File.separator)) {
				directory += File.separator;
			}

			for (String filename : includedFiles) {
				files.add(directory + filename);
			}
		}

	}

	/**
	 * Extracts the names of all classes from the source files and the byte code
	 * files and checks if a byte code file is present for every source file.
	 * 
	 * @throws ConQATException
	 *             if an IO problem occurs or a byte code file is missing
	 */
	private void extractClassNames() throws ConQATException {
		extractSourceClassNames();
		extractByteCodeClassNames();
		checkByteCodeClasses();
	}

	/**
	 * Extracts the class names from all source files and stores a map entry in
	 * map {@link #sourceClasses}.
	 * 
	 * @throws ConQATException
	 *             if an IO problem occurrs
	 */
	private void extractSourceClassNames() throws ConQATException {
		try {
			for (String filename : sourceFiles) {
				String className = JavaLibrary.getInstance().getFQClassName(
						filename);
				if (!isExcluded(className)) {
					if (sourceClasses.containsKey(className)) {
						getLogger().warn(
								"Files " + filename + " and "
										+ sourceClasses.get(className)
										+ " both contain a class with name "
										+ className);
					}
					sourceClasses.put(className, filename);
				}
			}
		} catch (IOException e) {
			throw new ConQATException(e);
		}
	}

	/**
	 * Extracts the class names from all byte code files and stores a map entry
	 * in map {@link #byteCodeClasses}.
	 * 
	 * @throws ConQATException
	 *             if a IO problem occurs
	 */
	private void extractByteCodeClassNames() throws ConQATException {
		for (String filename : byteCodeFiles) {

			JavaClass claz = getClass(filename);
			if (claz == null) {
				throw new ConQATException("Couldn't read " + filename);
			}

			String className = claz.getClassName();
			// if this class is relevant, cache it
			if (sourceClasses.containsKey(className)) {
				byteCodeClasses.put(className, filename);
			}
		}
	}

	/**
	 * Checks if a byte code file is present for every source code file. This
	 * logs all missing byte code files.
	 */
	private void checkByteCodeClasses() throws ConQATException {
		int missingByteCodeCount = 0;
		// even if we run in non-lenient mode, it is convenient to log all
		// classes that are not found. Hence, we do not exit after the first
		// missing class.
		for (String className : new HashSet<String>(sourceClasses.keySet())) {
			if (!byteCodeClasses.containsKey(className)) {
				getLogger().warn(
						"Bytecode for class " + className + " not found.");
				sourceClasses.remove(className);
				missingByteCodeCount++;
			}
		}
		if (missingByteCodeCount > 0) {
			String message = "No byte code found for " + missingByteCodeCount
					+ " classes.";
			if (lenientMode) {
				getLogger().warn(message + " Classes are excluded from scope.");
			} else {
				throw new ConQATException(message);
			}
		}
	}

	/**
	 * Build the tree by inserting every class in the tree.
	 * 
	 * @throws ConQATException
	 *             if canonization fails.
	 */
	private JavaRootElement buildTree() throws ConQATException {
		// add the byte code directories to the class path. This is used by
		// JavaRootElement.getJavaClass to determine the BCEL class
		HashSet<String> actualByteCodeDirectories = determineByteCodeDirectories();
		classpath.addAll(0, actualByteCodeDirectories);
		JavaRootElement root = new JavaRootElement(FileLibrary
				.canonize(sourceDirectories), FileLibrary
				.canonize(actualByteCodeDirectories), classpath);
		for (String className : sourceClasses.keySet()) {
			insertClass(root, className);
		}
		return root;
	}

	/** Determine the actually used byte code directories. */
	private HashSet<String> determineByteCodeDirectories() {
		HashSet<String> dirs = new HashSet<String>();

		for (String byteCodeFilename : byteCodeFiles) {
			String byteCodeDirectoryName = determineByteCodeDirectory(byteCodeFilename);

			if (byteCodeDirectoryName != null) {
				dirs.add(byteCodeDirectoryName);
			}
		}

		getLogger().info("Actual byte code directories: " + dirs);
		return dirs;
	}

	/**
	 * Determine the byte code directory for a byte code file.
	 * 
	 * @return the byte code directory or <code>null</code> if this byte code
	 *         file is not included in the scope.
	 */
	private String determineByteCodeDirectory(String byteCodeFilename) {
		JavaClass clazz = getClass(byteCodeFilename);
		if (clazz == null) {
			getLogger().warn(
					"Could not determine byte code directory for "
							+ byteCodeFilename);
			return null;
		}

		String className = clazz.getClassName();
		// check if the class is included in the scope.
		if (!sourceClasses.containsKey(className)) {
			return null;
		}

		// 7 is the length of ".class" + 1 for the trailing path separator
		int endIndex = byteCodeFilename.length() - className.length() - 7;
		CCSMAssert.isTrue(endIndex > 0, "Class name longer than file name");
		String byteCodeDirectory = byteCodeFilename.substring(0, endIndex);

		return byteCodeDirectory;
	}

	/**
	 * Insert a class into the tree.
	 * 
	 * @param currentElement
	 *            the root element.
	 * @param className
	 *            the full qualified class name.
	 */
	private void insertClass(JavaPackageElement currentElement, String className) {

		// find position in tree
		String[] classParts = className.split("\\.");
		for (int i = 0; i + 1 < classParts.length; ++i) {
			JavaPackageElement child = (JavaPackageElement) currentElement
					.getChild(classParts[i]);
			if (child == null) {
				child = new JavaPackageElement(classParts[i]);
				currentElement.addChild(child);
			}
			currentElement = child;
		}

		// insert class
		JavaClassElement classElement = new JavaClassElement(
				classParts[classParts.length - 1], new File(sourceClasses
						.get(className)), new File(byteCodeClasses
						.get(className)));
		currentElement.addChild(classElement);
	}

	/** Check if one of class exclude prefixes matches for this class. */
	private boolean isExcluded(String classname) {
		for (String prefix : classExcludePrefixes) {
			if (classname.startsWith(prefix)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Parse class file using BCEL.
	 * 
	 * @param path
	 *            path of the class file
	 * @return the class object or <code>null</code> if a problem occurred.
	 */
	private JavaClass getClass(String path) {
		try {
			ClassParser parser = new ClassParser(path);
			return parser.parse();
		} catch (IOException ex) {
			return null;
		} catch (ClassFormatException ex) {
			return null;
		}
	}
}

/*--------------------------------------------------------------------------+
   $Id: TokenUnit.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token;

import edu.tum.cs.conqat.clonedetective.core.UnitBase;
import edu.tum.cs.scanner.ETokenType;

/**
 * Unit-implementation for tokens.
 * 
 * @author Rainer Spitzhirn
 * @author $Author: hummelb $
 * 
 * @version $Revision: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
public class TokenUnit extends UnitBase {

	/** Underlying token */
	private final ETokenType tokenType;

	/** Start position of token in its file */
	private final int offset;

	/**
	 * Create new {@link TokenUnit}.
	 * <p>
	 * Since we don't know how many lines a token spans, we always use 1 for
	 * covered lines.
	 * 
	 * @param content
	 *            the token's content
	 * @param startLineInFile
	 *            Line number of start of unit in file
	 * @param originId
	 *            Id of the element this unit stems from
	 */
	public TokenUnit(String content, int offset, int startLineInFile,
			String originId, ETokenType tokenType, int indexInFile) {
		super(startLineInFile, originId, content, 1, indexInFile);
		this.tokenType = tokenType;
		this.offset = offset;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		String result = "TOKEN '" + getContent() + "' (" + getType() + ")";
		result += " \"" + getOriginId() + "\"" + " line "
				+ getStartLineInFile();
		return result;
	}

	/** Getter */
	public ETokenType getType() {
		return tokenType;
	}

	/** Getter */
	public int getOffset() {
		return offset;
	}

}
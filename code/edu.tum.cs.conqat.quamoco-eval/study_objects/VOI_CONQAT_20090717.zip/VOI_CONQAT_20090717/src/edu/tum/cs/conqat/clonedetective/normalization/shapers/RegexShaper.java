/*--------------------------------------------------------------------------+
   $Id: RegexShaper.java 19092 2009-03-14 12:44:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.shapers;

import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.IUnit;
import edu.tum.cs.conqat.clonedetective.core.IUnitProvider;
import edu.tum.cs.conqat.clonedetective.detection.SentinelUnit;
import edu.tum.cs.conqat.clonedetective.normalization.UnitProviderBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.IConQATProcessor;
import edu.tum.cs.conqat.core.IConQATProcessorInfo;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * {@ConQAT.doc}
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 19092 $
 * @levd.rating GREEN Rev: 19092
 */
@AConQATProcessor(description = ""
		+ "Inserts sentinels before units that match one of a set of regular expressions. "
		+ "Matching is performed on the textual representation of the units.")
public class RegexShaper extends UnitProviderBase<IFileSystemElement, IUnit>
		implements IConQATProcessor {

	/** Provider */
	private IUnitProvider<IFileSystemElement, IUnit> provider;

	/** Patterns. Initialize to empty list in case it does not get set. */
	private final PatternList patterns = new PatternList();

	/** Flag that indicates that the last returned unit was a sentinel */
	private boolean lastWasSentinel = false;

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "unit", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Unit provider")
	public void setUnitProvider(
			@AConQATAttribute(name = "provider", description = "Unit provider") IUnitProvider<IFileSystemElement, IUnit> provider) {
		this.provider = provider;
	}

	/** {@ConQAT.doc} */
	@AConQATParameter(name = "patterns", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Patterns matching units before which sentinels are inserted")
	public void setPatterns(
			@AConQATAttribute(name = "ref", description = "Reference to pattern producer") PatternList patterns) {
		this.patterns.addAll(patterns);
	}

	/** {@inheritDoc} */
	@Override
	protected void init(IFileSystemElement root) throws CloneDetectionException {
		provider.init(root, getLogger());
	}

	/** {@inheritDoc} */
	@Override
	protected IUnit provideNext() throws CloneDetectionException {
		IUnit nextUnit = provider.lookahead(1);
		if (nextUnit == null) {
			return null;
		}

		if (!lastWasSentinel && patterns.matchesAny(nextUnit.getContent())) {
			lastWasSentinel = true;
			return new SentinelUnit(nextUnit.getOriginId());
		}

		lastWasSentinel = false;
		return provider.getNext();
	}

	/** {@inheritDoc} */
	public void init(IConQATProcessorInfo processorInfo) {
		// nothing to do
	}

	/** {@inheritDoc} */
	public IUnitProvider<IFileSystemElement, IUnit> process() {
		return this;
	}

}

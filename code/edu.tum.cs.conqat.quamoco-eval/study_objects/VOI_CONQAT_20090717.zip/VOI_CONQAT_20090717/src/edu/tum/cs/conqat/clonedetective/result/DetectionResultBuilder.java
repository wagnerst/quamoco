/*--------------------------------------------------------------------------+
   $Id: DetectionResultBuilder.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.clonedetective.utils.ECloneClassComparator;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Creates a list of clone classes for display in ConQAT.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "Creates a list of the clone classes")
public class DetectionResultBuilder extends ConQATProcessorBase {

	/** Key used to store length of clone in lines */
	@AConQATKey(description = "Key used to store length of clone in lines", type = "java.lang.Integer")
	public static final String CLONE_LENGTH_IN_LINES = "Length in Lines";

	/** Key used to store start line of clone */
	@AConQATKey(description = "Key used to store start line of clone", type = "java.lang.Integer")
	public static final String CLONE_START_LINE = "Line";

	/** Key used to store number of clones in clone class */
	@AConQATKey(description = "Key used to store number of clones in clone class", type = "java.lang.Integer")
	public static final String VOLUME = "Volume";

	/** Key used to store number of clones in clone class */
	@AConQATKey(description = "Key used to store number of clones in clone class", type = "java.lang.Integer")
	public static final String CARDINALITY = "#Instances";

	/** Key used to store normalized length of clones in clone class */
	@AConQATKey(description = "Key used to store normalized length of clones in clone class", type = "java.lang.Integer")
	public static final String NORMALIZED_LENGTH = "Normalized length";

	/**
	 * Constant that indicates unlimited number of clones, thus no truncation of
	 * result
	 */
	public static final int UNLIMITED = -1;

	/** Number that determines after how many clones the result is truncated. */
	private int maxCloneCount = UNLIMITED;

	/** Clone detection result from which clone classes are taken */
	private CloneDetectionResultElement result;

	/** Comparator used to sort clone classes */
	private ECloneClassComparator comparator = ECloneClassComparator.NORMALIZED_LENGTH;

	/** ConQAT Parameter */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			CloneDetectionResultElement result) {
		this.result = result;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "sort", description = "Metric according to which clone classes are sorted", minOccurrences = 0, maxOccurrences = 1)
	public void setComparator(
			@AConQATAttribute(name = "dimension", description = "Valid dimensions are NORMALIZED_LENGTH, VOLUME and CARDINALITY, default value is NORMALIZED_LENGTH")
			ECloneClassComparator comparator) {
		this.comparator = comparator;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "max", description = "Maximal number of clones that gets included. All clones exceeding this number are truncated", minOccurrences = 0, maxOccurrences = 1)
	public void setMaxCloneCount(
			@AConQATAttribute(name = "clones", description = "Use " + UNLIMITED
					+ " to include all clones. Default is " + UNLIMITED + ".")
			int maxCloneCount) {
		this.maxCloneCount = maxCloneCount;
	}

	/** {@inheritDoc} */
	public DetectionResultRootNode process() {
		// sort clone classes
		List<CloneClass> allCloneClasses = result.getList();
		Collections.sort(allCloneClasses, comparator);

		// truncate list after maxCloneCount
		List<CloneClass> keptCloneClasses = new ArrayList<CloneClass>();
		int clonesSoFar = 0;
		for (CloneClass cloneClass : allCloneClasses) {
			if (maxCloneCount == UNLIMITED
					|| clonesSoFar + cloneClass.size() < maxCloneCount) {
				keptCloneClasses.add(cloneClass);
				clonesSoFar += cloneClass.size();
			} else {
				break;
			}
		}

		// create root
		DetectionResultRootNode root = new DetectionResultRootNode();
		String rootPath = result.getRoot().getId();

		// add clone classes
		for (CloneClass cloneClass : keptCloneClasses) {
			root.addChild(new CloneClassNode(cloneClass, rootPath));
		}

		return root;
	}

}

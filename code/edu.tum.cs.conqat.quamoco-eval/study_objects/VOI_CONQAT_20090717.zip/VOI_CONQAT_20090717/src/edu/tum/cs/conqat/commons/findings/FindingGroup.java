/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingGroup.java 21887 2009-07-10 15:06:10Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.Collection;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.collections.IdentityHashSet;
import edu.tum.cs.conqat.commons.findings.location.ELocationType;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * A group of findings that collects related findings, such as the clones of a
 * clone group or findings indicating he same flaw.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 21887 $
 * @levd.rating YELLOW Rev: 21887
 */
public class FindingGroup extends ConQATNodeBase implements
		IRemovableConQATNode {

	/** The category this belongs to. */
	private final FindingCategory category;

	/** The description for this category. */
	private final String description;

	/** The findings in this group. */
	private final Collection<Finding<?>> findings = new IdentityHashSet<Finding<?>>();

	/** Counter for generating unique child IDs. */
	private int idCounter = 0;

	/**
	 * Hidden constructor. Use the factory method in {@link FindingCategory}
	 * instead.
	 */
	/* package */FindingGroup(String description, FindingCategory category) {
		this.description = description;
		this.category = category;
	}

	/** Copy constructor. */
	@SuppressWarnings("unchecked")
	/* package */FindingGroup(FindingGroup other, FindingCategory category)
			throws DeepCloneException {
		super(other);
		this.category = category;
		this.description = other.description;
		this.idCounter = other.idCounter;
		for (Finding finding : other.findings) {
			this.findings.add(new Finding(finding, this));
		}
	}

	/** {@inheritDoc} */
	public void remove() {
		category.remove(this);
	}

	/** Removes a finding. */
	/* package */void remove(Finding<?> finding) {
		findings.remove(finding);
	}

	/** {@inheritDoc} */
	public String getId() {
		return category.getId() + ":" + getName();
	}

	/** {@inheritDoc} */
	public String getName() {
		return description;
	}

	/** {@inheritDoc} */
	public FindingCategory getParent() {
		return category;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !findings.isEmpty();
	}

	/** {@inheritDoc} */
	public Finding<?>[] getChildren() {
		return findings.toArray(new Finding[findings.size()]);
	}

	/** Returns the finding type of this group. */
	public EFindingType getFindingType() {
		return category.getFindingType();
	}

	/** Returns the location type of this group. */
	public ELocationType getLocationType() {
		return category.getLocationType();
	}

	/**
	 * Creates a new message finding. The given value must be correct for the
	 * finding type.
	 */
	public Finding<?> createFinding(String originTool, Object value) {
		CCSMPre.isTrue(value != null
				&& getFindingType().getValueType().isAssignableFrom(
						value.getClass()), "Invalid value for finding type.");
		Finding<Object> finding = new Finding<Object>(this, originTool,
				++idCounter, value);
		findings.add(finding);
		return finding;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Throws an exception as we do not support cloning at this level.
	 */
	public IRemovableConQATNode deepClone() {
		throw new UnsupportedOperationException(
				"Deep cloning not supported at this level.");
	}
}

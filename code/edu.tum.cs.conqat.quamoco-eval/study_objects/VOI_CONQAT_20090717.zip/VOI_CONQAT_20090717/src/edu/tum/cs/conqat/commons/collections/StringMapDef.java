/*--------------------------------------------------------------------------+
   $Id: StringMapDef.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.collections;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Provides a <code>HashMap&lt;String, String&gt;</code> to be used for
 * various purposes.
 * 
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: hummelb $
 * @version $Rev: 16780 $
 * @levd.rating GREEN Rev: 16780
 */
@AConQATProcessor(description = "Defines a mapping from string to strings.")
public class StringMapDef extends ConQATProcessorBase {

	/** The map. */
	private final Map<String, String> map = new HashMap<String, String>();

	/** Take a (key, value) pair. Values defined once can't be overriden. */
	@AConQATParameter(name = "entry", description = "Definition of a "
			+ "(key, value) pair. Keys must be unique.")
	public void addKeyValuePair(
			@AConQATAttribute(name = "key", description = "The key.")
			String key,
			@AConQATAttribute(name = "value", description = "The value.")
			String value) throws ConQATException {

		if (map.containsKey(key)) {
			throw new ConQATException("Key '" + key + "' defined twice");
		}
		map.put(key, value);
	}

	/** Does not really process anything, but just returns the created map. */
	public Map<String, String> process() {
		return map;
	}
}

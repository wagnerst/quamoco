/*--------------------------------------------------------------------------+
   $Id: WordExtractor.java 21644 2009-06-22 16:33:49Z hummelb $
 |                                                                          |
 | Copyright 2005-2008 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor extracts the words from a set of identifiers and returns the
 * set of words.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 21644 $
 * @levd.rating GREEN Rev: 21644
 * 
 * @see edu.tum.cs.conqat.text.identifier.CompoundBreaker
 */
@AConQATProcessor(description = "This processor extracts the words from a "
		+ "set of identifiers and returns the set of words. ")
public class WordExtractor extends ConQATProcessorBase {

	/** Set of identifiers. */
	private Set<String> identifiers;

	/** Set of words. */
	private final Set<String> words = new HashSet<String>();

	/** Set set of identifiers. */
	@AConQATParameter(name = "identifiers", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Gives the set of identifiers which are broken up into words.")
	public void setList(@AConQATAttribute(name = "set", description = ""
			+ "The set of identifiers (strings).")
	Set<String> identifiers) {
		this.identifiers = identifiers;
	}

	/** {@inheritDoc} */
	public Set<String> process() {
		CompoundBreaker breaker = new CompoundBreaker();
		for (String identifier : identifiers) {
			words.addAll(breaker.breakCompound(identifier));
		}
		return words;
	}
}

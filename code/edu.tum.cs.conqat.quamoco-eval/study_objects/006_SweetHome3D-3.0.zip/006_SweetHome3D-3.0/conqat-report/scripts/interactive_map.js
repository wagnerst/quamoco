
/**
 * Interactive Tooltip
 * @author: Timo Besenreuther
 * @author: Florian Deissenboeck
 */
 
function InteractiveMap(selector) {
	
	/** The displayed keys of the nodes */
	var _keys = [];
	
	/** The data of the map */
	var _data = {};
	
	/** Color of the frames */
	var _frameColor = false;
	
	/** The id of the currently focused record */
	var _focused;
	
	/** Map to find parent containers by id */
	var _parentContainers = {};
	
	/** Map dom element */
	var _element;
	
	/** Map dom element dimensions */
	var _containerDimensions;
	
	/** IE6 detection */
	var _ie6 = jQuery.browser.msie && parseInt(jQuery.browser.version, 10) == 6;
	var _ie6Offset = _ie6 ? 6 : 0;
	
	/** Set the displayed keys */
	this.setKeys = function(keys) {
		_keys = keys;
	};
	
	/** Set the color of the frames */
	this.setFrameColor = function(color) {
		_frameColor = color;
	};
	
	/** Add a new container to the map */
	this.addContainer = function(x, y, x2, y2, id, parentId) {
		var record = {
			'x': x, 'y': y,
			'x2': x2, 'y2': y2,
			'id': id, 'parentId': parentId
		};
		_parentContainers[id] = record;
	};
	
	/** Add a record to the map */
	this.addData = function(x, y, x2, y2, id, data, parentId) {
		var record = {
			'x': x, 'y': y,
			'x2': x2,
			'y2': y2,
			'id': id,
			'data': data,
			'parentId': parentId
		};
		if (typeof(_data[x]) == 'undefined') {
			_data[x] = {};
		}
		_data[x][y] = record;
	};
	
	/** Helper function for creating new elements */
	var _create = function(tag) {
		return $(document.createElement(tag));
	};
	
	/** Highlight a record */
	var _highlight = function(data, recursiveCall) {
		if (!_frameColor) return;
		if (!recursiveCall) {
			_hideHighlight();
			// show opaque highlight for current record
			var div = _create('div').addClass('MapHighlight').css({
				position: 'absolute',
				background: 'white',
				left: _containerDimensions.left + data.x + 2,
				top: _containerDimensions.top + data.y + 2,
				width: (data.x2 - data.x - 2) + 'px',
				height: (data.y2 - data.y - 2) + 'px',
				opacity: 0.2
			});
			$('body').prepend(div);
		}
		if (data.parentId != "" || !recursiveCall) {
			// outline parent containers
			var div = _create('div').addClass('MapHighlight').css({
				position: 'absolute',
				border: '3px solid ' + _frameColor,
				left: _containerDimensions.left + data.x,
				top: _containerDimensions.top + data.y,
				width: (data.x2 - data.x - 4) + _ie6Offset + 'px',
				height: (data.y2 - data.y - 4) + _ie6Offset + 'px'
			});
			$('body').prepend(div);		
			var parent = _parentContainers[data.parentId];
			if (typeof(parent) != 'undefined') {
				_highlight(parent, true);
			}
		}
	};
	
	var _hideHighlight = function() {
		$('.MapHighlight').remove();
	};
	
	/** Dynamic dom elements */
	var _tooltip;
	var _header;
	var _content = [];
	
	/** Create dom elements */
	var _createDom = function() {
		
		// create tooltip container
		_tooltip = _create('div').css({
			position: 'absolute',
			backgroundColor: '#CCCCCC',
			border: '1px solid #666666',
			color: 'black',
			opacity: 0.8
		}).hide();
		$('body').prepend(_tooltip);
	
		// create header
		_header = _create('div').css({
			backgroundColor: '#666666',
			border: '1px solid #666666',
			color: 'white',
			fontFamily: 'verdana, helvetica, sans-serif',
			fontSize: '10px'
		});
		_tooltip.append(_header);
	
		// create content table
		var table = _create('table');
		_tooltip.append(table);
		var tdCss = {
			backgroundColor: '#CCCCCC',
			color: 'black',
			fontFamily: 'verdana, helvetica, sans-serif',
			fontSize: '10px'
		};
		for (var i = 0; i < _keys.length; i++) {
			var tr = _create('tr');
			var left = _create('td').html(_keys[i]).css(tdCss);
			var right = _create('td').css(tdCss);
			table.append(tr);
			tr.append(left);
			tr.append(right);
			_content.push(right);
		}
		
	};
	
	/** Find a record by coordinates */
	var _findRecord = function(x, y, workX) {
		var workY = y;
		
		// get next vertical line
		var line;
		do {
			line = _data[workX];
			workX--;
		} while (typeof(line) == 'undefined' && workX >= 0);
		
		if (typeof(line) == 'undefined')
			return null;
		
		// get next rectangle
		var data;
		do {
			data = line[workY];
			workY--;
		} while (typeof(data) == 'undefined' && workY >= 0);
		
		// match?
		if (typeof(data) != 'undefined' &&
				data.x <= x && data.x2 >= x && data.y <= y && data.y2 >= y) {
			if (_focused == data.id) {
				return null;
			}
			_focused = data.id;
			return data;
		} else {
			return _findRecord(x, y, workX );
		}
	};
	
	// register document read listener
	$(document).ready(function() {
		_init();
	});
	
	/** Initialize the map */
	var _init = function() {
		_element = $(selector);
		_containerDimensions = _element.offset();
		_containerDimensions.width = _element.width();
		_containerDimensions.height = _element.height();
		_createDom();
		$('body').mousemove(function(e) {
			if (e.pageX < _containerDimensions.left
					|| e.pageX > _containerDimensions.left + _containerDimensions.width
					|| e.pageY < _containerDimensions.top
					|| e.pageY > _containerDimensions.top + _containerDimensions.height) {
				// mouse is outside map
				_focused = null;
				_tooltip.hide();
				_hideHighlight();
				return;
			}
			
			// move tooltip
			_tooltip.css({
				top: (e.pageY + 15) + 'px',
				left: (e.pageX + 15) + 'px'
			});
		
			// derive offset within map
			var x = e.pageX - _containerDimensions.left - 2;
			var y = e.pageY - _containerDimensions.top - 2;
			
			// find rectangle
			var data = _findRecord(x, y, x);
			if (data == null) {
				return;
			}
			
			// fill tooltip
			_header.html(data.id);
			for (var i = 0; i < _keys.length; i++) {
				_content[i].html(data.data[i]);
			}
			_tooltip.show();
			
			// move highlights
			_highlight(data);
		});
	};
	
}
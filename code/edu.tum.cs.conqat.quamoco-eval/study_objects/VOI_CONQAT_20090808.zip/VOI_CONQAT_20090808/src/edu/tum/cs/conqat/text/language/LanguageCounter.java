/*--------------------------------------------------------------------------+
   $Id: LanguageCounter.java 23503 2009-08-07 16:17:42Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.language;

import java.util.EnumSet;
import java.util.List;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.analysis.FileAnalyzerBase;
import edu.tum.cs.conqat.sourcecode.library.SourceCodeLibrary;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.ETokenType.ETokenClass;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23503 $
 * @levd.rating GREEN Hash: 85FF930F10869805E04E92B7C9D5CD31
 */
@AConQATProcessor(description = "This processor counts how often which language is used in selected token types.")
public class LanguageCounter extends FileAnalyzerBase<ISourceCodeElement> {

	/** Key for languages. */
	@AConQATKey(description = "Distribution of languages.", type = "edu.tum.cs.commons.collections.CounterSet<String>")
	public static final String KEY_LANG = "Lang";

	/** Set of token classes to include in analysis. */
	private final EnumSet<ETokenClass> tokenClasses = EnumSet
			.noneOf(ETokenClass.class);

	/** List of tokens to be ignored. */
	private PatternList ignorePattern;

	/** Add token class. */
	@AConQATParameter(name = "token", minOccurrences = 1, description = "Add a token class.")
	public void addTokenClass(
			@AConQATAttribute(name = "class", description = "Specifies "
					+ "token class.") ETokenClass tokenClass) {
		tokenClasses.add(tokenClass);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "ignore", minOccurrences = 0, maxOccurrences = 1, description = "Set list of tokens to ignore.")
	public void setIgnorePattern(
			@AConQATAttribute(name = "list", description = "List of pattern which describes ignored tokens.") PatternList list) {
		ignorePattern = list;
	}

	/** {@inheritDoc} */
	@Override
	protected void analyzeFile(ISourceCodeElement element) {
		List<IToken> tokens;
		try {
			tokens = SourceCodeLibrary.getInstance().getTokens(element);
		} catch (ConQATException e) {
			getLogger().warn("Empty source element: " + element);
			return;
		}

		CounterSet<String> languages = new CounterSet<String>();
		for (IToken token : tokens) {
			if (tokenClasses.contains(token.getType().getTokenClass())) {
				if (ignorePattern == null
						|| !ignorePattern.matchesAny(token.getText())) {
					languages.inc(LanguageDecider.decideLanguage(token
							.getText()));
				}
			}
		}
		element.setValue(KEY_LANG, languages);
	}

	/** {@inheritDoc} */
	@Override
	protected String[] getKeys() {
		return new String[] { KEY_LANG };
	}

}

/*--------------------------------------------------------------------------+
   $Id: FilteringTokenProvider.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token;

import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.region.RegionSet;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.regions.RegionSetDictionary;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.filesystem.traversal.ElementTraversalUtils;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.IToken;

/**
 * Token provider that filters tokens based on the filter region information
 * stored in the IFileSystemElements the tokens originated from, and based on an
 * optional pattern list against which tokens are matched.
 * 
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * 
 * @version $Revision: 23489 $
 * @levd.rating GREEN Hash: 44CA28E4FCAC04B97E9335B8EB98AEC8
 */
public class FilteringTokenProvider extends TokenProviderBase {

	/** Default name of region set of ignored tokens */
	public static final String IGNORE = "ignore";

	/** Source of the tokens that are filtered */
	private final ITokenProvider tokenProvider;

	/** Maps files to their filtered regions */
	private final HashedListMap<CanonicalFile, RegionSet> idToFilteredregions = new HashedListMap<CanonicalFile, RegionSet>();

	/** Ignore patterns for tokens */
	private final PatternList ignorePatterns;

	/**
	 * Names of the {@link RegionSet}s that for which matching tokens are
	 * filtered out.
	 */
	private final Set<String> ignoreRegionSetNames;

	/**
	 * Default constructor. Ignores tokens from default ignore set
	 * {@value #IGNORE} and empty ignore patterns.
	 * 
	 * @param tokenProvider
	 *            Source of unfiltered tokens.
	 */
	public FilteringTokenProvider(ITokenProvider tokenProvider) {
		this(tokenProvider, CollectionUtils.asHashSet(new String[] { IGNORE }),
				new PatternList());
	}

	/**
	 * Creates a {@link FilteringTokenProvider}
	 * 
	 * @param tokenProvider
	 *            Source of unfiltered tokens.
	 * 
	 * @param ignoreRegionSetNames
	 *            Name of the {@link RegionSet} for which matching tokens get
	 *            ignored
	 * 
	 * @param ignorePatterns
	 *            Tokens that are matched by these patterns are ignored.
	 */
	public FilteringTokenProvider(ITokenProvider tokenProvider,
			Set<String> ignoreRegionSetNames, PatternList ignorePatterns) {
		this.tokenProvider = tokenProvider;
		this.ignoreRegionSetNames = ignoreRegionSetNames;
		this.ignorePatterns = ignorePatterns;
	}

	/** Returns next token that is not filtered out */
	@Override
	protected IToken provideNext() throws CloneDetectionException {
		IToken token = tokenProvider.getNext();

		while (token != null && isFilteredOut(token)) {
			token = tokenProvider.getNext();
		}

		return token;
	}

	/** Returns true, if a token should be filtered out */
	private boolean isFilteredOut(IToken token) {
		CanonicalFile file = token.getFile();
		int tokenOffset = token.getOffset();

		List<RegionSet> ignoredRegionSets = idToFilteredregions.getList(file);
		if (ignoredRegionSets == null) {
			return false;
		}

		for (RegionSet ignoredRegionSet : ignoredRegionSets) {
			if (ignoredRegionSet.contains(tokenOffset)) {
				return true;
			}
		}

		if (ignorePatterns.matchesAny(token.getText())) {
			return true;
		}

		return false;
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ISourceCodeElement root) throws CloneDetectionException {
		// init token provider
		tokenProvider.init(root, getLogger());

		// init map that maps from element id to set of filtered regions
		Map<CanonicalFile, IFileSystemElement> idToElement;
		try {
			idToElement = ElementTraversalUtils
					.createCanonicalFileToElementMap((IFileSystemElement) root);
		} catch (ConQATException e) {
			throw new CloneDetectionException(e.getMessage(), e);
		}

		for (CanonicalFile file : idToElement.keySet()) {
			IFileSystemElement element = idToElement.get(file);

			RegionSet filteredRegions;
			try {
				for (String ignoreRegionSetName : ignoreRegionSetNames) {
					filteredRegions = RegionSetDictionary.retrieve(element,
							ignoreRegionSetName);
					if (filteredRegions != null) {
						idToFilteredregions.add(file, filteredRegions);
					}
				}
			} catch (ConQATException e) {
				getLogger().warn(
						"Skipping element '" + element.getId() + "': "
								+ e.getMessage());
			}

		}
	}

}

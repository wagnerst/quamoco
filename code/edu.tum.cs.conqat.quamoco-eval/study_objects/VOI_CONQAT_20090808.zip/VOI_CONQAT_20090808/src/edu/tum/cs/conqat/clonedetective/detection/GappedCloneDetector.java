/*--------------------------------------------------------------------------+
   $Id: GappedCloneDetector.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.algo.Diff;
import edu.tum.cs.commons.algo.Diff.Delta;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.EEditOperation;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.detection.suffixtree.ApproximateCloneDetectingSuffixTree;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Approximate clone detection based on suffix trees. Does find approximate (aka
 * gapped) clones. Internally the {@link ApproximateCloneDetectingSuffixTree} is
 * used.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 9674FEC0213D94F613BF304CE48892B3
 */
@AConQATProcessor(description = "Suffix tree based approximate clone detector.")
public class GappedCloneDetector extends CloneDetectorBase {

	/** The maximal number of errors we are allowed. */
	private int maxErrors;

	/** Number of units that must be equal at the start of a clone */
	private int initialEquality = 1;

	/** Setter. */
	@AConQATParameter(name = "errors", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Sets the maximal allowed number of errors in a clone.")
	public void setMaxErrors(
			@AConQATAttribute(name = "max", description = "Sets the maximal allowed number of errors in a clone.") int maxErrors) {
		this.maxErrors = maxErrors;
	}

	/** Setter. */
	@AConQATParameter(name = "initial", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Number of units that must be equal at the start of a clone.")
	public void setInitialEquality(
			@AConQATAttribute(name = "equality", description = "Default is 1.") int initialEquality) {
		this.initialEquality = initialEquality;
	}

	/** {@inheritDoc} */
	@Override
	protected List<CloneClass> detectClones() {
		List<CloneClass> cloneClasses = new ArrayList<CloneClass>();

		ApproximateCloneDetectingSuffixTree cdstree = new ApproximateCloneDetectingSuffixTree(
				units) {

			@Override
			protected boolean mayNotMatch(Object character) {
				return character instanceof SentinelUnit;
			}

			@Override
			protected void reportBufferShortage(int leafStart, int leafLength) {
				getLogger()
						.debug(
								"Encountered suffix tree node, whose word is too large for the buffer. "
										+ "This might occur with very long clones. "
										+ "As a result the clone will be chopped into parts and "
										+ "potentially some small parts of the clone might get lost. Start at "
										+ leafStart + "; length " + leafLength);
			}
		};
		getLogger().debug("Suffix tree created. Detecting clones...");
		cdstree.findClones(minLength, maxErrors, initialEquality,
				new GapDetectingCloneConsumer(cloneClasses));
		getLogger().debug("Clone detection finished!");
		return cloneClasses;
	}

	/** A clone consumer, which in addition detects gaps on the clones reported. */
	private class GapDetectingCloneConsumer extends CloneConsumer {

		/** The first clone of the clone class. */
		private Clone firstClone = null;

		/** The position of the first clone. */
		private int firstPos = 0;

		/** The length of the first clone. */
		private int firstLength = 0;

		/** Constructor. */
		private GapDetectingCloneConsumer(List<CloneClass> cloneClasses) {
			super(cloneClasses);
		}

		/** {@inheritDoc} */
		@Override
		public void startCloneClass(int normalizedLength) {
			super.startCloneClass(normalizedLength);
			firstClone = null;
		}

		/** Adds a clone to the current {@link CloneClass} */
		@Override
		public Clone addClone(int globalPosition, int length) {
			// get clone without gap information
			Clone clone = super.addClone(globalPosition, length);

			Delta<Unit> delta = Diff.computeDelta(units.subList(firstPos,
					firstPos + firstLength), units.subList(globalPosition,
					globalPosition + length));

			if (firstClone != null) {
				clone.setDeltaInUnits(delta.getSize());
				fillGaps(clone, delta, globalPosition);
			} else {
				clone.setDeltaInUnits(0);
				firstClone = clone;
				firstPos = globalPosition;
				firstLength = length;
			}

			return clone;
		}

		/** Fills the gaps for the given clone. */
		private void fillGaps(Clone clone, Delta<Unit> delta,
				int globalPosition) {
			boolean firstNeedsGaps = !firstClone.containsGaps();

			for (int i = 0; i < delta.getSize(); ++i) {
				int pos = delta.getPosition(i);
				if (pos > 0) {
					pos--;
					Unit unit = units.get(globalPosition + pos);
					int offset = unit.getStartLineInFile()
							- clone.getStartLineInFile();
					for (int j = 0; j < unit.getCoveredLines(); ++j) {
						clone.addGap(offset + j, EEditOperation.INSERT);
					}
				} else if (firstNeedsGaps) {
					pos = -pos - 1;
					Unit unit = units.get(firstPos + pos);
					int unitStartLine = unit.getStartLineInFile();
					int firstCloneStartLine = firstClone.getStartLineInFile();
					int offset = unitStartLine - firstCloneStartLine;
					for (int j = 0; j < unit.getCoveredLines(); ++j) {
						firstClone.addGap(offset + j, EEditOperation.DELETE);
					}
				}
			}
		}
	}
}

/*--------------------------------------------------------------------------+
   $Id: EFindingKeys.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.awt.Color;

import edu.tum.cs.commons.assessment.ETrafficLightColor;

/**
 * Enumeration of well known finding keys.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: B7A43AD551C7D0F43570AB1F3830BB61
 */
public enum EFindingKeys {

	/** Human readable message. */
	MESSAGE(String.class),

	/** Color. */
	COLOR(Color.class),

	/** Numerical measurement. */
	MEASUREMENT(Double.class),

	/** Assessment. */
	ASSESSMENT(ETrafficLightColor.class);

	/** The type usually stored for the key. */
	private final Class<?> type;

	/** Constructor. */
	private EFindingKeys(Class<?> type) {
		this.type = type;
	}

	/** Returns the type stored for the key. */
	public Class<?> getType() {
		return type;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return name().toLowerCase();
	}
}

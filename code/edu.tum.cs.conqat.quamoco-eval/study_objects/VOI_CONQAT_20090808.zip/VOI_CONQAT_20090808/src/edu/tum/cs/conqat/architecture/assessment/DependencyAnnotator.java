/*--------------------------------------------------------------------------+
   $Id: DependencyAnnotator.java 23504 2009-08-07 16:20:27Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.assessment;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.conqat.architecture.scope.ArchitectureDefinition;
import edu.tum.cs.conqat.architecture.scope.ComponentNode;
import edu.tum.cs.conqat.architecture.scope.ComponentResolver;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23504 $
 * @levd.rating GREEN Hash: 9274D67804C102E456AB7119B1BF219B
 */
@AConQATProcessor(description = "This processor adds dependencies to the policies of an architecture.")
public class DependencyAnnotator extends
		ConQATPipelineProcessorBase<ArchitectureDefinition> {

	/** Key for elements w/o a component. */
	@AConQATKey(description = "Stores the list of orphaned nodes.", type = "java.util.List<String>")
	public static final String ORPHANS_KEY = "orphans";

	/** Key under which the set of matched types is stored */
	@AConQATKey(description = "Stores the names of types matched to a component.", type = "java.util.Set<String>")
	public static final String MATCHED_TYPES_KEY = "matched_types";

	/** The root node currently being analyzed. */
	private IConQATNode root;

	/** Set of keys storing the string lists containing the dependencies. */
	private final Set<String> keys = new HashSet<String>();

	/** The resolver used to locate components. */
	private ComponentResolver resolver;

	/** Orphans are element IDs which could not be mapped to a component. */
	private final Set<String> orphans = new HashSet<String>();

	/** Counts the number of dependencies processed. */
	private int dependencyCount = 0;

	/** {ConQAT.Doc} */
	@AConQATParameter(name = "dependencies", minOccurrences = 1, maxOccurrences = 1, description = "The node structure providing the dependencies.")
	public void setDependencies(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IConQATNode root) {
		this.root = root;
	}

	/** {ConQAT.Doc} */
	@AConQATParameter(name = "list-key", description = ""
			+ "Add a key to read a dependency list from. "
			+ "The same key is put into the edge summary lists of all edges created from these lists.")
	public void addListKey(
			@AConQATAttribute(name = "key", description = "The name of the key.") String key) {
		keys.add(key);
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(ArchitectureDefinition arch)
			throws ConQATException {
		resolver = new ComponentResolver(arch, getLogger());

		TraversalUtils.visitLeavesDepthFirst(new DependecyVisitor(), root);

		NodeUtils.addToDisplayList(arch, ORPHANS_KEY);
		NodeUtils.getOrCreateStringList(arch, ORPHANS_KEY).addAll(orphans);

		getLogger().info("Processed " + dependencyCount + " dependencies.");
		getLogger().info(
				"Number of orphans (classes that could not be mapped to component): "
						+ orphans.size());

		// fail if no suitable input was provided.
		if (dependencyCount == 0) {
			throw new ConQATException(
					"No dependencies found in provided scope! Probably this is a configuration error.");
		}
	}

	/**
	 * Returns the component for a given ID using the {@link #resolver}. Returns
	 * null if no component could be found.
	 */
	private ComponentNode findComponent(String id) {
		ComponentNode component = resolver.findComponentFor(id);
		if (component == null) {
			orphans.add(id);
		} else {
			NodeUtils.getOrCreateStringSet(component, MATCHED_TYPES_KEY)
					.add(id);
		}
		return component;
	}

	/** Inserts a dependency into this architecture. */
	private void insertDependency(ComponentNode sourceComponent,
			ComponentNode targetComponent, String sourceId, String targetId) {
		dependencyCount += 1;

		if (sourceComponent == targetComponent
				|| sourceComponent.getAncestorSet().contains(targetComponent)
				|| targetComponent.getAncestorSet().contains(sourceComponent)) {
			return;
		}

		sourceComponent.getOrCreatePolicy(targetComponent).addDependency(
				sourceId, targetId);
	}

	/** Visitor for inserting the dependencies. */
	public class DependecyVisitor implements
			INodeVisitor<IConQATNode, ConQATException> {

		/** {@inheritDoc} */
		public void visit(IConQATNode node) {
			ComponentNode sourceNode = findComponent(node.getId());
			if (sourceNode == null) {
				return;
			}

			for (String key : keys) {
				List<String> targetList = NodeUtils.getStringList(node, key);
				if (targetList == null) {
					continue;
				}

				for (String targetID : targetList) {
					ComponentNode targetComponent = findComponent(targetID);
					if (targetComponent != null) {
						insertDependency(sourceNode, targetComponent, node
								.getId(), targetID);
					}
				}
			}
		}
	}

}

/*--------------------------------------------------------------------------+
   $Id: FindingUtils.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingCategory;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.location.FileLocation;
import edu.tum.cs.conqat.commons.findings.location.LocationBase;
import edu.tum.cs.conqat.commons.node.NodeUtils;

/**
 * Utility methods for findings.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: AF622614FC79A8706277513326FC3285
 */
public class FindingUtils {

	/**
	 * Returns findings grouped by the (absolute) file they are referencing.
	 * Findings with a non-file related location are ignored.
	 */
	public static HashedListMap<CanonicalFile, Finding> getFindingsByAbsoluteFile(
			FindingReport report) {
		HashedListMap<CanonicalFile, Finding> result = new HashedListMap<CanonicalFile, Finding>();
		for (FindingCategory category : report.getChildren()) {
			for (FindingGroup group : category.getChildren()) {
				for (Finding finding : group.getChildren()) {
					for (CanonicalFile file : getAffectedFiles(finding)) {
						result.add(file, finding);
					}
				}
			}
		}
		return result;
	}

	/** Returns all (absolute) file names which are affected by a finding. */
	private static Collection<CanonicalFile> getAffectedFiles(Finding finding) {
		Collection<CanonicalFile> result = new HashSet<CanonicalFile>();
		for (LocationBase location : finding.getLocations()) {
			if (location instanceof FileLocation) {
				result.add(((FileLocation) location).getFile());
			}
		}
		return result;
	}

	/**
	 * Adopts (i.e. clones) the given findings for the provided target report.
	 * So the findings will be copied into the given report.
	 */
	public static List<Finding> adoptFindings(FindingReport targetReport,
			Collection<Finding> findings) {
		List<Finding> result = new ArrayList<Finding>();
		for (Finding finding : findings) {
			result.add(adoptFinding(targetReport, finding));
		}
		return result;
	}

	/** Adopts (i.e. clones) the given finding for the provided target report. */
	public static Finding adoptFinding(FindingReport targetReport,
			Finding finding) {
		FindingGroup sourceGroup = finding.getParent();
		FindingCategory targetCategory = targetReport
				.getOrCreateCategory(sourceGroup.getParent().getName());
		FindingGroup targetGroup = targetCategory.getGroupByName(sourceGroup
				.getName());
		if (targetGroup == null) {
			targetGroup = targetCategory.createFindingGroup(sourceGroup
					.getName());
			NodeUtils.copyValues(sourceGroup.getKeys(), sourceGroup,
					targetGroup);
		}

		Finding result = targetGroup.createFinding(finding.getOriginTool());
		for (LocationBase location : finding.getLocations()) {
			result.addLocation(location);
		}
		NodeUtils.copyValues(finding.getKeys(), finding, result);

		return result;
	}
}

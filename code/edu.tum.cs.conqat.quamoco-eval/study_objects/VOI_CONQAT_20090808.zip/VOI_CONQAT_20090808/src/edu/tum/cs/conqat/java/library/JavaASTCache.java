/*--------------------------------------------------------------------------+
   $Id: JavaASTCache.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.library;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import net.sourceforge.pmd.TargetJDK1_5;
import net.sourceforge.pmd.ast.ASTCompilationUnit;
import net.sourceforge.pmd.ast.JavaParser;
import net.sourceforge.pmd.symboltable.SymbolFacade;
import edu.tum.cs.commons.cache.CacheBase;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.java.scope.IJavaClassElement;

/**
 * A dynamic cache for the AST to reduce parsing times. The cache should be
 * accessed via class <code>JavaLibrary</code>. This class additionally uses the
 * file cache in <code>FileLibrary</code>. This class uses the parser provided
 * by PMD.
 * <p>
 * Full qualified names of classes are used as hash keys.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: 1526E12AF49AC24732647C96674267E5
 * @see edu.tum.cs.conqat.java.library.JavaLibrary
 * @see net.sourceforge.pmd.ast.JavaParser
 */
/* package */class JavaASTCache
		extends
		CacheBase<IJavaClassElement, String, ASTCompilationUnit, ConQATException> {

	/** File libary to obtain cached source files. */
	private final FileLibrary fileLibrary = FileLibrary.getInstance();

	/** Parser factory. */
	private final TargetJDK1_5 targetJDKVersion = new TargetJDK1_5();

	/**
	 * Obtain AST.
	 * 
	 * @param element
	 *            The class.
	 * @return an AST object created by the PMD
	 * @throws ConQATException
	 *             if the file could not be read or the PMD parser raised an
	 *             error
	 */
	@Override
	protected ASTCompilationUnit obtainItem(IJavaClassElement element)
			throws ConQATException {

		String content = fileLibrary.getContent(element.getFile());
		Reader reader = new StringReader(content);
		JavaParser parser = targetJDKVersion.createParser(reader);
		ASTCompilationUnit compilationUnit = null;
		try {
			compilationUnit = parser.CompilationUnit();
		} catch (RuntimeException ex) {
			// we deliberately catch everything here to be robust against PMD
			// bugs
			throw new ConQATException("Parsing error for " + element + ": "
					+ ex.getMessage(), ex);
		}
		SymbolFacade stb = new SymbolFacade();
		stb.initializeWith(compilationUnit);
		try {
			reader.close();
		} catch (IOException e) {
			// can't happen, reading from string
		}
		return compilationUnit;
	}

	/** The fully qualified name of a class is used as hash key. */
	@Override
	protected String getHashKey(IJavaClassElement element) {
		return element.getId();
	}

}

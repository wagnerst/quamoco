/*--------------------------------------------------------------------------+
   $Id: ERenderMode.java 23504 2009-08-07 16:20:27Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.output;

import java.awt.Color;

import edu.tum.cs.commons.color.ECCSMColor;
import edu.tum.cs.conqat.architecture.format.EAssessmentType;
import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.architecture.scope.DependencyPolicy;
import edu.tum.cs.conqat.html_presentation.color.AssessmentColorizer;

/**
 * The mode used for rendering.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23504 $
 * @levd.rating GREEN Hash: 8E98C84B5D23AC978017648A0228048A
 */
public enum ERenderMode {

	/** Renders plain policies. */
	POLICIES,

	/** Renders assessments (red, yellow, green). */
	ASSESSMENT,

	/** Renders violations only (red). */
	VIOLATIONS,

	/** Renders violations and tolerations (red, yellow). */
	VIOLATIONS_AND_TOLERATIONS;

	/**
	 * Returns whether a policy should be included when using this render mode.
	 */
	public boolean includePolicy(DependencyPolicy edge) {
		switch (this) {
		case POLICIES:
			return edge.getPolicyType() != EPolicyType.ALLOW_IMPLICIT
					&& edge.getPolicyType() != EPolicyType.DENY_IMPLICIT;
		case VIOLATIONS:
			return edge.getAssessment() == EAssessmentType.INVALID;
		case VIOLATIONS_AND_TOLERATIONS:
			return edge.getAssessment() == EAssessmentType.INVALID
					|| edge.getPolicyType() == EPolicyType.TOLERATE_EXPLICIT;
		default:
			return true;
		}
	}

	/** Returns the color used for a policy. */
	public Color determineColor(DependencyPolicy edge) {
		if (this == POLICIES) {
			return AssessmentColorizer.determineColor(edge.getPolicyType()
					.toTrafficLightColor());
		}

		if (edge.getAssessment() == null) {
			return ECCSMColor.DARK_GRAY.getColor();
		}
		if (edge.getAssessment() == EAssessmentType.INVALID) {
			return ECCSMColor.RED.getColor();
		}
		if (edge.getPolicyType() == EPolicyType.TOLERATE_EXPLICIT) {
			return ECCSMColor.YELLOW.getColor();
		}

		return ECCSMColor.GREEN.getColor();
	}
}
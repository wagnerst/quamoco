/*--------------------------------------------------------------------------+
   $Id: SimulinkCloneDetector.java 23502 2009-08-07 16:17:34Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.clones;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.model_clones.detection.IModelCloneDetector;
import edu.tum.cs.conqat.model_clones.detection.util.ICloneReporter;
import edu.tum.cs.conqat.model_clones.model.IDirectedEdge;
import edu.tum.cs.conqat.model_clones.model.INode;
import edu.tum.cs.conqat.simulink.clones.model.SimulinkDirectedEdge;
import edu.tum.cs.conqat.simulink.clones.model.SimulinkModelGraph;
import edu.tum.cs.conqat.simulink.clones.model.SimulinkModelGraphCreator;
import edu.tum.cs.conqat.simulink.clones.model.SimulinkNode;
import edu.tum.cs.conqat.simulink.clones.normalize.ISimulinkNormalizer;
import edu.tum.cs.conqat.simulink.clones.result.SimulinkClone;
import edu.tum.cs.conqat.simulink.clones.result.SimulinkCloneResultNode;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.simulink.model.SimulinkBlock;
import edu.tum.cs.simulink.model.SimulinkLine;

/**
 * Clone detector for Simulink models.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23502 $
 * @levd.rating GREEN Hash: CC23C30670ECD575E994DDB4E19F864A
 */
@AConQATProcessor(description = "Performs clone detection on simulink models.")
public class SimulinkCloneDetector extends ConQATProcessorBase implements
		ICloneReporter {

	/** The key used for the clone size. */
	@AConQATKey(description = "The size of the clone in number of blocks.", type = "java.lang.Integer")
	public static final String SIZE_KEY = "size";

	/** The key used for the clone weight. */
	@AConQATKey(description = "The weight of the clone.", type = "java.lang.Integer")
	public static final String WEIGHT_KEY = "weight";

	/** The key used for the number of occurrences of the clone. */
	@AConQATKey(description = "The number of occurrences of the clone.", type = "java.lang.Integer")
	public static final String OCCURRENCES_KEY = "occurrences";

	/** The key used for the number of occurrences of the clone. */
	@AConQATKey(description = "The volume of a clone is the size multiplied with the number of occurrences.", type = "java.lang.Integer")
	public static final String VOLUME_KEY = "volume";

	/** The key used for the weight sum. */
	@AConQATKey(description = "The sum of the weights.", type = "java.lang.Integer")
	public static final String WEIGHT_SUM_KEY = "weight sum";

	/** The key used for the model names. */
	@AConQATKey(description = "The names of the models in which the clone was found.", type = "java.util.Set<String>")
	public static final String MODELS_KEY = "models";

	/** The input node. */
	private ISimulinkElement input;

	/** The result of this processor. */
	private final SimulinkCloneResultNode result = new SimulinkCloneResultNode();

	/** The clone that is currently reported. */
	private SimulinkClone currentClone = null;

	/** Counter used for statistics and to generate IDs. */
	private int cloneCounter = 0;

	/** The detector used. */
	private IModelCloneDetector detector;

	/** The normalizer used. */
	private ISimulinkNormalizer normalizer;

	/** Set the input. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setModel(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			ISimulinkElement input) {
		this.input = input;
	}

	/** Set the detection used. */
	@AConQATParameter(name = "detection", minOccurrences = 1, maxOccurrences = 1, description = "The detection being used.")
	public void setDetection(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			IModelCloneDetector detector) {
		this.detector = detector;
	}

	/** Set the normalizers. */
	@AConQATParameter(name = "normalizer", minOccurrences = 1, maxOccurrences = 1, description = "Setup the normalizer used.")
	public void setNormalizers(
			@AConQATAttribute(name = "ref", description = "Reference to the normalizer")
			ISimulinkNormalizer normalizer) {
		this.normalizer = normalizer;
	}

	/** {@inheritDoc} */
	public SimulinkCloneResultNode process() throws ConQATException {

		NodeUtils.addToDisplayList(result, VOLUME_KEY, WEIGHT_SUM_KEY,
				OCCURRENCES_KEY, SIZE_KEY, WEIGHT_KEY, MODELS_KEY);
		result.setValue(NodeConstants.HIDE_ROOT, true);

		SimulinkModelGraph modelGraph = SimulinkModelGraphCreator
				.createModelGraph(input, normalizer);
		detector.detect(modelGraph, this, getLogger());

		getLogger().info("Found " + cloneCounter + " clones");
		return result;
	}

	/** {@inheritDoc} */
	public void startModelCloneClass(int numClones, int numNodes, int numEdges) {
		currentClone = new SimulinkClone(cloneCounter++);
		currentClone.setValue(VOLUME_KEY, numClones * numNodes);
		currentClone.setValue(OCCURRENCES_KEY, numClones);
		currentClone.setValue(SIZE_KEY, numNodes);
		currentClone.setValue(MODELS_KEY, new TreeSet<String>());
		result.addChild(currentClone);
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public void addModelCloneInstance(List<INode> nodes,
			List<IDirectedEdge> edges) {
		List<SimulinkBlock> blocks = nodesToBlocks(nodes);
		List<SimulinkLine> lines = edgesToLines(edges);
		currentClone.addBlocksLinesPair(blocks, lines);
		((Set<String>) currentClone.getValue(MODELS_KEY)).add(blocks.get(0)
				.getModel().getName());

		int weight = 0;
		for (INode n : nodes) {
			weight += n.getWeight();
		}
		currentClone.setValue(WEIGHT_KEY, weight);
		currentClone.setValue(WEIGHT_SUM_KEY, weight
				* (Integer) currentClone.getValue(OCCURRENCES_KEY));
	}

	/**
	 * Converts a list of {@link SimulinkNode}s as returned from the detection
	 * (i.e. as {@link INode}s) into the corresponding {@link SimulinkBlock}
	 * list.
	 */
	private List<SimulinkBlock> nodesToBlocks(List<INode> nodes) {
		List<SimulinkBlock> blocks = new ArrayList<SimulinkBlock>();
		for (INode node : nodes) {
			CCSMAssert.isTrue(node instanceof SimulinkNode,
					"Detector returned unknown nodes!");
			SimulinkNode snode = (SimulinkNode) node;
			blocks.add(snode.getBlock());
		}
		return blocks;
	}

	/**
	 * Converts a list of {@link SimulinkLine}s as returned from the detection
	 * (i.e. as {@link IDirectedEdge}s) into the corresponding
	 * {@link SimulinkLine} list.
	 */
	private List<SimulinkLine> edgesToLines(List<IDirectedEdge> edges) {
		List<SimulinkLine> lines = new ArrayList<SimulinkLine>();
		for (IDirectedEdge edge : edges) {
			CCSMAssert.isTrue(edge instanceof SimulinkDirectedEdge,
					"Detector returned unknown edges!");
			SimulinkDirectedEdge sedge = (SimulinkDirectedEdge) edge;
			lines.add(sedge.getLine());
		}
		return lines;
	}
}

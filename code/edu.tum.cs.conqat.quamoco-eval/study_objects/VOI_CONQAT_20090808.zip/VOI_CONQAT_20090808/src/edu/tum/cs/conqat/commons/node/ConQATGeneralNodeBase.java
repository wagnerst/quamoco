/*--------------------------------------------------------------------------+
   $Id: ConQATGeneralNodeBase.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.node;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.clone.DeepCloneException;

/**
 * This is a base class for {@link IConQATNode}s with a hierarchy having only
 * one type.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 09D09FE164E099102261740B7DE355CE
 * 
 * @param <E>
 *            the type of node handled.
 */
public abstract class ConQATGeneralNodeBase<E extends ConQATGeneralNodeBase<E>>
		extends ConQATNodeBase implements IRemovableConQATNode {

	/** The list of child nodes. */
	private final Map<String, E> children = new HashMap<String, E>();

	/** The parent of this node. */
	private E parent = null;

	/** (Empty) default constructor. */
	protected ConQATGeneralNodeBase() {
		// do nothing
	}

	/** Copy constructor. Recursively copies entire tree. */
	@SuppressWarnings("unchecked")
	protected ConQATGeneralNodeBase(ConQATGeneralNodeBase<E> node)
			throws DeepCloneException {
		super(node);
		for (E e : node.children.values()) {
			addChild((E) e.deepClone());
		}
	}

	/** Adds a child node. */
	@SuppressWarnings("unchecked")
	public void addChild(E childNode) {
		if (children.containsKey(childNode.getName())) {
			throw new IllegalArgumentException(
					"A node of this name already exists: "
							+ childNode.getName());
		}
		children.put(childNode.getName(), childNode);
		childNode.setParent((E) this);
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !children.isEmpty();
	}

	/** {@inheritDoc} */
	public E[] getChildren() {
		if (children.isEmpty()) {
			return null;
		}
		E[] result = allocateArray(children.size());
		children.values().toArray(result);
		return result;
	}

	/** Returns the number of children. */
	public int getNumberOfChildren() {
		return children.size();
	}

	/** Returns the child node of the gicen name or null if none exists. */
	public E getNamedChild(String name) {
		return children.get(name);
	}

	/**
	 * Creates a new array of given size and type <code>E</code> (template
	 * method).
	 */
	protected abstract E[] allocateArray(int size);

	/** {@inheritDoc} */
	public E getParent() {
		return parent;
	}

	/** Sets the parent node of this. */
	protected void setParent(E parentNode) {
		parent = parentNode;
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public void remove() {
		if (parent != null) {
			parent.removeChild((E) this);
			setParent(null);
		}
	}

	/** Removes the child of the given name. */
	protected void removeChild(E childNode) {
		children.remove(childNode.getName());
	}
}

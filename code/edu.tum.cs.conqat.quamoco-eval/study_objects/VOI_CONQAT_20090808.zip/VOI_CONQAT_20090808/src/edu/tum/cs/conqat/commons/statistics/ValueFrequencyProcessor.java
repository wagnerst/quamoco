/*--------------------------------------------------------------------------+
   $Id: ValueFrequencyProcessor.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.statistics;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * This processor creates a KeyedData object by counting the frequency of
 * objects specified by a key at the leaves ConQATNode hierarchy. The values
 * must implement interface java.util.Comparable.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 3607A62E1CAE8891BE1EDA336DF77970
 */
@AConQATProcessor(description = "This processor creates a KeyedData object by "
		+ "counting the frequency of objects specified by a key at the leaves "
		+ "ConQATNode hierarchy. The values must implement interface "
		+ "java.util.Comparable.")
public class ValueFrequencyProcessor extends ConQATProcessorBase implements
		INodeVisitor<IConQATNode, ConQATException> {

	/** The root node. */
	private IConQATNode root;

	/** Counter array for counting the frequency. */
	private final CounterSet<Comparable<?>> counter = new CounterSet<Comparable<?>>();

	/** Key for the value. */
	private String key;

	/** Set the root element to work on. */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC)
			IConQATNode root) {
		this.root = root;
	}

	/** Set key for value. */
	@AConQATParameter(name = ConQATParamDoc.READKEY_KEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Key pointing to the desired value.")
	public void setKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC)
			String key) {
		this.key = key;
	}

	/** {@inheritDoc} */
	public KeyedData<?> process() throws ConQATException {
		TraversalUtils.visitLeavesDepthFirst(this, root);
		return new KeyedData<Comparable<?>>(counter);
	}

	/**
	 * This method obtains the values from the node and increases counter
	 * accordingly. If the value is <code>null</code> it will be ignored but
	 * logged.
	 * 
	 * @throws ConQATException
	 *             if the value is neither <code>null</code> nor instance of
	 *             {@link Comparable}.
	 */
	public void visit(IConQATNode node) throws ConQATException {
		Object valueToStore = node.getValue(key);

		if (valueToStore == null) {
			getLogger().info("Null value for key " + key + " ignored.");
			return;
		}

		if (!(valueToStore instanceof Comparable)) {
			throw new ConQATException("Can't store value " + valueToStore
					+ " as it is not comparabale.");
		}

		// cast is safe as type was checked before
		counter.inc((Comparable<?>) valueToStore);
	}

}

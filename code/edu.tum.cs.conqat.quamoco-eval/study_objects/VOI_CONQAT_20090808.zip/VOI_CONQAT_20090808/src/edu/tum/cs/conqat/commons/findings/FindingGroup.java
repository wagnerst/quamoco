/*--------------------------------------------------------------------------+
   $Id: FindingGroup.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * A group of findings that collects related findings, such as the clones of a
 * clone group or findings indicating the same flaw.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 0E515B810009528BE1A4125AC07377A8
 */
public class FindingGroup extends ConQATNodeBase implements
		IRemovableConQATNode {

	/** The category this belongs to. */
	private final FindingCategory category;

	/** The description for this category. */
	private final String description;

	/** The findings in this group. */
	private final Map<Integer, Finding> findings = new HashMap<Integer, Finding>();

	/** Counter for generating unique child IDs. */
	private int idCounter = 0;

	/**
	 * Hidden constructor. Use the factory method in {@link FindingCategory}
	 * instead.
	 */
	/* package */FindingGroup(String description, FindingCategory category) {
		this.description = description;
		this.category = category;
	}

	/** Copy constructor. */
	/* package */FindingGroup(FindingGroup other, FindingCategory category)
			throws DeepCloneException {
		super(other);
		this.category = category;
		this.description = other.description;
		this.idCounter = other.idCounter;
		for (Finding finding : other.findings.values()) {
			this.findings.put(finding.id, new Finding(finding, this));
		}
	}

	/** {@inheritDoc} */
	public void remove() {
		category.remove(this);
	}

	/** Removes a finding. */
	/* package */void remove(Finding finding) {
		findings.remove(finding);
	}

	/** {@inheritDoc} */
	public String getId() {
		return category.getId() + ":" + getName();
	}

	/** {@inheritDoc} */
	public String getName() {
		return description;
	}

	/** {@inheritDoc} */
	public FindingCategory getParent() {
		return category;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !findings.isEmpty();
	}

	/** {@inheritDoc} */
	public Finding[] getChildren() {
		return findings.values().toArray(new Finding[findings.size()]);
	}

	/** Returns a finding by id (or null). */
	/* package */Finding getFindingById(int id) {
		return findings.get(id);
	}

	/** Creates a new finding. */
	public Finding createFinding(String originTool) {
		Finding finding = new Finding(this, originTool, ++idCounter);
		findings.put(finding.id, finding);
		return finding;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Throws an exception as we do not support cloning at this level.
	 */
	public IRemovableConQATNode deepClone() {
		throw new UnsupportedOperationException(
				"Deep cloning not supported at this level.");
	}

	/** Returns the number of children/findings. */
	public int getChildrenSize() {
		return findings.size();
	}
}

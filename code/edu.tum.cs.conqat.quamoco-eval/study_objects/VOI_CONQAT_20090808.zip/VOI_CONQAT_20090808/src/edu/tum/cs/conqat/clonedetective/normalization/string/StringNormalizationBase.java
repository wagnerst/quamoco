/*--------------------------------------------------------------------------+
   $Id: StringNormalizationBase.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.string;

import edu.tum.cs.commons.string.LineSplitter;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.lazyscope.IElementProvider;
import edu.tum.cs.conqat.clonedetective.normalization.UnitProviderBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.commons.pattern.PatternTransformationList;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for String based normalizations
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 637FE906228B868E9A70526D1F808C3E
 */
/* package */abstract class StringNormalizationBase extends
		UnitProviderBase<IFileSystemElement, StringUnit> {

	/** The input component used to access elements. */
	private final IElementProvider<IFileSystemElement> inputProvider;

	/** Processor that performs layout preserving removals during normalization */
	private final LayoutPreservingPatternReplacer removals;

	/** List of replacement transformations performed during normalization */
	private final PatternTransformationList replacements;

	/** The current source file. */
	private IFileSystemElement currentSourceFile;

	/** The current position within a file (line number) */
	private int currentLineNumber = -1;

	/** The current unit index within a file */
	private int currentUnitIndex = -1;

	/** Flag that determines whether empty lines are filtered out */
	protected final boolean ignoreEmptyLines;

	/** Flag that determines whether lines are trimmed */
	protected final boolean trimLines;

	/**
	 * Flag that determines whether all whitespace is removed from the string
	 * unit
	 */
	protected final boolean removeAllWhitespace;

	/** This is used to split lines. */
	private final LineSplitter splitter = new LineSplitter();

	/** Constructor */
	public StringNormalizationBase(
			IElementProvider<IFileSystemElement> inputProvider,
			PatternList removeConfig, PatternTransformationList replacements,
			boolean trimLines, boolean ignoreEmptyLines,
			boolean removeAllWhitespace) {
		this.inputProvider = inputProvider;
		this.removals = new LayoutPreservingPatternReplacer(removeConfig);
		this.replacements = replacements;
		this.ignoreEmptyLines = ignoreEmptyLines;
		this.trimLines = trimLines;
		this.removeAllWhitespace = removeAllWhitespace;

		// setting the splitter's input to the empty string makes it return null
		// on first call to splitter.getNextLine()
		splitter.setContent(StringUtils.EMPTY_STRING);
	}

	/** {@inheritDoc} */
	@Override
	protected void init(IFileSystemElement root) {
		inputProvider.init(root, getLogger());
	}

	/**
	 * Obtain next input line.
	 * 
	 * @return the next line or <code>null</code> if all lines have been
	 *         returned
	 * @throws CloneDetectionException
	 *             only thrown if the input component throws an exception. This
	 *             component itself <i>does not</i> throw any exceptions.
	 */
	@Override
	protected StringUnit provideNext() throws CloneDetectionException {
		// determine next line that is not ignored
		String content = null;
		while (content == null) {
			content = findNextUnignoredInFile();
			if (content == null && !moveToNextFileSucceeded()) {
				// no more lines found
				return null;
			}
		}

		currentUnitIndex++;
		int indexInFile = currentUnitIndex;

		return new StringUnit(normalize(content), currentSourceFile.getFile(),
				currentLineNumber, indexInFile);
	}

	/**
	 * Template method that allows deriving classes to perform normalization of
	 * the content
	 */
	protected abstract String normalize(String content);

	/** Retrieves next line from line splitter */
	protected String getNextLine() {
		currentLineNumber += 1;
		return splitter.getNextLine();
	}

	/**
	 * Template method that deriving classes override to provide the next string
	 * for unit creation
	 */
	protected abstract String findNextUnignoredInFile();

	/**
	 * Sets normalization to next input file.
	 * 
	 * @return true, if a new input file was found, false
	 */
	private boolean moveToNextFileSucceeded() throws CloneDetectionException {
		currentSourceFile = inputProvider.getNext();

		// check if there are more source files
		if (currentSourceFile == null) {
			// no more source files
			getLogger().debug("no more source files.");
			return false;
		}

		getLogger().debug("Processing source file: " + currentSourceFile);

		// set new splitter content and reset line number
		String content;
		try {
			content = normalizeCurrentFileContent();
		} catch (ConQATException e) {
			String filename = currentSourceFile.getFile().getCanonicalPath();
			throw new CloneDetectionException("Could not read content of file "
					+ filename, e);
		}
		splitter.setContent(content);
		currentLineNumber = -1;
		currentUnitIndex = -1;

		return true;
	}

	/**
	 * Reads content of current source file and applies normalizations.
	 * <p>
	 * Performs a check whether the normalization changed the number of lines.
	 * 
	 * @throws ConQATException
	 */
	private String normalizeCurrentFileContent() throws ConQATException {
		// read content
		String content = FileLibrary.getInstance().getContent(
				currentSourceFile.getFile());
		int lineNumberCountBefore = StringUtils.splitLines(content).length;

		// perform normalization
		content = removals.process(content);
		content = replacements.applyTransformation(content);

		// Check whether transformations have been layout preserving
		int lineNumberCountAfter = StringUtils.splitLines(content).length;
		if (lineNumberCountBefore != lineNumberCountAfter) {
			getLogger().warn(
					"Normalization of file '"
							+ currentSourceFile.getFile().getCanonicalPath()
							+ "' changed number of lines!");
		}

		// return normalized content
		return content;
	}

}
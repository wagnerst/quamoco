/*--------------------------------------------------------------------------+
   $Id: IConQATLogger.java 23485 2009-08-07 16:07:01Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.logging;

import edu.tum.cs.commons.logging.ILogger;

/**
 * This interface describes ConQAT loggers that are used to log information in
 * ConQAT processors. An instance of this interface is provided to every
 * processor via
 * {@link  edu.tum.cs.conqat.core.IConQATProcessorInfo#getLogger()}.
 * 
 * 
 * @author Florian Deissenboeck
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * @version $Rev: 23485 $
 * @levd.rating GREEN Hash: D4FFB6CC29A65BD955C85AB8824991F6
 */
public interface IConQATLogger extends ILogger {
	
	/** Log message with the specified level. */
	public void log(ELogLevel level, Object message);

	/** Log message with the specified level. */
	public void log(ELogLevel level, Object message, Throwable throwable);
}
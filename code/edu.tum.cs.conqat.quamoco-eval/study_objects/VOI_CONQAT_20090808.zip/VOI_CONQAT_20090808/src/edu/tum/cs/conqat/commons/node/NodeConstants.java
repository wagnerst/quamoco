/*--------------------------------------------------------------------------+
   $Id: NodeConstants.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.node;

import edu.tum.cs.conqat.commons.findings.FindingReport;

/**
 * Common constants used for the keys in the IConQATNode key value pairs. For
 * many of these there are convenience methods in
 * {@link edu.tum.cs.conqat.commons.node.NodeUtils}.
 * 
 * @author Florian Deissenboeck
 * @author Benjamin Hummel
 * @author Tilman Seifert
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 2EC2B19D67518FA45FB005755283C50B
 */
public class NodeConstants {

	/**
	 * The display list is appended to the root node of an IConQATONode
	 * hierarchy and holds a java.util.List&lt;String&gt; containing the keys
	 * relevant for the presentation layer.
	 */
	public static final String DISPLAY_LIST = "display-list";

	/**
	 * A java.util.Comparator that should be used for sorting the children of
	 * this node if sorting is required (e.g. in the presentation).
	 */
	public static final String COMPARATOR = "comparator";

	/**
	 * An {@link edu.tum.cs.commons.assessment.Assessment} for the node.
	 */
	public static final String SUMMARY = "summary";

	/**
	 * This can be attached to the root of node hierarchy to signal not to
	 * display the root node.
	 */
	public static final String HIDE_ROOT = "hide-root";

	/** A {@link FindingReport} for the root node. */
	public static final String FINDINGS_REPORT = "findings-report";
}

/*--------------------------------------------------------------------------+
   $Id: Finding.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.findings.location.LocationBase;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * A single finding which represents a single issue found during an analysis.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: FB6D11DA8533542A32B62CFE9B3EA6EE
 */
public class Finding extends ConQATNodeBase implements IRemovableConQATNode {

	/** The locations. */
	private final List<LocationBase> locations = new ArrayList<LocationBase>();

	/** The finding group this finding belongs to. */
	private final FindingGroup findingGroup;

	/** The originating tool. */
	private final String originTool;

	/** The id which is unique within the findings group. */
	/* package */final int id;

	/** Hidden constructor. Use factory methods in {@link FindingGroup} instead. */
	/* package */Finding(FindingGroup findingGroup, String originTool, int id) {
		this.findingGroup = findingGroup;
		this.originTool = originTool;
		this.id = id;
	}

	/** Copy constructor. */
	/* package */Finding(Finding other, FindingGroup findingGroup)
			throws DeepCloneException {
		super(other);
		this.findingGroup = findingGroup;
		this.originTool = other.originTool;
		this.id = other.id;
		this.locations.addAll(other.locations);
	}

	/** Returns the locations for this finding. */
	public UnmodifiableList<LocationBase> getLocations() {
		return CollectionUtils.asUnmodifiable(locations);
	}

	/** Adds a location. */
	public void addLocation(LocationBase location) {
		locations.add(location);
	}

	/** Returns the origin tool. */
	public String getOriginTool() {
		return originTool;
	}

	/** {@inheritDoc} */
	public IRemovableConQATNode[] getChildren() {
		return null;
	}

	/** {@inheritDoc} */
	public void remove() {
		findingGroup.remove(this);
	}

	/** {@inheritDoc} */
	public String getId() {
		return findingGroup.getId() + ":" + getName();
	}

	/** {@inheritDoc} */
	public String getName() {
		return originTool + " finding " + id;
	}

	/** {@inheritDoc} */
	public FindingGroup getParent() {
		return findingGroup;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Returns false.
	 */
	public boolean hasChildren() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Throws an exception as we do not support cloning at this level.
	 */
	public IRemovableConQATNode deepClone() {
		throw new UnsupportedOperationException(
				"Deep cloning not supported at this level.");
	}

	/** Returns the message if set. */
	public String getMessage() {
		Object o = getValue(EFindingKeys.MESSAGE.toString());
		if (o instanceof String) {
			return (String) o;
		}
		return StringUtils.EMPTY_STRING;
	}
}

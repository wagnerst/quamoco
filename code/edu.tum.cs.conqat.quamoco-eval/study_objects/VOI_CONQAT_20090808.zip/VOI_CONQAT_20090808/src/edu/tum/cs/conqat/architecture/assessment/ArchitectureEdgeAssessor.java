/*--------------------------------------------------------------------------+
   $Id: ArchitectureEdgeAssessor.java 23504 2009-08-07 16:20:27Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.assessment;

import java.util.ArrayList;
import java.util.Collection;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.architecture.format.EAssessmentType;
import edu.tum.cs.conqat.architecture.scope.ArchitectureDefinition;
import edu.tum.cs.conqat.architecture.scope.DependencyPolicy;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author Benjamin Hummel
 * @author Tilman Seifert
 * @author $Author: deissenb $
 * @version $Rev: 23504 $
 * @levd.rating GREEN Hash: 1105A9413B3029088CBD01F1DCC63741
 */
@AConQATProcessor(description = "This processor assesses the policies of the given "
		+ "architecture according to the dependencies stored there.")
public class ArchitectureEdgeAssessor extends
		ConQATPipelineProcessorBase<ArchitectureDefinition> {

	/** {@inheritDoc} */
	@Override
	protected void processInput(ArchitectureDefinition arch) {
		Collection<DependencyPolicy> policies = new ArrayList<DependencyPolicy>();
		arch.collectPolicies(policies);
		for (DependencyPolicy policy : policies) {
			policy.setAssessment(determineAssessmentType(policy));
		}
	}

	/** Returns a policy's assessments based on the dependencies. */
	private EAssessmentType determineAssessmentType(DependencyPolicy policy) {
		boolean empty = policy.getDependencies().isEmpty();

		switch (policy.getPolicyType()) {
		case ALLOW_EXPLICIT:
		case ALLOW_IMPLICIT:
			if (empty) {
				return EAssessmentType.UNNECESSARY;
			}
			return EAssessmentType.VALID;

		case DENY_IMPLICIT:
		case DENY_EXPLICIT:
			if (empty) {
				return EAssessmentType.VALID;
			}
			return EAssessmentType.INVALID;

		case TOLERATE_EXPLICIT:
			if (empty) {
				return EAssessmentType.UNNECESSARY;
			}
			for (ImmutablePair<String, String> dependency : policy
					.getDependencies()) {
				if (!policy.tolerated(dependency.getFirst(), dependency
						.getSecond())) {
					return EAssessmentType.INVALID;
				}
			}
			return EAssessmentType.VALID;

		default:
			CCSMAssert.fail("Unknown value: " + policy.getPolicyType());
		}
		return null;
	}
}

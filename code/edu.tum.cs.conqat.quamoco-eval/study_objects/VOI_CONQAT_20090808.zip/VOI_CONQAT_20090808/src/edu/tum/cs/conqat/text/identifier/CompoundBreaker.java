/*--------------------------------------------------------------------------+
   $Id: CompoundBreaker.java 23503 2009-08-07 16:17:42Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import edu.tum.cs.commons.string.StringUtils;

/**
 * This class breaks compound words in their components. It knows how to deal
 * with underscore-separated, whitespace-separated and camel cased words. The
 * algorithm removes trailing digits from the components and ignores components
 * of length one.
 * 
 * 
 * @author Florian Deissenboeck
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * 
 * @version $Revision: 23503 $
 * @levd.rating GREEN Hash: E7BD5FE4A9C9AC2336B78954816F5004
 */
public class CompoundBreaker {

	/** Matches all white space characters. */
	private final static Pattern WHITESPACE_PATTERN = Pattern.compile("\\s+");

	/**
	 * Matches any character that is not an upper case letter followed by an
	 * upper case letter.
	 */
	private final static Pattern LOWER_UPPER_PATTERN = Pattern
			.compile("(\\P{Lu})(\\p{Lu})");

	/** Matches digits at the of a string. */
	private final static Pattern END_DIGITS_PATTERN = Pattern.compile("\\d+$");

	/** Underscore */
	private final static String UNDERSCORE = "_";

	/**
	 * Break compound word.
	 * 
	 * @param compound
	 *            the compound to break.
	 * @return the components of the compound.
	 */
	public List<String> breakCompound(String compound) {
		List<String> result = new ArrayList<String>();

		Matcher matcher = WHITESPACE_PATTERN.matcher(compound);
		compound = matcher.replaceAll(UNDERSCORE);

		matcher = LOWER_UPPER_PATTERN.matcher(compound);
		compound = matcher.replaceAll("$1" + UNDERSCORE + "$2");

		for (String part : compound.split(UNDERSCORE)) {
			part = part.toLowerCase();

			matcher = END_DIGITS_PATTERN.matcher(part);
			part = matcher.replaceFirst(StringUtils.EMPTY_STRING);

			if (part.length() >= 2) {
				result.add(part);
			}
		}
		return result;
	}

}
/*--------------------------------------------------------------------------+
   $Id: JavaDocCache.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.library;

import java.io.File;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.sun.javadoc.ClassDoc;
import com.sun.tools.javac.util.Context;
import com.sun.tools.javac.util.ListBuffer;
import com.sun.tools.javadoc.JavadocTool;
import com.sun.tools.javadoc.Messager;
import com.sun.tools.javadoc.ModifierFilter;
import com.sun.tools.javadoc.RootDocImpl;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.java.scope.IJavaClassElement;
import edu.tum.cs.conqat.java.scope.IJavaElement;
import edu.tum.cs.conqat.java.scope.IJavaRootElement;
import edu.tum.cs.conqat.java.scope.JavaClassElement;

/**
 * Cache implementation for JavaDoc documentation. On the first documentation
 * request (via {@link #getDoc(IJavaClassElement)} the root element of the
 * element tree the requested element belongs to is determined. JavaDoc facility
 * is called for all class elements that are decendants of this root element.
 * All results are cached. On subsequent calls the documentation is returned
 * straight from the cache.
 * <p>
 * JavaDoc logging information is redirected to log4j. JavaDoc errors are logged
 * as warnings.
 * <p>
 * The current implementation has a number of drawbacks: <br/>
 * <br/>
 * 
 * <ul>
 * <li>It is not memory-sensitive. Caching may cause an out of memory error.</li>
 * <li>It doesn't deal with package documentation.</li>
 * <li>It is very inefficient in the following situation:<br/>
 * <ol>
 * <li>Class documentation is request for a specific element.</li>
 * <li>The documentation is not cached yet so JavaDoc facility is run for the
 * whole tree.</li>
 * <li>Another element is added to tree.</li>
 * <li>A request for that specific (new) element triggers a rerun of the JavaDoc
 * facility for the whole tree.</li>
 * <li>If this should happen inside some kind of iteration performance is
 * doomed.</li>
 * </ol>
 * </li>
 * <li>Due to the crude JavaDoc interface the implementation isn't very elegant.
 * </li>
 * </ul>
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: 7BE1AAADFC965DD68261207E34752465
 */
/* package */class JavaDocCache {

	/** Logger. */
	private static final Logger logger = Logger.getLogger(JavaDocCache.class);

	/**
	 * Cache. This uses the underlying file as key since {@link File} has a
	 * proper implementation of <code>hashCode()</code> method.
	 */
	private final HashMap<File, ClassDoc> cache = new HashMap<File, ClassDoc>();

	/**
	 * Get JavaDoc documentation for a class. If the documentation ist not
	 * cached this starts java doc processing for the whole class and package
	 * tree this class belongs to and caches all documentation nodes.
	 * 
	 * @return the JavaDoc documentation or <code>null</code> if documentation
	 *         couldn't be derived.
	 * @throws ConQATException
	 * 
	 */
	public ClassDoc getDoc(IJavaClassElement element) throws ConQATException {

		ClassDoc classDoc = cache.get(element.getFile());

		// already cached
		if (classDoc != null) {
			return classDoc;
		}

		// this tree hasn't been cached before, so process and cache it
		cache(element);

		// if it's not in cache now it couldn't be processed
		classDoc = cache.get(element.getFile());
		if (classDoc == null) {
			throw new ConQATException("Couldn't find JavaDoc for element: "
					+ element.getId());
		}

		return classDoc;
	}

	/**
	 * For a given elment find the root of the tree, start JavaDoc processing
	 * for the whole tree and cache all results.
	 * 
	 * @param element
	 *            any Java element of an tree
	 */
	private void cache(IJavaElement element) throws ConQATException {

		IJavaRootElement rootNode = element.getRootElement();

		Context context = new Context();

		PrintWriter errorWriter = new PrintWriter(new Stream2LoggerAdapter(
				logger, Level.DEBUG, "JavaDoc Error"));
		PrintWriter warningWriter = new PrintWriter(new Stream2LoggerAdapter(
				logger, Level.DEBUG, "JavaDoc Warning"));

		// do not store info messages
		PrintWriter infoWriter = new PrintWriter(new NullOutputStream());

		// This is correct, as the messager attaches itself to the context.
		new SimpleMessager(context, errorWriter, warningWriter, infoWriter);

		JavadocTool tool = JavadocTool.make0(context);

		ModifierFilter showAccess = new ModifierFilter(
				ModifierFilter.ALL_ACCESS);
		String encoding = StringUtils.EMPTY_STRING;
		String docLocale = StringUtils.EMPTY_STRING;
		boolean breakiterator = false;
		ListBuffer<String[]> options = new ListBuffer<String[]>();
		ListBuffer<String> includedElements = addAllChildren(rootNode);
		boolean docClasses = false;
		ListBuffer<String> subPackages = new ListBuffer<String>();
		ListBuffer<String> excludedPackages = new ListBuffer<String>();
		boolean quiet = false;

		try {
			RootDocImpl rootDoc = tool.getRootDocImpl(docLocale, encoding,
					showAccess, includedElements.toList(), options.toList(),
					breakiterator, subPackages.toList(), excludedPackages
							.toList(), docClasses, false, quiet);

			if (rootDoc == null) {
				throw new ConQATException("Could not analyze JavaDoc for "
						+ rootNode);
			}

			Map<String, IJavaElement> classLookup = TraversalUtils
					.createIdToNodeMap((IJavaElement) rootNode);
			for (ClassDoc doc : rootDoc.classes()) {
				IJavaElement tmpElement = classLookup.get(doc.qualifiedName());
				if (tmpElement instanceof IJavaClassElement) {
					cache.put(tmpElement.getFile(), doc);
				}
			}

		} 
catch (Exception e) {}
finally {
			errorWriter.close();
			warningWriter.close();
			infoWriter.close();
		}

	}

	/** Returns a list of all names of source files in the tree. */
	private ListBuffer<String> addAllChildren(IJavaElement element) {
		ListBuffer<String> result = new ListBuffer<String>();
		for (IJavaElement leaf : TraversalUtils.listLeavesDepthFirst(element)) {
			if (leaf instanceof JavaClassElement) {
				result.append(leaf.getFile().getCanonicalPath());
			}
		}
		return result;
	}

	/**
	 * As the constructor of {@link Messager} is protected, we need this class
	 * to create a messager instance.
	 */
	private class SimpleMessager extends Messager {
		/** Create new Messager. */
		protected SimpleMessager(Context context, PrintWriter errWriter,
				PrintWriter warnWriter, PrintWriter noticeWriter) {
			super(context, StringUtils.EMPTY_STRING, errWriter, warnWriter,
					noticeWriter);
		}
	}
}

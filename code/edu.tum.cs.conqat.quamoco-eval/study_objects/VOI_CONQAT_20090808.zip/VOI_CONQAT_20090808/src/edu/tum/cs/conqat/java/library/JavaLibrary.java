/*--------------------------------------------------------------------------+
   $Id: JavaLibrary.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.library;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;

import net.sourceforge.pmd.ast.ASTCompilationUnit;

import org.apache.bcel.classfile.JavaClass;

import com.sun.javadoc.ClassDoc;

import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.java.scope.IJavaClassElement;

/**
 * This class offers commonly used functionality for analyzing java files.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: A85C9A9D4E2188C00C4A0399F0F4C95D
 */
public class JavaLibrary {

	/** singleton instance */
	private static JavaLibrary instance;

	/** Cache for the AST representations of the class elements. */
	private final JavaASTCache astCache = new JavaASTCache();

	/** Cache for JavaDoc documentation. */
	private final JavaDocCache docCache = new JavaDocCache();

	/** package name extractor */
	private final PackageDeclarationExtractor extractor = new PackageDeclarationExtractor();

	/** Get the sole singleton instance. */
	public static JavaLibrary getInstance() {
		if (instance == null) {
			instance = new JavaLibrary();
		}
		return instance;
	}

	/** prevent intantiation */
	private JavaLibrary() {
		// prevent instantiation
	}

	/**
	 * Get full qualified class name of a class. The name is derived by
	 * analyzing the package statement in the file.
	 * 
	 * @param path
	 *            path of the source file
	 * @return the full qualified class name
	 * @throws IOException
	 *             if file can't be read.
	 * @throws ConQATException
	 */
	public String getFQClassName(String path) throws IOException,
			ConQATException {
		String packageName = extractor.getPackageName(path);
		if (packageName != null) {
			return packageName + "." + getClassName(path);
		}
		return getClassName(path);
	}

	/**
	 * Get the class name of a java class. The class name is derived from the
	 * file name.
	 * 
	 * @return the class name.
	 */
	private String getClassName(String path) {
		// strip .java extension
		String result = path.substring(0, path.length() - 5);

		int index = result.lastIndexOf(File.separator);
		if (index < 0) {
			return result;
		}
		return result.substring(index + 1);
	}

	/**
	 * Get AST for a class element.
	 * 
	 * @return the AST
	 * @throws ConQATException
	 *             if parsing fails
	 */
	public ASTCompilationUnit getAST(IJavaClassElement classElement)
			throws ConQATException {
		return astCache.getItem(classElement);
	}

	/**
	 * Get JavaDoc documentation for class. This includes cache management.
	 * 
	 * @throws ConQATException
	 *             if JavaDoc could not be retrieved for the element.
	 */
	public ClassDoc getDoc(IJavaClassElement javaClassElement)
			throws ConQATException {
		return docCache.getDoc(javaClassElement);
	}

	/**
	 * Obtain BCEL class object.
	 * 
	 * @return a BCEL class object,
	 * @throws ConQATException
	 *             if the class couldn't be found.
	 */
	public JavaClass getClass(IJavaClassElement classElement)
			throws ConQATException {
		// caching is handled in the root element.
		return classElement.getRootElement().getJavaClass(classElement.getId());
	}

	/**
	 * Get set of alls super classes and all interfaces of a class.
	 * 
	 * @throws ConQATException
	 *             if super classes and interfaces could not be resolved.
	 */
	public HashSet<JavaClass> getSuperClassesAndInterfaces(JavaClass clazz)
			throws ConQATException {

		HashSet<JavaClass> result = new HashSet<JavaClass>();
		try {
			JavaClass[] interfaces = clazz.getAllInterfaces();
			result.addAll(Arrays.asList(interfaces));

			JavaClass[] superClasses = clazz.getSuperClasses();
			result.addAll(Arrays.asList(superClasses));
		} catch (ClassNotFoundException e) {
			throw new ConQATException(
					"Could not determine interfaces or super classes for class: "
							+ clazz.getClassName());
		}
		return result;
	}

	/**
	 * Extracts the class name from a VM type signature (see
	 * http://java.sun.com/javase/6/docs/technotes/guides/jni/spec/types.html#wp16432).
	 * If this is just a plain class name is is returned without modification.
	 * In case of problems or primitive types an empty string is returned.
	 */
	public String ignoreArtificialPrefix(String className) {
		if (className.startsWith("[")) {
			while (className.startsWith("[")) {
				className = className.substring(1);
			}
			if (className.startsWith("L") && className.endsWith(";")) {
				className = className.substring(1, className.length() - 1);
			} else {
				return "";
			}
		}
		return className.replace('/', '.');
	}

	/**
	 * Returns true if this is an internal class.
	 */
	public boolean isInternalClass(String usedClassName) {
		return usedClassName.contains("$");
	}

	/**
	 * Check whether class element is an interface.
	 * 
	 * @throws ConQATException
	 *             if the class couldn't be found.
	 */
	public boolean isInterface(IJavaClassElement classElement)
			throws ConQATException {
		return getClass(classElement).isInterface();
	}
}

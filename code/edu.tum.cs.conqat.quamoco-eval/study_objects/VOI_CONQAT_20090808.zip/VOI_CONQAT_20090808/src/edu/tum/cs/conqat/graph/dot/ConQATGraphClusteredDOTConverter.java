/*--------------------------------------------------------------------------+
   $Id: ConQATGraphClusteredDOTConverter.java 23498 2009-08-07 16:13:56Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.dot;

import static edu.tum.cs.commons.string.StringUtils.CR;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphInnerNode;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;

/**
 * A class for converting a {@link ConQATGraph} to input suitable for the DOT
 * program using a clustered representation.
 * 
 * @author Florian Deissenboeck
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23498 $
 * @levd.rating GREEN Hash: CFFBCA290CD20120E0D8C28EC0726863
 */
public class ConQATGraphClusteredDOTConverter extends ConQATGraphDOTConverter {

	/** Counter for generating unique cluster names. */
	private int clusterID = 0;

	/** Use DFS for generating clusters. */
	@Override
	protected String createVertexDescription(ConQATGraph graph) {
		return createInnerNodeDescription(graph);
	}

	/** Creates the clustered description for a node and its children. */
	protected String createInnerNodeDescription(ConQATGraphInnerNode node) {
		StringBuilder result = new StringBuilder();

		for (ConQATGraphInnerNode inner : node.getInnerNodes()) {
			result.append("subgraph cluster_" + clusterID++ + " {" + CR
					+ "  label = \"" + makeLabel(inner) + "\";" + CR
					+ "  fontname = \"Helvetica\";" + CR);
			result.append(createInnerNodeDescription(inner));
			result.append("}" + CR);
		}

		for (ConQATVertex vertex : node.getChildVertices()) {
			result.append(createVertex(vertex));
		}

		return result.toString();
	}
}

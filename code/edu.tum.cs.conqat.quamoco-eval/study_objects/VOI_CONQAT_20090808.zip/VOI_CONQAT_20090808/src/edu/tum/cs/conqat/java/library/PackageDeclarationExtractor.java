/*--------------------------------------------------------------------------+
   $Id: PackageDeclarationExtractor.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.library;

import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;

import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.scanner.ELanguage;
import edu.tum.cs.scanner.ETokenType;
import edu.tum.cs.scanner.IScanner;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.ScannerException;
import edu.tum.cs.scanner.ScannerFactory;

/**
 * This class extracts the package name from Java source files using a scanner.
 * This is package visible as it is only accessed using the {@link JavaLibrary}.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: E200C40D799332F89ABAA9833BFCBF55
 */
/* package */class PackageDeclarationExtractor {

	/** The scanner. */
	private final IScanner scanner = ScannerFactory.newScanner(ELanguage.JAVA,
			new StringReader(""), null);

	/**
	 * Get package name of a source file. If a source file contains multiple
	 * package declarations only the first is evaluated.
	 * 
	 * @param path
	 *            file path
	 * @return the package name or <code>null</code> if class is in the
	 *         default package
	 * @throws IOException
	 *             if an IO exception occurs
	 * @throws ConQATException
	 *             if the file has an invalid package name
	 */
	public String getPackageName(String path) throws IOException,
			ConQATException {
		FileReader reader = new FileReader(path);
		scanner.reset(reader, null);

		IToken token;

		StringBuilder packageDeclaration = new StringBuilder();

		try {
			while ((token = scanner.getNextToken()).getType() != ETokenType.EOF) {

				// loop until package keyword
				if (token.getType() == ETokenType.PACKAGE) {

					// loop from from package keyword to semicolon
					while ((token = scanner.getNextToken()).getType() != ETokenType.SEMICOLON) {

						/*
						 * A package name must be qualified identifier which is
						 * defined as (JLS 18.1)
						 * 
						 * QualifiedIdentifier: Identifier { . Identifier }
						 * 
						 * Therefore an Exception is raised if a token other
						 * then identifier or dot is encountered. However, it is
						 * not ensured that the name starts and ends with an
						 * identifier
						 * 
						 */
						if (token.getType() != ETokenType.IDENTIFIER
								&& token.getType() != ETokenType.DOT) {
							throw new ConQATException("Illegal token '"
									+ token.getText() + "' (" + token.getType()
									+ ") in package statement in " + path);
						}

						// append to declaration
						packageDeclaration.append(token.getText());
					}

					// done after the first package declaration
					break;
				}
			}
		} catch (ScannerException e) {
			throw new ConQATException("Error while scanning " + path, e);
		} finally {
			reader.close();
		}

		// no package declaration found
		if (packageDeclaration.length() == 0) {
			return null;
		}

		return packageDeclaration.toString();
	}
}

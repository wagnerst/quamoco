/*--------------------------------------------------------------------------+
   $Id: ITokenConfiguration.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token.configuration;

/**
 * Configuration for token-based normalization.
 * <p>
 * Determines, how normalization is performed.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 3BC83BE0F15A232E125CB35DCC80B65E
 */
public interface ITokenConfiguration {

	/** Get name of this token configuration. */
	public String getName();

	/** Ignore delimiters? */
	public boolean isIgnoreDelimiters();

	/** Ignore comments? */
	public boolean isIgnoreComments();

	/** Ignore pre-processor directives? */
	public boolean isIgnorePreprocessorDirectives();
	
	/** Normalize identifiers? */
	public boolean isNormalizeIdentifiers();
	
	/** Normalize fully qualified names? */
	public boolean isNormalizeFullyQualifiedNames();
	
	/** Normalize type keywords? */
	public boolean isNormalizeTypeKeywords();

	/** Normalize string literals? */
	public boolean isNormalizeStringLiterals();

	/** Normalize char literals? */
	public boolean isNormalizeCharacterLiterals();

	/** Normalize number literals? */
	public boolean isNormalizeNumberLiterals();

	/** Normalize boolean literals? */
	public boolean isNormalizeBooleanLiterals();
	
	/** Ignore this reference? */
	public boolean isIgnoreThis();
	
	/** Ignore visibility modifier? */
	public boolean isIgnoreModifier();

}

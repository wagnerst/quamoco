/*--------------------------------------------------------------------------+
   $Id: TokenProvider.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.lazyscope.IElementProvider;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.ELanguage;
import edu.tum.cs.scanner.ILenientScanner;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.ScannerFactory;
import edu.tum.cs.scanner.ScannerUtils;
import edu.tum.cs.scanner.ETokenType.ETokenClass;

/**
 * Provides the tokens of an {@link ISourceCodeElement}.
 * 
 * @author Elmar Juergens
 * @author Christoph Mair
 * @author Rainer Spitzhirn
 * @author Julian Much
 * @author Sergius Schneider
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Revision: 23489 $
 * @levd.rating GREEN Hash: D68D895C8CC75BD0ABC8C08E542498F8
 */
public class TokenProvider extends TokenProviderBase {

	/**
	 * Files whose percentage of invalid tokens is higher than this threshold
	 * are discarded entirely. The rationale is that the scanner recognizes the
	 * file so badly, that it won't provide any sensible input for clone
	 * detection.
	 */
	private static final double INVALID_TOKENS_THRESHOLD = 0.15;

	/** The source component yielding elements. */
	private final IElementProvider<ISourceCodeElement> elementProvider;

	/** Scanner used for breaking file content into tokens */
	private ILenientScanner lenientScanner;

	/**
	 * The {@link ISourceCodeElement} currently being processed by the
	 * {@link TokenProvider}
	 */
	private ISourceCodeElement currentElement;

	/**
	 * Iterator keeps track of position in the list of tokens of the
	 * {@link ISourceCodeElement} currently being processed
	 */
	private Iterator<IToken> tokenIterator;

	/**
	 * Create new {@link TokenProvider}
	 */
	public TokenProvider(IElementProvider<ISourceCodeElement> inputComponent) {
		elementProvider = inputComponent;
	}

	/** Forward initialization to element provider */
	@Override
	public void init(ISourceCodeElement root) {
		elementProvider.init(root, getLogger());

		// create scanner for source language.
		ELanguage language = root.getLanguage();

		lenientScanner = ScannerFactory.newLenientScanner(language, "", null);
	}

	/**
	 * Returns the next token, or null, if there are no tokens left.
	 * <p>
	 * This actually works in a file by file manner. A scanner processes a full
	 * file and stores its tokens locally. Calls to this method then return
	 * stored tokens. So no performance provisions can be given on calls to this
	 * method.
	 * <p>
	 * This method is currently implemented in a recursive manner. If it should
	 * ever give performance problems or recursion stack overflow errors,
	 * consider to remove recursion.
	 * <p>
	 * {@link CloneDetectionException}s produced by the underlying scanner are
	 * logged as warnings.
	 */
	@Override
	protected IToken provideNext() throws CloneDetectionException {

		// token iterator is initialized and has more tokens
		if (tokenIterator != null && tokenIterator.hasNext()) {
			return tokenIterator.next();
		}

		// move to next file
		currentElement = elementProvider.getNext();

		// if there are no more files, we're done
		if (currentElement == null) {
			return null;
		}

		// get list of tokens in the current file
		List<IToken> tokens = readTokensFrom(currentElement);

		// ignore empty source files
		if (tokens.isEmpty()) {
			tokenIterator = null;
			// recursive call to get next valid token
			return getNext();
		}

		// set iterator and call recursively
		tokenIterator = tokens.iterator();
		return getNext();
	}

	/** Read all tokens from the an {@link ISourceCodeElement} into a list. */
	private List<IToken> readTokensFrom(ISourceCodeElement element) {
		if (element.getFile() == null) {
			return CollectionUtils.emptyList();
		}

		setScannerTo(element);
		String filename = element.getFile().getCanonicalPath();

		List<IToken> tokens = new ArrayList<IToken>();
		try {
			tokens = ScannerUtils.readTokens(lenientScanner);
		} catch (IOException e) {
			getLogger().warn(
					"Could not read tokens from element '" + filename + "':"
							+ e.getMessage());
		}

		handleErrorTokens(filename, tokens);

		return tokens;
	}

	/**
	 * Handles scanner errors. If the error tokens exceed threshold
	 * {@link #INVALID_TOKENS_THRESHOLD}, all tokens from a file are discarded,
	 * and a single corresponding log message is created. Else, log messages for
	 * each individual error token are created.
	 */
	private void handleErrorTokens(String filename, List<IToken> tokens) {
		List<IToken> errorTokens = getErrorTokens(tokens);

		if (tooManyErrorTokens(tokens, errorTokens)) {
			String message = "Could not read tokens from element '"
					+ filename
					+ "': Too many tokens could not be recognized by the scanner.";
			getLogger().warn(message);

			tokens.clear();
			return;
		}

		for (IToken token : errorTokens) {
			String message = "Unknown token in file: " + filename + ": "
					+ token;
			getLogger().warn(message);
		}

	}

	/** Determines whether error token ratio exceeds threshold */
	private boolean tooManyErrorTokens(List<IToken> tokens,
			List<IToken> errorTokens) {
		double invalidRatio = (double) errorTokens.size()
				/ (double) tokens.size();
		return invalidRatio >= INVALID_TOKENS_THRESHOLD;
	}

	/** Returns a list with the error tokens contained in a token list */
	private List<IToken> getErrorTokens(List<IToken> tokens) {
		List<IToken> errorTokens = new ArrayList<IToken>();

		for (IToken token : tokens) {
			if (token.getType().getTokenClass() == ETokenClass.ERROR) {
				errorTokens.add(token);
			}
		}

		return errorTokens;
	}

	/** Sets the scanner to work on the {@link ISourceCodeElement} */
	private void setScannerTo(ISourceCodeElement currentElement) {
		try {
			String content = FileLibrary.getInstance().getContent(
					currentElement.getFile());
			StringReader contentReader = new StringReader(content);
			lenientScanner.reset(contentReader, currentElement.getFile());
		} catch (ConQATException e) {
			getLogger().warn("Could not read file: " + e.getMessage());
		}
	}

}
/*--------------------------------------------------------------------------+
   $Id: IJavaElement.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.scope;

import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * Interface for java elements.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: A436AB6219F7D49182CCF69756755DD8
 */
public interface IJavaElement extends ISourceCodeElement {

	/** Returns the fully qualified class name. */
	public String getId();

	/** Get parent element. */
	public IJavaElement getParent();

	/**
	 * {@inheritDoc}
	 * <p>
	 * Redeclared to have more specific return type.
	 */
	public IJavaElement[] getChildren();

	/** Returns the root element. */
	public IJavaRootElement getRootElement();
}

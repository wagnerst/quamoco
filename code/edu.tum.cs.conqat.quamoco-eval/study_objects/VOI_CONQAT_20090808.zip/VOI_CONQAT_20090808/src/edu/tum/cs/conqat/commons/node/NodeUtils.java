/*--------------------------------------------------------------------------+
   $Id: NodeUtils.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.node;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.FindingsList;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Collection of utility methods used to manipulate key value pairs on
 * IConQATNodes.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 05BFEA0563215BA712BEB8B166D94041
 * 
 */
public class NodeUtils {

	/**
	 * Checks whether the value at the given key is a List. Returns the list if
	 * it exists, or <code>null</code> otherwise.
	 */
	public static List<String> getStringList(IConQATNode node, String key) {
		return getTypedList(node, key, String.class);
	}

	/**
	 * Checks whether the value at the given key is a List. Returns the list if
	 * it exists, or <code>null</code> otherwise.
	 */
	@SuppressWarnings("null")
	public static FindingsList getFindingsList(IConQATNode node, String key) {
		CCSMPre.isTrue(node != null, "Node may not be null!");
		Object o = node.getValue(key);
		if (!(o instanceof FindingsList)) {
			return null;
		}

		return (FindingsList) o;
	}

	/**
	 * Checks whether the value at the given key is a List. Returns the list if
	 * it exists, or <code>null</code> otherwise. This does not check the
	 * contents of the list, so if you are unsure use Object as type.
	 */
	@SuppressWarnings("null")
	private static <T> List<T> getTypedList(IConQATNode node, String key,
			@SuppressWarnings("unused") Class<T> type) {
		CCSMPre.isTrue(node != null, "Node may not be null!");

		Object o = node.getValue(key);
		if (!(o instanceof List)) {
			return null;
		}

		@SuppressWarnings("unchecked")
		List<T> list = (List<T>) o;
		return list;
	}

	/**
	 * Checks whether the value at the given key is a set. Returns the set if it
	 * exists, or <code>null</code> otherwise. This does not check the contents
	 * of the set, so if you are unsure use Object as type.
	 */
	@SuppressWarnings("null")
	private static <T> Set<T> getTypedSet(IConQATNode node, String key,
			@SuppressWarnings("unused") Class<T> type) {
		CCSMPre.isTrue(node != null, "Node may not be null!");

		Object o = node.getValue(key);
		if (!(o instanceof Set)) {
			return null;
		}

		@SuppressWarnings("unchecked")
		Set<T> set = (Set<T>) o;
		return set;
	}

	/**
	 * Checks whether the value at the given key is a List. If so, returns it,
	 * otherwise a new list is created, added, and returned.
	 */
	public static List<String> getOrCreateStringList(IConQATNode node,
			String key) {
		return getOrCreateTypedList(node, key, String.class);
	}

	/**
	 * Checks whether the value at the given key is a set. If so, returns it,
	 * otherwise a new set is created, added, and returned.
	 */
	public static Set<String> getOrCreateStringSet(IConQATNode node, String key) {
		Set<String> set = getTypedSet(node, key, String.class);
		if (set == null) {
			set = new HashSet<String>();
			node.setValue(key, set);
		}
		return set;
	}

	/**
	 * Checks whether the value at the given key is a List. If so, returns it,
	 * otherwise a new list is created, added, and returned.
	 */
	public static FindingsList getOrCreateFindingsList(IConQATNode node,
			String key) {
		FindingsList list = getFindingsList(node, key);
		if (list == null) {
			list = new FindingsList(node);
			node.setValue(key, list);
		}
		return list;
	}

	/**
	 * Checks whether the value at the given key is a List. If so, returns it,
	 * otherwise a new list is created, added, and returned.
	 */
	public static <T> List<T> getOrCreateTypedList(IConQATNode node,
			String key, Class<T> type) {
		List<T> list = getTypedList(node, key, type);
		if (list == null) {
			list = new ArrayList<T>();
			node.setValue(key, list);
		}
		return list;
	}

	/**
	 * Returns the display list of the provided ConQAT node. If none exists a
	 * new one will be created and added to the node.
	 * 
	 * @param node
	 *            the node to get the display list from.
	 */
	public static List<String> getDisplayList(IConQATNode node) {
		return getOrCreateStringList(node, NodeConstants.DISPLAY_LIST);
	}

	/**
	 * Appends all provided values not already in the display list to the
	 * display list of the given node.
	 */
	public static void addToDisplayList(IConQATNode node, String... values) {
		List<String> displayList = getDisplayList(node);
		for (String value : values) {
			if (!displayList.contains(value)) {
				displayList.add(value);
			}
		}
	}

	/**
	 * Appends all provided values not already in the display list to the
	 * display list of the given node.
	 */
	public static void addToDisplayList(IConQATNode node,
			Iterable<String> values) {
		for (String value : values) {
			addToDisplayList(node, value);
		}
	}

	/**
	 * Returns the summary assessment for a node. If none exists an empty
	 * assessment will be returned.
	 * 
	 * @param node
	 *            the node to get the summary assessment.
	 */
	public static Assessment getSummary(IConQATNode node) {
		return getOrCreateAssessment(node, NodeConstants.SUMMARY);
	}

	/**
	 * Returns the finding report stored at the node. If none exists, a new one
	 * will be created. Note that anything stored at this key which is not a
	 * {@link FindingReport} will be overwritten.
	 */
	public static FindingReport getFindingReport(IConQATNode node) {
		Object o = node.getValue(NodeConstants.FINDINGS_REPORT);
		if (!(o instanceof FindingReport)) {
			FindingReport report = new FindingReport();
			node.setValue(NodeConstants.FINDINGS_REPORT, report);
			return report;
		}
		return (FindingReport) o;
	}

	/**
	 * Checks whether the value at the given key is an assessment. If so, it is
	 * returned, otherwise creates a new assessment, adds it for the key and
	 * returns it.
	 * 
	 * @param node
	 *            the node to read the list from.
	 * @param key
	 *            the key the list is stored at.
	 */
	public static Assessment getOrCreateAssessment(IConQATNode node, String key) {
		Object o = node.getValue(key);
		if (!(o instanceof Assessment)) {
			Assessment a = new Assessment();
			node.setValue(key, a);
			return a;
		}
		return (Assessment) o;
	}

	/**
	 * Determines if the root node should be hidden or not. It will be hidden if
	 * value with key {@link NodeConstants#HIDE_ROOT} is <code>true</code>. In
	 * all other case or if the value is not present this returns
	 * <code>false</code>.
	 */
	public static boolean getHideRoot(IConQATNode node) {
		Object o = node.getValue(NodeConstants.HIDE_ROOT);
		return o instanceof Boolean && ((Boolean) o).booleanValue();
	}

	/**
	 * Add a message to a node that concerns a subelement of the node that is
	 * node model as {@link IConQATNode}. This creates a {@link HashedListMap}
	 * <code>&lt;String,String&gt;</code> at the node value.
	 * 
	 * @param node
	 *            node
	 * @param key
	 *            message key
	 * @param id
	 *            id of the subelement
	 * @param message
	 *            the message
	 * @throws ConQATException
	 *             if the node already has value for the defined key different
	 *             from a {@link HashedListMap}.
	 */
	@SuppressWarnings("unchecked")
	public static void addMessage(IConQATNode node, String key, String id,
			String message) throws ConQATException {

		Object value = node.getValue(key);

		HashedListMap<String, String> map;
		if (value == null) {
			map = new HashedListMap<String, String>();
			node.setValue(key, map);
		} else if (!(value instanceof HashedListMap)) {
			throw new ConQATException("Node " + node.getId()
					+ " already has a value of type "
					+ value.getClass().getName());
		} else {
			map = (HashedListMap<String, String>) value;
		}
		map.add(id, message);
	}

	/**
	 * Get messages created by
	 * {@link #addMessage(IConQATNode, String, String, String)}.
	 * 
	 * @param node
	 *            the node the message is attached to
	 * @param key
	 *            message key
	 * @param id
	 *            subelement id
	 * @return the list of messages for the specified sub element or
	 *         <code>null</code> if no message were found
	 */
	public static List<String> getMessageList(IConQATNode node, String key,
			String id) {

		HashedListMap<String, String> map = getMessages(node, key);

		if (map == null) {
			return null;
		}

		return map.getList(id);
	}

	/**
	 * Get messages created by
	 * {@link #addMessage(IConQATNode, String, String, String)}.
	 * 
	 * @param node
	 *            the node the message is attached to
	 * @param key
	 *            message key
	 * @return the messages or <code>null</code> if no message were found
	 */
	@SuppressWarnings("unchecked")
	public static HashedListMap<String, String> getMessages(IConQATNode node,
			String key) {
		Object value = node.getValue(key);

		if (!(value instanceof HashedListMap)) {
			return null;
		}
		return (HashedListMap<String, String>) value;
	}

	/**
	 * Get a double value stored at a node.
	 * 
	 * @throws ConQATException
	 *             if the value is <code>null</code> or not numeric.
	 */
	public static double getDoubleValue(IConQATNode node, String key)
			throws ConQATException {
		Object value = node.getValue(key);
		if (!(value instanceof Number)) {
			throw new ConQATException("Value '" + value + "' stored for key '"
					+ key + "' at node '" + node.getId() + "' is not a number.");
		}
		return ((Number) value).doubleValue();
	}

	/**
	 * Get a double value stored at a node. If the value is <code>null</code> or
	 * not number the provided default value is returned.
	 */
	public static double getDoubleValue(IConQATNode node, String key,
			double defaultValue) {
		try {
			return getDoubleValue(node, key);
		} catch (ConQATException e) {
			return defaultValue;
		}
	}

	/**
	 * Get string representation of the value stored at a node.
	 * 
	 * @throws ConQATException
	 *             if the value is <code>null</code>.
	 */
	public static String getStringValue(IConQATNode node, String key)
			throws ConQATException {
		Object value = node.getValue(key);
		if (value == null) {
			throw new ConQATException("No value stored for key '" + key
					+ "' at node '" + node.getId() + "' is not a number.");
		}
		return value.toString();
	}

	/**
	 * Get string representation of the value stored at a node. If the value is
	 * <code>null</code>, the provided default value is returned.
	 */
	public static String getStringValue(IConQATNode node, String key,
			String defaultValue) {
		Object value = node.getValue(key);
		if (value == null) {
			return defaultValue;
		}
		return value.toString();
	}

	/**
	 * Get value of a specified type stored at a node.
	 * 
	 * @throws ConQATException
	 *             if the value is <code>null</code> or not an instance of the
	 *             specified type.
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getValue(IConQATNode node, String key, Class<T> type)
			throws ConQATException {
		Object value = node.getValue(key);
		if (!type.isInstance(value)) {
			throw new ConQATException("Value '" + value + "' stored for key '"
					+ key + "' at node '" + node.getId() + "' is not a "
					+ type.getName() + ".");
		}
		return (T) value;
	}

	/**
	 * Get value of a specified type stored at a node. If the value is
	 * <code>null</code> or not an instance of the specified type the provided
	 * default value is returned.
	 */
	public static <T> T getValue(IConQATNode node, String key, Class<T> type,
			T defaultValue) {
		try {
			return getValue(node, key, type);
		} catch (ConQATException e) {
			return defaultValue;
		}
	}

	/**
	 * Checks if the node defines a comparator via
	 * {@link NodeConstants#COMPARATOR} and returns the sorted children of the
	 * node. If no comparator is defined the children are returned unsorted.
	 * Returns <code>null</code> if the node doesn't have children.
	 */
	@SuppressWarnings("unchecked")
	public static IConQATNode[] getSortedChildren(IConQATNode node) {
		if (!node.hasChildren()) {
			return null;
		}
		IConQATNode[] children = node.getChildren();

		Comparator comparator = getComparator(node);
		if (comparator != null) {
			Arrays.sort(children, comparator);
		}
		return children;
	}

	/**
	 * Checks if the node defines a comparator via
	 * {@link NodeConstants#COMPARATOR} and returns the sorted children of the
	 * node. This method is required as the
	 * {@link #getSortedChildren(edu.tum.cs.conqat.commons.node.IConQATNode)}
	 * method does not return {@link IRemovableConQATNode}s. We cannot make this
	 * generic as this would require each node to return children of the same
	 * type as the node.
	 */
	@SuppressWarnings("unchecked")
	public static IRemovableConQATNode[] getRemovableSortedChildren(
			IRemovableConQATNode node) {
		if (!node.hasChildren()) {
			return null;
		}
		IRemovableConQATNode[] children = node.getChildren();
		Comparator comparator = getComparator(node);
		if (comparator != null) {
			Arrays.sort(children, comparator);
		}
		return children;
	}

	/**
	 * Get comparator stored at key {@value NodeConstants#COMPARATOR}. This
	 * returns <code>null</code> if value is not present or not of type
	 * {@link Comparator},
	 */
	public static Comparator<?> getComparator(IConQATNode node) {
		Object comparatorObject = node.getValue(NodeConstants.COMPARATOR);
		if (comparatorObject instanceof Comparator) {
			return (Comparator<?>) comparatorObject;
		}
		return null;
	}

	/**
	 * For each key in keyList, copy stored value from sourceNode to targetNode.
	 * 
	 * @param keyList
	 *            List of keys for which stored values are copied.
	 * 
	 * @param sourceNode
	 *            Node from which values are read.
	 * 
	 * @param targetNode
	 *            Node to which values are copied
	 */
	public static void copyValues(Iterable<String> keyList,
			IConQATNode sourceNode, IConQATNode targetNode) {

		for (String key : keyList) {
			Object value = sourceNode.getValue(key);
			if (value != null) {
				targetNode.setValue(key, value);
			}
		}
	}

	/**
	 * Returns the root node for the given node, which is found by traversing up
	 * the hierarchy as long as the parent node is not null.
	 */
	public static IConQATNode getRootNode(IConQATNode node) {
		while (node.getParent() != null) {
			node = node.getParent();
		}
		return node;
	}
}

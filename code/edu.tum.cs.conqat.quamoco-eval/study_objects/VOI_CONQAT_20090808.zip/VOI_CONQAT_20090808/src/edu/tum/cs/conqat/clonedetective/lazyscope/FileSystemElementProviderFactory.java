/*--------------------------------------------------------------------------+
   $Id: FileSystemElementProviderFactory.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Creates a {@link FileSystemElementProvider}.
 * <p>
 * This class could be unified with {@link SourceCodeElementProviderFactory}
 * using generics. However, since the ConQAT load time type checking mechanism
 * cannot deal with generics, this was deliberately not done.
 * 
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * 
 * @version $Revision: 23489 $
 * @levd.rating GREEN Hash: 2DA033A71A06A583EBF0722325AA0EF3
 */
@AConQATProcessor(description = "Creates a FileSystemElementProvider")
public class FileSystemElementProviderFactory extends ConQATProcessorBase {

	/** Key under which ignore flag is stored */
	private String ignoreKey;

	/** ConQAT Parameter */
	@AConQATParameter(name = "ignore", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Key under which ignore flag is stored.")
	public void setIgnoreKey(
			@AConQATAttribute(name = "key", description = "If no key is given, no files are ignored")
			String ignoreKey) {
		this.ignoreKey = ignoreKey;
	}

	/** Creates a {@link FileSystemElementProvider} */
	public FileSystemElementProvider process() {
		return new FileSystemElementProvider(ignoreKey);
	}
}

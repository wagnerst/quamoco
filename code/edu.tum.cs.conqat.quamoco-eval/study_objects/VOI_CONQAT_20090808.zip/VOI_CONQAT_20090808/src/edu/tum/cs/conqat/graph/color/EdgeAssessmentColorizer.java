/*--------------------------------------------------------------------------+
   $Id: EdgeAssessmentColorizer.java 23498 2009-08-07 16:13:56Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.color;

import java.awt.Color;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.color.ECCSMColor;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Determine edge colors based on assessment.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23498 $
 * @levd.rating GREEN Hash: B08F477B8D685C68D6828E80FD9038E1
 */
@AConQATProcessor(description = "Colors the edges of the provided graph based on the stored assessment.")
public class EdgeAssessmentColorizer extends EdgeColorizerBase<Assessment> {

	/** {@inheritDoc} */
	@Override
	protected Color determineColor(Assessment assessment) {
		switch (assessment.getDominantColor()) {
		case RED:
			return ECCSMColor.RED.getColor();
		case YELLOW:
			return ECCSMColor.YELLOW.getColor();
		case GREEN:
			return ECCSMColor.GREEN.getColor();
		default:
			return Color.GRAY;
		}
	}
}

/*--------------------------------------------------------------------------+
   $Id: CloneListReportWriterProcessor.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.report.CloneReportWriter;
import edu.tum.cs.conqat.clonedetective.core.report.SourceFileDescriptor;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * @version $Revision: 23489 $
 * @levd.rating GREEN Hash: FF3BB1CD8A2380B1ACFA5F8C00AEE547
 */
@AConQATProcessor(description = "Processor that writes a clone detection result file in xml format."
		+ "This processor writes a report based on the clone list alone.")
public class CloneListReportWriterProcessor extends
		CloneReportWriterProcessorBase {

	/** Clone detection result for which report gets written */
	private List<CloneClass> cloneClasses;

	/** ConQAT Parameter */
	@AConQATParameter(name = "clone-classes", description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setDetectionResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) List<CloneClass> cloneClasses) {
		this.cloneClasses = cloneClasses;
	}

	/** {@inheritDoc} */
	@Override
	protected void doWriteReport() throws ConQATException {
		writeReport(cloneClasses, new Date(), targetFile, getLogger());
	}

	/**
	 * Writes a clone report file using a {@link CloneReportWriter}.
	 * 
	 * @param cloneClasses
	 *            Result clone classes that get written to the report
	 * @param systemDate
	 *            Date denoting the system version on which clone detection was
	 *            performed.
	 * @param targetFile
	 *            File into which report gets written
	 * @param logger
	 *            Logger used to log errors occurring during report writing
	 * 
	 * @throws ConQATException
	 *             If report creation fails.
	 */
	public static void writeReport(List<CloneClass> cloneClasses,
			Date systemDate, File targetFile,
			@SuppressWarnings("unused") IConQATLogger logger)
			throws ConQATException {
		CloneReportWriter.writeReport(cloneClasses,
				createSourceFileDescriptors(cloneClasses), systemDate,
				targetFile);
	}

	/** Creates a Map from Clone files to {@link SourceFileDescriptor}s. */
	private static Map<CanonicalFile, SourceFileDescriptor> createSourceFileDescriptors(
			List<CloneClass> cloneClasses) {
		Map<CanonicalFile, SourceFileDescriptor> sourceFileInfos = new HashMap<CanonicalFile, SourceFileDescriptor>();

		int sourceFileIdCounter = 0;

		// determine set of files
		Set<CanonicalFile> files = new HashSet<CanonicalFile>();
		for (CloneClass cloneClass : cloneClasses) {
			for (Clone clone : cloneClass.getClones()) {
				files.add(clone.getFile());
			}
		}

		// compute mapping
		for (CanonicalFile file : CollectionUtils.sort(files)) {
			sourceFileInfos.put(file, new SourceFileDescriptor(
					sourceFileIdCounter++, file, -1, StringUtils.EMPTY_STRING));
		}

		return sourceFileInfos;
	}

}

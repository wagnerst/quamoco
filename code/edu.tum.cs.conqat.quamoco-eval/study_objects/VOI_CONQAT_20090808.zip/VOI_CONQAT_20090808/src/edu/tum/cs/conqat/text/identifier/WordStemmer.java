/*--------------------------------------------------------------------------+
   $Id: WordStemmer.java 23503 2009-08-07 16:17:42Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor creates a set of stemmed words from a set of words. It uses
 * Porter's Stemming Algorithm.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23503 $
 * @levd.rating GREEN Hash: 448E5476B0C4A4F24F90B83A769B6205
 * 
 * @see edu.tum.cs.conqat.text.identifier.PorterStemmer
 */
@AConQATProcessor(description = "This processor creates a set of "
		+ "stemmed words from a set of english words. It uses Porter's "
		+ "Stemming Algorithm.")
public class WordStemmer extends ConQATProcessorBase {

	/** Set of original words. */
	private Set<String> words;

	/** Set of stemmed words. */
	private final Set<String> stemmedWords = new HashSet<String>();

	/** Set set of words. */
	@AConQATParameter(name = "words", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Defined the set of words being stemmed.")
	public void setList(
			@AConQATAttribute(name = "set", description = "The set of english words (strings).")
			Set<String> list) {
		this.words = list;
	}

	/** {@inheritDoc} */
	public Set<String> process() {
		PorterStemmer stemmer = new PorterStemmer();
		for (String word : words) {
			stemmedWords.add(stemmer.stem(word));
		}
		return stemmedWords;
	}
}

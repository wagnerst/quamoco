/*--------------------------------------------------------------------------+
   $Id: SimulinkModelElement.java 23502 2009-08-07 16:17:34Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.scope;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.FileSystemElement;
import edu.tum.cs.simulink.model.SimulinkModel;

/**
 * This class represent Simulink model files.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23502 $
 * @levd.rating GREEN Hash: 5D4C02A70D38F6FF2770210AC9984468
 */
public class SimulinkModelElement extends SimulinkElement {

	/** The encapsulated model. */
	private final SimulinkModel model;

	/**
	 * Constructor.
	 * 
	 * @throws ConQATException
	 *             if name could not be canonicalized
	 */
	public SimulinkModelElement(SimulinkModel model, String name)
			throws ConQATException {
		super(name);
		this.model = model;
	}

	/** Copy constructor. */
	protected SimulinkModelElement(SimulinkModelElement modelNode)
			throws DeepCloneException {
		super(modelNode);
		model = modelNode.model.deepClone();
	}

	/** {@inheritDoc} */
	@Override
	public SimulinkModelElement deepClone() throws DeepCloneException {
		return new SimulinkModelElement(this);
	}

	/** Returns the enclosed model. */
	public SimulinkModel getModel() {
		return model;
	}

	/** Throws exception as model elements cannot have children. */
	@Override
	public void addChild(FileSystemElement childNode) {
		CCSMAssert.fail("Cannot add child to model element");
	}
}

/*--------------------------------------------------------------------------+
   $Id: CloneClassMerger.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection.filter;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import edu.tum.cs.commons.collections.IdentityHashSet;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: F71F9A969B871EC980B4B5F3DFD620BF
 */
@AConQATProcessor(description = "Merges clone classes that contain clones with identical fingerprints")
public class CloneClassMerger extends
		ConQATPipelineProcessorBase<CloneDetectionResultElement> {

	/** {@inheritDoc} */
	@Override
	protected void processInput(CloneDetectionResultElement input) {

		Set<CloneClass> result = new IdentityHashSet<CloneClass>();
		Map<String, CloneClass> clonesMap = new HashMap<String, CloneClass>();
		for (CloneClass cloneClass : input.getList()) {
			Set<CloneClass> mergeClasses = new IdentityHashSet<CloneClass>();
			for (Clone clone : cloneClass.getClones()) {
				mergeClasses.add(clonesMap.get(clone.getFingerprint()));
			}
			mergeClasses.remove(null);

			if (!mergeClasses.isEmpty()) {
				result.removeAll(mergeClasses);
				for (CloneClass mergeClass : mergeClasses) {
					for (Clone clone : mergeClass.getClones()) {
						cloneClass.add(clone);
					}
				}
			}
			for (Clone clone : cloneClass.getClones()) {
				clonesMap.put(clone.getFingerprint(), cloneClass);
			}
			result.add(cloneClass);
		}

		int mergedCount = input.getList().size() - result.size();
		getLogger().debug(
				"Removed " + mergedCount + " clone classes through merging");

		input.getList().clear();
		input.getList().addAll(result);
	}

}

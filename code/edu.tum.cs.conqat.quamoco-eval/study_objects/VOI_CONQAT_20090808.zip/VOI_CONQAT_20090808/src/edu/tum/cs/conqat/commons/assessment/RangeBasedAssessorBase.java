/*--------------------------------------------------------------------------+
   $Id: RangeBasedAssessorBase.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.assessment;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * An assessor based on given ranges.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 5B445402CDCA7B77BF17D2D00749832C
 */
public abstract class RangeBasedAssessorBase<E> extends LocalAssessorBase<E> {

	/** The ranges used in the assessment. */
	private final List<Range> ranges = new ArrayList<Range>();

	/** Color used, if no range matches. */
	private ETrafficLightColor defaultColor = ETrafficLightColor.RED;

	/** Add a new assessment range. */
	@AConQATParameter(name = "range", description = "Adds an assessment range.")
	public void addRange(
			@AConQATAttribute(name = "lower", description = "lower bound of the range")
			double lower,
			@AConQATAttribute(name = "upper", description = "upper bound of the range")
			double upper,
			@AConQATAttribute(name = "color", description = "color to use if the value is in this range")
			ETrafficLightColor color) throws ConQATException {
		ranges.add(new Range(lower, upper, color));
	}

	/** Set the color used if no range matches. */
	@AConQATParameter(name = "default", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Set the assessment color returned if no range contained the value. Default is RED.")
	public void setDefaultColor(
			@AConQATAttribute(name = "color", description = "traffic light color")
			ETrafficLightColor color) {
		defaultColor = color;
	}

	/** {@inheritDoc} */
	@Override
	protected final Assessment assessValue(E e) {
		double value = obtainDouble(e);
		for (Range r : ranges) {
			if (r.contains(value)) {
				return new Assessment(r.color);
			}
		}
		return new Assessment(defaultColor);
	}

	/** Obtains a double from the value which should be assessed. */
	protected abstract double obtainDouble(E value);

	/** Helper class to store ranges and their assigned colors. */
	private static class Range {

		/** lower bound */
		private final double lower;

		/** upper bound */
		private final double upper;

		/** assigned color. */
		public final ETrafficLightColor color;

		/** Constructor. */
		public Range(double lower, double upper, ETrafficLightColor color)
				throws ConQATException {
			if (lower > upper) {
				throw new ConQATException("Invalid range (lower > upper).");
			}
			this.lower = lower;
			this.upper = upper;
			this.color = color;
		}

		/** Returns whether the provided value is contained in this range. */
		public boolean contains(double value) {
			return (lower <= value) && (value <= upper);
		}
	}
}

/*--------------------------------------------------------------------------+
   $Id: LocalAssessorBase.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.assessment;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for processors creating an assessment based on local decisions
 * (i.e. without looking at other nodes).
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: D4554AD6856E082C987A7ABF157C9441
 * 
 * @param <E>
 *            the type expected by the assessment method.
 */
public abstract class LocalAssessorBase<E> extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.ALL;
	}

	/** The key to read from. */
	private String readKey;

	/** The key to write the result into. */
	private String outputKey;

	/** Color used, if the key does not exist. */
	private ETrafficLightColor errorColor = ETrafficLightColor.UNKNOWN;

	/** Whether to replace an assessment or to merge it with an old one. */
	private boolean replace = false;

	/** Set the key to read from. */
	@AConQATParameter(name = ConQATParamDoc.READKEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Set the key to read the assessed value from.")
	public void setReadKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC)
			String key) {
		readKey = key;
	}

	/** Set the key used for writing. */
	@AConQATParameter(name = ConQATParamDoc.WRITEKEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The key to write the assessment into.")
	public void setWriteKey(
			@AConQATAttribute(name = ConQATParamDoc.WRITEKEY_KEY_NAME, description = ConQATParamDoc.WRITEKEY_KEY_DESC)
			String key) {
		outputKey = key;
	}

	/** Set the color used if an error occurs. */
	@AConQATParameter(name = "error", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Set the assessment color returned if the read key is not present or of the wrong type."
			+ " Default is UNKNOWN.")
	public void setErrorColor(
			@AConQATAttribute(name = "color", description = "traffic light color")
			ETrafficLightColor color) {
		errorColor = color;
	}

	/** Set whether to replace an assessment or to merge it with an old one. */
	@AConQATParameter(name = "replace", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "This controls what happens if the key already holds an assessment. "
			+ "Setting it true will replace the old one, while false will merge both."
			+ "Default is false (i.e. merge).")
	public void setReplace(
			@AConQATAttribute(name = "value", description = "true (replace) or false (merge)")
			boolean value) {
		replace = value;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		NodeUtils.addToDisplayList(root, outputKey);
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) {
		Assessment assessment = null;

		try {
			Object o = node.getValue(readKey);
			if (o != null) {
				@SuppressWarnings("unchecked")
				E value = (E) o;
				assessment = assessValue(value);
			}
		} catch (ClassCastException e) {
			// ignore here, as we use the error color instead below
		}

		if (assessment == null) {
			assessment = new Assessment(errorColor);
		}

		if (replace) {
			node.setValue(outputKey, assessment);
		} else {
			NodeUtils.getOrCreateAssessment(node, outputKey)
					.add(assessment);
		}
	}

	/**
	 * Calculates the assessment for a given value. In case of an error
	 * <code>null</code> should be returned.
	 * 
	 * @param value
	 *            the value to be assessed.
	 */
	protected abstract Assessment assessValue(E value);
}

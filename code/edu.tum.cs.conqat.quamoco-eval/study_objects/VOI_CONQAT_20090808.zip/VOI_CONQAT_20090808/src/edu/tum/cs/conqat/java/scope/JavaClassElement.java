/*--------------------------------------------------------------------------+
   $Id: JavaClassElement.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.scope;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.filesystem.CanonicalFile;

/**
 * An element representing a Java class. A java class element maintains two
 * references, one to the source code file and the other to the byte code file
 * of the java class it represents.
 * <p>
 * The methods specified <code>IFileSystemElement</code> apply to the source
 * file representation of the class.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: 0D8A988889F73912D9BC76AC13B15FD3
 * 
 * @see edu.tum.cs.conqat.filesystem.scope.IFileSystemElement
 */
public class JavaClassElement extends JavaElementBase implements
		IJavaClassElement {

	/** Source path */
	private final CanonicalFile sourceFile;

	/** Byte code path. */
	private final CanonicalFile byteCodeFile;

	/**
	 * Create a new class element.
	 * 
	 * @param name
	 *            the local name of the class
	 * @param sourceFile
	 *            path to the class' source file
	 * @param byteCodeFile
	 *            path to the class' bytecode file
	 */
	public JavaClassElement(String name, CanonicalFile sourceFile,
			CanonicalFile byteCodeFile) {
		super(name);
		this.sourceFile = sourceFile;
		this.byteCodeFile = byteCodeFile;
	}

	/** Copy constructor. */
	protected JavaClassElement(JavaClassElement element)
			throws DeepCloneException {
		super(element);
		this.sourceFile = element.sourceFile;
		this.byteCodeFile = element.byteCodeFile;
	}

	/** As classes can't have children this always returns <code>null</code>. */
	public JavaElementBase[] getChildren() {
		return null;
	}

	/** As classes can't have children this always returns <code>false</code>. */
	public boolean hasChildren() {
		return false;
	}

	/** {@inheritDoc} */
	@Override
	public JavaClassElement deepClone() throws DeepCloneException {
		return new JavaClassElement(this);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * This is the same as {@link #getSourceCodeFile()}.
	 */
	public CanonicalFile getFile() {
		return getSourceCodeFile();
	}

	/** {@inheritDoc} */
	public CanonicalFile getByteCodeFile() {
		return byteCodeFile;
	}

	/** {@inheritDoc} */
	public CanonicalFile getSourceCodeFile() {
		return sourceFile;
	}

}

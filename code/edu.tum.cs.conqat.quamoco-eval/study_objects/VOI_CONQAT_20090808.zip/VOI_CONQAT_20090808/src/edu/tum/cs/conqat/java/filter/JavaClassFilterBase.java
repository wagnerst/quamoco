/*--------------------------------------------------------------------------+
   $Id: JavaClassFilterBase.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.filter;

import org.apache.bcel.classfile.JavaClass;

import edu.tum.cs.conqat.commons.filter.FilterBase;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.java.library.JavaLibrary;
import edu.tum.cs.conqat.java.scope.IJavaClassElement;
import edu.tum.cs.conqat.java.scope.IJavaElement;

/**
 * Base class for Java class filters.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: AEBD196652873A623959A1D3C4A5D9F7
 */
public abstract class JavaClassFilterBase extends FilterBase<IJavaElement> {

	/** Single library instance. */
	private static final JavaLibrary javaLibrary = JavaLibrary.getInstance();

	/** {@inheritDoc} */
	@Override
	protected final boolean isFiltered(IJavaElement element) {
		if (element instanceof IJavaClassElement) {
			IJavaClassElement classElement = (IJavaClassElement) element;
			try {
				JavaClass analyzedClass = javaLibrary.getClass(classElement);
				return isFiltered(classElement, analyzedClass);
			} catch (ConQATException ex) {
				getLogger().warn("Could not analyze class: " + element.getId());
			}
		}
		return false;
	}

	/**
	 * Template method for filtering java classes.
	 * 
	 * @param classElement
	 *            the class element
	 * @param analyzedClass
	 *            the corresponding BCEL class object.
	 * @return <code>true</code> if element should be filtered,
	 *         <code>false</code> if not
	 */
	protected abstract boolean isFiltered(IJavaClassElement classElement,
			JavaClass analyzedClass);

}

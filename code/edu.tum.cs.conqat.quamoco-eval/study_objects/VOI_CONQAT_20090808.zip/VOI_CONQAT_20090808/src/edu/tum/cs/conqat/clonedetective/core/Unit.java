/*--------------------------------------------------------------------------+
   $Id: Unit.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import edu.tum.cs.commons.filesystem.CanonicalFile;

/**
 * Base class for units.
 * <p>
 * We have observed that in large code bases, the number of different units
 * after normalization is significantly smaller than the total number of units.
 * We exploit this observation in order to reduce the memory footprint of the
 * units by pooling unit content strings. This way, each unit content string is
 * only kept in memory once, independent of how often it occurs in the source
 * code. For pooling, we use Java's {@link String#intern()} facility in the
 * constructor {@link Unit}.
 * <p>
 * <b>Note:</b> The implementation of {@link #hashCode()} and
 * {@link #equals(Object)} are crucial for the detection algorithm.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @author Elmar Juergens
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: C832AAE8EA960984B5130497824BE8B0
 */
public abstract class Unit {

	/** The position in the file */
	private final int startLineInFile;

	/** The file this unit stems from. */
	private final CanonicalFile file;

	/** The number of lines covered by this unit */
	private final int coveredLines;

	/** The number of lines covered by this unit */
	private final int indexInFile;

	/** The content of this unit. */
	private final String content;

	/** Create new unit */
	protected Unit(int startLineInFile, CanonicalFile file, String content,
			int coveredLines, int indexInFile) {
		this.startLineInFile = startLineInFile;
		this.file = file;
		this.content = content.intern();
		this.coveredLines = coveredLines;
		this.indexInFile = indexInFile;
	}

	/** File this unit originates from. */
	public CanonicalFile getFile() {
		return file;
	}

	/** Gets the line number of the start of the unit in the source file. */
	public int getStartLineInFile() {
		return startLineInFile;
	}

	/** Gets the index of the unit in the source file */
	public int getIndexInFile() {
		return indexInFile;
	}

	/** Returns the number of lines this unit covers in the source file */
	public int getCoveredLines() {
		return coveredLines;
	}

	/** Textual content of the unit. */
	public String getContent() {
		return content;
	}

	/**
	 * The hash code of a unit object is identical to the hash code of its
	 * content string.
	 * 
	 * @see #getContent()
	 */
	@Override
	public int hashCode() {
		return content.hashCode();
	}

	/** Two unit objects are equal if there content strings are equal. */
	@Override
	public boolean equals(Object other) {
		// contrary to the myths on the net this is not slower than catching
		// the class cast exception
		if (!(other instanceof Unit)) {
			return false;
		}

		// Since the content string is interned, we can perform reference
		// comparison instead of calling equals()
		return content == ((Unit) other).content;
	}

	/** Default implementation returns false. Override for synthetic units */
	public boolean isSynthetic() {
		return false;
	}
}

/*--------------------------------------------------------------------------+
   $Id: BlackListFilter.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection.filter;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.FileSystemScope;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Filters out clone classes based on their fingerprints.
 * <p>
 * Blacklist files are simply text files that contain a fingerprint on each
 * line. In order to enable flexible integration into a continuous build
 * environment, this processor takes a blacklist root {@link IFileSystemElement}
 * as input and processes all files that are located under it as black lists.
 * This root can e.g. be produced by a {@link FileSystemScope} that collects all
 * files with extension .blacklist. This way, a user only needs to copy a
 * blacklist file into the blacklist root directory, and it will be considered
 * by the next detection run.
 * <p>
 * The blacklist root parameter is optional on purpose. This way, it can be used
 * as an optional parameter in a clone detection block. If it is not set,
 * blacklisting is simply deactivated.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 4A4F039BF3E3D0A9D032EB3FF69563C4
 */
@AConQATProcessor(description = "Filters out clone classes based on their fingerprints"
		+ "Blacklist files are simply text files that contain a fingerprint on each"
		+ "line. In order to enable flexible integration into a continuous build"
		+ "environment, this processor takes a blacklist root IFileSystemElement"
		+ "as input and processes all files that are located under it as black lists."
		+ "This root can e.g. be produced by a FileSystemScope that collects all"
		+ "files with extension .blacklist. This way, a user only needs to copy a"
		+ "blacklist file into the blacklist root directory, and it will be considered"
		+ "by the next detection run."
		+ "The blacklist root parameter is optional on purpose. This way, it can be used"
		+ "as an optional parameter in a clone detection block. If it is not set,"
		+ "blacklisting is simply deactivated.")
public class BlackListFilter extends CloneClassFilterBase {

	/** Set of fingerprints of clone classes that get filtered out */
	private final Set<String> blacklist = new HashSet<String>();

	/** Name of the files that contain the blacklisted fingerprints */
	private IFileSystemElement blacklistRoot = null;

	/** ConQAT Parameter */
	@AConQATParameter(name = "blacklist", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Directory under which blacklist files are located")
	public void addFingerprintDirectory(
			@AConQATAttribute(name = "root", description = "If not set, blacklisting is deactivated")
			IFileSystemElement blacklistRoot) {
		this.blacklistRoot = blacklistRoot;
	}

	/** Load the blacklisted {@link CloneClass} fingerprints */
	@Override
	protected void setUp(CloneDetectionResultElement input)
			throws ConQATException {
		try {
			// if not set, skip
			if (blacklistRoot == null) {
				return;
			}

			// read fingerprints from all blacklist files
			List<IFileSystemElement> blacklists = TraversalUtils
					.listLeavesDepthFirst(blacklistRoot);
			for (IFileSystemElement blacklistElement : blacklists) {
				File blacklistFile = blacklistElement.getFile();
				if (blacklistFile != null && blacklistFile.isFile()) {
					readBlacklistFile(blacklistFile);
				}
			}
		} catch (IOException e) {
			throw new ConQATException("Cannot read blacklists!" + e);
		}
	}

	/**
	 * Reads a blacklist file and adds all contained fingerprints to the
	 * blacklist
	 */
	private void readBlacklistFile(File blacklistFile) throws IOException {
		getLogger().info("Reading blacklist: " + blacklistFile);

		String fingerprints = FileSystemUtils.readFile(blacklistFile);

		if (!StringUtils.isEmpty(fingerprints)) {
			for (String fingerprint : StringUtils
					.splitLinesAsList(fingerprints)) {
				if (!StringUtils.isEmpty(fingerprint)) {
					blacklist.add(fingerprint);
				}
			}
		} else {
			// in order to provide graceful behaviour in a nightly
			// build, we warn if an empty fingerprint file is found,
			// and raise no error.
			getLogger().warn("Empty blacklist found: " + blacklistFile);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected boolean filteredOut(CloneClass cloneClass) {
		return blacklist.contains(cloneClass.getFingerprint());
	}

}

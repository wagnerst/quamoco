/*--------------------------------------------------------------------------+
   $Id: CloneDependencyAnnotator.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Annotates each file in the file tree with a list of the files to which it has
 * clone dependencies.
 * <p>
 * These dependency lists can be used to create graph representations of the
 * clone relationships using the ConQAT Graph bundle.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 65817757933C232D79AD16A4A3F94B71
 */
@AConQATProcessor(description = "Annotates each file in the file tree with a list of the files to which "
		+ "it has clone dependencies.")
public class CloneDependencyAnnotator extends CloneAnnotatorBase {

	/** Key for List of clone dependencies. */
	@AConQATKey(description = "Holds list of element ids with which this element has "
			+ "cloning relations, or empty list, if it has no cloning relations", type = "java.util.List<String>")
	public static final String CLONE_DEPENDENCY_LIST_KEY = "Clone Dependency";

	/** Stores the dependency list at an element */
	@Override
	protected void annotateClones(IFileSystemElement element,
			UnmodifiableList<Clone> clonesList) {
		List<String> fileDependencies = createFileDependencies(clonesList);

		element.setValue(CLONE_DEPENDENCY_LIST_KEY, fileDependencies);
	}

	/** Create a list of the files involved in list of clones */
	private List<String> createFileDependencies(List<Clone> clonesList) {
		Set<String> filenames = new HashSet<String>();

		if (!clonesList.isEmpty()) {
			// all all sibling files
			for (Clone clone : clonesList) {
				// we tolerate creation of self loops here, since we remove them
				// below anyway
				for (Clone sibling : clone.getCloneClass().getClones()) {
					filenames.add(sibling.getFile().getCanonicalPath());
				}
			}

			// remove self loops
			filenames.remove(CollectionUtils.getAny(clonesList).getFile()
					.getCanonicalPath());
		}

		return new ArrayList<String>(filenames);
	}

}

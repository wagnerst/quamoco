/*--------------------------------------------------------------------------+
   $Id: ConstantAssigner.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.defs;

import edu.tum.cs.commons.reflect.ReflectionUtils;
import edu.tum.cs.commons.reflect.TypeConversionException;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Stores a constant value under a fixed key in each target node.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 7B5711D64513302A8CDFF987468A0A5C
 */
@AConQATProcessor(description = "Stores a constant value under a fixed key in each target node")
public class ConstantAssigner extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** Name of target key */
	private String key;

	/** Value of constant */
	private Object value;

	/**
	 * ConQAT Parameter
	 */
	@AConQATParameter(name = "constant", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Constant value that gets set")
	public void setConstant(
			@AConQATAttribute(name = "key", description = "Key under which constant is stored") String key,
			@AConQATAttribute(name = "value", description = "Value of constant") String valueString,
			@AConQATAttribute(name = "type", description = "Type of constant (int, bool, ...)") String typeName)
			throws ConQATException {
		try {
			Class<?> type = ReflectionUtils.resolveType(typeName);
			value = ReflectionUtils.convertString(valueString, type);
		} catch (ClassNotFoundException e) {
			throw new ConQATException("Unknown type name: " + typeName, e);
		} catch (TypeConversionException e) {
			throw new ConQATException("Could not convert value '" + valueString
					+ "' to type '" + typeName + "'.", e);
		}
		this.key = key;
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** Sets constant in every node */
	public void visit(IConQATNode node) {
		node.setValue(key, value);
	}

}

/*--------------------------------------------------------------------------+
   $Id: DetectionResultRootNode.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.commons.node.NodeUtils;

/**
 * Root node for a "list" of clone classes.
 * <p>
 * In order to have the different keys contained in a detection result in one
 * place, they are all defined in this class.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 6F9EF32ACA3543DE34A6BC5F86DA8EF1
 */
public class DetectionResultRootNode extends ConQATNodeBase {

	/** The list of children. */
	private final List<CloneClassNode> children = new ArrayList<CloneClassNode>();

	/** Create new result node. */
	public DetectionResultRootNode(Comparator<CloneClass> comparator) {
		// Hide root node
		setValue(NodeConstants.HIDE_ROOT, true);
		setValue(NodeConstants.COMPARATOR,
				new CloneClassNode.CloneClassNodeComparator(comparator));

		// Add clone class metrics to display list
		NodeUtils.addToDisplayList(this,
				CloneListBuilderBase.NORMALIZED_LENGTH,
				CloneListBuilderBase.CARDINALITY, CloneListBuilderBase.VOLUME,
				CloneListBuilderBase.CLONE_START_LINE,
				CloneListBuilderBase.CLONE_LENGTH_IN_LINES,
				CloneListBuilderBase.GAP_COUNT, CloneListBuilderBase.COVERED);
	}

	/** Copy constructor. */
	private DetectionResultRootNode(DetectionResultRootNode node)
			throws DeepCloneException {
		super(node);
		for (CloneClassNode c : children) {
			addChild(c.deepClone());
		}
	}

	/** Add a child node to this node. */
	/* package */void addChild(CloneClassNode node) {
		children.add(node);
		node.setParent(this);
	}

	/** {@inheritDoc} */
	public DetectionResultRootNode deepClone() throws DeepCloneException {
		return new DetectionResultRootNode(this);
	}

	/** {@inheritDoc} */
	public String getName() {
		return "Clone Detection Result";
	}

	/** Return constant string "Clone Root" */
	public String getId() {
		return "Clone Classes Root";
	}

	/** {@inheritDoc} */
	public CloneClassNode[] getChildren() {
		return children.toArray(new CloneClassNode[children.size()]);
	}

	/** {@inheritDoc} */
	public IConQATNode getParent() {
		return null;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !children.isEmpty();
	}

	/** Remove the given node. */
	/* package */void removeNode(CloneClassNode node) {
		children.remove(node);
	}
}

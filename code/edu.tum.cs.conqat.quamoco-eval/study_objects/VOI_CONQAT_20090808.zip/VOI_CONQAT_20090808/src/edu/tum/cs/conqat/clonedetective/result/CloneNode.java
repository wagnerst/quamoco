/*--------------------------------------------------------------------------+
   $Id: CloneNode.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.utils.EBooleanStoredValue;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * This class represents a single clone. It works as an adapter between
 * {@link Clone}s and {@link edu.tum.cs.conqat.commons.node.IConQATNode}s.
 * 
 * @author Florian Deissenboeck
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: C88FD8E8A1D9EAB4D4D2E1BC413721B5
 */
public class CloneNode extends ConQATNodeBase {

	/** Clone represented by this CloneNode */
	private final Clone clone;

	/**
	 * Path prefix of clone file that gets pruned, since it is the same for all
	 * clones.
	 */
	private final String rootPath;

	/** The parent for this node. */
	private CloneClassNode parent = null;

	/** Create clone node from clone. */
	public CloneNode(Clone clone, String rootPath) {
		this.clone = clone;
		this.rootPath = rootPath;

		setValue(CloneListBuilderBase.CLONE_START_LINE, clone
				.getStartLineInFile());
		setValue(CloneListBuilderBase.CLONE_LENGTH_IN_LINES, clone
				.getLengthInFile());
		setValue(CloneListBuilderBase.GAP_COUNT, clone.getGapPositions().size());
		setValue(CloneListBuilderBase.COVERED, EBooleanStoredValue.COVERED
				.getValue(clone));
	}

	/** Copy constructor. */
	private CloneNode(CloneNode node) throws DeepCloneException {
		super(node);
		this.clone = node.clone;
		this.rootPath = node.rootPath;
	}

	/** {@inheritDoc} */
	public String getId() {
		return clone.getFile() + ":" + clone.getStartLineInFile() + ":"
				+ clone.getLengthInFile();
	}

	/** {@inheritDoc} */
	public String getName() {
		return "..."
				+ clone.getFile().getCanonicalPath().substring(
						rootPath.length());
	}

	/** {@inheritDoc} */
	public CloneNode deepClone() throws DeepCloneException {
		return new CloneNode(this);
	}

	/** {@inheritDoc} */
	public IRemovableConQATNode[] getChildren() {
		return null;
	}

	/** {@inheritDoc} */
	public CloneClassNode getParent() {
		return parent;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return false;
	}

	/** Set the parent. */
	/* package */void setParent(CloneClassNode node) {
		this.parent = node;
	}
}

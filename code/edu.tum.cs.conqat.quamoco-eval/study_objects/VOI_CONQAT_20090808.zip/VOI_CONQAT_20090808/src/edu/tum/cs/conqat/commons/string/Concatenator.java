/*--------------------------------------------------------------------------+
   $Id: Concatenator.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.string;

import java.util.ArrayList;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Processor for string concatenation.
 * 
 * @author deissenb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 08860DA872E68D42A2419ED0701B40ED
 */
@AConQATProcessor(description = "Processor for string concatenation. "
		+ "Individual parts of the string may be separated by separator.")
public class Concatenator extends ConQATProcessorBase {

	/** Parts of the string. */
	private final ArrayList<String> parts = new ArrayList<String>();

	/** Separator */
	private String separator = StringUtils.EMPTY_STRING;

	/** Add part. */
	@AConQATParameter(name = "part", minOccurrences = 1, description = "Add part of the string.")
	public void addPart(
			@AConQATAttribute(name = "string", description = "String part")
			String part) {

		parts.add(part);
	}

	/** Set separator. */
	@AConQATParameter(name = "separator", maxOccurrences = 1, description = "Define separator.")
	public void setSeparator(
			@AConQATAttribute(name = "string", description = "Separator string [empty string].")
			String separator) {

		this.separator = separator;
	}

	/** Concatenate parts */
	public String process() {
		return StringUtils.concat(parts, separator);
	}
}

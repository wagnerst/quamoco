/*--------------------------------------------------------------------------+
   $Id: ProjectFileParser.java 23496 2009-08-07 16:12:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.project;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.xml.IXMLElementProcessor;
import edu.tum.cs.commons.xml.XMLReader;
import edu.tum.cs.commons.xml.XMLResolver;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.scope.BuildConfiguration;
import edu.tum.cs.conqat.dotnet.scope.solution.SolutionFileParser.EFormatVersion;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Base class for parsers of VS.NET project files.
 * <p>
 * Since different versions of the Visual Studio generate different project file
 * formats, different project file parsers exist. This class serves as factory
 * to create a {@link ProjectFileParser} for a specific VS.NET version.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23496 $
 * @levd.rating GREEN Hash: EE91765241DD8DB5B59C1886E97ACBBF
 */
public abstract class ProjectFileParser {

	/**
	 * Encoding that gets used for parsing of VS.NET project files, or
	 * <code>null</code>, if default encoding is to be used
	 */
	private String encoding = null;

	/** The build configuration that is used to build the project. */
	protected BuildConfiguration configuration = null;

	/** Logger used to issue log statements */
	protected final IConQATLogger logger;

	/** Constructor */
	public ProjectFileParser(IConQATLogger logger) {
		this.logger = logger;
	}

	/** Extracts the code files that are part of the project */
	public List<String> extractSourceFilenames(File projectFile)
			throws ConQATException {

		ProjectFileReaderBase reader = createReader(projectFile, encoding);
		List<String> filenames = new ArrayList<String>();

		filenames = new ArrayList<String>();

		for (String relativeFilename : reader.readRelativeSourceFileNames()) {
			filenames.add(FileLibrary.absoluteFilenameFrom(projectFile
					.getAbsolutePath(), relativeFilename));
		}

		return filenames;
	}

	/**
	 * Extracts the path to the assembly that is generated when compiling this
	 * project
	 */
	public List<String> extractAssemblyFilename(File projectFile,
			BuildConfiguration _configuration) throws ConQATException {
		ProjectFileReaderBase reader = createReader(projectFile, encoding);
		List<String> filenames = new ArrayList<String>();
		configuration = _configuration;
		String relativeFilename = reader.readRelativeAssemblyName();

		// the filename is null if the relative output path could not be
		// retrieved. The warning is already set by readRelativeAssemblyName()
		if (relativeFilename != null) {
			filenames.add(FileLibrary.absoluteFilenameFrom(projectFile
					.getAbsolutePath(), relativeFilename));
		}
		return filenames;
	}

	/**
	 * Template factory name that returns the project-file version specific
	 * XMLReader
	 */
	protected abstract ProjectFileReaderBase createReader(File projectFile,
			String encoding);

	/** Getter */
	public String getEncoding() {
		return encoding;
	}

	/** Sets encoding of XML file. */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	/**
	 * Factory name that creates a project file reader according to the solution
	 * file version
	 */
	public static ProjectFileParser create(EFormatVersion version,
			IConQATLogger logger) {
		switch (version) {
		case VERSION_10:
			// fall through, since no relevant changes in from version 9 to 10
		case VERSION_9:
			return new ProjectFileParser9_10(logger);
		case VERSION_8:
			return new ProjectFileParser8(logger);
		default:
			throw new RuntimeException(
					"No reader for this project file format implemented!");
		}
	}

	/** Xml reader that performs actual XML processing. */
	protected abstract class ProjectFileReaderBase
			extends
			XMLReader<EProjectFileXmlElement, EProjectFileXmlAttribute, ConQATException> {

		/** The list of relative source filename. */
		protected final List<String> relativeSourceFilenames = new ArrayList<String>();

		/** The name of the assembly */
		protected String assemblyName = null;

		/** The relative path to the assembly */
		protected String outputPath = null;

		/** The output type (can be either Library or Exe) */
		protected String outputType = null;

		/** The name of the project file */
		private final String projectFilename;

		/** Constructor */
		public ProjectFileReaderBase(File projectFile) {
			super(
					projectFile,
					encoding,
					new XMLResolver<EProjectFileXmlElement, EProjectFileXmlAttribute>(
							EProjectFileXmlAttribute.class));
			this.projectFilename = projectFile.getAbsolutePath();
		}

		/**
		 * Reads the relative names of the included code files from the project
		 * file
		 */
		public List<String> readRelativeSourceFileNames()
				throws ConQATException {
			parseProjectFile();
			processDecendantElements(createProcessor());
			return relativeSourceFilenames;
		}

		/**
		 * Reads the relative names of the executables created by this project
		 */
		public String readRelativeAssemblyName() throws ConQATException {
			String fileEnding = "";
			parseProjectFile();

			// get the name of the assembly
			processDecendantElements(createAssemblyNameProcessor());

			// get the output type (it can only be "Library" or "Exe")
			IXMLElementProcessor<EProjectFileXmlElement, ConQATException> processor = createOutputTypeProcessor();

			// The createOutputTypeProcessor method in VS2003 projects returns
			// null because the AssemblyNameProcessor already sets the output
			// type for VS2003 project files
			if (processor != null) {
				processDecendantElements(processor);
			}

			if (outputType.equals("Library")) {
				fileEnding = ".dll";
			} else {
				if (!outputType.equals("Exe") && !outputType.equals("WinExe")) {
					logger.warn("The assembly " + assemblyName
							+ " that was found in project " + projectFilename
							+ " is neither a .dll nor a .exe file");
					return null;
				}
				fileEnding = ".exe";
			}

			// get the relative path to the assembly
			processDecendantElements(createRelativeAssemblyPathProcessor());

			CCSMAssert.isNotNull(assemblyName, "No assemblyName in project "
					+ projectFilename + " identified");
			if (outputPath == null) {
				logger.warn("No relative output path found for project "
						+ projectFilename
						+ ". Perhaps the build configuration ("
						+ configuration.getName() + "|"
						+ configuration.getPlatform()
						+ ") is not valid for the project file.");
				return null;
			}

			return outputPath + assemblyName + fileEnding;
		}

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createProcessor();

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createAssemblyNameProcessor();

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createOutputTypeProcessor();

		/**
		 * Template factory name that creates the XMLProcessor that performs the
		 * actual information retrieval
		 */
		protected abstract IXMLElementProcessor<EProjectFileXmlElement, ConQATException> createRelativeAssemblyPathProcessor();

		/** Parse XML file */
		private void parseProjectFile() throws ConQATException {
			try {
				parseFile();
			} catch (SAXParseException e) {
				throw new ConQATException("XML parsing exception at line "
						+ e.getLineNumber() + ", colum " + e.getColumnNumber()
						+ " (" + e.getMessage() + ")");
			} catch (SAXException e) {
				throw new ConQATException("XML parsing exception)");
			} catch (IOException e) {
				throw new ConQATException("File " + projectFilename
						+ " could not be read");
			}
		}
	}
}

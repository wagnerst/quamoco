/*--------------------------------------------------------------------------+
   $Id: LogFileWriter.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;

/**
 * Interface that defines constraints on {@link CloneClass}es. Constraints can
 * be evaluated on a single clone class, independent of other {@link CloneClass}
 * es in the same detection result.
 * 
 * @author juergens
 * @author $Author$
 * @version $Rev$
 * @levd.rating GREEN Hash: F6A8E5B8050BA28D575256FB94713CC6
 */
public interface ICloneClassConstraint {

	/** Returns true, if constraint is satisfied, false if not */
	public boolean satisfied(CloneClass cloneClass);

}

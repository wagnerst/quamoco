/*--------------------------------------------------------------------------+
   $Id: SubStateAnalyzer.java 23502 2009-08-07 16:17:34Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.stateflow.StateflowNodeBase;
import edu.tum.cs.simulink.model.stateflow.StateflowState;
import edu.tum.cs.simulink.util.SimulinkUtils;

/**
 * {@ConQAT.Doc}
 * 
 * @author deissenb
 * @author $Author: deissenb $
 * @version $Rev: 23502 $
 * @levd.rating GREEN Hash: DE72EE437FD449E403B59D5002CD1F7F
 */
@AConQATProcessor(description = "This processor counts the number of substates "
		+ "of each state. A node is rated red if it has exactly one substates "
		+ "or more then the specified threshold. If threshold is unspecified only "
		+ "states with exactly one substate are rated. Additionally a "
		+ "threshold for the sum of transitions of the sub states of the state can "
		+ "specified.")
public class SubStateAnalyzer extends StateflowAnalyzerBase {

	/** Key for assessment. */
	@AConQATKey(description = "Key for assessment", type = "edu.tum.cs.commons.assessment.Assessment")
	public static final String ASSESSMENT_KEY = "SubStateAssessment";

	/** Key for messages. */
	@AConQATKey(description = "Key for messages", type = "edu.tum.cs.commons.collections.HashedListMap<String, String>")
	public static final String MESSAGES_KEY = "SubStateMessage";

	/** Maximum number of substates, <code>null</code> for no threshold. */
	private Integer subStateThreshold = null;

	/** Maximum number of transitions, <code>null</code> for no threshold. */
	private Integer transitionThreshold = null;

	/** ConQAT Parameter */
	@AConQATParameter(name = "sub-state", minOccurrences = 0, maxOccurrences = 1, description = "Maximum number of allowed substates.")
	public void setSubStateThreshold(
			@AConQATAttribute(name = "threshold", description = "Number of allowed substates") int threshold) {
		subStateThreshold = threshold;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "transition", minOccurrences = 0, maxOccurrences = 1, description = "Maximum number of allowed substates.")
	public void setTransitionThreshold(
			@AConQATAttribute(name = "threshold", description = "Number of allowed transitions") int threshold) {
		transitionThreshold = threshold;
	}

	/** Add key to display list. */
	@Override
	protected void setUp(ISimulinkElement root) {
		NodeUtils.addToDisplayList(root, ASSESSMENT_KEY, MESSAGES_KEY);
	}

	/** Optimistically rate model green. */
	@Override
	protected void setUpModel(SimulinkModelElement modelNode) {
		modelNode.setValue(ASSESSMENT_KEY, new Assessment(
				ETrafficLightColor.GREEN));
	}

	/** Check if a state has exactly one sub state. */
	@Override
	protected void analyzeState(StateflowState state,
			SimulinkModelElement modelNode) throws ConQATException {

		String id = SimulinkUtils.getFQStateName(state);
		ArrayList<String> messages = new ArrayList<String>();

		checkOneSubstate(state, messages);
		checkSubStateThreshold(state, messages);
		checkTransitions(state, messages);

		if (!messages.isEmpty()) {
			modelNode.setValue(ASSESSMENT_KEY, new Assessment(
					ETrafficLightColor.RED));
			for (String message : messages) {
				NodeUtils.addMessage(modelNode, MESSAGES_KEY, id, message);
			}
		}
	}

	/** Check if state has exactly one sub state (or junction). */
	private void checkOneSubstate(StateflowState state, List<String> messages) {
		if (state.getNodes().size() == 1) {
			messages.add("State has ONE sub state.");
		}
	}

	/** Check if the number of sub states is above the threshold. */
	private void checkSubStateThreshold(StateflowState state,
			List<String> messages) {
		if (subStateThreshold == null) {
			return;
		}
		int subStateCount = countSubStates(state);
		if (subStateCount > subStateThreshold) {
			messages.add("State contains " + subStateCount + " substates.");
		}
	}

	/** Check if the number of transitions is above the threshold. */
	private void checkTransitions(StateflowState state, List<String> messages) {
		if (transitionThreshold == null) {
			return;
		}
		int transitionCount = countTransitions(state);
		if (transitionCount > transitionThreshold) {
			messages.add("State contains " + transitionCount + " transitions.");
		}
	}

	/**
	 * Count substates. In contrast to {@link StateflowState#getNodes()}.getSize()
	 * this counts only states does not include junctions.
	 */
	private int countSubStates(StateflowState state) {
		int subStateCount = 0;
		for (StateflowNodeBase node : state.getNodes()) {
			if (node instanceof StateflowState) {
				subStateCount++;
			}
		}
		return subStateCount;
	}

	/**
	 * Counts the number of transitions under this state, i.e. the sum of all
	 * transitions of all substates.
	 */
	private int countTransitions(StateflowState state) {
		int transitionCount = 0;

		for (StateflowNodeBase node : state.getNodes()) {
			transitionCount += node.getInTransitions().size();
		}

		return transitionCount;
	}
}

/*--------------------------------------------------------------------------+
   $Id: SimulinkSizeAnalyzer.java 23502 2009-08-07 16:17:34Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.stateflow.StateflowMachine;
import edu.tum.cs.simulink.util.SimulinkUtils;

/**
 * This processor counts block, charts and states.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23502 $
 * @levd.rating GREEN Hash: C9C22E894F4B8CB2969F9769EDC779DA
 */
@AConQATProcessor(description = "This processor counts block, charts and states of Simulink models.")
public class SimulinkSizeAnalyzer extends SimulinkModelAnalyzerBase {

	/** Block count key. */
	@AConQATKey(description = "Number of blocks", type = "java.lang.Integer")
	public static final String BLOCKS_KEY = "#Blocks";

	/** State count key. */
	@AConQATKey(description = "Number of states", type = "java.lang.Integer")
	public static final String STATES_KEY = "#States";

	/** Chart count key. */
	@AConQATKey(description = "Number of charts", type = "java.lang.Integer")
	public static final String CHARTS_KEY = "#Charts";

	/** Add keys to display list. */
	@Override
	protected void setUp(ISimulinkElement root) {
		NodeUtils.addToDisplayList(root, BLOCKS_KEY, CHARTS_KEY, STATES_KEY);
	}

	/** Analyze model sizes. */
	@Override
	protected void analyzeModel(SimulinkModelElement model) {
		model.setValue(BLOCKS_KEY, SimulinkUtils.countSubBlocks(model
				.getModel()));

		StateflowMachine machine = model.getModel().getStateflowMachine();

		if (machine == null) {
			model.setValue(CHARTS_KEY, 0);
			model.setValue(STATES_KEY, 0);
		} else {
			model.setValue(CHARTS_KEY, model.getModel().getStateflowMachine()
					.getCharts().size());
			model.setValue(STATES_KEY, SimulinkUtils.countStates(model
					.getModel().getStateflowMachine()));
		}
	}
}

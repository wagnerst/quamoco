/*--------------------------------------------------------------------------+
   $Id: ReportUtils.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.EEditOperation;

/**
 * Utility functions for reading and writing clone reports.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 5B5B81CD1F007EFDA6533D090EC4A0FD
 */
public class ReportUtils {

	/**
	 * Creates a gap string for a gapped clone.
	 */
	public static String createGapOffsetString(Clone clone) {
		List<String> gapDigests = new ArrayList<String>();

		for (int lineOffset = 0; lineOffset < clone.getLengthInFile(); lineOffset++) {
			EEditOperation gapType = clone.getGapTypeAt(lineOffset);
			if (gapType != EEditOperation.NONE) {
				gapDigests.add(lineOffset + ":" + gapType);
			}
		}

		return StringUtils.concat(gapDigests, ",");
	}

	/**
	 * Reads gap information from a gap offset string and stores it in a
	 * {@link Clone}
	 */
	/* package */static void parseGapOffsetString(Clone clone,
			String gapOffsetsString) {
		if (StringUtils.isEmpty(gapOffsetsString)) {
			return;
		}

		for (String gapDigest : gapOffsetsString.split(",")) {
			String[] gapDigestParts = gapDigest.split(":");
			int gapOffset = Integer.parseInt(gapDigestParts[0]);
			EEditOperation gapType = EEditOperation.valueOf(gapDigestParts[1]);
			clone.addGap(gapOffset, gapType);
		}
	}

}

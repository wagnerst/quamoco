/*--------------------------------------------------------------------------+
   $Id: JavaRootElement.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.scope;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.util.Repository;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.collections.UnmodifiableSet;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.java.library.CachingRepository;

/**
 * An element for the root of the Java element tree. Here additional information
 * such as the classpath are stored. Additionally internal structures such as
 * the BCEL cache are located here (as it depends on the actual classpath used).
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: 545D666FCD391B8B29826D266B139A84
 */
public class JavaRootElement extends JavaPackageElement implements
		IJavaRootElement {

	/** The classpath. */
	private final List<String> classPath;

	/** The repository used for looking up java classes. */
	private final Repository bcelRepository;

	/** Source directories of this Java scope. */
	private final Set<CanonicalFile> sourceDirectories;

	/** Byte code directories of this Java scope. */
	private final Set<CanonicalFile> byteCodeDirectories;

	/** Constructor. */
	public JavaRootElement(Collection<CanonicalFile> sourceDirectories,
			Collection<CanonicalFile> byteCodeDirectories,
			List<String> classPath) {
		super("");
		this.sourceDirectories = new HashSet<CanonicalFile>(sourceDirectories);
		this.byteCodeDirectories = new HashSet<CanonicalFile>(
				byteCodeDirectories);
		this.classPath = new ArrayList<String>(classPath);
		bcelRepository = new CachingRepository(this.classPath);
	}

	/** Copy constructor. */
	protected JavaRootElement(JavaRootElement element)
			throws DeepCloneException {
		super(element);
		this.sourceDirectories = new HashSet<CanonicalFile>(
				element.sourceDirectories);
		this.byteCodeDirectories = new HashSet<CanonicalFile>(
				element.byteCodeDirectories);
		// share class path and repository
		this.classPath = element.classPath;
		this.bcelRepository = element.bcelRepository;
	}

	/** {@inheritDoc} */
	@Override
	public IJavaRootElement getRootElement() {
		return this;
	}

	/** {@inheritDoc} */
	public UnmodifiableList<String> getClassPath() {
		return CollectionUtils.asUnmodifiable(classPath);
	}

	/** {@inheritDoc} */
	@Override
	public JavaRootElement deepClone() throws DeepCloneException {
		return new JavaRootElement(this);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws ConQATException
	 */
	public JavaClass getJavaClass(String className) throws ConQATException {
		try {
			return bcelRepository.loadClass(className);
		} catch (ClassNotFoundException e) {
			throw new ConQATException("Could not load class: " + className, e);
		}
	}

	/** {@inheritDoc} */
	public UnmodifiableSet<CanonicalFile> getByteCodeDirectories() {
		return CollectionUtils.asUnmodifiable(byteCodeDirectories);
	}

	/** {@inheritDoc} */
	public UnmodifiableSet<CanonicalFile> getSourceDirectories() {
		return CollectionUtils.asUnmodifiable(sourceDirectories);
	}
}

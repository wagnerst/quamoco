/*--------------------------------------------------------------------------+
   $Id: NumericValueFilter.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.filter;

import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This filter removes all nodes without a result-value in the given range.
 * 
 * @author Aichner Michael
 * @author Puchinger Christian
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 33E25C1978473D5E86B8BF10E1E25ACD
 */
@AConQATProcessor(description = "Filters nodes based on a numeric value stored at the prodived key. "
		+ "Nodes are only kept, if this value is within a defined range. "
		+ "Directories are not explicitly handled, but are removed if empty.")
public class NumericValueFilter extends
		KeyBasedFilterBase<Number, IRemovableConQATNode> {

	/** The smallest value to take into account. */
	private double lowerBound = Double.NEGATIVE_INFINITY;

	/** The biggest value to take into account. */
	private double upperBound = Double.POSITIVE_INFINITY;

	/** Sets the lower bound. */
	@AConQATParameter(name = "lower", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Range's lower bound. Default is negative infinity.")
	public void setLowerBound(
			@AConQATAttribute(name = "value", description = "The bound.")
			double lowerBound) {

		this.lowerBound = lowerBound;
	}

	/** Sets the upper bound. */
	@AConQATParameter(name = "upper", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Range's upper bound. Default is positive infinity.")
	public void setUpperBound(
			@AConQATAttribute(name = "value", description = "The bound.")
			double upperBound) {

		this.upperBound = upperBound;
	}

	/** {@inheritDoc} */
	@Override
	protected boolean isFilteredForValue(Number value) {
		double d = value.doubleValue();
		return !((lowerBound <= d) && (d <= upperBound));
	}
}
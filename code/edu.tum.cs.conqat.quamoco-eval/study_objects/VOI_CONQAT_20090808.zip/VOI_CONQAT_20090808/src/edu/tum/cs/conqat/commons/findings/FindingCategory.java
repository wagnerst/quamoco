/*--------------------------------------------------------------------------+
   $Id: FindingCategory.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * A finding category collects finding groups from the same context (often the
 * same detection tool).
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 95DC593EF651F9643FCD955A057A62AC
 */
public class FindingCategory extends ConQATNodeBase implements
		IRemovableConQATNode {

	/** The finding groups in this category. */
	private final Map<String, FindingGroup> findingGroups = new HashMap<String, FindingGroup>();

	/** The report this belongs to. */
	private final FindingReport report;

	/** The name of this category. */
	private final String name;

	/** Hidden constructor. Use factory method in {@link FindingReport} instead. */
	/* package */FindingCategory(FindingReport report, String name) {
		this.report = report;
		this.name = name;
	}

	/** Copy constructor. */
	/* package */FindingCategory(FindingCategory other,
			FindingReport findingReport) throws DeepCloneException {
		super(other);
		this.report = findingReport;
		this.name = other.name;
		for (FindingGroup group : other.findingGroups.values()) {
			findingGroups.put(group.getName(), new FindingGroup(group, this));
		}
	}

	/** {@inheritDoc} */
	public String getName() {
		return name;
	}

	/**
	 * Creates a new finding group with the given description. The description
	 * should be unique within this category. This may not be called, if a group
	 * of this name already exists (check by {@link #getGroupByName(String)}).
	 */
	public FindingGroup createFindingGroup(String description) {
		CCSMPre.isFalse(findingGroups.containsKey(description),
				"Finding group of given name already exists.");
		FindingGroup findingGroup = new FindingGroup(description, this);
		findingGroups.put(findingGroup.getName(), findingGroup);
		return findingGroup;
	}

	/** Returns the named group or <code>null</code>. */
	public FindingGroup getGroupByName(String name) {
		return findingGroups.get(name);
	}

	/** {@inheritDoc} */
	public FindingGroup[] getChildren() {
		return findingGroups.values().toArray(
				new FindingGroup[findingGroups.size()]);
	}

	/** {@inheritDoc} */
	public void remove() {
		report.remove(this);
	}

	/** {@inheritDoc} */
	public String getId() {
		return name;
	}

	/** {@inheritDoc} */
	public FindingReport getParent() {
		return report;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !findingGroups.isEmpty();
	}

	/** Removes the given finding group from the category. */
	/* package */void remove(FindingGroup findingGroup) {
		findingGroups.remove(findingGroup);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Throws an exception as we do not support cloning at this level.
	 */
	public IRemovableConQATNode deepClone() {
		throw new UnsupportedOperationException(
				"Deep cloning not supported at this level.");
	}
}

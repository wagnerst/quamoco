/*--------------------------------------------------------------------------+
   $Id: SimulinkModelAnalyzerBase.java 23502 2009-08-07 16:17:34Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;

/**
 * Base class for processors that analyze Simulink models.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23502 $
 * @levd.rating GREEN Hash: 485D487749D70514DBD55702E314CD50
 */
public abstract class SimulinkModelAnalyzerBase extends
		NodeTraversingProcessorBase<ISimulinkElement> {

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** Visits all blocks if this is a {@link SimulinkModelElement}. */
	public void visit(ISimulinkElement node) throws ConQATException {
		if (node instanceof SimulinkModelElement) {
			SimulinkModelElement modelNode = (SimulinkModelElement) node;
			setUpModel(modelNode);
			analyzeModel(modelNode);
			finishModel(modelNode);
		}
	}

	/**
	 * Factory method called before traversing the blocks of the given model
	 * node. Default implementation does nothing.
	 */
	@SuppressWarnings("unused")
	protected void setUpModel(SimulinkModelElement modelNode)
			throws ConQATException {
		// nothing
	}

	/**
	 * Factory method called after traversing the blocks of the given model
	 * node. Default implementation does nothing.
	 */
	@SuppressWarnings("unused")
	protected void finishModel(SimulinkModelElement modelNode)
			throws ConQATException {
		// nothing
	}

	/** Override method to implement model analysis. */
	protected abstract void analyzeModel(SimulinkModelElement modelNode)
			throws ConQATException;

}

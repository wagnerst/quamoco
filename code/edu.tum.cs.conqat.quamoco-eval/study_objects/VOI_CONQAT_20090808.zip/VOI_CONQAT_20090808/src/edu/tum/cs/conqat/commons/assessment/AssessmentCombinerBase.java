/*--------------------------------------------------------------------------+
   $Id: AssessmentCombinerBase.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.assessment;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for processors combining multiple assessments found at different
 * keys.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 736C5A83A0AA240A2AD4D14EC149D607
 */
public abstract class AssessmentCombinerBase extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** The keys used for assessment input. */
	private final List<String> inputKeys = new ArrayList<String>();

	/** The key to write the result into. */
	private String outputKey;

	/** Add a key for reading an assessment. */
	@AConQATParameter(name = ConQATParamDoc.READKEY_NAME, minOccurrences = 1, description = ""
			+ "Adds a key to read an assessment from.")
	public void addReadKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC)
			String key) {
		inputKeys.add(key);
	}

	/** Set the key used for writing. */
	@AConQATParameter(name = ConQATParamDoc.WRITEKEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The key to write the combined value to. ")
	public void setWriteKey(
			@AConQATAttribute(name = ConQATParamDoc.WRITEKEY_KEY_NAME, description = ConQATParamDoc.WRITEKEY_KEY_DESC)
			String key) {
		outputKey = key;
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		NodeUtils.addToDisplayList(root, outputKey);
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) {
		ArrayList<Assessment> assessments = new ArrayList<Assessment>();
		for (String key : inputKeys) {
			Object o = node.getValue(key);
			if (!(o instanceof Assessment)) {
				getLogger().info(
						"No assesment found for key " + key + " at node "
								+ node.getId());
			} else {
				assessments.add((Assessment) o);
			}
		}

		Assessment combined = combineAssessments(assessments);
		node.setValue(outputKey, combined);
	}

	/** Template method for combining the assessements at a single node. */
	protected abstract Assessment combineAssessments(
			List<Assessment> assessments);

}

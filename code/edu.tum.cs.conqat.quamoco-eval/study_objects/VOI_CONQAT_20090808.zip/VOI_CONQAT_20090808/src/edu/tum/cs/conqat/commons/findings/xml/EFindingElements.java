/*--------------------------------------------------------------------------+
   $Id: EFindingElements.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.xml;

/**
 * Names of elements used in the finding XML format.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 0762B0985258C70B4081DD2B0B2F101B
 */
public enum EFindingElements {

	/** Finding report root element. */
	FINDING_REPORT,

	/** Element for finding category. */
	FINDING_CATEGORY,

	/** Element for finding groups. */
	FINDING_GROUP,

	/** Element for single finding. */
	FINDING,

	/** A code line location. */
	CODE_LINE,

	/** A code region location. */
	CODE_REGION,

	/** A code file location. */
	CODE_FILE,

	/** A qualified name location. */
	QUALIFIED_NAME,

	/** Element in key/value list. */
	KEY_VALUE_PAIR,
}

/*--------------------------------------------------------------------------+
   $Id: LayoutPreservingPatternReplacer.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.string;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import edu.tum.cs.conqat.commons.pattern.PatternList;

/**
 * Removes parts of a string that match one of a list of patterns. In contrast
 * to {@link String#replaceAll(String, String)}, the removal is performed in a
 * whitespace-preserving fashion.
 * <p>
 * This way, the positions of the non-removed text elements in the string after
 * processing still correspond to their positions in the input string.
 * <p>
 * Although for clone detection, line number preservation would currently be
 * sufficient, this class implements a character-position-preserving pattern
 * processing, since the CloneClipse application andn the region mechanism work
 * on character positions.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 7C112811C2A33D5841BC0E9C1894CCB5
 */
/* package */class LayoutPreservingPatternReplacer {

	/** List of patterns on which processor works */
	private final PatternList patterns;

	/** Constructor */
	public LayoutPreservingPatternReplacer(final PatternList patterns) {
		this.patterns = patterns;
	}

	/**
	 * Removes all parts of the string that are matched by one of the patterns
	 * in a whitespace preserving fashion.
	 */
	public String process(String string) {
		for (Pattern pattern : patterns) {
			string = processPattern(pattern, string);
		}
		return string;
	}

	/** Process a single pattern */
	private String processPattern(Pattern pattern, String string) {
		Matcher matcher = pattern.matcher(string);
		StringBuffer replaced = new StringBuffer();

		while (matcher.find()) {
			String replacement = createReplacement(string, matcher);
			matcher.appendReplacement(replaced, replacement);
		}
		matcher.appendTail(replaced);

		return replaced.toString();
	}

	/**
	 * Creates a replacement for the current match, in which every
	 * non-whitespace character is replaced by a space.
	 */
	private String createReplacement(String string, Matcher matcher) {
		int start = matcher.start();
		int end = matcher.end();
		StringBuffer replacement = new StringBuffer();

		for (int i = start; i < end; i++) {
			char currentChar = string.charAt(i);
			if (Character.isWhitespace(currentChar)) {
				replacement.append(currentChar);
			} else {
				replacement.append(" ");
			}
		}

		return replacement.toString();
	}

}

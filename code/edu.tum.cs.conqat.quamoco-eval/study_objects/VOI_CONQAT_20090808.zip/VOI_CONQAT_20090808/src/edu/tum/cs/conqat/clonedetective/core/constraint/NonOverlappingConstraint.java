/*--------------------------------------------------------------------------+
   $Id: NonOverlappingConstraint.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import java.util.List;

import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.region.Region;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: BF441A77A41855202CD094B1FC0FDFFF
 */
@AConQATProcessor(description = ""
		+ "Constraint that is satisfied if none of the clones of the CloneClass overlapp")
public class NonOverlappingConstraint extends ConstraintBase {

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) {
		HashedListMap<CanonicalFile, Region> cloneRegions = new HashedListMap<CanonicalFile, Region>();

		// look for overlaps
		for (Clone clone : cloneClass.getClones()) {
			CanonicalFile file = clone.getFile();
			Region cloneRegion = createCloneRegion(clone);

			if (overlaps(cloneRegion, cloneRegions.getList(file))) {
				return false;
			}
			cloneRegions.add(file, cloneRegion);
		}

		// if code reaches here, no overlap was found
		return true;
	}

	/** Creates a region for a clone */
	private Region createCloneRegion(Clone clone) {
		int start = clone.getStartLineInFile();
		int end = start + clone.getLengthInFile() - 1;
		return new Region(start, end);
	}

	/** Checks whether a region overlaps with any region in a list of regions */
	private boolean overlaps(Region cloneRegion, List<Region> regionsInSameFile) {
		if (regionsInSameFile == null) {
			return false;
		}

		for (Region region : regionsInSameFile) {
			if (region.overlaps(cloneRegion)) {
				return true;
			}
		}
		return false;
	}

}
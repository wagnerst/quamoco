/*--------------------------------------------------------------------------+
   $Id: ListNode.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.node;

import java.util.ArrayList;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.clone.DeepCloneException;

/**
 * A simple ConQAT node whose children are managed as a list, i.e. multiple
 * children can have the same name.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 25D2B22A85DBBB6173755DDA54C360AC
 */
public class ListNode extends ConQATNodeBase implements IRemovableConQATNode {

	/** Child list (initialized lazily). */
	private ArrayList<ListNode> children;

	/** Parent. */
	private ListNode parent;

	/** Node id. */
	private final String id;

	/** Create node with dummy id. */
	public ListNode() {
		id = "<root>";
	}

	/** Create node with id. */
	public ListNode(String id) {
		this.id = id;
	}

	/** Copy constructor. */
	protected ListNode(ListNode node) throws DeepCloneException {
		super(node);
		id = node.id;
		if (node.hasChildren()) {
			for (ListNode child : node.children) {
				addChild(child.deepClone());
			}
		}
	}

	/** {@inheritDoc} */
	public ListNode deepClone() throws DeepCloneException {
		return new ListNode(this);
	}

	/** {@inheritDoc} */
	public String getId() {
		return id;
	}

	/** Returns id. */
	public String getName() {
		return getId();
	}

	/** {@inheritDoc} */
	public ListNode[] getChildren() {
		if (children == null) {
			return null;
		}
		return children.toArray(new ListNode[children.size()]);
	}

	/** {@inheritDoc} */
	public void remove() {
		if (parent != null) {
			CCSMAssert.isFalse(parent.children == null, "Parent must have children");
			parent.children.remove(this);
			setParent(null);
		}
	}

	/** Set parent. */
	private void setParent(ListNode parent) {
		this.parent = parent;
	}

	/** {@inheritDoc} */
	public IConQATNode getParent() {
		return parent;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		if (children == null) {
			return false;
		}
		return !children.isEmpty();
	}

	/** Add child node. */
	public void addChild(ListNode child) {
		if (children == null) {
			children = new ArrayList<ListNode>();
		}
		children.add(child);
		child.setParent(this);
	}

}
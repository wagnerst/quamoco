/*--------------------------------------------------------------------------+
   $Id: FileSystemElementProvider.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Provider for {@link IFileSystemElement}s.
 * <p>
 * Remark on implementation: this class only sets the generic parameter its base
 * class to {@link IFileSystemElement}. This way, the ConQAT load time type
 * checking mechanism does not have to deal with generic types (which it
 * cannot).
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 97F2C24096F5EB66D324AFBE2E29BD84
 */
public class FileSystemElementProvider extends
		ElementProviderBase<IFileSystemElement> {

	/** Constructor. */
	public FileSystemElementProvider(String ignoreKey) {
		super(ignoreKey);
	}
}

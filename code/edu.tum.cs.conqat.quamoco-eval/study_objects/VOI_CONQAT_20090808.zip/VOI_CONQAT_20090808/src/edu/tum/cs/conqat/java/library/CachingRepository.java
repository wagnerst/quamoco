/*--------------------------------------------------------------------------+
   $Id: CachingRepository.java 23499 2009-08-07 16:15:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.java.library;

import java.io.File;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.bcel.classfile.ClassFormatException;
import org.apache.bcel.classfile.ClassParser;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.util.ClassPath;
import org.apache.bcel.util.Repository;
import org.apache.bcel.util.ClassPath.ClassFile;
import org.apache.log4j.Logger;

import edu.tum.cs.commons.string.StringUtils;

/**
 * This is a bcel repository which additionally caches its classes in a central
 * cache to speedup answering queries. Classes are loaded using a class path
 * initially provided.
 * 
 * TODO (FD): We need to discuss the Repository stuff.
 * 
 * @author Florian Deissenboeck
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * 
 * @version $Rev: 23499 $
 * @levd.rating GREEN Hash: 03BEAE3153F27AA50079D1417C59C174
 */
@SuppressWarnings("serial")
public class CachingRepository implements Repository {

	/** Logger. */
	private static final Logger logger = Logger
			.getLogger(CachingRepository.class);

	/** The cache for storing classes. */
	private static Map<String, SoftReference<JavaClass>> cache = new HashMap<String, SoftReference<JavaClass>>();

	/** The class path used in this repository. */
	private final ClassPath classPath;

	/**
	 * Create a new caching repository.
	 * 
	 * @param classPath
	 *            the class path to be used.
	 */
	public CachingRepository(List<String> classPath) {
		this.classPath = new ClassPath(StringUtils.concat(classPath,
				File.pathSeparator));
	}

	/** This method does nothing. */
	public void storeClass(JavaClass clazz) {
		// do nothing
	}

	/** This method does nothing. */
	public void removeClass(JavaClass clazz) {
		// do nothing
	}

	/** We do not differentiate between load class and find class. */
	public JavaClass findClass(String className) {
		JavaClass clazz = null;
		SoftReference<JavaClass> ref = cache.get(className);
		if (ref != null && ref.get() != null) {
			clazz = ref.get();
		} else {
			clazz = loadClassFromClassPath(className);
			if (clazz == null) {
				clazz = loadClassFromClassLoader(className);
			}
			cache.put(className, new SoftReference<JavaClass>(clazz));
		}

		if (clazz != null) {
			// this is crucial, so all classes later loaded via this classs use
			// this repository
			clazz.setRepository(this);
		}
		return clazz;
	}

	/**
	 * Obtains the class from the cache if possible. Otherwise the class is
	 * loaded via the embedded class loader.
	 * 
	 * @throws ClassNotFoundException
	 */
	public JavaClass loadClass(String className) throws ClassNotFoundException {
		JavaClass clazz = findClass(className);
		if (clazz == null) {
			throw new ClassNotFoundException("Couldn't load class: "
					+ className);
		}
		return clazz;
	}

	/** Loads the given class using the class path. */
	private JavaClass loadClassFromClassPath(String className) {

		ClassFile classFile;
		try {
			classFile = classPath.getClassFile(className.replace('.', '/'));
		} catch (IOException e) {
			// not found, so just return
			return null;
		}

		try {
			return new ClassParser(classFile.getInputStream(), className)
					.parse();
		} catch (IOException e) {
			logger.warn("IO error on file " + classFile);
		} catch (ClassFormatException ex) {
			logger.warn("Class format error for file " + classFile);
		}
		return null;
	}

	/** Loads the given class using the system class loader. */
	private JavaClass loadClassFromClassLoader(String className) {
		try {
			Class<?> clazz = Class.forName(className);
			String name = clazz.getName();

			int i = name.lastIndexOf('.');
			if (i > 0) {
				name = name.substring(i + 1);
			}
			name += ".class";

			ClassParser parser = new ClassParser(clazz
					.getResourceAsStream(name), clazz.getName());
			return parser.parse();
		} catch (ClassNotFoundException e) {
			logger.warn("Can't find class " + className);
		} catch (ClassFormatException e) {
			logger.warn("Class format error for class " + className);
		} catch (IOException e) {
			logger.warn("IO error on file class " + className);
		}
		return null;
	}

	/**
	 * Forwards to {@link #loadClass(String)}.
	 * 
	 * @throws ClassNotFoundException
	 */
	@SuppressWarnings("unchecked")
	public JavaClass loadClass(Class clazz) throws ClassNotFoundException {
		return loadClass(clazz.getName());
	}

	/** This method does nothing. */
	public void clear() {
		// do nothing
	}

	/**
	 * This returns the class path. As far as we can tell this is never called
	 * from within BCEL.
	 */
	public ClassPath getClassPath() {
		return classPath;
	}
}

﻿using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("CC.NET Client Communications Library - .NET 3.5 Extensions")]
[assembly: AssemblyDescription(".NET 3.5 extentions to the CC.NET Client Communications Library.")]
[assembly: AssemblyConfiguration("")]
[assembly: ComVisible(false)]
[assembly: Guid("94BEB5C0-4283-4ec5-9A25-43A6B730C8B3")]

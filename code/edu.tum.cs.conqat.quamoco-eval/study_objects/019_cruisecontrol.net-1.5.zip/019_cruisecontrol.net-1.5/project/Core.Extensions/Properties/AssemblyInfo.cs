﻿using System.Reflection;
using System.Runtime.CompilerServices;
//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("CC.NET Core Extensions (.NET 3.5) Library")]
[assembly: AssemblyDescription("Adds additional functionality that is based in .NET 3.5.")]
[assembly: AssemblyConfiguration("")]
[assembly: InternalsVisibleTo("ThoughtWorks.CruiseControl.UnitTests")]

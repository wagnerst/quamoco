﻿using System;

namespace ThoughtWorks.CruiseControl.CCCmd
{
    public enum CommandType
    {
        Retrieve,
        ForceBuild,
        AbortBuild,
        StartProject,
        StopProject,
        Help
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ThoughtWorks.CruiseControl.Core.Security
{
    /// <summary>
    /// The channel information from a remoting channel.
    /// </summary>
    public class RemotingChannelSecurityInformation
        : ChannelSecurityInformation
    {
    }
}

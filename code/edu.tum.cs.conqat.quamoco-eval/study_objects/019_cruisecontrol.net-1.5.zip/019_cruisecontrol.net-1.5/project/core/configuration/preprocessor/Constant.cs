namespace ThoughtWorks.CruiseControl.Core.Config.Preprocessor
{
    internal class Constant
    {
        public string Name;
        public object Value;
    }
}


namespace ThoughtWorks.CruiseControl.Core.Logging
{
	public enum EnumeratorDirection
	{
		Backward,
		Forward
	}
}
namespace ThoughtWorks.CruiseControl.CCTrayLib.Configuration
{
	public enum TrayIconDoubleClickAction
	{
		ShowStatusWindow,
		NavigateToWebPageOfFirstProject,
	}
}
namespace ThoughtWorks.CruiseControl.CCTrayLib.Configuration
{
	public class AudioFiles
	{
		public string BrokenBuildSound;
		public string FixedBuildSound;
		public string StillFailingBuildSound;
		public string StillSuccessfulBuildSound;
	}

}
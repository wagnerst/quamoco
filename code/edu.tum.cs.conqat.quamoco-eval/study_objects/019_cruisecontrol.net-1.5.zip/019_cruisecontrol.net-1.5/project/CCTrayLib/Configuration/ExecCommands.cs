namespace ThoughtWorks.CruiseControl.CCTrayLib.Configuration
{
	public class ExecCommands
	{
		public string BrokenCommand;
		public string BuildingCommand;
		public string SuccessCommand;
		public string NotConnectedCommand;
		public string BrokenAndBuildingCommand;
	}
}

namespace ThoughtWorks.CruiseControl.CCTrayLib.Configuration
{
	public class Icons
	{
		public string BrokenIcon = string.Empty;
		public string BuildingIcon = string.Empty;
		public string SuccessIcon = string.Empty;
		public string NotConnectedIcon = string.Empty;
		public string BrokenAndBuildingIcon = string.Empty;
	}
}

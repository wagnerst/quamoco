namespace ThoughtWorks.CruiseControl.CCTrayLib
{
	public enum NotifyInfoFlags2
	{
		Error = 0x03,
		Info = 0x01,
		None = 0x00,
		Warning = 0x02
	}
}
using System;

namespace ThoughtWorks.CruiseControl.CCTrayLib.Presentation
{
	public interface IAudioPlayer
	{
		void Play(string filename);
	}

}
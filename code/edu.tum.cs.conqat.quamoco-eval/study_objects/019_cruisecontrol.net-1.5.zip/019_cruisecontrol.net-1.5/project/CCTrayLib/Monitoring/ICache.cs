namespace ThoughtWorks.CruiseControl.CCTrayLib.Monitoring
{
	public interface ICache
	{
		void InvalidateCache();
	}
}
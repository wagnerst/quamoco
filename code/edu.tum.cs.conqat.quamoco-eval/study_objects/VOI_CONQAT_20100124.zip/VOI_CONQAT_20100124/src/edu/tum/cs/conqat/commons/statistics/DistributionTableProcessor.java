/*--------------------------------------------------------------------------+
   $Id: DistributionTableProcessor.java 24722 2009-11-10 20:59:39Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.statistics;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.commons.math.Range;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.node.SetNode;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 24722 $
 * @levd.rating RED Hash: 3D9E754E01601763E75D07B057E390C2
 */
@AConQATProcessor(description = "This processor creates a simple node structure that can be layouted as "
		+ "table with the TableLayouter. This table describes the distribution of a "
		+ "set of specified metrics with respect to a selected metric (called "
		+ "'principal metric'). Example: The input of the processor is a "
		+ "SourceCodeElementTree where each node is attributed with its Nesting Depth, "
		+ "its LOC and its SLOC. The principal metric is Nesting Depth and the "
		+ "specified boundaries are 3 and 5. Then this processor will create a table "
		+ "with x rows. Row 1 describes the bracket ]-y;3], the columns LOC and "
		+ "SLOC contain the added LOC/SLOC of all files that have nesting depth <=3 "
		+ "(y is min(smallest boundary, smallest value found for principal metric). "
		+ "Row  Row 2 describes the bracket ]3;5]; the columns LOC and SLOC contain "
		+ "the added LOC/SLOC of all files that have nesting depth 3<n<=5. If there "
		+ "are files with nesting depth > 5, row 3 will be automatically added. It "
		+ "describes the bracket ]5;z]; the columns LOC and SLOC contain the added "
		+ "LOC/SLOC of all files that have nesting depth >5. "
		+ "(z is max(greatest boundary, greatest value found for principal metric). "
		+ "The final row contains the total amount of LOC/SLOC. If 'showPercentages' "
		+ "is set to true, the table contains additional columns that show the "
		+ "LOC/SLOC in a relative manner. Note: If the number of nodes (e.g. files) "
		+ "should be used as a metric, use the ConstantAssigner to set value '1' on each node.")
public class DistributionTableProcessor extends ConQATProcessorBase implements
		INodeVisitor<IConQATNode, NeverThrownRuntimeException> {

	/** The root node. */
	private IConQATNode root;

	/** The key for the principal metric. */
	private String principalKey;

	/** This counter set stores the totals for each metric. */
	private final CounterSet<String> totals = new CounterSet<String>();

	/**
	 * For each upper boundary (inclusive) this stores a counter set which
	 * stores the added metric values with this bracket.
	 */
	private final TreeMap<Double, CounterSet<String>> values = new TreeMap<Double, CounterSet<String>>();

	/** Flag to turn on/off percentages. */
	private boolean showPercentages = true;

	/**
	 * The minimum value found for the principal metric. We cannot simply store
	 * this in the {@link #values} map as this should be treated as an exclusive
	 * (lower) boundary.
	 */
	// TODO (BH): visibility!
	// TODO (BH): Ignore comment above :) and get rid of this attribute. This
	// calculated in on method and only used in one other, so please use return
	// value/parameter passing for this value.
	double minimum;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IConQATNode root) {
		this.root = root;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "principal-metric", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The principal metric defines.")
	public void setPrincipalMetric(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC) String key) {
		this.principalKey = key;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "boundary", minOccurrences = 1, description = ""
			+ "The boundary defines the upper value (inclusive) of a bracket.")
	public void addBoundary(
			@AConQATAttribute(name = "value", description = "Upper bracket boundary (inclusive)") double boundary) {
		values.put(boundary, new CounterSet<String>());
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "metric", minOccurrences = 1, description = ""
			+ "Metric to calculate distribution for.")
	public void addMetric(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC) String key) {
		totals.inc(key, 0);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "showPercentages", minOccurrences = 0, maxOccurrences = 1, description = "Turn on/off percentage columns [default is true].")
	public void setShowPercentages(
			@AConQATAttribute(name = "value", description = "Use false to turn off percentage columns") boolean showPercentages) {
		this.showPercentages = showPercentages;
	}

	/** {@inheritDoc} */
	public SetNode<String> process() {

		determineLimits();

		// TODO (BH): Please consolidate: you are using a visitor here, but the
		// listLeavesDepthFirst() method in determineLimits(). You could even
		// share the list for both methods, although I'm not sure this would
		// save that many CPU cycles.
		TraversalUtils.visitLeavesDepthFirst(this, root);

		SetNode<String> result = new SetNode<String>("root");

		createTableBody(result);

		createSumRow(result);

		for (String key : totals.getKeys()) {
			NodeUtils.addToDisplayList(result, key);
			if (showPercentages) {
				NodeUtils.addToDisplayList(result, getPercentageKey(key));
			}
		}

		result.setValue(NodeConstants.HIDE_ROOT, true);

		// we want to retain order of addition
		result.setValue(NodeConstants.COMPARATOR, null);
		return result;
	}

	/**
	 * Determine the upper and lower limits of the values of the principal
	 * metric.
	 */
	private void determineLimits() {
		List<IConQATNode> leaves = TraversalUtils.listLeavesDepthFirst(root);

		double max = Double.NEGATIVE_INFINITY;
		double min = Double.POSITIVE_INFINITY;

		for (IConQATNode node : leaves) {
			double value;
			try {
				value = NodeUtils.getDoubleValue(node, principalKey);
			} catch (ConQATException e) {
				getLogger().warn(
						"Key " + principalKey + " undefined for node "
								+ node.getId());
				continue;
			}
			min = Math.min(min, value);
			max = Math.max(max, value);
		}

		minimum = Math.min(min, values.firstKey());

		if (max > values.lastKey()) {
			values.put(max, new CounterSet<String>());
		}

	}

	/** Create the table rows for each bracket. */
	private void createTableBody(SetNode<String> result) {

		double lowerBoundary = minimum;

		ArrayList<Double> keys = new ArrayList<Double>(values.keySet());

		// we don't have to repeat this if the smallest element is the minimum
		if (minimum == values.firstKey()) {
			keys.remove(0);
		}

		for (double upperBoundary : keys) {
			// we use the range class only for the nice formatting.
			Range range = new Range(lowerBoundary, false, upperBoundary, true);
			SetNode<String> child = new SetNode<String>(range
					.format(NumberFormat.getInstance()));

			CounterSet<String> valueSet = values.get(upperBoundary);
			for (String key : totals.getKeys()) {
				child.setValue(key, valueSet.getValue(key));

				if (showPercentages && totals.getValue(key) != 0) {
					double percentage = ((double) valueSet.getValue(key) / totals
							.getValue(key)) * 100;
					child.setValue(getPercentageKey(key), percentage);
				}
			}
			result.addChild(child);
			lowerBoundary = upperBoundary;
		}
	}

	/** Create the bottom row that contains the sums. */
	private void createSumRow(SetNode<String> result) {
		SetNode<String> child = new SetNode<String>("Sum");
		result.addChild(child);

		for (String key : totals.getKeys()) {
			child.setValue(key, totals.getValue(key));
			if (showPercentages) {
				child.setValue(getPercentageKey(key), 100d);
			}
		}
	}

	/**
	 * This method fills the data structures {@link #totals} and {@link #values}
	 * that are subsequently used to create the table.
	 */
	public void visit(IConQATNode node) {

		double value;
		try {
			value = NodeUtils.getDoubleValue(node, principalKey);
		} catch (ConQATException e) {
			// we logged this before in determineBounds
			return;
		}

		Double matchingUpperBoundary = CollectionUtils.obtainCeilingKey(values,
				value);

		CounterSet<String> valueSet = values.get(matchingUpperBoundary);

		for (String key : totals.getKeys()) {
			// we use zero as default here to deal with possibly missing values.
			// No reason to log this, as this might happen frequently.
			int inc = (int) NodeUtils.getDoubleValue(node, key, 0);
			totals.inc(key, inc);
			valueSet.inc(key, inc);
		}
	}

	/**
	 * Determine key to be used for the percentage display of the given key.
	 * This ensure that there are no overlaps between the originally specified
	 * keys and the keys used for percentages.
	 */
	private String getPercentageKey(String key) {
		key = "%" + key;
		while (totals.contains(key)) {
			key += "_";
		}
		return key;
	}
}

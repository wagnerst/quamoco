/*--------------------------------------------------------------------------+
   $Id: HierarchyBuilder.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.hierarchy;

import java.util.List;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.node.StringSetNode;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 3A717BAEC0D1DAB5932E5E9839C36EEF
 */
@AConQATProcessor(description = ""
		+ "Builds a hierarchy from all leaf nodes contained in an input tree "
		+ "based on their fully qualified names."
		+ "Examples for such names can be file paths or type names."
		+ "A parameterizable regular expression governs the decomposition of the "
		+ "fully qualified names into their constituent local names."
		+ "<br/>"
		+ "The nodes in the new hierarchy are newly created as IRemovableConQATNodes"
		+ "<br/>"
		+ "All values that are declared visible via the root node's display list"
		+ "are copied from the source nodes to the target nodes.")
public class HierarchyBuilder extends ConQATProcessorBase {

	/** Input */
	private IRemovableConQATNode input;

	/** Key in which value the node's name is stored (if not given, id is used). */
	private String fqNameKey = null;

	/** Pattern that is used to split a fully qualified name into constituents */
	private String splitRegex;

	/** String used to combine id from name parts */
	private String separator = ".";

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setInput(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IRemovableConQATNode input) {
		this.input = input;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "id", description = "Name of the key that contains the fully qualified name of the node.", minOccurrences = 0, maxOccurrences = 1)
	public void setIdKey(
			@AConQATAttribute(name = "key", description = "Optional. Default is to use the node ids.") String idKey) {
		this.fqNameKey = idKey;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "split", description = "Regular expression used to split the fully qualified name into its constituents", minOccurrences = 1, maxOccurrences = 1)
	public void setSplitRegex(
			@AConQATAttribute(name = "regex", description = "Use java regular expression sytax.") String splitRegex) {
		this.splitRegex = splitRegex;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "separator", description = "String used to combine id from name parts [by default the dot is used]", minOccurrences = 0, maxOccurrences = 1)
	public void setSeparator(
			@AConQATAttribute(name = "strin", description = "Separator string") String separator) {
		this.separator = separator;
	}

	/** Performs the creation of a new hierarchy of nodes. */
	public IRemovableConQATNode process() {
		StringSetNode root = createRoot();
		List<String> displayList = NodeUtils.getDisplayList(input);

		for (IRemovableConQATNode node : TraversalUtils
				.listLeavesDepthFirst(input)) {

			String fqName = getFullyQualifiedName(node);
			if (StringUtils.isEmpty(fqName)) {
				getLogger().warn(
						"Skipping node: No value stored under key " + fqNameKey
								+ " in node: " + node.getId());
			} else {
				IConQATNode element = insert(root, fqName);
				NodeUtils.copyValues(displayList, node, element);
			}
		}

		return root;
	}

	/** Creates the root node and copies the display list from input */
	private StringSetNode createRoot() {
		StringSetNode root = new StringSetNode(StringUtils.EMPTY_STRING);
		NodeUtils.addToDisplayList(root, NodeUtils.getDisplayList(input));
		return root;
	}

	/**
	 * Return the id of a node or, if the parameter has been set on the
	 * processor, the value stored under the id-key.
	 */
	private String getFullyQualifiedName(IRemovableConQATNode node) {
		if (fqNameKey != null) {
			Object value = node.getValue(fqNameKey);
			if (value == null) {
				return null;
			}
			return value.toString();
		}

		return node.getId();
	}

	/**
	 * Inserts a node into the hierarchy
	 * 
	 * @param element
	 *            Root element under which new node gets inserted
	 * @param fqName
	 *            Hierarchical path to element that gets inserted
	 */
	private IConQATNode insert(StringSetNode element, String fqName) {
		String[] parts = fqName.split(splitRegex);

		for (int i = 0; i < parts.length; ++i) {
			StringSetNode childElement = element.getNamedChild(parts[i]);
			if (childElement == null) {
				String parentId = element.getId();
				if (!StringUtils.isEmpty(parentId)) {
					parentId += separator;
				}
				childElement = new StringSetNode(parentId + parts[i], parts[i]);
				element.addChild(childElement);
			}
			element = childElement;
		}

		return element;
	}

}

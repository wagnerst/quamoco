/*--------------------------------------------------------------------------+
   $Id: GapRatioConstraint.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 2F7D0DB45B3C72ACAF3A2B0784801096
 */
@AConQATProcessor(description = ""
		+ "Constraint that is satisfied if the ratio of gaps to units in the clone class are below a set threshold")
public class GapRatioConstraint extends ConstraintBase {

	/** Threshold used for filtering */
	private double maxGapRatio;

	/** ConQAT Parameter */
	@AConQATParameter(name = "max", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Sets the max gap ratio above which clone classes are filtered out")
	public void setsetMaxGapRatio(
			@AConQATAttribute(name = "value", description = "Max gap ratio (inclusive)") double maxGapRatio) {
		this.maxGapRatio = maxGapRatio;
	}

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) {
		return gapRatioFor(cloneClass) <= maxGapRatio;
	}

	/** Returns the max gap ratio for the clones of a clone class */
	private double gapRatioFor(CloneClass cloneClass) {
		double gapRatio = 0;
		for (Clone clone : cloneClass.getClones()) {
			gapRatio = Math.max(gapRatio, gapRatioFor(clone));
		}
		return gapRatio;
	}

	/** Computes the gap-ratio for a clone */
	private double gapRatioFor(Clone clone) {
		return clone.getDeltaInUnits() / (double) clone.getLengthInUnits();
	}

}

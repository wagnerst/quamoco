/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: ElementProviderFactoryBase.java 25229 2010-01-19 16:31:16Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.filesystem.regions.RegionMarkerStrategy;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for element provider factories
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 25229 $
 * @levd.rating RED Rev:
 */
public abstract class ElementProviderFactoryBase<Element extends IFileSystemElement>
		extends ConQATProcessorBase {

	/** Key under which ignore flag is stored */
	protected String ignoreKey;

	/** ConQAT Parameter */
	@AConQATParameter(name = "ignore", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Key under which ignore flag is stored.")
	public void setIgnoreKey(
			@AConQATAttribute(name = "key", description = "If no key is given, no files are ignored") String ignoreKey) {
		this.ignoreKey = ignoreKey;
	}

	/** List of strategies that get evaluated */
	protected final List<RegionMarkerStrategy<?>> strategies = new ArrayList<RegionMarkerStrategy<?>>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "region-marker", description = "Add region-marker strategy", minOccurrences = 0, maxOccurrences = -1)
	public void addAnnotationStrategy(
			@AConQATAttribute(name = "strategy", description = ConQATParamDoc.INPUT_REF_NAME) Object strategy) {
		this.strategies.add((RegionMarkerStrategy<?>) strategy);
	}

}
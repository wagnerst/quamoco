/*--------------------------------------------------------------------------+
   $Id: MinimumAggregator.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.aggregation;

import java.util.List;

import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This aggregator propagates the minimum value.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 6F83183870D6D3D4F5D14837994E92BD
 */
@AConQATProcessor(description = "An aggregator for propagating the minimum value. "
		+ "Any Comparable type (Date, Number, etc.) can be in the keys.")
public class MinimumAggregator extends AggregatorBase<Comparable<Object>> {

	/** {@inheritDoc} */
	@Override
	protected Comparable<Object> aggregate(List<Comparable<Object>> values) {
		Comparable<Object> result = values.get(0);
		for (Comparable<Object> value : values) {
			if (result.compareTo(value) > 0) {
				result = value;
			}
		}
		return result;
	}
}

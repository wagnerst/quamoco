package edu.tum.cs.conqat.simulink.clones.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.Stack;
import java.util.TreeSet;

import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.model_clones.label.CanonicalLabelCreator;
import edu.tum.cs.conqat.model_clones.label.GraphLabel;
import edu.tum.cs.conqat.model_clones.model.IDirectedEdge;
import edu.tum.cs.conqat.model_clones.model.IModelGraph;
import edu.tum.cs.conqat.model_clones.model.INode;
import edu.tum.cs.conqat.simulink.clones.normalize.ISimulinkNormalizer;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;
import edu.tum.cs.simulink.model.SimulinkLine;

/**
 * Class used to create a {@link SimulinkModelGraph} from a
 * {@link ISimulinkElement}. Subsystem nodes are not removed. The contents of a
 * subsystem are added as a disconnected component. This is not a processor, but
 * instead called by a processor directly.
 * 
 * @author pfaehlem
 * 
 */
public class SimulinkHierarchyGraphCreator extends SimulinkModelGraphCreator
		implements IBacktrackVisitor {

	/** unfinishedModelGraphs.pop() returns the last opened subsystem of DFS */
	private Stack<SimulinkGraphNodeWrapper> unfinishedModelGraphs;

	/** A collection of all subsystem nodes */
	protected final Collection<SimulinkGraphNodeWrapper> modelGraphs = new HashSet<SimulinkGraphNodeWrapper>();

	/** Holds all identified subsystem clones */
	private static final SortedSet<Collection<IModelGraph>> clonedSubsystems = new TreeSet<Collection<IModelGraph>>(
			new Comparator<Collection<IModelGraph>>() {
				// sort clone groups based on weight (until valuesorter works)
				public int compare(Collection<IModelGraph> arg0,
						Collection<IModelGraph> arg1) {
					return getWeight(arg0) - getWeight(arg1);
				}

				// identify node weight of first element
				private int getWeight(Collection<IModelGraph> modelGraphs) {
					Collection<INode> nodes = modelGraphs.iterator().next()
							.getNodes();
					int result = 0;
					for (INode node : nodes) {
						result += node.getWeight();
					}
					return result;
				}
			});

	protected SimulinkHierarchyGraphCreator(ISimulinkElement rootNode,
			ISimulinkNormalizer normalizer) {
		super(rootNode, normalizer);
		unfinishedModelGraphs = new Stack<SimulinkGraphNodeWrapper>();
	}

	/** Create and return the model graph. */
	protected SimulinkModelGraph create() throws ConQATException {
		for (ISimulinkElement model : TraversalUtils
				.listLeavesDepthFirst(input)) {
			if (model instanceof SimulinkModelElement) {
				SimulinkFurtherUtils.visitDepthFirst(
						((SimulinkModelElement) model).getModel(), this);
			}
		}
		includeEdges();

		removeDuplicateSubsystems();
		flatten();

		return result;
	}

	/**
	 * Convert the edges of the given block.
	 * 
	 * @param wrapperNode
	 */
	protected void convertEdges(SimulinkBlock block,
			SimulinkGraphNodeWrapper wrapperNode) throws ConQATException {
		// we are using only outgoing lines to avoid duplication here

		for (SimulinkLine line : block.getOutLines()) {
			ISimulinkNode sourceNode = blockMap.get(line.getSrcPort()
					.getBlock());
			ISimulinkNode targetNode = blockMap.get(line.getDstPort()
					.getBlock());

			if (sourceNode == null || targetNode == null) {
				throw new ConQATException("Incomplete line: " + line);
			}
			// add the edge if it's within this subsystem
			Collection<ISimulinkNode> subgraphNodes = wrapperNode.getNodes();
			// TODO: can this happen?
			if (subgraphNodes.contains(sourceNode)
					&& subgraphNodes.contains(targetNode)) {
				wrapperNode.addEdge(new SimulinkDirectedEdge(line, normalizer
						.normalizeLine(line), sourceNode, targetNode));
			}
		}
	}

	/**
	 * Removes all duplicate subsystems from the result (using canonical labels
	 * for subgraphs)
	 */
	private void removeDuplicateSubsystems() {
		HashedListMap<SimulinkGraphNodeWrapper, SimulinkGraphNodeWrapper> subSysClones = new HashedListMap<SimulinkGraphNodeWrapper, SimulinkGraphNodeWrapper>();
		System.out.println("Blockmap size before: " + blockMap.size());
		Map<GraphLabel, SimulinkGraphNodeWrapper> labelMap = new HashMap<GraphLabel, SimulinkGraphNodeWrapper>();
		List<SimulinkGraphNodeWrapper> toRemove = new ArrayList<SimulinkGraphNodeWrapper>();
		for (SimulinkGraphNodeWrapper wrapperNode : modelGraphs) {
			GraphLabel cLabel = CanonicalLabelCreator.getCanonicalLabel(
					wrapperNode.getNodes(), wrapperNode.getEdges());
			if (labelMap.containsKey(cLabel)) {
				toRemove.add(wrapperNode);

				subSysClones.add(labelMap.get(cLabel), wrapperNode);

				for (ISimulinkNode node : wrapperNode.getNodes()) {
					blockMap.remove(node.getBlock());
				}
			} else {
				labelMap.put(cLabel, wrapperNode);
			}
		}
		modelGraphs.removeAll(toRemove);
		System.out.println("Skipped a total of " + toRemove.size()
				+ " subsystems:");
		printRemovedSubsystems(subSysClones);
		buildClonedSubsystemInformation(subSysClones);

		System.out.println("Blockmap size after: " + blockMap.size());
	}

	/**
	 * Fills {@code clonedSubsystems} with the identified cloned subsystems.
	 */
	private void buildClonedSubsystemInformation(
			HashedListMap<SimulinkGraphNodeWrapper, SimulinkGraphNodeWrapper> subSysClones) {

		removeCoveredSubsystems(subSysClones);

		for (SimulinkGraphNodeWrapper subsys : subSysClones.getKeys()) {
			List<SimulinkGraphNodeWrapper> thisSubSysClones = subSysClones
					.getList(subsys);
			ArrayList<IModelGraph> cloneList = new ArrayList<IModelGraph>(
					thisSubSysClones.size() + 1);
			cloneList.add(createModelGraph(subsys));// add first
			for (final SimulinkGraphNodeWrapper clonedSubsystem : thisSubSysClones) {
				// and all clones
				cloneList.add(createModelGraph(clonedSubsystem));
			}
			clonedSubsystems.add(cloneList);
		}
	}

	/**
	 * Removes all subsystems from {@code subSysClones} that are contained
	 * within a bigger subsystem clone.
	 * 
	 * We may lose information, for a situation like this: A,B are subsystems. B
	 * has two clone instances, A has three clone instances, two of them within
	 * a B subsystem, one A instance does not lie within a B subsystem. In that
	 * case only the two subsystems of type B are reported. The third instance
	 * of A is not reported!
	 */
	private void removeCoveredSubsystems(
			HashedListMap<SimulinkGraphNodeWrapper, SimulinkGraphNodeWrapper> subSysClones) {

		Set<Object> containedSubsystemLabels = getCoveredSubsystemLabels(subSysClones);

		Iterator<SimulinkGraphNodeWrapper> wrapperIt = subSysClones.getKeys()
				.iterator();
		while (wrapperIt.hasNext()) {
			SimulinkGraphNodeWrapper subsys = wrapperIt.next();
			if (containedSubsystemLabels.contains(subsys
					.getEquivalenceClassLabel())) {
				wrapperIt.remove();
			}
		}
	}

	/**
	 * Returns those subsystem labels that are covered by a bigger cloned
	 * subsystem.
	 */
	private Set<Object> getCoveredSubsystemLabels(
			HashedListMap<SimulinkGraphNodeWrapper, SimulinkGraphNodeWrapper> subSysClones) {
		Set<Object> containedSubsystemLabels = new HashSet<Object>();
		for (SimulinkGraphNodeWrapper subsys : subSysClones.getKeys()) {
			for (INode node : subsys.getNodes()) {
				if (node instanceof SimulinkGraphNodeWrapper) {
					// filter underlying subsystem as it's contained in a bigger
					// clone
					// we may lose information though
					containedSubsystemLabels.add(node
							.getEquivalenceClassLabel());
				}
			}
		}
		return containedSubsystemLabels;
	}

	/**
	 * Prints details about the duplicate subsystems that were removed.
	 */
	private void printRemovedSubsystems(
			HashedListMap<SimulinkGraphNodeWrapper, SimulinkGraphNodeWrapper> subSysClones) {
		int i = 1;
		for (SimulinkGraphNodeWrapper subsys : subSysClones.getKeys()) {
			System.out.println("-----------Starting clone group " + i++
					+ " :--------------");
			System.out.println(subsys + "(NS: " + subsys.getNodes().size()
					+ ", ES: " + subsys.getEdges().size() + ", Sum: "
					+ (subsys.getNodes().size() + subsys.getEdges().size())
					+ ")");
			for (SimulinkGraphNodeWrapper clones : subSysClones.getList(subsys)) {
				System.out.println(clones);
			}
		}
	}

	/** Creates an IModelGraph for {@code clonedSubsystem} */
	private IModelGraph createModelGraph(
			final SimulinkGraphNodeWrapper clonedSubsystem) {
		return new IModelGraph() {

			public Collection<IDirectedEdge> getEdges() {
				return clonedSubsystem.getEdges();
			}

			public Collection<INode> getNodes() {
				return new ArrayList<INode>(clonedSubsystem.getNodes());
			}

		};
	}

	/**
	 * Converts the given block to a {@link SimulinkNode} and registers it with
	 * {@link #blockMap}.
	 */
	public void visit(SimulinkBlock block) throws ConQATException {
		ISimulinkNode node = null;
		if (block.hasSubBlocks()) {
			SimulinkModelGraph graph = new SimulinkModelGraph();
			SimulinkGraphNodeWrapper nodeGraph = new SimulinkGraphNodeWrapper(
					block, graph);
			if (unfinishedModelGraphs.size() > 0) {
				unfinishedModelGraphs.peek().addNode(nodeGraph);
			}
			unfinishedModelGraphs.push(nodeGraph);
			node = nodeGraph;
		} else {
			node = new SimulinkNode(block, normalizer.normalizeBlock(block),
					normalizer.determineWeight(block));
			unfinishedModelGraphs.peek().addNode(node);
		}
		blockMap.put(block, node);
	}

	/**
	 * Is called when the entire subtree was visited which lies under the node
	 * currently on top of {@code unfinishedModelGraphs}.
	 */
	public void backtrack() {
		SimulinkGraphNodeWrapper wrapperNode = unfinishedModelGraphs.pop();
		wrapperNode.updateEquivalenceClass();
		modelGraphs.add(wrapperNode);
	}

	/**
	 * Builds the final model graph. Subsystem contents are added as a
	 * disconnected component.
	 * 
	 * @throws ConQATException
	 */
	private void flatten() throws ConQATException {
		for (SimulinkGraphNodeWrapper wrapperNode : modelGraphs) {

			for (ISimulinkNode simulinkNode : wrapperNode.getNodes()) {
				result.addNode(simulinkNode);
			}
			for (IDirectedEdge edge : wrapperNode.getEdges()) {
				result.addEdge((SimulinkDirectedEdge) edge);
			}
			System.out.println("Integrating a part graph with "
					+ wrapperNode.getNodes().size() + " nodes " + " and "
					+ wrapperNode.getEdges().size() + " edges.");
		}

	}

	private void includeEdges() throws ConQATException {
		for (SimulinkGraphNodeWrapper wrapperNode : modelGraphs) {
			for (ISimulinkNode simulinkNode : wrapperNode.getNodes()) {
				convertEdges(simulinkNode.getBlock(), wrapperNode);
			}
		}
	}

	/**
	 * Create the model graph from the given Simulink root node using the
	 * provided normalizations.
	 */
	public static SimulinkModelGraph createModelGraph(
			ISimulinkElement rootNode, ISimulinkNormalizer normalizer)
			throws ConQATException {
		return new SimulinkHierarchyGraphCreator(rootNode, normalizer).create();
	}

	/**
	 * Returns all clones identified during duplicate subsystem identification.
	 * Must be called after @see
	 * {@link #createModelGraph(ISimulinkElement, ISimulinkNormalizer)}
	 * otherwise will return null.
	 * 
	 * @return
	 */
	public static Collection<Collection<IModelGraph>> getSubsystemClones() {
		return clonedSubsystems;
	}
}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: ContentConstraint.java 25219 2010-01-12 13:52:58Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 25219 $
 * @levd.rating YELLOW Hash: C5BA13F320B425B7502626DC24C0C2F5
 */
@AConQATProcessor(description = "Constraint that is satisfied if at least one pattern matches in at least one clone.")
public class ContentConstraint extends ConstraintBase {

	/** Patterns against which clones are matched */
	protected PatternList patterns;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "patterns", description = "Patterns against which cloned content is matched.", minOccurrences = 1, maxOccurrences = 1)
	public void setPatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) PatternList patterns) {
		this.patterns = patterns;
	}

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) throws ConQATException {
		for (Clone clone : cloneClass.getClones()) {
			String code = CloneUtils.getCloneContent(clone);
			if (patterns.findsAnyIn(code)) {
				return true;
			}
		}

		return false;
	}

}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingFormatEntry.java 24355 2009-10-01 12:09:19Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.format;


/**
 * A single entry in a finding format.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 24355 $
 * @levd.rating YELLOW Hash: 5D56A41C5F23E920302FCC984F575EEA
 */
public final class FindingFormatEntry {

	/** The key this refers to. */
	private final String key;

	/** Determines as which type the key should be interpreted. */
	private final EFindingFormatType type;

	/** Constructor. */
	public FindingFormatEntry(String key, EFindingFormatType type) {
		this.key = key;
		this.type = type;
	}

	/** Constructs a new instance from the serialized string. */
	public FindingFormatEntry(String serialized) {
		String[] parts = serialized.split(":", 2);
		this.key = parts[0];
		if (parts.length == 1) {
			this.type = EFindingFormatType.STRING;
		} else {
			this.type = EFindingFormatType.parseTypeName(parts[1]);
		}
	}

	/** Returns the key this refers to. */
	public String getKey() {
		return key;
	}

	/** Returns as which type the key should be interpreted. */
	public EFindingFormatType getType() {
		return type;
	}

	/** {@inheritDoc} */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof FindingFormatEntry)) {
			return false;
		}

		FindingFormatEntry other = (FindingFormatEntry) obj;
		return key.equals(other.key) && type == other.type;
	}

	/** {@inheritDoc} */
	@Override
	public int hashCode() {
		return key.hashCode() + 13 * type.hashCode();
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return key + ":" + type.getTypeName();
	}
}

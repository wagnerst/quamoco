/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FileRemoteJob.java 24572 2009-10-23 21:57:52Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.distributed;

import java.io.Serializable;
import java.nio.charset.Charset;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.distributed.JobDistributorBase;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * A job which calculates a value based on a single file.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 24572 $
 * @levd.rating YELLOW Hash: DC4BEE14C952B2E06E68B82B2F507D10
 */
public abstract class FileRemoteJob extends
		LoggingDistributableJob.RunnableWithResult {

	/** The file to work on. */
	protected final CanonicalFile file;

	/**
	 * The encoding to be used. We use a string (its name) instead of
	 * {@link Charset} as the later is not {@link Serializable}.
	 */
	protected final String encoding;

	/** Constructor. */
	public FileRemoteJob(CanonicalFile file, Charset encoding) {
		this.file = file;
		this.encoding = encoding.name();
	}

	/** {@inheritDoc} */
	@Override
	protected Object calculateResult() throws ConQATException {
		return calculateResult(file, encoding);
	}

	/** Calculates the result based on the given file. */
	protected abstract Object calculateResult(CanonicalFile file,
			String encoding) throws ConQATException;

	/** Convenience method used to schedule the job. */
	public void schedule(JobDistributorBase jobDistributor, IConQATNode node,
			String key, IConQATLogger logger) {
		jobDistributor.executeJob(new KeyCalculatingJob<FileRemoteJob>(this,
				node, key, logger), file);
	}
}

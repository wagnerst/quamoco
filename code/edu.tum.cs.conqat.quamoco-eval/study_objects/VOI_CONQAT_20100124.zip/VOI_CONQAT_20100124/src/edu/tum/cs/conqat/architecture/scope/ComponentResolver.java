/*--------------------------------------------------------------------------+
   $Id: ComponentResolver.java 24362 2009-10-02 06:39:40Z heineman $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.scope;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Maps element IDs to their corresponding architecture components.
 * 
 * @author juergens
 * @author $Author: heineman $
 * @version $Rev: 24362 $
 * @levd.rating YELLOW Hash: 360034EDE37B9D24EB2AAAA004FB426F
 */
public class ComponentResolver {

	/** The reference architecture. */
	private final ArchitectureDefinition arch;

	/** Logger used to issue warnings */
	private final IConQATLogger logger;

	/** Cache for element to component results. */
	private final Map<String, ComponentNode> elementLookup = new HashMap<String, ComponentNode>();

	/** Default constructor */
	public ComponentResolver(ArchitectureDefinition arch, IConQATLogger logger) {
		CCSMPre.isNotNull(arch, "Architecture must not be null");
		this.arch = arch;
		this.logger = logger;
	}

	/**
	 * Tries to determine the architecture component corresponding to a element
	 * ID. If no or more than one component is found, a warning message is
	 * logged.
	 * 
	 * @return Corresponding component, or null, if no unambiguous match could
	 *         be found
	 */
	public ComponentNode findComponentFor(String elementId) {

		ComponentNode node = elementLookup.get(elementId);
		if (node != null) {
			return node;
		}

		List<ComponentNode> components = new ArrayList<ComponentNode>();
		arch.findMatchingComponents(elementId, components);

		if (components.size() == 1) {
			elementLookup.put(elementId, components.get(0));
		} else if (components.isEmpty()) {
			elementLookup.put(elementId, null);
			logNoComponentFound(elementId);
		} else {

			// This checks whether the multiple components are related to
			// each other (i.e. are in a hierarchy). In this case the
			// deepest component is the one we want. This is required to
			// allow more general patterns at the parent components.
			// This code assumes that components was filled by preorder
			// traversal, so the components are stored from root to leaf.
			boolean hierarchy = true;
			for (int i = components.size() - 1; i > 0; i--) {
				if (!components.get(i).getAncestorSet().contains(
						components.get(i - 1))) {
					hierarchy = false;
					break;
				}
			}

			if (hierarchy) {
				elementLookup.put(elementId, components
						.get(components.size() - 1));
			} else {
				elementLookup.put(elementId, null);
				logMultipleComponentsFound(elementId, components);
			}
		}

		return elementLookup.get(elementId);
	}

	/** Create error logging messages if no component has been found */
	private void logNoComponentFound(String vertexId) {
		if (logger != null) {
			logger.warn("Could find no component for " + vertexId);
		}
	}

	/** Create error logging messages if multiple components have been found */
	private void logMultipleComponentsFound(String elementId,
			List<ComponentNode> components) {
		if (logger != null) {
			logger.warn("Found multiple components for " + elementId + ":"
					+ StringUtils.concat(components, ", "));
		}
	}

}

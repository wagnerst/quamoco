/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: KeyCalculatingJob.java 24572 2009-10-23 21:57:52Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.distributed;

import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * A job used for calculating and persisting simple values as keys.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 24572 $
 * @levd.rating YELLOW Hash: 353594F49E641BF2260548018071B055
 */
public class KeyCalculatingJob<T extends LoggingDistributableJob.RunnableWithResult>
		extends LoggingDistributableJob<T> {

	/** The remote job. */
	protected final T job;

	/** The node to store the result in. */
	protected final IConQATNode node;

	/** The key to store the result in. */
	protected final String key;

	/** Constructor. */
	public KeyCalculatingJob(T job, IConQATNode node, String key,
			IConQATLogger logger) {
		super(logger);
		this.job = job;
		this.node = node;
		this.key = key;
	}

	/** {@inheritDoc} */
	public T prepareRemoteJob() {
		return job;
	}

	/** {@inheritDoc} */
	@Override
	protected void processResult(Object result) {
		node.setValue(key, result);
	}
}

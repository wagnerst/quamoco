/*--------------------------------------------------------------------------+
   $Id: SourceCodeElementProviderFactory.java 25229 2010-01-19 16:31:16Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * Creates a {@link SourceCodeElementProvider}.
 * <p>
 * This class could be unified with {@link FileSystemElementProvider} using
 * generics. However, since the ConQAT load time type checking mechanism cannot
 * deal with generics, this was deliberately not done.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 25229 $
 * @levd.rating GREEN Hash: 141277DD45E8343CD409C1B4C4B02D3F
 */
@AConQATProcessor(description = "Creates a SourceCodeElementProvider")
public class SourceCodeElementProviderFactory extends
		ElementProviderFactoryBase<ISourceCodeElement> {

	/** Creates a {@link SourceCodeElementProvider} */
	public SourceCodeElementProvider process() {
		return new SourceCodeElementProvider(ignoreKey, strategies);
	}
}

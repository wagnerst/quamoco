/*--------------------------------------------------------------------------+
   $Id: ComponentNode.java 25096 2009-12-10 14:21:15Z heineman $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.scope;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Collection;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.architecture.format.EStereotype;
import edu.tum.cs.conqat.commons.CommonUtils;
import edu.tum.cs.conqat.commons.node.ConQATGeneralNodeBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * This is a node representing a component (which can in turn have sub
 * components). The elements of a system (usually these are classes) are mapped
 * onto these components.
 * 
 * @author Benjamin Hummel
 * @author $Author: heineman $
 * @version $Rev: 25096 $
 * @levd.rating RED Hash: 937EEA0148AB4480A934875DFE6D891C
 */
public class ComponentNode extends ConQATGeneralNodeBase<ComponentNode> {

	/** Full unique name of this component. */
	private final String name;

	/** Policy defining whether child components may depend on each other. */
	private final EPolicyType defaultPolicy;

	/**
	 * Position of this Component. The Position is relative to the parent
	 * Component!
	 */
	private final Point pos;

	/** Dimension of this Component. */
	private final Dimension dim;

	/** Patterns matching names of elements contained in this component. */
	private final PatternList containedElementPatterns = new PatternList();

	/**
	 * Patterns matching names of elements explicitly excluded from this
	 * component. (Overrules containedElementPatterns)
	 */
	private final PatternList excludedElementPatterns = new PatternList();

	/**
	 * All policies for which this component is the source. This is a map from
	 * the target to policy.
	 */
	private final Map<ComponentNode, DependencyPolicy> sourcePolicies = new IdentityHashMap<ComponentNode, DependencyPolicy>();

	/** All policies for which this component is the target. */
	private final Collection<DependencyPolicy> targetPolicies = new HashSet<DependencyPolicy>();

	/** The stereotype of this component */
	private EStereotype stereotype;

	/**
	 * Creates a new {@link ComponentNode}.
	 * 
	 * @param defaultPolicy
	 *            Default policy for this component. Default policy determines
	 *            whether, in absence of further policies, the child components
	 *            of this component are allowed to depend on each other.
	 * @param pos
	 *            Position of this component.
	 * @param stereotype the stereotype of this component.
	 * 
	 * @throws IllegalArgumentException
	 *             if pos is null.
	 * 
	 */
	/* package */ComponentNode(String name, EPolicyType defaultPolicy,
			Point pos, Dimension dim, EStereotype stereotype) {
		CCSMPre.isNotNull(pos, "The position must not be null");
		CCSMPre.isNotNull(dim, "The dimension must not be null");
		CCSMPre.isTrue(defaultPolicy.isImplicit(),
				"Default policy has to be implicit!");
		CCSMPre.isNotNull(stereotype, "The stereotype must not be null");

		this.name = name;
		this.defaultPolicy = defaultPolicy;
		this.pos = pos;
		this.dim = dim;
		this.stereotype = stereotype;
	}

	/** Copy constructor. */
	protected ComponentNode(ComponentNode other) throws DeepCloneException {
		super(other);
		name = other.name;
		defaultPolicy = other.defaultPolicy;
		containedElementPatterns.addAll(other.containedElementPatterns);
		excludedElementPatterns.addAll(other.excludedElementPatterns);

		pos = other.pos;
		dim = other.dim;
		stereotype = other.stereotype;
	}

	/**
	 * Creates a lookup table from names to components by traversing the nodes
	 * in DFS order and putting results into the provided map.
	 */
	protected void fillNameLookup(Map<String, ComponentNode> nameLookup) {
		nameLookup.put(getName(), this);
		if (hasChildren()) {
			for (ComponentNode child : getChildren()) {
				child.fillNameLookup(nameLookup);
			}
		}
	}

	/**
	 * Collect all policies by traversing the tree in DFS order and using only
	 * fromPolicies, to avoid duplicate entries. Results are put into the
	 * provided collection.
	 */
	public void collectPolicies(Collection<DependencyPolicy> policies) {
		policies.addAll(sourcePolicies.values());
		if (hasChildren()) {
			for (ComponentNode child : getChildren()) {
				child.collectPolicies(policies);
			}
		}
	}

	/** {@inheritDoc} */
	@Override
	protected ComponentNode[] allocateArray(int size) {
		return new ComponentNode[size];
	}

	/** {@inheritDoc} */
	public String getId() {
		// names are unique for architectures
		return getName();
	}

	/** {@inheritDoc} */
	public String getName() {
		return name;
	}

	/** Returns the name. */
	@Override
	public String toString() {
		return getName();
	}

	/** {@inheritDoc} */
	public ComponentNode deepClone() throws DeepCloneException {
		return new ComponentNode(this);
	}

	/** Adds an additional pattern to identify elements of this component. */
	/* package */void addElementRegex(String regex) throws ConQATException {
		containedElementPatterns.add(CommonUtils.compilePattern(regex));
	}

	/**
	 * Adds an additional exclude pattern to explicitly exclude elements of this
	 * component. (Overrules patterns added by {@link #addElementRegex(String)}
	 * ).
	 */
	/* package */void addExcludeRegex(String regex) throws ConQATException {
		excludedElementPatterns.add(CommonUtils.compilePattern(regex));
	}

	/** Add a dependency policy to this component. */
	// TODO (LH) Do we really want to use a checked exception here?
	// I can't see how a client recovers from this exception
	// So, I would rather use an unchecked exception here
	/* package */void addPolicy(DependencyPolicy policy) throws ConQATException {
		if (policy.getSource() == this) {
			if (sourcePolicies.containsKey(policy.getTarget())) {
				throw new ConQATException("Duplicate policy from " + getName()
						+ " to " + policy.getTarget());
			}
			sourcePolicies.put(policy.getTarget(), policy);
		}
		if (policy.getTarget() == this) {
			targetPolicies.add(policy);
		}
	}

	/**
	 * Find all components (this plus child components) into which the given
	 * element name fits. They are put into the provided collection. The list of
	 * component nodes is filled by 'preorder' traversal.
	 */
	/* package */void findMatchingComponents(String elementName,
			List<ComponentNode> result) {
		if (containedElementPatterns.matchesAny(elementName)) {

			// explicitly check if elementName is excluded
			if (!excludedElementPatterns.matchesAny(elementName)) {
				result.add(this);
			}
		}

		if (hasChildren()) {
			for (ComponentNode child : getChildren()) {
				child.findMatchingComponents(elementName, result);
			}
		}
	}

	/** Returns whether there is a policy to the other node. */
	public boolean hasPolicyTo(ComponentNode other) {
		return sourcePolicies.containsKey(other);
	}

	/**
	 * Returns the policy to the target component. If no policy exists, a new
	 * implicit policy is created.
	 * <p>
	 * The search for a policy checks if there is a direct policy. Otherwise we
	 * check for policies to any ancestor of the target component. If this fails
	 * as well, we continue up along the ancestors of the source using the same
	 * procedure until we either find a policy or reach a common ancestor
	 * component. In the later case we use the default policy of the common
	 * ancestor.
	 */
	public DependencyPolicy getOrCreatePolicy(ComponentNode targetComponent) {
		CCSMPre.isFalse(this == targetComponent, "No self policies supported.");

		LinkedHashSet<ComponentNode> targetAncestors = targetComponent
				.getAncestorSet();
		for (ComponentNode source : getAncestorSet()) {
			// source is common ancestor, so use its policy
			if (targetAncestors.contains(source)) {
				DependencyPolicy result = new DependencyPolicy(this,
						targetComponent, source.defaultPolicy);
				try {
					result.registerWithComponents();
				} catch (ConQATException e) {
					CCSMAssert
							.fail("This is not possible as we checked for this case before!");

				}
				return result;
			}

			for (ComponentNode target : targetAncestors) {
				DependencyPolicy policy = source.sourcePolicies.get(target);
				boolean isTopLevelPolicy = source == this
						&& target == targetComponent;
				// we do not take implicit policies that have been created
				// during assessment to avoid condensation of violations of
				// implicit policies.
				if (policy != null
						&& (isTopLevelPolicy || !policy.getPolicyType()
								.isImplicit())) {
					return policy;
				}
			}
		}

		throw new AssertionError(
				"This should never be reached as at least the root component "
						+ "should be a common ancestor for both.");
	}

	/**
	 * Returns a set containing this node and all predecessors of this node in
	 * the hierarchy! The order of nodes is preserved and starts from the
	 * current node down to the root.
	 */
	public LinkedHashSet<ComponentNode> getAncestorSet() {
		LinkedHashSet<ComponentNode> result = new LinkedHashSet<ComponentNode>();
		ComponentNode node = this;
		while (node != null) {
			result.add(node);
			node = node.getParent();
		}
		return result;
	}

	/** Returns the relative Position of this Component. */
	public Point getPosition() {
		return pos;
	}
	
	/** Returns the stereotype. */
	public EStereotype getStereotype() {
		return stereotype;
	}

	/** Returns the absolute Position of this Component. */
	public Point getAbsolutePosition() {
		Point result = new Point(pos);
		if (getParent() != null) {
			Point parentPos = getParent().getAbsolutePosition();
			result.translate(parentPos.x, parentPos.y);
		}
		return result;
	}

	/** Returns the Dimension of this Component. */
	public Dimension getDimension() {
		return dim;
	}

	/** Returns the absolute bounds of this component. */
	public Rectangle getAbsoluteBounds() {
		return new Rectangle(getAbsolutePosition(), getDimension());
	}

}

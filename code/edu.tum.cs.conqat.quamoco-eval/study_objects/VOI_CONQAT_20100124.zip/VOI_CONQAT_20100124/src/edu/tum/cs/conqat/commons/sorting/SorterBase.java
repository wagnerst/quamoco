/*--------------------------------------------------------------------------+
   $Id: SorterBase.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.sorting;

import java.util.Comparator;

import edu.tum.cs.commons.collections.InvertingComparator;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for sorting processors. These are based on setting the comparator
 * for all inner nodes of a ConQATNode tree. The actual sorting happens in the
 * presentation.
 * 
 * @author Florian Deissenboeck
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: AB51916092B071D35B227F80D489EA06
 */
public abstract class SorterBase extends
		NodeTraversingProcessorBase<IConQATNode> {

	/** Whether to sort ascending or descending. */
	private boolean descending = false;

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.INNER;
	}

	/** Set whether to sort ascending or descending. */
	@AConQATParameter(name = "descending", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "If this is set to true, the sorting is descending. Default is ascending (false).")
	public void setDescending(
			@AConQATAttribute(name = "value", description = "true or false")
			boolean descending) {
		this.descending = descending;
	}

	/** Set the comparator (only called for inner nodes). */
	public void visit(IConQATNode node) throws ConQATException {
		Comparator<IConQATNode> comp = getComparator(node);
		if (descending) {
			comp = new InvertingComparator<IConQATNode>(comp);
		}
		node.setValue(NodeConstants.COMPARATOR, comp);
	}

	/**
	 * Returns the comparator to be used for the given node. This is called
	 * exactly once for each node. The comparator should sort nodes in ascending
	 * order, as descending ordering is handled transparently in this class
	 * using an enclosing comparator.
	 */
	protected abstract Comparator<IConQATNode> getComparator(IConQATNode node)
			throws ConQATException;

}

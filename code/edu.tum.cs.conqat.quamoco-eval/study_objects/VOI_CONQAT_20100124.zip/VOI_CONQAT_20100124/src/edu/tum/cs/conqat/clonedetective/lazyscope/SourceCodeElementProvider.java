/*--------------------------------------------------------------------------+
   $Id: SourceCodeElementProvider.java 25229 2010-01-19 16:31:16Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import java.util.List;

import edu.tum.cs.conqat.filesystem.regions.RegionMarkerStrategy;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * Provider for {@link ISourceCodeElement}s.
 * <p>
 * Remark on implementation: this class only sets the generic parameter its base
 * class to {@link ISourceCodeElement}. This way, the ConQAT load time type
 * checking mechanism does not have to deal with generic types (which it
 * cannot).
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 25229 $
 * @levd.rating GREEN Hash: B5454FCA0D646B6E90A157E4F36E7DCD
 */
public class SourceCodeElementProvider extends
		ElementProviderBase<ISourceCodeElement> {

	/** Constructor. */
	public SourceCodeElementProvider(String ignoreKey) {
		super(ignoreKey);
	}

	/** Constructor. */
	public SourceCodeElementProvider(String ignoreKey,
			List<RegionMarkerStrategy<?>> strategies) {
		super(ignoreKey, strategies);
	}
}

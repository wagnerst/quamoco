/*--------------------------------------------------------------------------+
   $Id: CodeRegionLocation.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.location;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.filesystem.CanonicalFile;

/**
 * Location for code regions.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: EF87685C342B6606559B370E36139CDB
 */
public class CodeRegionLocation extends CodeLineLocation {

	/** The last line for the region (inclusive). */
	private final int lastLine;

	/** The position in the first line (zero based). */
	private final int firstPosition;

	/** The position in the last line (zero based) */
	private final int lastPosition;

	/** Constructor. */
	public CodeRegionLocation(CanonicalFile file, int firstLine, int lastLine) {
		this(file, firstLine, lastLine, 0, 0);
	}

	/** Constructor. */
	public CodeRegionLocation(CanonicalFile file, int firstLine, int lastLine,
			int firstPosition, int lastPosition) {
		super(file, firstLine);
		CCSMPre.isTrue(firstLine <= lastLine,
				"Invalid region with negative length!");
		this.lastLine = lastLine;
		this.firstPosition = firstPosition;
		this.lastPosition = lastPosition;
	}

	/** Returns the last line for the region (inclusive). */
	public int getLastLine() {
		return lastLine;
	}

	/** Returns the position in the first line (zero based). */
	public int getFirstPosition() {
		return firstPosition;
	}

	/** Returns the position in the last line (zero based) */
	public int getLastPosition() {
		return lastPosition;
	}

	/** Returns the length in lines. */
	public int getLengthInLines() {
		return lastPosition - firstPosition + 1;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return super.toString() + "-" + lastLine;
	}
}

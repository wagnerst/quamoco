/*--------------------------------------------------------------------------+
   $Id: DatabaseProcessorBase.java 23494 2009-08-07 16:12:12Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database;

import java.sql.Connection;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;

/**
 * Base class for processors that work on a database table.
 * 
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * @version $Rev: 23494 $
 * @levd.rating GREEN Hash: EECABE8629C0496B1BCA5E9C5328D7F8
 */
public abstract class DatabaseProcessorBase extends ConQATProcessorBase {

	/** Database connection. */
	protected Connection dbConnection;

	/** Name of the database table. */
	protected String tableName;

	/** Set database details. */
	@AConQATParameter(name = "database", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Describes the database and table used for storing the value.")
	public void setTable(
			@AConQATAttribute(name = "connection", description = "Database connection.") Connection dbConnection,
			@AConQATAttribute(name = "table", description = "The name of the table.") String tableName) {
		this.dbConnection = dbConnection;
		this.tableName = tableName;
	}

}
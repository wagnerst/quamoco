/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: EFindingFormatType.java 24355 2009-10-01 12:09:19Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.format;

/**
 * Enumeration of formatting types for findings.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 24355 $
 * @levd.rating YELLOW Hash: 34E14347F977F3B09DE67CFA95A7F356
 */
public enum EFindingFormatType {

	/** Textual type. */
	STRING("s"),

	/** Integral number. */
	INT("i"),

	/** Real number. */
	DOUBLE("d");

	/** The type name. */
	private final String typeName;

	/** Constructor. */
	private EFindingFormatType(String typeName) {
		this.typeName = typeName;
	}

	/** Returns the type name for this type. */
	public String getTypeName() {
		return typeName;
	}

	/**
	 * Returns the format type for a given type name. If nothing matches,
	 * {@link #STRING} is returned.
	 */
	public static EFindingFormatType parseTypeName(String typeName) {
		for (EFindingFormatType type : values()) {
			if (type.getTypeName().equals(typeName)) {
				return type;
			}
		}
		return STRING;
	}

}

/*--------------------------------------------------------------------------+
   $Id: StronglyConnectedComponentClusterer.java 23498 2009-08-07 16:13:56Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.cluster;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.graph.algo.StrongConnectivity;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphInnerNode;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphUtils;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;

/**
 * Divide the graph into strongly connected components.
 * 
 * @author Florian Deissenboeck
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23498 $
 * @levd.rating GREEN Hash: E62827FB0A9F5973457CF58FC0E05040
 */
@AConQATProcessor(description = "Divides the graph into strongly connected components. "
		+ "Strongly connected components are the maximal sets of vertices such that in "
		+ "each such set there is a (directed) path between every two vertices.")
public class StronglyConnectedComponentClusterer extends
		ConQATPipelineProcessorBase<ConQATGraph> {

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) throws ConQATException {

		ConQATGraphUtils.collapseHierarchy(graph);
		StrongConnectivity conn = new StrongConnectivity(graph);

		List<ConQATGraphInnerNode> clusterNodes = new ArrayList<ConQATGraphInnerNode>();
		for (int i = 0; i < conn.getNumComponents(); ++i) {
			clusterNodes.add(graph.createChildNode("Cluster " + i, "Cluster "
					+ i));
		}

		for (ConQATVertex vertex : graph.getVertices()) {
			int componentIndex = conn.getComponent(vertex);
			vertex.relocate(clusterNodes.get(componentIndex));
		}
	}
}

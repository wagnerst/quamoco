/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: RootValuesProcessor.java 24784 2009-11-18 10:02:11Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.statistics;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 24784 $
 * @levd.rating YELLOW Hash: 7CEE7D4213B7ECEF596DE09E9FEFA27F
 */
@AConQATProcessor(description = "Creates a KeyedData object from the keys and values stored in the "
		+ "display list of the root node. This KeyedData object can e.g. be used to create a pie chart.")
public class RootValuesProcessor extends ConQATProcessorBase {

	/** Input root node */
	private IConQATNode root;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IConQATNode root) {
		this.root = root;
	}

	/** {@inheritDoc} */
	public KeyedData<String> process() throws ConQATException {
		KeyedData<String> result = new KeyedData<String>();

		for (String key : NodeUtils.getDisplayList(root)) {
			Object value = root.getValue(key);
			try {
				Double numericValue = Double.parseDouble(value.toString());
				result.add(key, numericValue);
			} catch (NumberFormatException e) {
				throw new ConQATException("Cannot convert value" + value
						+ " stored in key " + key + " into a number: ", e);
			}
		}

		return result;
	}

}

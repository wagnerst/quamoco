/*--------------------------------------------------------------------------+
   $Id: TokenNormalizationFactory.java 24258 2009-09-18 10:25:23Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization;

import edu.tum.cs.conqat.clonedetective.core.TokenUnit;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IUnitProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.TokenNormalization;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * Creates a {@link TokenNormalization}.
 * <p>
 * Sentinels are inserted between tokens from different files.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 24258 $
 * @levd.rating GREEN Hash: 1F771C4C5FD462FA1F82EA74FDF3D7D1
 */
@AConQATProcessor(description = "Creates a TokenNormalization")
public class TokenNormalizationFactory extends
		TokenBasedNormalizationFactoryBase {

	/** {@inheritDoc} */
	public IUnitProvider<ISourceCodeElement, TokenUnit> process() {
		return new TokenNormalization(tokenProvider, configurationList,
				defaultConfiguration, debugFileExtension);
	}

}

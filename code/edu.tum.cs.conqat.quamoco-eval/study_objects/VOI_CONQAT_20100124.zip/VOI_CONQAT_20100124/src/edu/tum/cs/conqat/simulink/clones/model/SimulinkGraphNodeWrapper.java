package edu.tum.cs.conqat.simulink.clones.model;

import java.util.Collection;
import java.util.HashSet;
import java.util.regex.Pattern;

import edu.tum.cs.conqat.model_clones.label.CanonicalLabelCreator;
import edu.tum.cs.conqat.model_clones.model.IDirectedEdge;
import edu.tum.cs.conqat.model_clones.model.INode;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * Represents a subsystem node.
 * 
 * @author qx90518
 * 
 */
public class SimulinkGraphNodeWrapper implements ISimulinkNode {

	/** The simulink subsystem block */
	private SimulinkBlock block;

	/** The underlying subsystem */
	private SimulinkModelGraph graph;

	/** A subsystem's equivalence class */
	private String equivalenceClass;

	/** The pattern for subsystem equivalence classes */
	private static final Pattern subSysEquivalencePattern = Pattern
			.compile("[^\\s]*/|_([^\\s^\\d]+)[\\d]*");

	/**
	 * Creates a new Sim
	 * 
	 * @param block
	 * @param graph
	 */
	SimulinkGraphNodeWrapper(SimulinkBlock block, SimulinkModelGraph graph) {
		this.block = block;
		this.graph = graph;
		equivalenceClass = block.getName();
	}

	/**
	 * Builds the equivalence class String for this subsystem block that
	 * contains information about the underlying blocks.
	 * 
	 */
	public void updateEquivalenceClass() {
		equivalenceClass = "SubSys "
				+ CanonicalLabelCreator.getCanonicalLabel(graph.getNodes(),
						graph.getEdges()).hashCode();
	}

	public SimulinkBlock getBlock() {
		return block;
	}

	/**
	 * Returns this subsystems equivalence class (based on the subsystem's name)
	 * 
	 */
	public String getEquivalenceClassLabel() {
		return equivalenceClass;
	}

	public int getWeight() {
		return graph.getWeight();
	}

	public void addNode(ISimulinkNode node) {
		graph.addNode(node);
	}

	public void addEdge(SimulinkDirectedEdge edge) {
		graph.addEdge(edge);
	}

	public String toString() {
		return "Subsystem Node Wrapper representing block: " + block;
	}

	public Collection<ISimulinkNode> getNodes() {
		Collection<ISimulinkNode> nodes = new HashSet<ISimulinkNode>();
		for (INode node : graph.getNodes()) {
			nodes.add((ISimulinkNode) node);
		}

		return nodes;
	}

	public Collection<IDirectedEdge> getEdges() {
		return graph.getEdges();
	}

	/**
	 * Returns the total number of nodes within this subsystem.
	 * 
	 * @return
	 */
	public int nodeSize() {
		int result = 0;
		for (INode node : graph.getNodes()) {
			result += node.nodeSize();
		}
		return result;
	}

}

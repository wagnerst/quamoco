package edu.tum.cs.conqat.simulink.clones.model;

import edu.tum.cs.commons.visitor.IVisitor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.simulink.model.SimulinkBlock;

public interface IBacktrackVisitor extends IVisitor<SimulinkBlock, ConQATException> {
	/** Informs the visitor that all children of a node have been visited */
	void backtrack();
}

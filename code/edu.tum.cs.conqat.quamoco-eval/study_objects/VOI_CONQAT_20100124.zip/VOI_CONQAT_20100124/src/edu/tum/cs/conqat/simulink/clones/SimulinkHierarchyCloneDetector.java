package edu.tum.cs.conqat.simulink.clones;

import java.util.Collection;
import java.util.List;

import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.model_clones.detection.util.ICloneReporter;
import edu.tum.cs.conqat.model_clones.model.IDirectedEdge;
import edu.tum.cs.conqat.model_clones.model.IModelGraph;
import edu.tum.cs.conqat.model_clones.model.INode;
import edu.tum.cs.conqat.simulink.clones.model.SimulinkHierarchyGraphCreator;
import edu.tum.cs.conqat.simulink.clones.model.SimulinkModelGraph;

/**
 * Clone detector for Simulink models using a hierarchical representation for models and filters cloned subsystems.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23502 $
 * @levd.rating GREEN Hash: CC23C30670ECD575E994DDB4E19F864A
 */
@AConQATProcessor(description = "Performs clone detection on hierarchical simulink models.")
public class SimulinkHierarchyCloneDetector extends SimulinkCloneDetector implements
		ICloneReporter { 

	public static final int MIN_SUBSYS_WEIGHT = 10;
	public static final int MIN_SUBSYS_NODESIZE = 10;

	/**
	 * Causes cloned subsystems to be reported.
	 */
	protected void postDetectionHook() {		
		reportDuplicatedSubsystems(SimulinkHierarchyGraphCreator.getSubsystemClones());
	}

	/** {@inheritDoc} */
	protected SimulinkModelGraph createModelGraph() throws ConQATException {		
		return SimulinkHierarchyGraphCreator.createModelGraph(input, normalizer);
	}
	
	
	private void reportDuplicatedSubsystems(
			Collection<Collection<IModelGraph>> subsystemClones) {
		GroupLoop: for (Collection<IModelGraph> cloneGroup : subsystemClones) {
			boolean first = true;
			for (IModelGraph clone : cloneGroup) {
				@SuppressWarnings("unchecked")
				List<INode> nodes  = (List) clone.getNodes();
				@SuppressWarnings("unchecked")
				List<IDirectedEdge> edges  = (List) clone.getEdges();
				
				if (first) {
					int weight = 0;
					int nodeCount = 0;
					for (INode node : nodes) {
						weight += node.getWeight();
						nodeCount += node.nodeSize();
					}
					if (weight < MIN_SUBSYS_WEIGHT || nodeCount < MIN_SUBSYS_NODESIZE) continue GroupLoop;
					first = false;
					reporter.startModelCloneClass(cloneGroup.size(), nodes.size(), edges.size());
				}
				//subsystems only have in- and outports that do not count as interface size
				reporter.addModelCloneInstance(nodes, edges, 1);
			}
			
		}
		reporter.finishTransmission();
	}
}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: PairReportGeneratorBase.java 24258 2009-09-18 10:25:23Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IdProvider;

/**
 * Base class for classes that generate reports containing clone pairs.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 24258 $
 * @levd.rating YELLOW Hash: 6B233D86E779EB46BE48FF18D7AED0F4
 */
public abstract class PairReportGeneratorBase {

	/** Id provider used to create new clone class ids */
	protected final IdProvider idProvider = new IdProvider();

	/** Create paired {@link CloneClass}es */
	public List<CloneClass> createDetectionResult(List<CloneClass> cloneClasses) {
		List<CloneClass> pairClasses = new ArrayList<CloneClass>();

		for (CloneClass cloneClass : cloneClasses) {
			pairClasses.addAll(createPairClasses(cloneClass));
		}

		return new ArrayList<CloneClass>(pairClasses);
	}

	/** Create pair clone classes for all clones in a clone class */
	private List<CloneClass> createPairClasses(CloneClass cloneClass) {
		List<CloneClass> pairClasses = new ArrayList<CloneClass>();
		for (ImmutablePair<Clone, Clone> clonePair : computeUnorderedPairs(cloneClass
				.getClones())) {
			pairClasses.addAll(createPairClasses(clonePair));
		}

		return pairClasses;
	}

	/**
	 * Template method that deriving classes override to implement pair creation
	 */
	protected abstract Collection<? extends CloneClass> createPairClasses(
			ImmutablePair<Clone, Clone> clonePair);

	// TODO (EJ) Move into commons?
	/** Compute list of unordered pairs */
	private List<ImmutablePair<Clone, Clone>> computeUnorderedPairs(
			Collection<Clone> cloneCollection) {
		List<Clone> clones = new ArrayList<Clone>(cloneCollection);
		List<ImmutablePair<Clone, Clone>> pairs = new ArrayList<ImmutablePair<Clone, Clone>>();
		int size = clones.size();
		for (int firstIndex = 0; firstIndex < size; firstIndex++) {
			for (int secondIndex = firstIndex + 1; secondIndex < size; secondIndex++) {
				Clone first = clones.get(firstIndex);
				Clone second = clones.get(secondIndex);
				ImmutablePair<Clone, Clone> pair = new ImmutablePair<Clone, Clone>(
						first, second);
				pairs.add(pair);
			}
		}
		return pairs;
	}

}
/*--------------------------------------------------------------------------+
   $Id: SimulinkDirectedEdge.java 25242 2010-01-21 14:57:24Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.clones.model;

import edu.tum.cs.conqat.model_clones.model.IDirectedEdge;
import edu.tum.cs.conqat.model_clones.model.INode;
import edu.tum.cs.simulink.model.SimulinkLine;

/**
 * Implementation of the {@link IDirectedEdge} interface for Simulink.
 * 
 * @author hummelb
 * @author $Author:hummelb $
 * @version $Rev: 25242 $
 * @levd.rating GREEN Hash: B54236E217CB895B5E9FE05B639E0DE4
 */
public class SimulinkDirectedEdge implements IDirectedEdge {

	/** The corresponding simulink line. */
	private final SimulinkLine line;

	/** The normalized representation. */
	private final String normalized;

	/** The source node. */
	private final ISimulinkNode source;

	/** The target node. */
	private final ISimulinkNode target;

		/** Constructor. */
	/* package */SimulinkDirectedEdge(SimulinkLine line, String normalized,
			ISimulinkNode source, ISimulinkNode target) {
		this.line = line;
		this.normalized = source.getEquivalenceClassLabel() + " -> " + target.getEquivalenceClassLabel();
		//if eScan is removed, use: this.normalized = normalized;
		this.source = source;
		this.target = target;
	}

	/** {@inheritDoc} */
	public INode getSourceNode() {
		return source;
	}

	/** {@inheritDoc} */
	public INode getTargetNode() {
		return target;
	}

	/** Returns the line. */
	public SimulinkLine getLine() {
		return line;
	}

	/** {@inheritDoc} */
	public String getEquivalenceClassLabel() {
		return normalized;
	}
	
	
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof SimulinkDirectedEdge)) return false;
		SimulinkDirectedEdge edge = (SimulinkDirectedEdge) o;
		if (edge.getSourceNode() != source) return false;
		if (edge.getTargetNode() != target) return false;
		return true;	
	}
	
	/* this method can be removed if eScan is removed */
	public int hashCode() {
		return source.hashCode() + 31 * target.hashCode() + 17;
	}
	
	/* this method can be removed if eScan is removed */
	public String toString() {		
		return normalized;
	}
}

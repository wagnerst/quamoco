/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingFormat.java 24355 2009-10-01 12:09:19Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.format;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableSet;
import edu.tum.cs.commons.string.StringUtils;

/**
 * A finding format is basically just a set of entries and supports additional
 * convenience method for (de)serialization.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 24355 $
 * @levd.rating YELLOW Hash: 880975707FD743C7C59FBCEB9F0D288C
 */
public class FindingFormat {

	/** The entries. */
	private final Set<FindingFormatEntry> entries = new HashSet<FindingFormatEntry>();

	/** Constructor. */
	public FindingFormat(FindingFormatEntry... entries) {
		this.entries.addAll(Arrays.asList(entries));
	}

	/** Constructor for deserialization. */
	public FindingFormat(String serialized) {
		for (String format : serialized.split("[,;]+")) {
			entries.add(new FindingFormatEntry(format));
		}
	}

	/** Returns the entries. */
	public UnmodifiableSet<FindingFormatEntry> getEntries() {
		return CollectionUtils.asUnmodifiable(entries);
	}

	/** Adds an entry. */
	public void addEntry(FindingFormatEntry entry) {
		entries.add(entry);
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return StringUtils.concat(entries, ",");
	}
}

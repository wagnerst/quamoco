/*--------------------------------------------------------------------------+
   $Id: SimulinkUtils.java 25235 2010-01-21 10:51:35Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.util;

import edu.tum.cs.conqat.commons.findings.EFindingKeys;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.location.FileLocation;
import edu.tum.cs.conqat.commons.findings.location.QualifiedNameLocation;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;

/**
 * Utility method for the Simulink bundle.
 * 
 * @author deissenb
 * @author $Author: hummelb $
 * @version $Rev: 25235 $
 * @levd.rating GREEN Hash: 0223B2A1E6706EF34E9C987604E31918
 */
public class SimulinkUtils {
	/**
	 * Create a finding and attach it to a {@link IFileSystemElement}
	 * 
	 * @param group
	 *            the finding group the finding belongs to
	 * @param originTool
	 *            the class that best describes the creating tool.
	 * @param message
	 *            the message
	 * @param model
	 *            the affected model element
	 * @param id
	 *            the qualified name of the affected element, e.g. a Simulink
	 *            block
	 * @param key
	 *            the key used to store the finding
	 * @return the created finding
	 */
	public static Finding createAndAttachFinding(FindingGroup group,
			Class<?> originTool, String message, SimulinkModelElement model,
			String id, String key) {

		Finding finding = group.createFinding(originTool.getSimpleName());
		finding.setValue(EFindingKeys.MESSAGE.toString(), message);
		finding.addLocation(new QualifiedNameLocation(id));
		finding.addLocation(new FileLocation(model.getFile()));
		NodeUtils.getOrCreateFindingsList(model, key).add(finding);

		return finding;
	}
}

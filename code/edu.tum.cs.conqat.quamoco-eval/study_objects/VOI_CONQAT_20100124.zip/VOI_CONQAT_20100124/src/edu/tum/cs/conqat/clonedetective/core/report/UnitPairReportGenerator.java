/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: UnitPairReportGenerator.java 23748 2009-08-25 11:36:20Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;

/**
 * Generates a clone detection result that contains a clone pair for each pair
 * of cloned statements in an input report. This can be useful for tailoring.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 23748 $
 * @levd.rating YELLOW Hash: 193947398E23C30ED8E44CA607142CF2
 */
public class UnitPairReportGenerator extends PairReportGeneratorBase {

	/** Create pair clone classes for the statements between two clones */
	@Override
	protected Set<CloneClass> createPairClasses(
			ImmutablePair<Clone, Clone> clonePair) {

		Clone first = clonePair.getFirst();
		Clone second = clonePair.getSecond();
		CCSMAssert.isTrue(
				first.getLengthInUnits() == second.getLengthInUnits(),
				"Clones must have same number of units. CloneClass id:"
						+ first.getCloneClass().getId() + ", Clone ids: "
						+ first.getId() + ", " + second.getId());

		LinkedHashSet<CloneClass> pairClasses = new LinkedHashSet<CloneClass>();
		for (int unitIndex = 0; unitIndex < first.getLengthInUnits(); unitIndex++) {
			CloneClass pairClass = new CloneClass(1, idProvider.provideId());
			createUnitClone(first, unitIndex, pairClass);
			createUnitClone(second, unitIndex, pairClass);
			pairClasses.add(pairClass);
		}

		return pairClasses;
	}

	/** Create a clone covering exactly one unit of a larger clone */
	private Clone createUnitClone(Clone containingClone, int unitIndex,
			CloneClass cloneClass) {

		List<Unit> units = CloneUtils.getUnits(containingClone);
		CCSMAssert.isNotNull(units, "Must store units");

		Unit unit = units.get(unitIndex);

		int startLineInFile = unit.getStartLineInFile();
		int lengthInFile = unit.getCoveredLines();
		int lengthInUnits = 1;
		int startUnitIndexInFile = containingClone.getStartUnitIndexInFile()
				+ unitIndex;

		// we create an artificial fingerprint that is equal for all clones of
		// the clone class.
		String fingerprint = "Fingerprint" + cloneClass.getId();

		Clone clone = new Clone(idProvider.provideId(), cloneClass,
				containingClone.getFile(), startLineInFile, lengthInFile,
				startUnitIndexInFile, lengthInUnits, fingerprint);
		cloneClass.add(clone);

		return clone;
	}

}

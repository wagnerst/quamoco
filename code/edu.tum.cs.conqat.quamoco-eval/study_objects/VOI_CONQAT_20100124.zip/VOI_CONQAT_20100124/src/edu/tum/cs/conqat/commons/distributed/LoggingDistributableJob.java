/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: LoggingDistributableJob.java 24572 2009-10-23 21:57:52Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.distributed;

import java.io.Serializable;

import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.distributed.IDistributableJob;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * A distributable job which handles errors by logging.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 24572 $
 * @levd.rating YELLOW Hash: F04A965D884CA92D2E28A852E54E7653
 */
public abstract class LoggingDistributableJob<T extends LoggingDistributableJob.RunnableWithResult>
		implements IDistributableJob<T> {

	/** The logger. */
	protected final IConQATLogger logger;

	/** Constructor. */
	protected LoggingDistributableJob(IConQATLogger logger) {
		this.logger = logger;
	}

	/** {@inheritDoc} */
	public void processRemoteResult(T resultRunnable) {
		Object result = resultRunnable.result;
		if (result instanceof ConQATException) {
			logger.warn(((ConQATException) result).getMessage());
		} else if (result instanceof Throwable) {
			Throwable e = (Throwable) result;
			logger.error(e.getMessage(), e);
		} else {
			processResult(result);
		}
	}

	/** Template method for processing the result from the remote runnable. */
	protected abstract void processResult(Object result);

	/** A runnable which returns a single result. */
	public static abstract class RunnableWithResult implements Runnable,
			Serializable {

		/** The variable to store the result in. */
		protected Object result;

		/** {@inheritDoc} */
		public void run() {
			try {
				result = calculateResult();
			} catch (Throwable t) {
				result = t;
			}
		}

		/** Template method for calculating the result. */
		protected abstract Object calculateResult() throws Exception;
	}

}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: ContentCountConstraint.java 25219 2010-01-12 13:52:58Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import java.util.regex.Pattern;

import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 25219 $
 * @levd.rating RED Hash: FBBFF7774B2B603684EFB19D670C9797
 */
@AConQATProcessor(description = "Constraint that is satisfied if at least one pattern matches "
		+ "in at least one clone for a specified number of times.")
public class ContentCountConstraint extends ContentConstraint {

	/** Minimal number of matches threshold */
	private int minMatches;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "min", description = "Number of required matches for the constraint to be satisfied", minOccurrences = 1, maxOccurrences = 1)
	public void setMinMatches(
			@AConQATAttribute(name = "matches", description = "Number must be > 1") int minMatches)
			throws ConQATException {
		if (minMatches <= 1) {
			throw new ConQATException("minMatches must be > 1 bug was: "
					+ minMatches);
		}
		this.minMatches = minMatches;
	}

	/** {@inheritDoc} */
	@Override
	public boolean satisfied(CloneClass cloneClass) throws ConQATException {
		for (Clone clone : cloneClass.getClones()) {
			String code = CloneUtils.getCloneContent(clone);
			for (Pattern pattern : patterns) {
				int matches = 0;
				while (pattern.matcher(code).find()) {
					matches++;
				}

				if (matches >= minMatches) {
					return true;
				}
			}
		}

		return false;
	}

}

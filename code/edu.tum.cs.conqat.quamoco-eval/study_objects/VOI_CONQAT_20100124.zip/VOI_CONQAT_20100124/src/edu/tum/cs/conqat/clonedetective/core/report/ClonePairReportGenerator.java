/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: ClonePairReportGenerator.java 24258 2009-09-18 10:25:23Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.util.Collection;
import java.util.Set;

import edu.tum.cs.commons.collections.IdentityHashSet;
import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;

/**
 * Creates reports containing pairs of clone classes
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 24258 $
 * @levd.rating RED Hash: 6147D18A0419583A5DF364C35BCF208B
 */
public class ClonePairReportGenerator extends PairReportGeneratorBase {

	/** {@inheritDoc} */
	@Override
	protected Collection<CloneClass> createPairClasses(
			ImmutablePair<Clone, Clone> clonePair) {

		CloneClass cloneClass = new CloneClass(clonePair.getFirst()
				.getCloneClass().getNormalizedLength(), idProvider.provideId());
		copyClone(clonePair.getFirst(), cloneClass);
		copyClone(clonePair.getSecond(), cloneClass);

		Set<CloneClass> set = new IdentityHashSet<CloneClass>();
		set.add(cloneClass);

		return set;
	}

	/**
	 * Create a copy of a clone with a fresh id
	 * 
	 * @param cloneClass
	 *            {@link CloneClass} to which new clone gets added
	 */
	private Clone copyClone(Clone clone, CloneClass cloneClass) {
		String fingerPrint = "Fingerprint" + cloneClass.getId();
		Clone copy = new Clone(idProvider.provideId(), cloneClass, clone
				.getFile(), clone.getStartLineInFile(),
				clone.getLengthInFile(), clone.getStartUnitIndexInFile(), clone
						.getLengthInUnits(), fingerPrint, clone
						.getDeltaInUnits());
		copy.setBirth(clone.getBirth());
		if (CloneUtils.getUnits(clone) != null) {
			CloneUtils.setUnits(copy, CloneUtils.getUnits(clone));
		}
		cloneClass.add(copy);
		return copy;
	}
}

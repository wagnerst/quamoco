/*--------------------------------------------------------------------------+
   $Id: SVNRevisionComparator.java 23502 2009-08-07 16:17:34Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.svn;

import java.util.Comparator;

import edu.tum.cs.commons.clone.IDeepCloneable;

/**
 * Comparator for {@link SVNLogEntryNode}s based on their revision.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23502 $
 * @levd.rating GREEN Hash: DAA11F3FC5E9B53485D2929F5ECF2D18
 */
public class SVNRevisionComparator implements Comparator<SVNLogEntryNode>,
		IDeepCloneable {

	/** The single instance. */
	private static final SVNRevisionComparator instance = new SVNRevisionComparator();

	/** Private constructor to avoid instantiation. */
	private SVNRevisionComparator() {
		// nothing to do.
	}

	/** Returns the only instance of this comparator. */
	public static SVNRevisionComparator getInstance() {
		return instance;
	}

	/** @inheritDoc */
	public int compare(SVNLogEntryNode node1, SVNLogEntryNode node2) {
		return Long.signum(node2.getRevision() - node1.getRevision());
	}

	/** Do not clone. */
	public SVNRevisionComparator deepClone() {
		return instance;
	}
}

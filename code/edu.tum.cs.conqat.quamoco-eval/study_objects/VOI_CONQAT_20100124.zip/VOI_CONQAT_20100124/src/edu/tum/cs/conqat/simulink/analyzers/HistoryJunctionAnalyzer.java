/*--------------------------------------------------------------------------+
   $Id: HistoryJunctionAnalyzer.java 23502 2009-08-07 16:17:34Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkConstants;
import edu.tum.cs.simulink.model.stateflow.StateflowJunction;
import edu.tum.cs.simulink.util.SimulinkUtils;

/**
 * This processor checks if a model contains history junctions. Models with such
 * junctions are rated RED others GREEN.
 * 
 * @author deissenb
 * @author $Author: deissenb $
 * @version $Rev: 23502 $
 * @levd.rating GREEN Hash: DCCF9A0FB7788D61555B670DA9FCD716
 */
@AConQATProcessor(description = "This processor checks if a model contains "
		+ "history junctions. Models with such junctions are rated RED others "
		+ "GREEN.")
public class HistoryJunctionAnalyzer extends StateflowAnalyzerBase {

	/** Key for assessment. */
	@AConQATKey(description = "Key for assessment", type = "edu.tum.cs.commons.assessment.Assessment")
	public static final String ASSESSMENT_KEY = "HistoryJunctionAssessment";

	/** Key for messages. */
	@AConQATKey(description = "Key for messages", type = "edu.tum.cs.commons.collections.HashedListMap<String, String>")
	public static final String MESSAGES_KEY = "HistoryJunctionMessage";

	/** Constant for junction type. */
	private static String HISTORY_JUNCTION_TYPE = "HISTORY_JUNCTION";

	/** Add key to display list. */
	@Override
	protected void setUp(ISimulinkElement root) {
		NodeUtils.addToDisplayList(root, ASSESSMENT_KEY, MESSAGES_KEY);
	}

	/** Optimistically rate model green. */
	@Override
	protected void setUpModel(SimulinkModelElement modelNode) {
		modelNode.setValue(ASSESSMENT_KEY, new Assessment(
				ETrafficLightColor.GREEN));
	}

	/** Checks if a junctions is a history junction. */
	@Override
	protected void analyzeJunction(StateflowJunction junction,
			SimulinkModelElement modelNode) throws ConQATException {

		String type = junction.getParameter(SimulinkConstants.PARAM_type);

		if (type == null) {
			getLogger().warn(
					"Model " + modelNode.getId()
							+ " contains junction without " + type);
			return;
		}

		if (HISTORY_JUNCTION_TYPE.equals(type)) {
			String id = SimulinkUtils.getBlock(junction).getId();

			NodeUtils.addMessage(modelNode, MESSAGES_KEY, id,
					"Prohibited type '" + type + "'.");
			modelNode.setValue(ASSESSMENT_KEY, new Assessment(
					ETrafficLightColor.RED));
		}
	}
}

/*--------------------------------------------------------------------------+
   $Id: SimulinkElement.java 23867 2009-08-28 10:37:11Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.scope;

import java.nio.charset.Charset;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.FileSystemElement;

/**
 * Basic implementation for {@link ISimulinkElement} based on
 * {@link FileSystemElement}.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23867 $
 * @levd.rating GREEN Hash: 200B8E27901DDB08B64C7A959738008F
 */
public class SimulinkElement extends FileSystemElement implements
		ISimulinkElement {

	/**
	 * Constructor.
	 * 
	 * @throws ConQATException
	 *             if name could not be canonicalized
	 */
	protected SimulinkElement(String name, Charset encoding)
			throws ConQATException {
		super(name, encoding);
	}

	/** Copy constructor. */
	protected SimulinkElement(SimulinkElement element)
			throws DeepCloneException {
		super(element);
	}

	/** {@inheritDoc} */
	@Override
	public SimulinkElement[] getChildren() {
		return (SimulinkElement[]) super.getChildren();
	}

	/** {@inheritDoc} */
	@Override
	protected SimulinkElement[] allocateArray(int size) {
		return new SimulinkElement[size];
	}

	/** {@inheritDoc} */
	@Override
	public SimulinkElement deepClone() throws DeepCloneException {
		return new SimulinkElement(this);
	}
}

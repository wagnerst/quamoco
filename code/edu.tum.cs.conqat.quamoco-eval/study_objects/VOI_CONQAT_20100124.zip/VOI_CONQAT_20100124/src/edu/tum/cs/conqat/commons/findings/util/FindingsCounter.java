/*--------------------------------------------------------------------------+
   $Id: FindingsCounter.java 23924 2009-08-31 15:02:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.util;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23924 $
 * @levd.rating GREEN Hash: 9E434F214A59D9AB601A8B52744A9858
 */
@AConQATProcessor(description = ""
		+ "This processor counts the number of findings in a ConQAT node structure. "
		+ "Findings are counted both within the nodes and in finding lists "
		+ "stored in given keys. This way in can be used both for plain nodes as "
		+ "well as finding reports. The result is stored at the root.")
public class FindingsCounter extends NodeTraversingProcessorBase<IConQATNode> {

	/** The key to store the result in. */
	@AConQATKey(description = "The number of findings found.", type = "java.lang.Integer")
	public static final String KEY = "#findings";

	/** The number of findings found. */
	private int count = 0;

	/**
	 * Determines whether the display list should be included for the inspected
	 * keys.
	 */
	private boolean useDisplayList = true;

	/** The keys to look in for findings. */
	private final Set<String> keys = new HashSet<String>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "findings", description = "If keys are given, all findings stored at these keys are counted as well.")
	public void addKey(
			@AConQATAttribute(name = "key", description = "The key to look into.") String key) {
		keys.add(key);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "use-display-list", maxOccurrences = 1, description = "If this is set to true, all keys in the display list will be inspected for findings. Default is true.")
	public void setUseDisplayList(
			@AConQATAttribute(name = "value", description = "True or false.") boolean value) {
		useDisplayList = value;
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.ALL;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		if (useDisplayList) {
			keys.addAll(NodeUtils.getDisplayList(root));
		}
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) {
		if (node instanceof Finding) {
			++count;
		}
		for (String key : keys) {
			Object value = node.getValue(key);
			if (value instanceof Finding) {
				++count;
			} else if (value instanceof Collection) {
				for (Object o : (Collection<?>) value) {
					if (o instanceof Finding) {
						++count;
					}
				}
			}
		}
	}

	/** {@inheritDoc} */
	@Override
	protected void finish(IConQATNode root) {
		root.setValue(KEY, count);
	}
}

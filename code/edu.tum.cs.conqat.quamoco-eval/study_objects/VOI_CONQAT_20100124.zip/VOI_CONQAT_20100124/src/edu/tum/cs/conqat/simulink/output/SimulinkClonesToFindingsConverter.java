/*--------------------------------------------------------------------------+
   $Id: SimulinkClonesToFindingsConverter.java 24356 2009-10-01 12:39:58Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.output;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.findings.EFindingKeys;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingCategory;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.format.EFindingFormatType;
import edu.tum.cs.conqat.commons.findings.format.FindingFormat;
import edu.tum.cs.conqat.commons.findings.format.FindingFormatEntry;
import edu.tum.cs.conqat.commons.findings.location.QualifiedNameLocation;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.simulink.clones.SimulinkCloneDetector;
import edu.tum.cs.conqat.simulink.clones.result.SimulinkClone;
import edu.tum.cs.conqat.simulink.clones.result.SimulinkCloneResultNode;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 24356 $
 * @levd.rating YELLOW Hash: 297CBB7B996AC5FE611E4493970192F8
 */
@AConQATProcessor(description = "Processor for converting a Simulink clone result to a finding report.")
public class SimulinkClonesToFindingsConverter extends ConQATProcessorBase {

	/** The clones */
	private SimulinkCloneResultNode cloneResult;

	/** The category to add to. */
	private FindingCategory category;

	/** Counter for the clone groups. */
	private int numGroups = 0;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = "The simulink clone result.")
	public void setCloneResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) SimulinkCloneResultNode cloneResult) {
		this.cloneResult = cloneResult;
	}

	/** {@inheritDoc} */
	public FindingReport process() {
		FindingReport report = new FindingReport();
		category = report.getOrCreateCategory("Simulink Clones");
		for (SimulinkClone clone : cloneResult.getChildren()) {
			convertClone(clone);
		}
		return report;
	}

	/** Converts a clone to a finding group. */
	private void convertClone(SimulinkClone clone) {
		FindingGroup group = category.createFindingGroup("Clone Group "
				+ ++numGroups);
		for (UnmodifiableList<SimulinkBlock> blocks : clone.getBlockLists()) {
			Finding finding = group
					.createFinding("ConQAT Model Clone Detective");
			for (SimulinkBlock block : blocks) {
				finding.addLocation(new QualifiedNameLocation(block.getId()));
			}
		}

		FindingFormat format = new FindingFormat();
		copyKey(clone, group, format, SimulinkCloneDetector.SIZE_KEY,
				EFindingFormatType.INT);
		copyKey(clone, group, format, SimulinkCloneDetector.VOLUME_KEY,
				EFindingFormatType.INT);

		group.setValue(EFindingKeys.FORMAT.name(), format);
	}

	/** Copies a given key from the clone to the finding group. */
	private void copyKey(SimulinkClone clone, FindingGroup group,
			FindingFormat format, String key, EFindingFormatType type) {
		String findingKey = "clone_" + key;
		group.setValue(findingKey, clone.getValue(key));
		format.addEntry(new FindingFormatEntry(findingKey, type));
	}
}

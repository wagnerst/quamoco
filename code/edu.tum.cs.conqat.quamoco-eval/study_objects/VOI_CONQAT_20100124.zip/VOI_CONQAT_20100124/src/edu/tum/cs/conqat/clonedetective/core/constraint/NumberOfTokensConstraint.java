/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: NumberOfTokensConstraint.java 24258 2009-09-18 10:25:23Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.StatementUnit;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 24258 $
 * @levd.rating RED Hash: B74F68B214F5BA9A2A52F0F44B8FD858
 */
@AConQATProcessor(description = "Constraint that is satisfied if the statements of a clone contain at least a "
		// TODO (BH): The double negation (not applicable ... that are not ...)
		// might be confusing.
		+ "minimal number of tokens. Not applicable to clones that are not formed from "
		+ "statements. Only applicable if units are stored.")
public class NumberOfTokensConstraint extends ConstraintBase {

	/** Unknown value */
	private static final int UNKNOWN = -1;

	/** Minimal length in tokens */
	// TODO (BH): Why this UNKNOWN stuff? Why not just make the parameter below
	// required? Deactivation should be performed by removing the processor or
	// the link!
	private int minTokens = UNKNOWN;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "min", minOccurrences = 0, maxOccurrences = 1, description = "Minimal number of tokens")
	public void setMinLength(
			@AConQATAttribute(name = "tokens", description = "If not set, constraint is deactivated") int minTokens) {
		this.minTokens = minTokens;
	}

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) throws ConQATException {
		if (minTokens == UNKNOWN) {
			return true;
		}

		// TODO (BH): You should explain this behavior better in the processor
		// doc, i.e. that the max. num of tokens is compared.
		int maxTokens = 0;
		for (Clone clone : cloneClass.getClones()) {
			maxTokens = Math.max(numberOfTokens(clone), maxTokens);
		}

		return maxTokens >= minTokens;
	}

	/** Determines the number of tokens stored in the statements of a clone */
	@SuppressWarnings("unchecked")
	private int numberOfTokens(Clone clone) throws ConQATException {
		List<? extends Unit> units = CloneUtils.getUnits(clone);
		checkPreconditions(units);

		List<StatementUnit> statements = (List<StatementUnit>) units;
		int tokenCount = 0;
		for (StatementUnit statement : statements) {
			tokenCount += statement.getTokens().length;
		}

		return tokenCount;
	}

	/**
	 * Throws a ConQATException if the constraints usage conditions are not
	 * satisfied
	 */
	private void checkPreconditions(List<? extends Unit> units)
			throws ConQATException {
		String pleaseCheckConfig = "Please check your clone detection configuration.";
		if (units == null) {
			throw new ConQATException(
					"This constraint can only be used if the units are stored. "
							+ pleaseCheckConfig);
		}

		if (!(units.get(0) instanceof StatementUnit)) {
			throw new ConQATException(
					"This constraint can only be used on statement units. "
							+ pleaseCheckConfig);
		}
	}

}

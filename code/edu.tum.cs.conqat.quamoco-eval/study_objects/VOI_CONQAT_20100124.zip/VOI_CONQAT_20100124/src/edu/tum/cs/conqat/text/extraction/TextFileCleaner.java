/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.text
 |                                                                       |
   $Id: TextFileCleaner.java 24040 2009-09-04 10:05:00Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.extraction;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.analysis.FileAnalyzerBase;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 24040 $
 * @levd.rating RED Hash: 7FAA28599C8869D641BA716E2AECBF37
 */
@AConQATProcessor(description = "Removes certain unreadable characters from a text file")
public class TextFileCleaner extends FileAnalyzerBase<IFileSystemElement> {

	/** Set of characters that get removed */
	private final Set<Character> remove = new HashSet<Character>(Arrays
			.asList(new Character[] { '�', '�', '�', '�' }));

	/** Counts number of characters this processor removed */
	int removedChars = 0;

	/** {@inheritDoc} */
	@Override
	protected void analyzeFile(IFileSystemElement element) {
		try {
			String content = FileLibrary.getInstance().getContent(element);

			String cleanContent = clean(content);

			FileSystemUtils.writeFile(element.getFile(), cleanContent);
		} catch (ConQATException e) {
			getLogger().error("Could not read file: ", e);
		} catch (IOException e) {
			getLogger().error("Could not write file: ", e);
		}
	}

	// TODO (EJ) Move into StringUtils?
	/** Removes all undesired characters from the string */
	private String clean(String content) {
		StringBuilder result = new StringBuilder(content.length());
		for (int i = 0; i < content.length(); i++) {
			char c = content.charAt(i);
			if (!isRemove(c)) {
				result.append(c);
			} else {
				removedChars++;
			}
		}
		String cleanContent = result.toString();
		return cleanContent;
	}

	/** Determines whether a character is to be removed */
	private boolean isRemove(char c) {
		return remove.contains(c) || c < 31 && c != 10 && c != 13 && c != 9;
	}

	/** {@inheritDoc} */
	@Override
	protected String[] getKeys() {
		return new String[] {};
	}

	/** {@inheritDoc} */
	@Override
	protected void finish(IFileSystemElement root) throws ConQATException {
		super.finish(root);

		getLogger().info("Removed " + removedChars + " characters");
	}

}

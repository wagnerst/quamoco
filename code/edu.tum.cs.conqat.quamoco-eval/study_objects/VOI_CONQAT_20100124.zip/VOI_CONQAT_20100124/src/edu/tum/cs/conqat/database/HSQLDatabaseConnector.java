/*--------------------------------------------------------------------------+
   $Id: HSQLDatabaseConnector.java 23494 2009-08-07 16:12:12Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hsqldb.jdbcDriver;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * This processor creates a connection to a file-based HSQLDB database.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23494 $
 * @levd.rating GREEN Hash: EDB437428F207C5BC33436EC3E991D26
 */
@AConQATProcessor(description = "This processor creates a connection "
		+ "to a file-based HSQLDB database.")
public class HSQLDatabaseConnector extends ConQATProcessorBase {

	/** Database file. */
	private String dbFilePath;

	/** Set name of the driver class. */
	@AConQATParameter(name = "file", minOccurrences = 1, maxOccurrences = 1, description = "Database file.")
	public void setFile(
			@AConQATAttribute(name = "path", description = "Path to database file. "
					+ "Use forward slashes here. See "
					+ "http://hsqldb.org/doc/guide/ch01.html#N101B4 "
					+ "for details on path format.")
			String path) {
		dbFilePath = path;
	}

	/** {@inheritDoc} */
	public Connection process() throws ConQATException {

		File dbFile = new File(dbFilePath);

		try {
			FileSystemUtils.ensureParentDirectoryExists(dbFile);
		} catch (IOException e) {
			throw new ConQATException("Could not acces file: " + dbFile);
		}

		try {
			Class.forName(jdbcDriver.class.getName());
		} catch (ClassNotFoundException e) {
			throw new ConQATException("Can't load driver for HSQLDB.");
		}

		try {
			Connection connection = DriverManager.getConnection(
					"jdbc:hsqldb:file:" + dbFilePath + ";shutdown=true", "SA",
					"");
			return connection;
		} catch (SQLException e) {
			throw new ConQATException("Database error: " + e.getMessage());
		}
	}
}

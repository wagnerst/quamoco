/*--------------------------------------------------------------------------+
   $Id: ArchitectureEdgeAssessor.java 24563 2009-10-23 06:43:17Z heineman $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.assessment;

import java.util.ArrayList;
import java.util.Collection;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.architecture.format.EAssessmentType;
import edu.tum.cs.conqat.architecture.format.EStereotype;
import edu.tum.cs.conqat.architecture.scope.ArchitectureDefinition;
import edu.tum.cs.conqat.architecture.scope.ComponentNode;
import edu.tum.cs.conqat.architecture.scope.DependencyPolicy;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author Benjamin Hummel
 * @author Tilman Seifert
 * @author $Author: heineman $
 * @version $Rev: 24563 $
 * @levd.rating YELLOW Hash: B32DCCBCBB745AE5F6E4475BDA8B177B
 */
@AConQATProcessor(description = "This processor assesses the policies of the given "
		+ "architecture according to the dependencies stored there.")
public class ArchitectureEdgeAssessor extends
		ConQATPipelineProcessorBase<ArchitectureDefinition> {

	/** {@inheritDoc} */
	@Override
	protected void processInput(ArchitectureDefinition arch) {
		Collection<DependencyPolicy> policies = new ArrayList<DependencyPolicy>();
		arch.collectPolicies(policies);
		for (DependencyPolicy policy : policies) {
			policy.setAssessment(determineAssessmentType(policy));
		}
	}

	/** Returns a policy's assessments based on the dependencies. */
	private EAssessmentType determineAssessmentType(DependencyPolicy policy) {
		boolean empty = policy.getDependencies().isEmpty();

		switch (policy.getPolicyType()) {
		case ALLOW_EXPLICIT:
		case ALLOW_IMPLICIT:
			if (empty) {
				return EAssessmentType.UNNECESSARY;
			}
			return EAssessmentType.VALID;

		case DENY_IMPLICIT:
		case DENY_EXPLICIT:
			if (empty || isAllowedPublicAccess(policy)) {
				return EAssessmentType.VALID;
			}
			return EAssessmentType.INVALID;

		case TOLERATE_EXPLICIT:
			if (empty) {
				return EAssessmentType.UNNECESSARY;
			}
			for (ImmutablePair<String, String> dependency : policy
					.getDependencies()) {
				if (!policy.tolerated(dependency.getFirst(), dependency
						.getSecond())) {
					return EAssessmentType.INVALID;
				}
			}
			return EAssessmentType.VALID;

		default:
			CCSMAssert.fail("Unknown value: " + policy.getPolicyType());
		}
		return null;
	}

	/**
	 * @return whether this is an allowed access to a public component.
	 */
	private boolean isAllowedPublicAccess(DependencyPolicy policy) {
		ComponentNode source = policy.getSource();
		ComponentNode target = policy.getTarget();
		return (target.getStereotype().equals(EStereotype.PUBLIC) && source
				.getParent().equals(target.getParent()));
	}
}

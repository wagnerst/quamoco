/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: ENormalizationOption.java 24277 2009-09-20 17:42:17Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token.configuration;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Enum constants for configuration of the normalization phase.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 24277 $
 * @levd.rating RED Hash: 65ED9669DA8DBFBAB6DAB6314F3AD849
 */
public enum ENormalizationOption {

	/** option */
	IGNORE_COMMENTS,

	/** option */
	IGNORE_DELIMITERS,

	/** option */
	IGNORE_PREPROCESSOR_DIRECTIVES,

	/** option */
	NORMALIZE_IDENTIFIERS,

	/** option */
	NORMALIZE_FULLY_QUALIFIED_TYPE_NAMES,

	/** option */
	NORMALIZE_TYPE_KEYWORDS,

	/** option */
	NORMALIZE_BOOLEAN_LITERALS,

	/** option */
	NORMALIZE_CHARACTER_LITERALS,

	/** option */
	NORMALIZE_NUMBER_LITERALS,

	/** option */
	NORMALIZE_STRING_LITERALS,

	/** option */
	IGNORE_THIS,

	/** option */
	IGNORE_VISIBILITY_MODIFIER,

	/** option */
	STEM_WORDS,

	/** option */
	IGNORE_STOP_WORDS,

	/** option */
	IGNORE_END_OF_STATEMENT_TOKENS;

	/** Creates a map with all normalization options set to true */
	public static Map<ENormalizationOption, Boolean> setAll() {
		// TODO (BH): Why not use EnumMap here?
		Map<ENormalizationOption, Boolean> options = new HashMap<ENormalizationOption, Boolean>();
		// TODO (BH): Why not use ENormalizationOption.values() in next line?
		for (ENormalizationOption option : EnumSet
				.allOf(ENormalizationOption.class)) {
			options.put(option, true);
		}
		return options;
	}

	/** Creates a map with the default normalization options set */
	public static Map<ENormalizationOption, Boolean> getDefaultOptions() {
		Map<ENormalizationOption, Boolean> defaultOptions = setAll();

		defaultOptions.put(IGNORE_END_OF_STATEMENT_TOKENS, false);
		defaultOptions.put(NORMALIZE_IDENTIFIERS, false);
		defaultOptions.put(NORMALIZE_FULLY_QUALIFIED_TYPE_NAMES, false);
		defaultOptions.put(STEM_WORDS, false);
		defaultOptions.put(IGNORE_STOP_WORDS, false);

		return defaultOptions;
	}

}

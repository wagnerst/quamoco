/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: UnitPairReportGeneratorProcessor.java 23771 2009-08-25 18:05:57Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.report.UnitPairReportGenerator;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 23771 $
 * @levd.rating YELLOW Hash: 9379F3B938ED614A232415BA588DB20B
 */
@AConQATProcessor(description = "Generates a clone detection result that contains a clone pair "
		+ "for each pair of cloned statements in an input report. This can be useful for tailoring.")
public class UnitPairReportGeneratorProcessor extends
		DetectionResultProcessorBase {

	/** {@inheritDoc} */
	public CloneDetectionResultElement process() {
		List<CloneClass> pairClasses = new UnitPairReportGenerator()
				.createDetectionResult(detectionResult.getList());
		return detectionResultForCloneClasses(pairClasses);
	}

}

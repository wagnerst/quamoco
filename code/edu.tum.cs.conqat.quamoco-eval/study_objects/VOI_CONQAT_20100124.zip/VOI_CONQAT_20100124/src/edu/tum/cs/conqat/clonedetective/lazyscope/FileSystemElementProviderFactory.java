/*--------------------------------------------------------------------------+
   $Id: FileSystemElementProviderFactory.java 25229 2010-01-19 16:31:16Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Creates a {@link FileSystemElementProvider}.
 * <p>
 * This class could be unified with {@link SourceCodeElementProviderFactory}
 * using generics. However, since the ConQAT load time type checking mechanism
 * cannot deal with generics, this was deliberately not done.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 25229 $
 * @levd.rating GREEN Hash: 2DA033A71A06A583EBF0722325AA0EF3
 */
@AConQATProcessor(description = "Creates a FileSystemElementProvider")
public class FileSystemElementProviderFactory extends
		ElementProviderFactoryBase<IFileSystemElement> {

	/** Creates a {@link FileSystemElementProvider} */
	public FileSystemElementProvider process() {
		return new FileSystemElementProvider(ignoreKey, strategies);
	}
}

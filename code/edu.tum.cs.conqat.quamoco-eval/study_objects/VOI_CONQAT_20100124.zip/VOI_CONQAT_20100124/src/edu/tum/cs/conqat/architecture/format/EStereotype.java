/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.architecture
 |                                                                       |
   $Id$            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.format;

/**
 * Represents the type of a stereotype for components.
 * 
 * @author heineman
 * @author $Author$
 * @version $Rev$
 * @levd.rating YELLOW Hash: 5B387B76F97613DC84684D883F4FE99A
 */
public enum EStereotype {

	/** a normal component */
	NONE,

	/** a component that may be accessed from every component within its parent */
	PUBLIC;

	/**
	 * @return the string values.
	 */
	public static String[] stringValues() {
		EStereotype[] values = values();		
		String[] result = new String[values.length];
		for (int i = 0; i < result.length; i++) {
			result[i] = values[i].name();
		}
		return result;
	}

}

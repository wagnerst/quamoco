/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: DetectionResultProcessorBase.java 23905 2009-08-31 07:36:45Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;

/**
 * Base class for processors that work on {@link CloneDetectionResultElement}s.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 23905 $
 * @levd.rating YELLOW Hash: 152A7DD05D21343FE7EC7454B8EAEBA5
 */
public abstract class DetectionResultProcessorBase extends ConQATProcessorBase {

	/** Input {@link CloneDetectionResultElement} */
	protected CloneDetectionResultElement detectionResult;

	/** ConQAT Parameter */
	@AConQATParameter(name = "detection-result", description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setDetectionResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) CloneDetectionResultElement detectionResult) {
		this.detectionResult = detectionResult;
	}

	/**
	 * Create a detection result based on the original detection result and a
	 * list of {@link CloneClass}es.
	 */
	protected CloneDetectionResultElement detectionResultForCloneClasses(
			List<CloneClass> pairClasses) {
		return new CloneDetectionResultElement(detectionResult.getSystemDate(),
				detectionResult.getRoot(), pairClasses, detectionResult
						.getUnits());
	}

}
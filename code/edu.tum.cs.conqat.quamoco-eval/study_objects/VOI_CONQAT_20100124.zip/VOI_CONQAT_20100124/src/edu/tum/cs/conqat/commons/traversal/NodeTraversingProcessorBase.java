/*--------------------------------------------------------------------------+
   $Id: NodeTraversingProcessorBase.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.traversal;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for processors which work by traversing the tree of ConQATNodes
 * provided (using DFS) and possibly changing the values attached to these
 * nodes.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 2EEE7BD6EEB845BF9462C802E222DBFA
 */
public abstract class NodeTraversingProcessorBase<E extends IConQATNode>
		extends ConQATPipelineProcessorBase<E> implements
		INodeVisitor<E, ConQATException> {

	/** Returns the targets for the visitor (template method). */
	protected abstract ETargetNodes getTargetNodes();

	/** {@inheritDoc} */
	@Override
	protected void processInput(E root) throws ConQATException {
		setUp(root);
		TraversalUtils.visitDepthFirst(this, root, getTargetNodes());
		finish(root);
	}

	/**
	 * This method is called before any visiting method is called, so subclasses
	 * can check values, setup data structures or perform manipulations on the
	 * root. This is an empty implementation, so subclasses do not have to
	 * implement it themselves.
	 */
	@SuppressWarnings("unused")
	protected void setUp(E root) throws ConQATException {
		// nothing to do here
	}

	/**
	 * This method is called after visiting has been completed, so subclasses
	 * can perform final manipulations on the root. This is an empty
	 * implementation, so subclasses do not have to implement it themselves.
	 */
	@SuppressWarnings("unused")
	protected void finish(E root) throws ConQATException {
		// nothing to do here
	}
}
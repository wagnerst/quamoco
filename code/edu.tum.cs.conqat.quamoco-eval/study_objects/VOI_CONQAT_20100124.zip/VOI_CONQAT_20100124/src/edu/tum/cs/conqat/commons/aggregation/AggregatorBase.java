/*--------------------------------------------------------------------------+
   $Id: AggregatorBase.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.aggregation;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class to simplify building new aggregators. The output key is added to
 * the display list if it is not already present.
 * <p>
 * Aggregation is only performed for inner nodes. The tree is traversed depth
 * first, with child nodes visited first.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 3A5DA0AEFC93A239A67ED59ED56639A9
 * 
 * @param <E>
 *            the data type we aggregate on.
 */
public abstract class AggregatorBase<E> extends
		NodeTraversingProcessorBase<IConQATNode> {

	/** The key to read the input from. */
	private String inputKey;

	/** The key to write the result into. */
	private String outputKey;

	/** Flag that determines whether missing values are logged */
	private boolean logMissingInputValue = true;

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.INNER;
	}

	/** Set the key used for reading. */
	@AConQATParameter(name = ConQATParamDoc.READKEY_NAME, minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The key to read the aggregation value from.")
	public void setReadKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC)
			String key) {
		inputKey = key;
	}

	/** Set the key used for writing. */
	@AConQATParameter(name = ConQATParamDoc.WRITEKEY_NAME, minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "The key to write the aggregation value to. "
			+ "If not provided use the same key as for reading.")
	public void setWriteKey(
			@AConQATAttribute(name = ConQATParamDoc.WRITEKEY_KEY_NAME, description = ConQATParamDoc.WRITEKEY_KEY_DESC)
			String key) {
		outputKey = key;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "missing", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Logging behaviour")
	public void setLogMissingInputValue(
			@AConQATAttribute(name = "log", description = "Flag that determines whether missing values are logged", defaultValue = "true")
			boolean logMissingValue) {
		this.logMissingInputValue = logMissingValue;
	}

	/** Copy output key if required. */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		if (outputKey == null) {
			outputKey = inputKey;
		}
		NodeUtils.addToDisplayList(root, outputKey);
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) throws ConQATException {
		List<E> childValues = new ArrayList<E>();
		for (IConQATNode child : node.getChildren()) {

			// determine key to use
			String key = inputKey;
			if (child.hasChildren()) {
				key = outputKey;
			}

			Object value = child.getValue(key);
			if (value != null) {
				@SuppressWarnings("unchecked")
				E e = (E) value;
				childValues.add(e);
			} else if (logMissingInputValue) {
				getLogger().info(
						"No value for key '" + key + "' at node: "
								+ child.getId());
			}
		}

		if (childValues.isEmpty()) {
			return;
		}

		try {
			E result = aggregate(childValues);
			node.setValue(outputKey, result);
		} catch (ClassCastException ex) {
			throw new ConQATException("Invalid value encoutered!");
		}
	}

	/** Returns the key used for reading. */
	protected String getInputKey() {
		return inputKey;
	}

	/** Returns the key used for writing. */
	protected String getOutputKey() {
		return outputKey;
	}

	/**
	 * This method should calculate the aggregated value from the provided
	 * values. The provided list is guaranteed to have at least one entry.
	 */
	protected abstract E aggregate(List<E> values);
}

package edu.tum.cs.conqat.simulink.clones.model;

import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.simulink.model.SimulinkBlock;
import edu.tum.cs.simulink.util.SimulinkUtils;

public class SimulinkFurtherUtils extends SimulinkUtils {

	
	public static void visitDepthFirst(
			SimulinkBlock block, IBacktrackVisitor visitor) throws ConQATException {
		visitor.visit(block);
		if (!block.hasSubBlocks()) {
			return;
		}
		for (SimulinkBlock child : block.getSubBlocks()) {
			visitDepthFirst(child, visitor);
		}
		visitor.backtrack();
	}
}

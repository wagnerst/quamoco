/*--------------------------------------------------------------------------+
   $Id: CloneStartPositionComparator.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.utils;

import java.util.Comparator;

import edu.tum.cs.conqat.clonedetective.core.Clone;

/**
 * Compares clones by comparing their start positions.
 * <p>
 * Can be used to sort clones in a file by their start positions
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 729B6CC26B73249E057F00DF620B0B2A
 */
public class CloneStartPositionComparator implements Comparator<Clone> {

	/** Singleton instance */
	private static CloneStartPositionComparator instance = null;

	/** Enforce use of singleton instance */
	private CloneStartPositionComparator() {
		// Nothing to do
	}

	/** {@inheritDoc} */
	public int compare(Clone clone1, Clone clone2) {
		Integer start1 = clone1.getStartLineInFile();
		Integer start2 = clone2.getStartLineInFile();
		return start1.compareTo(start2);
	}

	/** Get singleton instance of this comparator */
	public static CloneStartPositionComparator getInstance() {
		if (instance == null) {
			instance = new CloneStartPositionComparator();
		}
		return instance;
	}

}
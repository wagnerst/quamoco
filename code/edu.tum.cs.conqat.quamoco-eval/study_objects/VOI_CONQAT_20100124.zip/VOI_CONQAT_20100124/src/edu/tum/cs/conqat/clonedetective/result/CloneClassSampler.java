/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: CloneClassSampler.java 23754 2009-08-25 12:06:55Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.util.Collections;
import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 23754 $
 * @levd.rating YELLOW Hash: 917CBFA3CDB56A6C94D4B6CAC922695B
 */
@AConQATProcessor(description = "Reduces a clone detection result to a random sample of specified size.")
public class CloneClassSampler extends DetectionResultProcessorBase {

	/** Default sample size */
	private static final int DEFAULT_SAMPLE_SIZE = 1000;

	/** Size of the sample */
	private int sampleSize = DEFAULT_SAMPLE_SIZE;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "sample", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Set size of sample (Number of clone classes that are kept. "
			+ "If less clone classes are contained, all are kept.)")
	public void setSampleSize(
			@AConQATAttribute(name = "size", description = "Default value is "
					+ DEFAULT_SAMPLE_SIZE) int sampleSize) {
		this.sampleSize = sampleSize;
	}

	/** {@inheritDoc} */
	public CloneDetectionResultElement process() {
		List<CloneClass> cloneClasses = randomizeCloneClassesOrder();

		cloneClasses = cutToSize(cloneClasses, sampleSize);

		logSampleDetails(cloneClasses);

		return new CloneDetectionResultElement(detectionResult.getSystemDate(),
				detectionResult.getRoot(), cloneClasses);
	}

	/** Returns list of clone classes in random order */
	private List<CloneClass> randomizeCloneClassesOrder() {
		List<CloneClass> cloneClasses = detectionResult.getList();
		Collections.shuffle(cloneClasses);
		return cloneClasses;
	}

	// TODO (EJ) Move into commons? Dear reviewer ;), do you think that this is
	// could be useful in other places as well?
	/** Returns a list that is truncated after the sample size */
	private List<CloneClass> cutToSize(List<CloneClass> cloneClasses, int size) {
		int toIndex = Math.min(size, cloneClasses.size());
		cloneClasses = cloneClasses.subList(0, toIndex);
		return cloneClasses;
	}

	/** Create log messages containing information about truncation */
	private void logSampleDetails(List<CloneClass> sample) {
		double originalSize = detectionResult.getList().size();
		double sampleSize = sample.size();
		getLogger().info(
				"Chose a sample of " + sampleSize + " out of " + originalSize
						+ " clone classes");

		double ratio = sampleSize / originalSize;
		getLogger()
				.info("Sample has size " + ratio * 100 + "% of original set");
	}

}

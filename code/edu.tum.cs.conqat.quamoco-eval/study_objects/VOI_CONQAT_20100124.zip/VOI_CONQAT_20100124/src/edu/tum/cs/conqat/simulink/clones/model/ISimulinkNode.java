package edu.tum.cs.conqat.simulink.clones.model;

import edu.tum.cs.conqat.model_clones.model.INode;
import edu.tum.cs.simulink.model.SimulinkBlock;

public interface ISimulinkNode extends INode {
	/** Returns the block. */
	public abstract SimulinkBlock getBlock();

}
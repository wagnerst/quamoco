/*--------------------------------------------------------------------------+
   $Id: NormalizationDebugUtils.java 24258 2009-09-18 10:25:23Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.clonedetective.core.TokenUnit;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.logging.IConQATLogger;
import edu.tum.cs.scanner.IToken;

/**
 * Utility functions for writing debug files.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 24258 $ 16369
 * @levd.rating GREEN Hash: 4C18AF5C9C7EE278CE553B21B253EDC5
 */
/* package */class NormalizationDebugUtils {

	/**
	 * Copies all whitespace between a start and an end index (both inclusive)
	 * from a string into a StringBuilder. Encountered non-whitespace characters
	 * are replaced with spaces. This way, the tabulation and line breaks from
	 * the source string are preserved in the target {@link StringBuilder}.
	 */
	/* package */static void copyWhitespace(int startOffset, int endOffset,
			String source, StringBuilder target) {
		if (startOffset > endOffset) {
			return;
		}

		for (int pos = startOffset; pos <= endOffset; pos++) {
			char c = source.charAt(pos);
			if (Character.isWhitespace(c)) {
				target.append(c);
			} else {
				target.append(" ");
			}
		}
	}

	/** Writes a debug file */
	/* package */static void writeDebugFile(CanonicalFile originalFile,
			Map<IToken, TokenUnit> normalization, IConQATLogger logger,
			String debugFileExtension) {

		try {
			String originalContent = FileLibrary.getInstance().getContent(
					originalFile,
					FileLibrary.getInstance().obtainEncoding(originalFile));
			File debugFile = new File(originalFile.getCanonicalPath()
					+ debugFileExtension);
			FileSystemUtils.writeFile(debugFile, createDebugFileContent(
					originalContent, normalization));
		} catch (ConQATException e) {
			logDebugFileException(originalFile, e, logger);
		} catch (IOException e) {
			logDebugFileException(originalFile, e, logger);
		}
	}

	/** Write exception to log file */
	private static void logDebugFileException(File originalFile, Throwable e,
			IConQATLogger logger) {
		logger.warn("Could not write debug file for : " + originalFile + ": "
				+ e.getMessage());
	}

	/**
	 * Creates the debug file content for an input file and its token list. This
	 * method attempts to replace each token or the original file with its
	 * normalized counterpart while preserving line and column numbers as good
	 * as possible.
	 */
	private static String createDebugFileContent(String originalContent,
			Map<IToken, TokenUnit> normalization) {
		StringBuilder content = new StringBuilder();
		int lastOffset = 0;

		// Since normalization is a LinkedHashMap, the tokens are in the
		// insertion sequence
		for (IToken originalToken : normalization.keySet()) {
			TokenUnit normalizedToken = normalization.get(originalToken);

			if (normalizedToken == null) {
				continue;
			}

			NormalizationDebugUtils.copyWhitespace(lastOffset, originalToken
					.getOffset() - 1, originalContent, content);
			content.append(normalizedToken.getContent());
			lastOffset = originalToken.getOffset()
					+ normalizedToken.getContent().length();
		}
		return content.toString();
	}

}

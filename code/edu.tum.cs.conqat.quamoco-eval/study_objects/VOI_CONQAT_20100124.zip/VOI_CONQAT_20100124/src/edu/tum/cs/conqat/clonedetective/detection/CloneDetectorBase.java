/*--------------------------------------------------------------------------+
   $Id: CloneDetectorBase.java 24205 2009-09-15 19:38:47Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection;

import java.util.Date;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.digest.Digester;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionStatistics;
import edu.tum.cs.conqat.clonedetective.core.ECloneDetectionStatistic;
import edu.tum.cs.conqat.clonedetective.core.IDatabaseSpace;
import edu.tum.cs.conqat.clonedetective.core.IdProvider;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.core.constraint.CardinalityConstraint;
import edu.tum.cs.conqat.clonedetective.core.constraint.ConstraintList;
import edu.tum.cs.conqat.clonedetective.core.constraint.ICloneClassConstraint;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.clonedetective.detection.suffixtree.ICloneConsumer;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IUnitProvider;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for clone detection processors.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 24205 $
 * @levd.rating GREEN Hash: 3A25547959D987CD2C5EA37C26647B5E
 */
public abstract class CloneDetectorBase extends ConQATProcessorBase {

	/** Key used for storing detection statistics */
	public static final String DETECTION_STATS = "Detection Statistics";

	/** Key that is used to store the number of units in an element */
	public static final String UNITS_KEY = "Units";

	/**
	 * Number of units that a clone must at least comprise. If it has less, it
	 * gets filtered out.
	 */
	protected int minLength;

	/** Stores clone detection statistics */
	private CloneDetectionStatistics statistics;

	/** Root of the input tree */
	private IFileSystemElement input;

	/**
	 * {@link IUnitProvider} that provides units on which the clone detection is
	 * performed. Serves as normalization strategy.
	 */
	private IUnitProvider<IFileSystemElement, Unit> iUnitProvider;

	/** List of units retrieved from the units provider */
	protected List<Unit> units;

	/**
	 * If this string is set to a non-empty value, a debug file (containing the
	 * normalized units) is written for each input file.
	 */
	private String debugFileExtension = null;

	/**
	 * Key that contains flag that determines whether file gets ignored.
	 * Influences log message generation, but not unit draining.
	 */
	private String ignoreKey;

	/** List of constraints that all detected clone classes must satisfy */
	private final ConstraintList constraints = new ConstraintList();

	/** Database space used for tracing */
	private IDatabaseSpace dbSpace;

	/** Timestamp at which detection started */
	private Date systemDate;

	/** {@link IdProvider} used to create Ids for clone classes and clones */
	protected IdProvider idProvider;

	/** Flag that determines whether the units are stored in clones */
	private boolean storeUnits = false;

	/** ConQAT Parameter */
	@AConQATParameter(name = "debug", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "If this string is set to a non-empty value, a debug file is written for each input file")
	public void setDebugFileExtension(
			@AConQATAttribute(name = "extension", description = "File extension") String debugFileExtension) {
		if (StringUtils.isEmpty(debugFileExtension)) {
			throw new IllegalArgumentException(
					"Empty debug file extension not allowed, since it would overwrite existing files.");
		}
		if (!debugFileExtension.startsWith(".")) {
			debugFileExtension = "." + debugFileExtension;
		}
		this.debugFileExtension = debugFileExtension;
	}

	/** Sets the unit list */
	@AConQATParameter(name = "clonelength", description = "Minimal length of Clone", minOccurrences = 1, maxOccurrences = 1)
	public void setMinLength(
			@AConQATAttribute(name = "min", description = "Minimal length of Clone") int minLength) {
		this.minLength = minLength;
	}

	/** Sets the input */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setInput(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IFileSystemElement input) {
		this.input = input;
	}

	/**
	 * Sets normalization strategy.
	 * <p>
	 * In general, ConQAT load time type checking does not check generic
	 * parameters. This is no problem in this case, as
	 * {@link IFileSystemElement} and {@link Unit} are the most general
	 * instantiations of the generic parameters for {@link IUnitProvider}
	 */
	@AConQATParameter(name = "normalization", description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setNormalization(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IUnitProvider<IFileSystemElement, Unit> unitProvider) {
		iUnitProvider = unitProvider;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "ignore", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Key under which ignore flag is stored.")
	public void setIgnoreKey(
			@AConQATAttribute(name = "key", description = "If no key is given, no files are ignored") String ignoreKey) {
		this.ignoreKey = ignoreKey;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "constraint", minOccurrences = 0, maxOccurrences = -1, description = ""
			+ "Adds a constraint that each detected clone class must satisfy")
	public void addConstraint(
			@AConQATAttribute(name = "type", description = "Clone classes that do not match the constraint are filtered") ICloneClassConstraint constraint) {
		constraints.add(constraint);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "database", description = "Database connection for clone tracing.", minOccurrences = 0, maxOccurrences = 1)
	public void setDbSpace(
			@AConQATAttribute(name = "space", description = "If not set, no tracing is performed. If set, storeUnits is also set to true.") IDatabaseSpace dbSpace) {
		this.dbSpace = dbSpace;
		if (dbSpace != null) {
			storeUnits = true;
		}
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "system", minOccurrences = 0, maxOccurrences = 1, description = "Date denoting the system version on which clone detection is performed.")
	public void setSystemDate(
			@AConQATAttribute(name = "date", description = "If not set, system date is set to now") Date systemDate) {
		this.systemDate = systemDate;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "store", description = "Flag that determines whether units are stored in clones.", minOccurrences = 0, maxOccurrences = 1)
	public void setStoreUnits(
			@AConQATAttribute(name = "units", description = "Increases memory requirements. Default is false. Automatically set if a database space is set.") boolean storeUnits) {
		if (dbSpace != null && !storeUnits) {
			getLogger().warn(
					"Cannot set store-units to false, since dbSpace is set");
		} else {
			this.storeUnits = storeUnits;
		}
	}

	/** Constructor */
	public CloneDetectorBase() {
		// only detect clone classes of cardinality 2 or greater.
		// (clone classes can have cardinality of 1, if all contained clones
		// are considered equal by the set that stores a clone classes'
		// clones. this can happen if clones only differ
		// in start and end units that are located on the same lines.)
		CardinalityConstraint constraint = new CardinalityConstraint();
		constraint.setMin(2);
		constraints.add(constraint);
	}

	/** Calls template method to perform clone detection in deriving class */
	public CloneDetectionResultElement process() throws ConQATException {
		// initialize id provider
		idProvider = initIdProvider();

		// create detection statistics object
		statistics = new CloneDetectionStatistics();
		input.setValue(DETECTION_STATS, statistics);

		UnitDrain drain = new UnitDrain(getLogger(), debugFileExtension,
				ignoreKey);
		units = drain.drainUnits(input, iUnitProvider);

		List<CloneClass> cloneClasses = detectClones();

		collectStatistics(cloneClasses);

		// create detection result parameter object
		return new CloneDetectionResultElement(getSystemDate(), input,
				cloneClasses, createUnitsMap());
	}

	/**
	 * If the database connection is set, we use a GlobalIdProvider, else a
	 * standard {@link IdProvider}.
	 */
	private IdProvider initIdProvider() {
		if (dbSpace == null) {
			return new IdProvider();
		}

		return dbSpace.getIdProvider();
	}

	/**
	 * Stores number of processed units and number of found clones in detection
	 * statistics object
	 */
	private void collectStatistics(List<CloneClass> cloneClasses) {
		int unitCount = units.size();
		int cloneCount = CloneUtils.countClones(cloneClasses);

		getLogger().info("# Units: " + unitCount);
		getLogger().info("# Clones: " + cloneCount);

		statistics.setStatistic(ECloneDetectionStatistic.PROCESSED_UNIT_COUNT,
				unitCount);
		statistics.setStatistic(ECloneDetectionStatistic.CLONE_COUNT,
				cloneCount);
	}

	/** Create map from files to units on which detection was performed */
	private Map<CanonicalFile, Unit[]> createUnitsMap() {
		HashedListMap<CanonicalFile, Unit> unitsPerFile = new HashedListMap<CanonicalFile, Unit>();
		for (Unit unit : units) {
			CanonicalFile file = unit.getFile();
			// skip synthetic units, since they are not contained in the files
			if (!unit.isSynthetic()) {
				unitsPerFile.add(file, unit);
			}
		}

		return unitsPerFile.listsToArrays(Unit.class);
	}

	/**
	 * Template method that deriving classes override to implement their clone
	 * detection
	 */
	protected abstract List<CloneClass> detectClones() throws ConQATException;

	/** Getter */
	protected Date getSystemDate() {
		if (systemDate == null) {
			// if not set, set to now
			systemDate = new Date();
		}
		return systemDate;
	}

	/**
	 * Receives found clones found during clone detection and packages them into
	 * clone classes.
	 * <p>
	 * Since this class accesses the units list of the clone detector, it is
	 * internal.
	 */
	protected class CloneConsumer implements ICloneConsumer {

		/** List in which the created clone classes are stored */
		private final List<CloneClass> cloneClasses;

		/**
		 * Creates a ICloneConsumer that writes the {@link CloneClass}es it
		 * creates into the given list
		 */
		public CloneConsumer(List<CloneClass> cloneClasses) {
			this.cloneClasses = cloneClasses;
		}

		/** {@link CloneClass} currently being filled */
		protected CloneClass currentCloneClass;

		/** Start new clone class */
		public void startCloneClass(int normalizedLength) {
			currentCloneClass = new CloneClass(normalizedLength, idProvider
					.provideId());
		}

		/** Adds a clone to the current {@link CloneClass} */
		public Clone addClone(int globalPosition, int length) {
			// compute length of clone in lines
			Unit firstUnit = units.get(globalPosition);
			Unit lastUnit = units.get(globalPosition + length - 1);
			List<Unit> cloneUnits = units.subList(globalPosition,
					globalPosition + length);

			CanonicalFile file = firstUnit.getFile();
			int startLineInFile = firstUnit.getStartLineInFile();
			int lengthInFile = lastUnit.getStartLineInFile()
					- firstUnit.getStartLineInFile()
					+ lastUnit.getCoveredLines();

			int startUnitIndexInFile = firstUnit.getIndexInFile();
			int endUnitIndexInFile = lastUnit.getIndexInFile();
			int lengthInUnits = endUnitIndexInFile - startUnitIndexInFile + 1;
			CCSMAssert.isTrue(lengthInUnits >= 0, "Negative length in units!");
			String fingerprint = createFingerprint(globalPosition, length);

			Clone clone = new Clone(idProvider.provideId(), currentCloneClass,
					file, startLineInFile, lengthInFile, startUnitIndexInFile,
					lengthInUnits, fingerprint);
			clone.setBirth(getSystemDate());

			if (storeUnits) {
				CloneUtils.setUnits(clone, cloneUnits);
			}

			currentCloneClass.add(clone);

			return clone;
		}

		/** Create fingerprint for current clone */
		protected String createFingerprint(int globalPosition, int length) {
			StringBuilder fingerprintBase = new StringBuilder();
			for (int pos = globalPosition; pos < globalPosition + length; pos++) {
				fingerprintBase.append(units.get(pos).getContent());
			}
			return Digester.createMD5Digest(fingerprintBase.toString());
		}

		/** Check constraints */
		public boolean completeCloneClass() throws ConQATException {
			boolean constraintsSatisfied = constraints
					.allSatisfied(currentCloneClass);

			if (constraintsSatisfied) {
				cloneClasses.add(currentCloneClass);
			}

			return constraintsSatisfied;
		}
	}

}
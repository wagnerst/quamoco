/*--------------------------------------------------------------------------+
   $Id: ConQATInstallationScope.java 23503 2009-08-07 16:17:42Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.self;

import java.io.File;

import edu.tum.cs.conqat.bundle.BundleException;
import edu.tum.cs.conqat.bundle.BundleInfo;
import edu.tum.cs.conqat.bundle.BundlesConfiguration;
import edu.tum.cs.conqat.bundle.BundlesManager;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * A scope that creates a {@link ConQATInstallationRoot} node.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23503 $
 * @levd.rating GREEN Hash: 4588DFE38AFA50A29F7B616FD90151C0
 */
@AConQATProcessor(description = "This processor reads the given ConQAT installation and bundles.")
public class ConQATInstallationScope extends ConQATProcessorBase {

	/** Key used for the name. */
	@AConQATKey(description = "The pretty name of the bundle", type = "java.lang.String")
	public static final String NAME_KEY = "Name";

	/** Key used for the version. */
	@AConQATKey(description = "The version of the bundle", type = "edu.tum.cs.commons.version.Version")
	public static final String VERSION_KEY = "Version";

	/** Key used for the provider. */
	@AConQATKey(description = "The provider of the bundle", type = "java.lang.String")
	public static final String PROVIDER_KEY = "Provider";

	/** ConQAT installation directory. */
	private File conqatDir;

	/** The bundles manager used for loading the bundles. */
	private final BundlesManager bundlesManager = new BundlesManager();

	/** Set the ConQAT directory. */
	@AConQATParameter(name = "conqat", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The directory ConQAT is installed into.")
	public void setConQATDirectory(
			@AConQATAttribute(name = "dir", description = "The name of the directory.")
			String dir) {
		this.conqatDir = new File(dir);
	}

	/** Add a bundle location. */
	@AConQATParameter(name = "bundle", minOccurrences = 0, description = ""
			+ "Add a single bundle.")
	public void addBundleLocation(
			@AConQATAttribute(name = "dir", description = "The directory name of the bundle.")
			String dir) throws ConQATException {
		try {
			bundlesManager.addBundleLocation(dir);
		} catch (BundleException e) {
			throw new ConQATException(e);
		}
	}

	/** Add a bundle collection. */
	@AConQATParameter(name = "bundle-collection", minOccurrences = 0, description = ""
			+ "Add a collection of bundles.")
	public void addBundleCollection(
			@AConQATAttribute(name = "dir", description = "The name of the directory the bundles are in.")
			String dir) throws ConQATException {
		try {
			bundlesManager.addBundleCollection(dir);
		} catch (BundleException e) {
			throw new ConQATException(e);
		}
	}

	/** {@inheritDoc} */
	public ConQATInstallationRoot process() throws ConQATException {
		ConQATInstallationRoot root = new ConQATInstallationRoot(conqatDir);
		NodeUtils.addToDisplayList(root, NAME_KEY, VERSION_KEY, PROVIDER_KEY);

		BundlesConfiguration config;
		try {
			config = bundlesManager.loadAndSortBundles();
		} catch (BundleException e) {
			throw new ConQATException(e);
		}
		for (BundleInfo bundle : config.getBundles()) {
			getLogger().info("Added bundle " + bundle.getId());
			ConQATBundleNode node = new ConQATBundleNode(bundle);
			node.setValue(NAME_KEY, bundle.getName());
			node.setValue(VERSION_KEY, bundle.getVersion());
			node.setValue(PROVIDER_KEY, bundle.getProvider());
			root.addChild(node);
		}
		return root;
	}
}

package net.sf.jabref.bst;

public interface Warn {
	public void warn(String s);
}

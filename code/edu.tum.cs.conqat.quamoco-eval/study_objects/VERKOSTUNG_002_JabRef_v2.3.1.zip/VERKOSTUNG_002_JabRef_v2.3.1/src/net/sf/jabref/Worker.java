

package net.sf.jabref;


/**
 * ...
 */
public interface Worker {

    public void run();

}

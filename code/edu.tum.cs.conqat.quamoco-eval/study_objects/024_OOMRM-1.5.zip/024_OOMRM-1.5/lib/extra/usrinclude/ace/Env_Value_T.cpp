// $Id: Env_Value_T.cpp 69051 2005-10-28 16:14:56Z ossama $

#ifndef ACE_ENV_VALUE_T_CPP
#define ACE_ENV_VALUE_T_CPP

#include "ace/Env_Value_T.h"

#if ! defined (__ACE_INLINE__)
#include "ace/Env_Value_T.inl"
#endif /* __ACE_INLINE__ */

#endif /* ACE_ENV_VALUE_T_CPP */

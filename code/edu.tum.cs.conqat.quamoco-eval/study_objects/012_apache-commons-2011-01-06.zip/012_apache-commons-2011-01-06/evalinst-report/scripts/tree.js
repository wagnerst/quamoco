function showBranch(id){
	var objBranch = document.getElementById("branch-"+id).style;
	var objNode = document.getElementById("node-"+id).style;
	if(objBranch.display=="block") {
		objBranch.display="none";
		objNode.backgroundImage = "url(images/group.gif)";
  } else {
		objBranch.display="block";
		objNode.backgroundImage = "url(images/group_open.gif)";
	}
}

function collapseAll() {
 var rows = document.getElementsByTagName("UL");
 for (var j = 0; j < rows.length; j++) {
   var r = rows[j];
   if (r.id.indexOf("branch") == 0) {
     r.style.display = "none";    
   }
 }
 
 rows = document.getElementsByTagName("LI");
 for (var j = 0; j < rows.length; j++) {
   var r = rows[j];
   if (r.id.indexOf("node") == 0) {
    r.style.backgroundImage = "url(images/group.gif)";
   }
 }
}

function expandAll() {
 var rows = document.getElementsByTagName("UL");
 for (var j = 0; j < rows.length; j++) {
   var r = rows[j];
   if (r.id.indexOf("branch") == 0) {
     r.style.display = "block";
   }
 }
 
 rows = document.getElementsByTagName("LI");
 for (var j = 0; j < rows.length; j++) {
   var r = rows[j];
   if (r.id.indexOf("node") == 0) {
    r.style.backgroundImage = "url(images/group_open.gif)";
   }
 }
}


/* 'Stylesheet/Regeln hinzufuegen 260907' (c) cybaer@binon.net - http://Coding.binon.net/AddStyle */
/* Lizenz CC <http://creativecommons.org/licenses/by-nc-sa/3.0/> */
/* Kommerzielle Lizenz: lizenzen@aldaron.de */
function addStyle(rules,target) {
 var styleObj=null, styleSheetObj=null, i, j, p, selector, singleSelector, text;
 if(document.createElement && document.getElementsByTagName) {
  if(typeof(target)=="number") {
   if(target<=-1) { target=document.getElementsByTagName("style").length+Math.ceil(target); }
   target=Math.max(0,Math.min(document.getElementsByTagName("style").length-1,Math.floor(target)));
  }
  if(typeof(target)=="undefined" || typeof(target)=="string" || !document.getElementsByTagName("style")[target]) {
   if(document.createStyleSheet) {
    styleSheetObj=document.createStyleSheet();
    styleObj=styleSheetObj.owningElement || styleSheetObj.ownerNode;
   } else {
    styleObj=document.createElement("style");
    document.getElementsByTagName("head")[0].appendChild(styleObj);
   }
   styleObj.setAttribute("type","text/css");
   if(target) { styleObj.setAttribute("media",target); }
  } else if(typeof(target)=="number") {
   styleObj=document.getElementsByTagName("style")[target];
   styleSheetObj=styleObj.sheet || styleObj.styleSheet;
  }
  if(styleObj && rules) {
   /*@cc_on
   @if(@_jscript)
    rule=rules.replace(/\s+/g," ").replace(/\/\*.+?\*\//g,"").split("}");
    for(i=0;i<rule.length;i++) {
     p=rule[i].indexOf("{");
     selector=rule[i].substring(0,p).replace(/^\s+|\s+$/g,"");
     text=rule[i].substring(p+1).replace(/^\s+|\s+$/g,"");
     if(selector) {
      if(selector.indexOf(",")) {
       singleSelector=selector.split(",");
      } else {
       singleSelector=new Array(selector);
      }
      for(j=0;j<singleSelector.length;j++) { styleSheetObj.addRule(singleSelector[j].replace(/^\s+|\s+$/g,""),(text)?text:" "); }
     }
    }
   @else @*/
    if(styleObj.firstChild) { styleObj.firstChild.nodeValue=styleObj.firstChild.nodeValue.replace("<!--",""); }
    if(styleObj.lastChild) { styleObj.lastChild.nodeValue=styleObj.lastChild.nodeValue.replace("-->",""); }
    styleObj.appendChild(document.createTextNode(rules+"\n"));
   /*@end @*/
  }
 }
 return styleObj;
}


/*--------------------------------------------------------------------------+
   $Id: ShaperBase.java 25971 2010-02-06 11:16:26Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.shapers;

import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.normalization.token.ITokenProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.TokenProviderBase;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.IConQATProcessor;
import edu.tum.cs.conqat.core.IConQATProcessorInfo;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.IToken;

/**
 * Base class for shapers. Shapers modify the token stream before normalization
 * to influence the outcome of clone detection.
 * <p>
 * Shapers can either swallow tokens or insert synthetic pendingSentinel tokens.
 * Sentinel tokens are unequal to each other by definition and thus limit
 * clones.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25971 $
 * @levd.rating GREEN Hash: F70798F8EDFAF3BEC21DE72D1E29BACE
 */
public abstract class ShaperBase extends TokenProviderBase implements
		IConQATProcessor {

	/** Source of the tokens stream that gets shaped */
	protected ITokenProvider tokenProvider;

	/** Sentinel that gets returned upon next access */
	private IToken pendingSentinel = null;

	/** Set token provider whose tokens are filtered */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setTokenProvider(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_NAME) ITokenProvider tokenProvider) {
		this.tokenProvider = tokenProvider;
	}

	/** Returns reference to this */
	public ShaperBase process() {
		return this;
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ISourceCodeElement root) throws CloneDetectionException {
		tokenProvider.init(root, getLogger());
	}

	/** {@inheritDoc} */
	@Override
	public void init(IConQATProcessorInfo processorInfo) {
		logger = processorInfo.getLogger();
	}

	/** {@inheritDoc} */
	@Override
	protected IToken provideNext() throws CloneDetectionException {
		IToken token = null;

		while (token == null) {
			// check for pending pendingSentinel
			if (pendingSentinel != null) {
				IToken reference = pendingSentinel;
				pendingSentinel = null;
				return reference;
			}

			// retrieve next token
			token = tokenProvider.getNext();
			if (token == null) {
				return null;
			}

			// check whether to append sentinel
			if (isBoundary(token)) {
				pendingSentinel = SentinelToken.createSentinelAfter(token);
			}

			// determine whether to skip token
			if (skip(token)) {
				token = null;
			}
		}

		return token;
	}

	/** Template method that allows deriving classes to skip tokens */
	protected boolean skip(@SuppressWarnings("unused") IToken token) {
		return false;
	}

	/** Determines whether a token represents a boundary */
	protected abstract boolean isBoundary(IToken token);

}
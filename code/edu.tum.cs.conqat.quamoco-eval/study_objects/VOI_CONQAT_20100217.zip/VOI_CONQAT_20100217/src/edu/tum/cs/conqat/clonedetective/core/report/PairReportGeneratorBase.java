/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: PairReportGeneratorBase.java 25575 2010-01-26 13:48:46Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IdProvider;

/**
 * Base class for classes that generate reports containing clone pairs.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25575 $
 * @levd.rating GREEN Hash: 67898DCAB3DA7E1927ADA8C4FC9F3F69
 */
public abstract class PairReportGeneratorBase {

	/** Id provider used to create new clone class ids */
	protected final IdProvider idProvider = new IdProvider();

	/** Create paired {@link CloneClass}es */
	public List<CloneClass> createDetectionResult(List<CloneClass> cloneClasses) {
		List<CloneClass> pairClasses = new ArrayList<CloneClass>();

		for (CloneClass cloneClass : cloneClasses) {
			createPairClasses(cloneClass, pairClasses);
		}

		return pairClasses;
	}

	/** Create pair clone classes for all clones in a clone class */
	private void createPairClasses(CloneClass cloneClass,
			List<CloneClass> pairClasses) {
		for (ImmutablePair<Clone, Clone> clonePair : CollectionUtils
				.computeUnorderedPairs(cloneClass.getClones())) {
			pairClasses.addAll(createPairClasses(clonePair));
		}
	}

	/**
	 * Template method that deriving classes override to implement pair creation
	 */
	protected abstract Collection<? extends CloneClass> createPairClasses(
			ImmutablePair<Clone, Clone> clonePair);

}
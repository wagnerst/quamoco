package edu.tum.cs.conqat.clonedetective.core.report.enums;

/**
 * Enumeration for clone change types occurring during evolution.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25575 $
 * @levd.rating GREEN Hash: D754BE2A768A785AE021B4DE9E31242E
 */
public enum EChangeType {

	/** Intentionally coupled modification */
	CONSISTENT,

	/** Unintentionally uncoupled modification */
	INCONSISTENT,

	/** Intentionally uncoupled modification */
	INDEPENDENT,

	/** Don't know */
	DONT_KNOW,

	/** Not yet decided */
	UNRATED
}

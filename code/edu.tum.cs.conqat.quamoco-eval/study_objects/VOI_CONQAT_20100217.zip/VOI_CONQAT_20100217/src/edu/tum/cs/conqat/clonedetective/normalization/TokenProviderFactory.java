/*--------------------------------------------------------------------------+
   $Id: TokenProviderFactory.java 25459 2010-01-26 10:12:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization;

import edu.tum.cs.conqat.clonedetective.lazyscope.IElementProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.ITokenProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.TokenProvider;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25459 $
 * @levd.rating GREEN Hash: 4A339449EDC69F10D0C0FE725BFCEE3E
 */
@AConQATProcessor(description = "Creates a token provider")
public class TokenProviderFactory extends ConQATProcessorBase {

	/** Provides the elements (i.e. files) the tokens stem from */
	private IElementProvider<ISourceCodeElement> inputProvider;

	/** Set element provider */
	@AConQATParameter(description = ConQATParamDoc.INPUT_DESC, name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1)
	public void setElementProvider(
			@AConQATAttribute(description = ConQATParamDoc.INPUT_REF_DESC, name = ConQATParamDoc.INPUT_REF_NAME) IElementProvider<ISourceCodeElement> inputProvider) {
		this.inputProvider = inputProvider;
	}

	/** {@inheritDoc} */
	public ITokenProvider process() {
		return new TokenProvider(inputProvider);
	}
}

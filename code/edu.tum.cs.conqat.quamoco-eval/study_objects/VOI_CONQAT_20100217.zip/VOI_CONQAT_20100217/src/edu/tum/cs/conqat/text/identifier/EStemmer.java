/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.text
 |                                                                       |
   $Id: EStemmer.java 25414 2010-01-25 16:51:52Z heineman $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import org.tartarus.snowball.SnowballProgram;
import org.tartarus.snowball.ext.DanishStemmer;
import org.tartarus.snowball.ext.DutchStemmer;
import org.tartarus.snowball.ext.EnglishStemmer;
import org.tartarus.snowball.ext.FinnishStemmer;
import org.tartarus.snowball.ext.FrenchStemmer;
import org.tartarus.snowball.ext.German2Stemmer;
import org.tartarus.snowball.ext.HungarianStemmer;
import org.tartarus.snowball.ext.ItalianStemmer;
import org.tartarus.snowball.ext.NorwegianStemmer;
import org.tartarus.snowball.ext.PortugueseStemmer;
import org.tartarus.snowball.ext.RomanianStemmer;
import org.tartarus.snowball.ext.RussianStemmer;
import org.tartarus.snowball.ext.SpanishStemmer;
import org.tartarus.snowball.ext.SwedishStemmer;
import org.tartarus.snowball.ext.TurkishStemmer;

/**
 * Enumeration of stemmers for different languages. A stemmer transforms a word
 * into its root form. The stemmers are described in detail at <a
 * href="http://snowball.tartarus.org/">http://snowball.tartarus.org/</a> while
 * the version used here is taken from Apache lucene which contains Java classes
 * generated from the snowball code.
 * <p>
 * The following stemmers are not included:
 * <ul>
 * <li>Porter, as it is superseded by English</li>
 * <li>German, as we use German2</li>
 * <li>Lovins and KP as these are old algorithms for languages already supported
 * </li>
 * </ul>
 * 
 * @author hummelb
 * @author $Author: heineman $
 * @version $Rev: 25414 $
 * @levd.rating GREEN Hash: 2BB5BACE7EF583A68CD17BC49CD02AC3
 */
public enum EStemmer {

	/** Stemmer for danish language. */
	DANISH(new DanishStemmer()),

	/** Stemmer for dutch language. */
	DUTCH(new DutchStemmer()),

	/** Stemmer for english language. */
	ENGLISH(new EnglishStemmer()),

	/** Stemmer for finnish language. */
	FINNISH(new FinnishStemmer()),

	/** Stemmer for french language. */
	FRENCH(new FrenchStemmer()),

	/** Stemmer for german language. */
	GERMAN(new German2Stemmer()),

	/** Stemmer for hungarian language. */
	HUNGARIAN(new HungarianStemmer()),

	/** Stemmer for italian language. */
	ITALIAN(new ItalianStemmer()),

	/** Stemmer for norwegian language. */
	NORWEGIAN(new NorwegianStemmer()),

	/** Stemmer for portuguese language. */
	PORTUGUESE(new PortugueseStemmer()),

	/** Stemmer for romanian language. */
	ROMANIAN(new RomanianStemmer()),

	/** Stemmer for russian language. */
	RUSSIAN(new RussianStemmer()),

	/** Stemmer for spanish language. */
	SPANISH(new SpanishStemmer()),

	/** Stemmer for swedish language. */
	SWEDISH(new SwedishStemmer()),

	/** Stemmer for turkish language. */
	TURKISH(new TurkishStemmer());

	/** The stemmer used. */
	private final SnowballProgram stemmer;

	/** Constructor. */
	private EStemmer(SnowballProgram stemmer) {
		this.stemmer = stemmer;
	}

	/** Stems the given word. */
	public synchronized String stem(String s) {
		stemmer.setCurrent(s);
		stemmer.stem();
		return stemmer.getCurrent();
	}

}

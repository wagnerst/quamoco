/*--------------------------------------------------------------------------+
   $Id: FindingsList.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assertion.CCSMPre;
import edu.tum.cs.commons.clone.IDeepCloneable;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;

/**
 * A list of findings. Actually this list does not store the findings
 * themselves, but path descriptors which can be used to locate a finding in a
 * {@link FindingReport}.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 4DB622A3AF8CF7964C70036B930AA389
 */
public class FindingsList extends AbstractList<Finding> implements
		IDeepCloneable {

	/** The associated node. */
	private final IConQATNode node;

	/** The list storing the finding paths. */
	private final List<FindingPathDescriptor> findingPaths = new ArrayList<FindingPathDescriptor>();

	/** Constructor. */
	public FindingsList(IConQATNode node) {
		this.node = node;
	}

	/** Copy constructor. */
	public FindingsList(FindingsList other, IConQATNode node) {
		this.node = node;
		findingPaths.addAll(other.findingPaths);
	}

	/** {@inheritDoc} */
	@Override
	public Finding get(int index) {
		return findingPaths.get(index).locateFinding(getReport());
	}

	/** Returns the finding report relevant for this list. */
	private FindingReport getReport() {
		return NodeUtils.getFindingReport(NodeUtils.getRootNode(node));
	}

	/** {@inheritDoc} */
	@Override
	public int size() {
		return findingPaths.size();
	}

	/** {@inheritDoc} */
	@Override
	public Finding set(int index, Finding element) {
		CCSMPre.isTrue(
				element.getParent().getParent().getParent() == getReport(),
				"May only add findings located in the root report!");
		Finding result = get(index);
		findingPaths.set(index, new FindingPathDescriptor(element));
		return result;
	}

	/** {@inheritDoc} */
	@Override
	public void add(int index, Finding element) {
		CCSMPre.isTrue(
				element.getParent().getParent().getParent() == getReport(),
				"May only add findings located in the root report!");
		findingPaths.add(index, new FindingPathDescriptor(element));
	}

	/** {@inheritDoc} */
	@Override
	public Finding remove(int index) {
		Finding result = get(index);
		findingPaths.remove(index);
		return result;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Throws an exception as we do not support cloning at this level.
	 */
	public IRemovableConQATNode deepClone() {
		throw new UnsupportedOperationException(
				"Deep cloning not supported at this level.");
	}

	/** Finding descriptors. */
	private static final class FindingPathDescriptor {

		/** Description of the category. */
		private final String categoryName;

		/** Name of the group. */
		private final String groupName;

		/** Id of the finding. */
		private final int findingId;

		/** Constructor. */
		public FindingPathDescriptor(Finding finding) {
			findingId = finding.id;
			FindingGroup group = finding.getParent();
			groupName = group.getName();
			categoryName = group.getParent().getName();
		}

		/**
		 * Locates the finding identified by this path in the given report or
		 * returns <code>null</code> if it is not found.
		 */
		public Finding locateFinding(FindingReport report) {
			FindingCategory category = report.getCategory(categoryName);
			if (category == null) {
				return null;
			}
			FindingGroup group = category.getGroupByName(groupName);
			if (group == null) {
				return null;
			}
			return group.getFindingById(findingId);
		}
	}
}

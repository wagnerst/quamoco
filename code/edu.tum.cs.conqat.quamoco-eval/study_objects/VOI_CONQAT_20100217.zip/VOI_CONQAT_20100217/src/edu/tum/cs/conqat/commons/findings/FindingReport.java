/*--------------------------------------------------------------------------+
   $Id: FindingReport.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * A finding report is a collection of finding categories.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: F5043D9EBF7509A4D70B151835721CAB
 */
public class FindingReport extends ConQATNodeBase implements
		IRemovableConQATNode {

	/** The time this report was created. */
	private final Date time;

	/** The categories. */
	private final Map<String, FindingCategory> categories = new HashMap<String, FindingCategory>();

	/** Constructor. */
	public FindingReport() {
		this(new Date());
	}

	/** Constructor. */
	public FindingReport(Date time) {
		this.time = (Date) time.clone();
	}

	/** Copy constructor. */
	/* package */FindingReport(FindingReport other) throws DeepCloneException {
		super(other);
		this.time = (Date) other.time.clone();
		for (FindingCategory category : other.categories.values()) {
			categories.put(category.getName(), new FindingCategory(category,
					this));
		}
	}

	/** Returns the category with the given name or null. */
	public FindingCategory getCategory(String name) {
		return categories.get(name);
	}

	/**
	 * Returns the category with the given name or creates one using the finding
	 * and location types.
	 */
	public FindingCategory getOrCreateCategory(String name) {
		FindingCategory category = categories.get(name);
		if (category == null) {
			category = new FindingCategory(this, name);
			categories.put(name, category);
		}
		return category;
	}

	/** Returns the time when the report was created. */
	public Date getTime() {
		return time;
	}

	/** {@inheritDoc} */
	public FindingCategory[] getChildren() {
		return categories.values().toArray(
				new FindingCategory[categories.size()]);
	}

	/** {@inheritDoc} */
	public void remove() {
		// does nothing
	}

	/** Removes the given category. */
	/* package */void remove(FindingCategory findingCategory) {
		categories.remove(findingCategory.getName());
	}

	/** {@inheritDoc} */
	public String getId() {
		return getName();
	}

	/** {@inheritDoc} */
	public String getName() {
		return "";
	}

	/** {@inheritDoc} */
	public IConQATNode getParent() {
		return null;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !categories.isEmpty();
	}

	/** {@inheritDoc}. */
	public FindingReport deepClone() throws DeepCloneException {
		return new FindingReport(this);
	}

}

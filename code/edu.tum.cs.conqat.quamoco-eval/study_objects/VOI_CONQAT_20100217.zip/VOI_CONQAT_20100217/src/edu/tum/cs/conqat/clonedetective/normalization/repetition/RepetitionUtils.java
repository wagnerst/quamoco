/*--------------------------------------------------------------------------+
   $Id: RepetitionUtils.java 25971 2010-02-06 11:16:26Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.repetition;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.region.Region;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.StatementUnit;
import edu.tum.cs.conqat.clonedetective.core.TokenUnit;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.normalization.provider.ListBasedTokenProvider;
import edu.tum.cs.conqat.clonedetective.normalization.statement.StatementNormalization;
import edu.tum.cs.conqat.clonedetective.normalization.token.FilteringTokenProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.ITokenProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.TokenNormalization;
import edu.tum.cs.conqat.clonedetective.normalization.token.configuration.ITokenConfiguration;
import edu.tum.cs.conqat.clonedetective.normalization.token.configuration.TokenConfigurationDef;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.logging.IConQATLogger;
import edu.tum.cs.conqat.sourcecode.library.SourceCodeLibrary;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.scanner.IToken;

/**
 * Utility classes for repetition detection.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25971 $
 * @levd.rating GREEN Hash: 248C3E1052EB25DACEEF81DC64F37C60
 */
public class RepetitionUtils {

	/**
	 * Creates an array of the {@link StatementUnit}s of an element.
	 */
	public static StatementUnit[] getStatements(ISourceCodeElement element,
			IConQATLogger logger) throws ConQATException,
			CloneDetectionException {

		TokenNormalization normalization = createFullNormalizationFor(element,
				logger);
		StatementNormalization sequencer = new StatementNormalization(
				normalization, true);
		sequencer.init(element, logger);

		return drainStatementsOnly(sequencer).toArray(new StatementUnit[] {});
	}

	/** Creates a region for a repetition */
	public static Region regionFor(Repetition<StatementUnit> repetition) {
		int start = repetition.getStart().getStartOffset();
		int end = repetition.getEnd().getEndOffset();
		String origin = "repetition: motif length "
				+ repetition.getMotifLength();

		return new Region(start, end, origin);
	}

	/**
	 * Gets a provider for fully normalized {@link TokenUnit}s for an
	 * {@link ISourceCodeElement}
	 */
	public static TokenNormalization createFullNormalizationFor(
			ISourceCodeElement element, IConQATLogger logger)
			throws ConQATException {
		// set up token provider chain
		List<IToken> tokens = SourceCodeLibrary.getInstance()
				.getTokens(element);
		ITokenProvider rawTokenProvider = new ListBasedTokenProvider(tokens);
		ITokenProvider ignoreFilteredTokenProvider = new FilteringTokenProvider(
				rawTokenProvider);

		// set up and return normalization
		TokenNormalization normalization = new TokenNormalization(
				ignoreFilteredTokenProvider,
				new ArrayList<ITokenConfiguration>(),
				fullNormalizationConfiguration());
		normalization.init(element, logger);
		return normalization;
	}

	/** Creates an {@link ITokenConfiguration} with full normalization */
	private static ITokenConfiguration fullNormalizationConfiguration() {
		TokenConfigurationDef configuration = new TokenConfigurationDef();
		configuration.setAll();
		return configuration.process();
	}

	/**
	 * Drains the list of statements from a {@link StatementNormalization}. All
	 * non-statement units (i.e. sentinels) contained in the normalization are
	 * dropped.
	 */
	/* package */static List<StatementUnit> drainStatementsOnly(
			StatementNormalization normalization)
			throws CloneDetectionException {
		List<StatementUnit> statements = new ArrayList<StatementUnit>();
		Unit unit = normalization.getNext();
		while (unit != null) {
			if (unit instanceof StatementUnit) {
				statements.add((StatementUnit) unit);
			}
			unit = normalization.getNext();
		}
		return statements;
	}

}

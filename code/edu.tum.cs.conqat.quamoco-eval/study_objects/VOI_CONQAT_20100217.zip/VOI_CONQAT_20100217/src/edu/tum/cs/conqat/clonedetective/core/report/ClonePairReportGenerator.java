/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: ClonePairReportGenerator.java 25643 2010-01-26 16:39:00Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.util.Collection;
import java.util.Collections;

import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;

/**
 * Creates reports containing pairs of clone classes
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25643 $
 * @levd.rating GREEN Hash: DC0EAD4AFFB77F372833EA176281E1D0
 */
public class ClonePairReportGenerator extends PairReportGeneratorBase {

	/** {@inheritDoc} */
	@Override
	protected Collection<CloneClass> createPairClasses(
			ImmutablePair<Clone, Clone> clonePair) {

		CloneClass cloneClass = new CloneClass(clonePair.getFirst()
				.getCloneClass().getNormalizedLength(), idProvider.provideId());
		copyClone(clonePair.getFirst(), cloneClass);
		copyClone(clonePair.getSecond(), cloneClass);

		return Collections.singleton(cloneClass);
	}

	/**
	 * Create a copy of a clone with a fresh id.
	 * 
	 * @param cloneClass
	 *            {@link CloneClass} to which new clone gets added
	 */
	private Clone copyClone(Clone clone, CloneClass cloneClass) {
		String fingerPrint = "Fingerprint" + cloneClass.getId();
		Clone copy = new Clone(idProvider.provideId(), cloneClass, clone
				.getFile(), clone.getStartLineInFile(),
				clone.getLengthInFile(), clone.getStartUnitIndexInFile(), clone
						.getLengthInUnits(), fingerPrint, clone
						.getDeltaInUnits());
		copy.setBirth(clone.getBirth());
		if (CloneUtils.getUnits(clone) != null) {
			CloneUtils.setUnits(copy, CloneUtils.getUnits(clone));
		}

		return copy;
	}
}

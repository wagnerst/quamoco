/*--------------------------------------------------------------------------+
   $Id: ModifiedAfterConstraint.java 23875 2009-08-28 12:39:48Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import java.util.Date;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 23875 $
 * @levd.rating GREEN Hash: F1883B24CE62492782EC37023F42FEDA
 */
@AConQATProcessor(description = "Constraint that is only satisfied if the latest fingerprint modification"
		+ " occurred after a baseline date.")
public class ModifiedAfterConstraint extends DateConstraintBase {

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) {
		Date latestModification = cloneClass.getLatestModification();
		boolean satisfied = latestModification.after(baselineDate);
		return satisfied;
	}

}

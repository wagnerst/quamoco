package edu.tum.cs.conqat.commons.distributed;

import java.io.Serializable;

import edu.tum.cs.conqat.logging.ELogLevel;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Class used for storing log messages.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 25929 $
 * @levd.rating GREEN Hash: F1B629A89BF0E2FBF91569FE540ACC0B
 */
/* package */final class StoredLogMessage implements Serializable {

	/** The level. */
	private final ELogLevel level;

	/** The message (as string to be serializable). */
	private final String message;

	/** The exception (if any). */
	private final Throwable throwable;

	/** Constructor. */
	public StoredLogMessage(ELogLevel level, Object message, Throwable throwable) {
		this.level = level;
		if (message == null) {
			this.message = null;
		} else {
			this.message = message.toString();
		}
		this.throwable = throwable;
	}

	/**
	 * Logs the contents of a stored message to a logger.
	 * 
	 * @param loggingPrefix
	 *            a string prepended to each message before logging.
	 */
	public void logTo(IConQATLogger logger, String loggingPrefix) {
		if (throwable == null) {
			logger.log(level, loggingPrefix + message);
		} else {
			logger.log(level, loggingPrefix + message, throwable);
		}
	}
}
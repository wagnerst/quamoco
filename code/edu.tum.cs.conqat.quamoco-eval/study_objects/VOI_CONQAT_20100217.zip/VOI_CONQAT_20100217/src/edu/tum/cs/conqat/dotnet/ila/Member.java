/*--------------------------------------------------------------------------+
   $Id: Member.java 24147 2009-09-11 09:07:41Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.ila;

/**
 * Value object that stores IL code member information. This class is immutable.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 24147 $
 * @levd.rating GREEN Hash: 622FA2B109C47FC13F61DA1C8F00A9F7
 */
public class Member {

	/** Member name */
	private final String name;

	/** Member type */
	private final String type;

	/** Member visibility */
	private final String visibility;

	/** Abstract modifier of member */
	private final boolean isAbstract;

	/** Member metadata token */
	private final String token;

	/** Number of il statements of the member */
	private final int numberIlStatements;

	/** Constructor */
	public Member(String name, String type, String visibility,
			boolean isAbstract, String token, int numberIlStatements) {
		this.name = name;
		this.type = type;
		this.visibility = visibility;
		this.isAbstract = isAbstract;
		this.token = token;
		this.numberIlStatements = numberIlStatements;
	}

	/** Returns true, if member is a method. */
	public boolean isMethod() {
		return "Method".equals(type);
	}

	/** Returns true, if member is a constructor. */
	public boolean isConstructor() {
		return "Constructor".equals(type) || "StaticConstructor".equals(type);
	}

	/**
	 * Returns true, if member is callable, i.e. either a method or a
	 * constructor
	 */
	public boolean isCallable() {
		return isMethod() || isConstructor();
	}

	/** Returns name. */
	public String getName() {
		return name;
	}

	/** Returns type. */
	public String getType() {
		return type;
	}

	/** Returns visibility. */
	public String getVisibility() {
		return visibility;
	}

	/** Returns isAbstract */
	public boolean isAbstract() {
		return isAbstract;
	}

	/** Returns token. */
	public String getToken() {
		return token;
	}

	/** Returns numberIlStatements. */
	public int getNumberIlStatements() {
		return numberIlStatements;
	}

	/** Returns name. */
	@Override
	public String toString() {
		return name;
	}

}
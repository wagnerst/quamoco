/*--------------------------------------------------------------------------+
   $Id: LogFileWriter.java 16780 2008-06-20 16:56:44Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope;

import java.io.File;
import java.util.List;

import edu.tum.cs.commons.factory.IParameterizedFactory;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.scope.project.ProjectFileParser;
import edu.tum.cs.conqat.filesystem.scope.FileSystemElement;
import edu.tum.cs.conqat.filesystem.scope.FileSystemElementFactory;

/**
 * Creates a source code scope of the files contained in one single VS.NET
 * solution file. If any file is contained in multiple included projects, it
 * only occurs once in the scope.
 * <p>
 * Currently, only a single language is supported for the entire scope.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: feilkas $
 * @version $Rev: 22568 $
 * @levd.rating GREEN Hash: 7B459D9B29CA5073636BC02389D95E8B
 */
@AConQATProcessor(description = "Creates an assembly file scope and collects the"
		+ " assemblies contained in one single VS.NET solution file. ")
public class SolutionAssemblyScope extends SolutionScopeBase<FileSystemElement> {

	/** The default name of the build configuration */
	public static final String DEFAULT_CONFIGURATION_NAME = "Debug";

	/** The platform used by default */
	public static final String DEFAULT_PLATFORM = "AnyCPU";

	/** The build configuration that is used to compile the projects */
	private BuildConfiguration configuration = new BuildConfiguration(
			DEFAULT_CONFIGURATION_NAME, DEFAULT_PLATFORM);

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "build-configuration", description = "The configuration used to build the solution", minOccurrences = 0, maxOccurrences = 1)
	public void setConfiguration(
			@AConQATAttribute(name = "name", defaultValue = DEFAULT_CONFIGURATION_NAME, description = "Name of the configuration, e.g. 'Debug' or 'Release'") String configurationName,
			@AConQATAttribute(name = "platform", defaultValue = DEFAULT_PLATFORM, description = "Name of the platform, e.g. 'AnyCPU'") String platformName) {
		configuration = new BuildConfiguration(configurationName, platformName);
	}

	/**
	 * {@inheritDoc}. This method is required since ConQAT does not support type
	 * checking on generics.
	 */
	@Override
	public FileSystemElement process() throws ConQATException {
		return super.process();
	}

	/** Template method that extracts the assembly filenames from a project file */
	@Override
	List<String> extractRelevantFilesFromProject(File projectFile,
			ProjectFileParser projectParser) throws ConQATException {
		return projectParser
				.extractAssemblyFilename(projectFile, configuration);
	}

	/** {@inheritDoc} */
	@Override
	protected IParameterizedFactory<FileSystemElement, String, ConQATException> createElementFactory() {
		return new FileSystemElementFactory(encoding);
	}

}

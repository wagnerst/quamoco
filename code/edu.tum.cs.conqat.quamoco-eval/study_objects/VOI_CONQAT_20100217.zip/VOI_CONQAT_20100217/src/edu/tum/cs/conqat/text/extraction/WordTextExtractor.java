package edu.tum.cs.conqat.text.extraction;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hwpf.extractor.WordExtractor;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * @version $Rev: 25896 $
 * @levd.rating GREEN Hash: 8CD43033F99CD3D3AF6F51F7DC6F6BDC
 */
@AConQATProcessor(description = "Extracts text from word documents."
		+ "For each file in the input scope, an equally named file with suffix '.txt' "
		+ "is created that contains the extracted text.")
public class WordTextExtractor extends
		NodeTraversingProcessorBase<IFileSystemElement> {

	/** If set to true, each a newline is inserted after each dot. */
	private boolean wrapAtDot = false;

	/** If set to true, each a newline is inserted after each whitespace block. */
	private boolean wrapAtWhitespace = false;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "wrap-at-dot", description = "If set to true, each a newline is inserted after each dot", minOccurrences = 0, maxOccurrences = 1)
	public void setWrapAtDot(
			@AConQATAttribute(name = "value", description = "Default is false") boolean wrapAtDot) {
		this.wrapAtDot = wrapAtDot;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "wrap-at-whitespace", description = "If set to true, each a newline is inserted after each whitespace block.", minOccurrences = 0, maxOccurrences = 1)
	public void setWrapAtWhitespace(
			@AConQATAttribute(name = "value", description = "Default is false") boolean wrapAtWhitespace) {
		this.wrapAtWhitespace = wrapAtWhitespace;
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** {@inheritDoc} */
	public void visit(IFileSystemElement node) throws ConQATException {
		InputStream in = null;
		try {
			CanonicalFile sourceFile = node.getFile();
			if (!sourceFile.isFile()) {
				throw new ConQATException("Input is not a valid word file: "
						+ sourceFile);
			}

			getLogger().info("Extracting text from file: " + sourceFile);

			in = new FileInputStream(sourceFile);
			String text = extractText(in);

			if (wrapAtDot) {
				text = text.replaceAll("[.]", "." + StringUtils.CR);
			}

			if (wrapAtWhitespace) {
				text = text.replaceAll("\\s+", StringUtils.CR);
			}

			File targetFile = new File(sourceFile.getCanonicalPath() + ".txt");
			FileSystemUtils.writeFile(targetFile, text);
		} catch (IOException e) {
			handleException(e, node);
		} finally {
			FileSystemUtils.close(in, getLogger());
		}

	}

	/** Extract text from word file */
	private String extractText(InputStream in) throws IOException {
		WordExtractor extractor = new WordExtractor(in);
		String[] pars = extractor.getParagraphText();
		return StringUtils.concat(pars, StringUtils.CR);
	}

	/** Wrap exception into {@link ConQATException} */
	private void handleException(Throwable e, IFileSystemElement node) {
		getLogger().warn(
				"Problems extracting word text: "
						+ node.getFile().getCanonicalPath(), e);
	}

}

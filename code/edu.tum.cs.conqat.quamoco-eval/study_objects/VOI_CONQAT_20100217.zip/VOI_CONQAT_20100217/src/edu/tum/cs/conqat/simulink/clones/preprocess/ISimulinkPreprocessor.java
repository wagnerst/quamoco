/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.simulink
 |                                                                       |
   $Id: ISimulinkPreprocessor.java 26079 2010-02-15 10:54:54Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.clones.preprocess;

import java.util.Set;

import edu.tum.cs.commons.clone.IDeepCloneable;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.model_clones.detection.util.ICloneReporter;
import edu.tum.cs.conqat.simulink.clones.normalize.ISimulinkNormalizer;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * Interface of strategies which may preprocess a Simulink model prior to clone
 * detection. The preprocessing phase may also report clones.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 26079 $
 * @levd.rating YELLOW Hash: F9F83B5B8D652521FDEC21752625507D
 */
public interface ISimulinkPreprocessor extends IDeepCloneable {

	/**
	 * Performs preprocessing.
	 * 
	 * @param model
	 *            the model to preprocess. The model may be modified as a
	 *            result, however instead of deletions, it is better to add
	 *            blocks to the ignore list.
	 * @param normalizer
	 *            the normalization applied.
	 * @param ignoredBlocks
	 *            the set of blocks which should be ignored. This set serves as
	 *            both input and output.
	 * @param reporter
	 *            a reporter through which any clones found may be reported.
	 */
	void preprocess(ISimulinkElement model, ISimulinkNormalizer normalizer,
			Set<SimulinkBlock> ignoredBlocks, ICloneReporter reporter)
			throws ConQATException;
}

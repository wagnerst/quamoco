/*--------------------------------------------------------------------------+
   $Id: ConQATBundleNode.java 23503 2009-08-07 16:17:42Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.self;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.bundle.BundleInfo;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * A node representing a single ConQAT bundle.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23503 $
 * @levd.rating GREEN Hash: 968FE20F672BBCC9E773C86FEA49620A
 */
public class ConQATBundleNode extends ConQATNodeBase implements
		IRemovableConQATNode {

	/** The parent node. */
	private ConQATInstallationRoot parent;

	/** Info on the underlying bundle. */
	private final BundleInfo bundleInfo;

	/** Create new bundle node. */
	/* package */ConQATBundleNode(BundleInfo bundleInfo) {
		this.bundleInfo = bundleInfo;
	}

	/** Copy constructor. */
	protected ConQATBundleNode(ConQATBundleNode node) throws DeepCloneException {
		super(node);
		this.bundleInfo = node.bundleInfo;
	}

	/** Name string is revision. */
	public String getName() {
		return getId();
	}

	/** Returns the revision number. */
	public String getId() {
		return bundleInfo.getId();
	}

	/** {@inheritDoc} */
	public ConQATBundleNode deepClone() throws DeepCloneException {
		return new ConQATBundleNode(this);
	}

	/** Returns <code>null</code>. */
	public IRemovableConQATNode[] getChildren() {
		return null;
	}

	/** {@inheritDoc} */
	public void remove() {
		if (parent != null) {
			parent.removeNode(this);
		}
	}

	/** {@inheritDoc} */
	public ConQATInstallationRoot getParent() {
		return parent;
	}

	/** Returns <code>false</code>. */
	public boolean hasChildren() {
		return false;
	}

	/** Set the parent node. */
	/* package */void setParent(ConQATInstallationRoot parent) {
		this.parent = parent;
	}

	/** Returns the contained bundle info. */
	public BundleInfo getBundleInfo() {
		return bundleInfo;
	}
}

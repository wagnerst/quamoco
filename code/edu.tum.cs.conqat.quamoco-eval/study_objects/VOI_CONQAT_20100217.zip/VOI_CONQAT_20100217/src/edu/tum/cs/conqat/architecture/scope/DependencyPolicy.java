/*--------------------------------------------------------------------------+
   $Id: DependencyPolicy.java 23504 2009-08-07 16:20:27Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.scope;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.commons.collections.UnmodifiableSet;
import edu.tum.cs.conqat.architecture.format.EAssessmentType;
import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * This describes the policy for dependencies between two components. This class
 * also can store actual dependencies and assessments.
 * 
 * @author Tilman Seifert
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23504 $
 * @levd.rating GREEN Hash: 1D6EC0F296E2B1A7B8E117D90F7529AA
 */
public class DependencyPolicy {

	/**
	 * Maps from tolerated source IDs to lists of target IDs. We use a list map,
	 * although a set would be better for lookup, as we expect the number of
	 * tolerations to be relatively low.
	 */
	private final HashedListMap<String, String> tolerations = new HashedListMap<String, String>();

	/** The dependencies stored as string pairs (source and target IDs). */
	private final Set<ImmutablePair<String, String>> dependencies = new HashSet<ImmutablePair<String, String>>();

	/** Source component. */
	private final ComponentNode source;

	/** Target component. */
	private final ComponentNode target;

	/** Policy type. */
	private final EPolicyType policyType;

	/** The assessment type for this policy. */
	private EAssessmentType assessment = null;

	/** Create new policy. */
	/* package */DependencyPolicy(ComponentNode from, ComponentNode to,
			EPolicyType policyType) {
		if (from == null || to == null) {
			throw new IllegalArgumentException("Nodes must not be null");
		}
		if (from == to) {
			throw new IllegalArgumentException("No self loops allowed!");
		}

		this.source = from;
		this.target = to;
		this.policyType = policyType;
	}

	/**
	 * Copy constructor using another DependencyPolicy as reference but new from
	 * and to components. Used for cloning component node hierarchies.
	 */
	/* package */DependencyPolicy(DependencyPolicy depPolicy,
			ComponentNode newFrom, ComponentNode newTo) {
		this(newFrom, newTo, depPolicy.policyType);

		this.dependencies.addAll(depPolicy.dependencies);
		this.assessment = depPolicy.assessment;

		for (String key : depPolicy.tolerations.getKeys()) {
			this.tolerations.addAll(key, depPolicy.tolerations.getList(key));
		}
	}

	/** Returns the source for the policy. */
	public ComponentNode getSource() {
		return source;
	}

	/** Returns the policy. */
	public EPolicyType getPolicyType() {
		return policyType;
	}

	/** Returns the target for the policy. */
	public ComponentNode getTarget() {
		return target;
	}

	/** Adds a Toleration to the list */
	public void addToleration(String sourceId, String targetId) {
		tolerations.add(sourceId, targetId);
	}

	/** Returns true, if the dependency from sourceId to targetId is tolerated. */
	public boolean tolerated(String sourceId, String targetId) {
		List<String> toleratedFromSource = tolerations.getList(sourceId);
		return toleratedFromSource != null
				&& toleratedFromSource.contains(targetId);
	}

	/** Insert this policy into the referenced components. */
	/* package */void registerWithComponents() throws ConQATException {
		source.addPolicy(this);
		target.addPolicy(this);
	}

	/** Adds a dependency for this policy. */
	public void addDependency(String source, String target) {
		dependencies.add(new ImmutablePair<String, String>(source, target));
	}

	/** Returns the assessment type (may be null if not yet set). */
	public EAssessmentType getAssessment() {
		return assessment;
	}

	/** Sets the assessment type. */
	public void setAssessment(EAssessmentType assessment) {
		this.assessment = assessment;
	}

	/** Returns the dependencies. */
	public UnmodifiableSet<ImmutablePair<String, String>> getDependencies() {
		return CollectionUtils.asUnmodifiable(dependencies);
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return getSource().getName() + " -> " + getTarget().getName();
	}
}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.architecture
 |                                                                       |
   $Id$            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.format;

/**
 * Represents the type of a stereotype for components.
 * 
 * @author heineman
 * @author $Author$
 * @version $Rev$
 * @levd.rating GREEN Hash: 6D6027D202F46D387DFD077BB20D8B51
 */
public enum EStereotype {

	/** a normal component */
	NONE,

	/** a component that may be accessed from every component within its parent */
	PUBLIC;
}

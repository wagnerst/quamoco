/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingTypeSpec.java 25450 2010-01-26 10:00:39Z heineman $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.typespec;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableSet;
import edu.tum.cs.commons.string.StringUtils;

/**
 * A finding type spec is basically just a set of key name/type entries and
 * supports additional convenience method for (de)serialization.
 * 
 * @author hummelb
 * @author $Author: heineman $
 * @version $Rev: 25450 $
 * @levd.rating GREEN Hash: 1A66FDAC4AD8D8ECAED4D0B3F35AAC5C
 */
public class FindingTypeSpec {

	/** The entries. */
	private final Set<FindingTypeSpecEntry> entries = new HashSet<FindingTypeSpecEntry>();

	/** Constructor. */
	public FindingTypeSpec(FindingTypeSpecEntry... entries) {
		this.entries.addAll(Arrays.asList(entries));
	}

	/** Constructor for deserialization (inverse of {@link #toString()}). */
	public FindingTypeSpec(String serialized) {
		for (String format : serialized.split("[,]")) {
			entries.add(new FindingTypeSpecEntry(format));
		}
	}

	/** Returns the entries. */
	public UnmodifiableSet<FindingTypeSpecEntry> getEntries() {
		return CollectionUtils.asUnmodifiable(entries);
	}

	/** Adds an entry. */
	public void addEntry(FindingTypeSpecEntry entry) {
		entries.add(entry);
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return StringUtils.concat(entries, ",");
	}
}

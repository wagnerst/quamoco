/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: RepetitionParameters.java 25659 2010-01-26 17:52:57Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.repetition;

import java.io.Serializable;

import edu.tum.cs.conqat.core.ConQATException;

/**
 * Parameter object that stores repetition detection parameters.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 25659 $
 * @levd.rating GREEN Hash: 05B6800EF71B8D058B5B85EC377A680B
 */
public class RepetitionParameters implements Serializable {

	/** Minimal length of repetition in units */
	private final int minLength;

	/** Length of shortest repetition motif being searched for */
	private final int minMotifLength;

	/** Length of longest repetition motif being searched for */
	private final int maxMotifLength;

	/** Minimal required number of motive instances in repetition */
	private final int minMotifInstances;

	/**
	 * Constructor.
	 * 
	 * @throws ConQATException
	 *             if values are invalid
	 **/
	public RepetitionParameters(int minLength, int minMotifLength,
			int maxMotifLength, int minMotifInstances) throws ConQATException {

		check(minLength > 0, "Repetition min length must be > 0!");
		check(minMotifLength > 0, "Repetition min motif length must be > 0!");
		check(maxMotifLength >= minMotifLength,
				"Repetition max motif length must be > min motig length!");
		check(minMotifInstances >= 2,
				"Repetition min motif instances must ne >= 2!");

		this.minLength = minLength;
		this.minMotifLength = minMotifLength;
		this.maxMotifLength = maxMotifLength;
		this.minMotifInstances = minMotifInstances;
	}

	/** Throws a {@link ConQATException}, if a condition is violated */
	private void check(boolean condition, String exceptionMessage)
			throws ConQATException {
		if (!condition) {
			throw new ConQATException(exceptionMessage);
		}
	}

	/** Returns minimal length of repetition in units */
	public int getMinLength() {
		return minLength;
	}

	/** Returns length of shortest repetition motif being searched for */
	public int getMinMotifLength() {
		return minMotifLength;
	}

	/** Returns length of longest repetition motif being searched for */
	public int getMaxMotifLength() {
		return maxMotifLength;
	}

	/** Returns minimal required number of motive instances in repetition */
	public int getMinMotifInstances() {
		return minMotifInstances;
	}

}
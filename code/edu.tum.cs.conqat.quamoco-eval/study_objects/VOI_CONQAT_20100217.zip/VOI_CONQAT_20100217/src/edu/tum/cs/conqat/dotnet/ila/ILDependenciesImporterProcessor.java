/*--------------------------------------------------------------------------+
   $Id: ILDependenciesImporterProcessor.java 24193 2009-09-15 07:50:36Z feilkas $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.ila;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * {@ConQAT.Doc}
 * 
 * @see ILAnalyzerRunnerProcessor
 * 
 * @author Elmar Juergens
 * @author $Author: feilkas $
 * 
 * @version $Revision: 24193 $
 * @levd.rating GREEN Hash: 909FD4A70235B4E6D27FA24E0071E737
 */
@AConQATProcessor(description = "Reads dependency information stored in XML produced by the Intermediate"
		+ "Language Analyzer files into a representation that can be used for"
		+ "architecture assessment."
		+ "In contrast to Java, where class files closely resemble package structure,"
		+ "the mapping between code and assemblies is a lot more arbitrary in the .NET"
		+ "world. In order to map types found in IL to source files, debug information"
		+ "is required that is not always available."
		+ "This processor is hence NO pipeline processor that annotates a source tree"
		+ "with dependency information. Instead, it parses all ILA XML files located"
		+ "under a root IFileSystemElement and returns a very simple rooted list"
		+ "of types and dependencies that can be used to create a dependency graph.")
public class ILDependenciesImporterProcessor extends ConQATProcessorBase
		implements INodeVisitor<IFileSystemElement, ConQATException> {

	/** Key under which the dependencies are stored */
	@AConQATKey(description = "Key under which the dependencies are stored", type = "java.util.List<String>")
	public static final String DEPENDENCIES = "Dependency List";

	/** Key under which members are stored */
	@AConQATKey(description = "Key under which the members are stored", type = "java.util.List<String>")
	public static final String MEMBERS = "Members";

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Key under which assembly name is stored.", type = "java.lang.String")
	public static final String ASSEMBLY_NAME = "AssemblyName";

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Key under which metadata token is stored.", type = "java.lang.String")
	public static final String TOKEN = "Token";

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Key under which name is stored.", type = "java.lang.String")
	public static final String NAME = "Name";

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Key under which type is stored.", type = "java.lang.String")
	public static final String TYPE = "Type";

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Key under which declaration type (class, interface, ...) is stored.", type = "java.lang.String")
	public static final String DECLTYPE = "DeclType";

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Key under which the number of IL statement is stored.", type = "int")
	public static final String IL_STATEMENT_COUNT = "IlStatementCount";

	/**
	 * Root of the directory tree that contains the XML files containing IL
	 * information that serve as input for this processor.
	 */
	private IFileSystemElement root;

	/** Root of the result tree containing dependency information */
	private ListNode outputRoot;

	/** Dependencies that match the ignore pattern are thrown away. */
	private PatternList ignorePatterns = new PatternList();

	/** Dependencies in types whose base type matches are ignored */
	private PatternList ignoreBaseTypePatterns = new PatternList();

	/**
	 * If this pattern list is set, only dependencies that match one of these
	 * patterns are included. (Mainly useful for debugging purposes to
	 * temporarily reduce the amount dependencies.)
	 */
	private PatternList includePatterns = null;

	/** Set that stores all dependencies that have been imported */
	private final Set<String> allDependencies = new HashSet<String>();

	/** If this string is set, all dependencies are written to this file */
	private String dependenciesFilename;

	/**
	 * Flag that determines whether to ignore types generated by the compiler.
	 * Default value is true.
	 */
	private boolean ignoreSynthetic = true;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = "File system tree that contains ILA XML files.", minOccurrences = 1, maxOccurrences = 1)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IFileSystemElement root) {
		this.root = root;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "ignore", description = "Dependencies that match the ignore patterns are thrown away", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnorePatterns(
			@AConQATAttribute(name = "patterns", description = "Regular expressions") PatternList ignorePatterns) {
		this.ignorePatterns = ignorePatterns;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "ignore-basetype", description = "If set, types whose base class matches one of these patters are ignored", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnoreBaseTypePatterns(
			@AConQATAttribute(name = "patterns", description = "Regular expressions") PatternList ignoreBaseTypePatterns) {
		this.ignoreBaseTypePatterns = ignoreBaseTypePatterns;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "include", description = ""
			+ "If this pattern list is set, only dependencies matching one of the patterns are included."
			+ "Mainly useful for debugging", minOccurrences = 0, maxOccurrences = 1)
	public void setIncludePatterns(
			@AConQATAttribute(name = "patterns", description = "Regular expressions") PatternList includePatterns) {
		this.includePatterns = includePatterns;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.PREDECESSOR_NAME, description = ConQATParamDoc.PREDECESSOR_NAME_DESC)
	public void addPredecessor(
			@SuppressWarnings("unused") @AConQATAttribute(name = ConQATParamDoc.PREDECESSOR_REF_NAME, description = ConQATParamDoc.PREDECESSOR_REF_DESC) Object predecessor) {
		// do nothing
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "debug-dependencies", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "If this filename is set, all imported dependencies are written to this file in alphabetical order. Maily useful for testing purposes.")
	public void setDependenciesFilename(
			@AConQATAttribute(name = "filename", description = "Name of dependencies file.") String dependenciesFilename) {
		this.dependenciesFilename = dependenciesFilename;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "ignore-synthetic", description = "Flag that determines whether to ignore types generated by the compiler. Default value is true.", minOccurrences = 0, maxOccurrences = 1)
	public void setIgnoreSynthetic(
			@AConQATAttribute(name = "value", description = "Default value is true") boolean ignoreSynthetic) {
		this.ignoreSynthetic = ignoreSynthetic;
	}

	/** Read dependencies from all IL-XML files */
	public ListNode process() throws ConQATException {
		outputRoot = new ListNode();
		TraversalUtils.visitLeavesDepthFirst(this, root);

		NodeUtils.addToDisplayList(outputRoot, DEPENDENCIES, MEMBERS, DECLTYPE,
				IL_STATEMENT_COUNT);

		if (isWriteDependenciesFile()) {
			writeDependenciesFile();
		}

		return outputRoot;
	}

	/** Determines whether to write a dependencies file */
	private boolean isWriteDependenciesFile() {
		return dependenciesFilename != null;
	}

	/**
	 * Writes the sorted list of all imported dependencies into the file named
	 * {@link #dependenciesFilename}
	 */
	private void writeDependenciesFile() throws ConQATException {
		String content = StringUtils.concat(CollectionUtils
				.sort(allDependencies), StringUtils.CR);
		try {
			FileSystemUtils.writeFile(new File(dependenciesFilename), content);
		} catch (IOException e) {
			throw new ConQATException("Could not write dependencies file", e);
		}
	}

	/**
	 * Read dependencies from a single IL-XML file
	 */
	public void visit(IFileSystemElement element) {
		if (element.getFile().isFile()) {
			IlaXmlReader xmlReader = new IlaXmlReader(element.getFile(),
					outputRoot, ignorePatterns, includePatterns,
					ignoreBaseTypePatterns, ignoreSynthetic);

			try {
				xmlReader.parse();
			} catch (ConQATException ex) {
				getLogger().error(
						"Could not parse file: " + element.getFile() + ": "
								+ ex.getMessage());
				return;
			}

			if (isWriteDependenciesFile()) {
				allDependencies.addAll(xmlReader.getAllDependencies());
			}

		}
	}

}

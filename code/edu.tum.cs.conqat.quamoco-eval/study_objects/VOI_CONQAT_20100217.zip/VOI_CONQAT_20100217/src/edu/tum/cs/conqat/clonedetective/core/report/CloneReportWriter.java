/*--------------------------------------------------------------------------+
   $Id: CloneReportWriter.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.deltaInUnits;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.fingerprint;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.id;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.length;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.lengthInUnits;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.lineCount;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.normalizedLength;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.path;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.sourceFileId;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.startLine;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.startUnitIndexInFile;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.systemdate;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.xmlns;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportElement.cloneReport;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportElement.sourceFile;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportElement.value;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportElement.values;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.xml.IXMLResolver;
import edu.tum.cs.commons.xml.XMLWriter;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.KeyValueStoreBase;
import edu.tum.cs.conqat.clonedetective.core.utils.ECloneClassComparator;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Output class for the XML format clone reports.
 * 
 * @author Florian Deissenboeck
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 19424A4D58312D524E2AB385550A9989
 */
public class CloneReportWriter {

	/** Pattern used to write dates to string */
	public static final String DATE_PATTERN = "yyyy.MM.dd HH:mm:ss:SSSZ";

	/** XMLWriter that performs the XML processing */
	private final XMLWriter<ECloneReportElement, ECloneReportAttribute> writer;

	/**
	 * Method object method: Creates a {@link CloneReportWriter} and writes a
	 * clone report file.
	 * 
	 * @param cloneClasses
	 *            Result clone classes that get written to the report
	 * 
	 * @param sourceFileDescriptorsMap
	 *            Map that maps from source file name to the corresponding
	 *            {@link SourceFileDescriptor}
	 * @param targetFile
	 *            File into which report gets written
	 * 
	 * @throws ConQATException
	 *             If report creation fails.
	 */
	public static void writeReport(List<CloneClass> cloneClasses,
			Map<CanonicalFile, SourceFileDescriptor> sourceFileDescriptorsMap,
			Date systemDate, File targetFile) throws ConQATException {
		try {
			CloneReportWriter writer = new CloneReportWriter(targetFile);
			writer.writeReport(cloneClasses, sourceFileDescriptorsMap,
					systemDate);
		} catch (IOException e) {
			throw new ConQATException("Could not write report: "
					+ e.getMessage());
		}
	}

	/** Private constructor to enforce use of static method */
	private CloneReportWriter(File targetFile) throws IOException {
		FileSystemUtils.ensureParentDirectoryExists(targetFile);
		writer = new XMLWriter<ECloneReportElement, ECloneReportAttribute>(
				new PrintStream(targetFile, FileSystemUtils.UTF8_ENCODING),
				new CloneReportResolver());
	}

	/** Create XML clone reports. */
	private void writeReport(List<CloneClass> cloneClasses,
			Map<CanonicalFile, SourceFileDescriptor> sourceFileDescriptorsMap,
			Date systemDate) {

		writer.addHeader("1.0", FileSystemUtils.UTF8_ENCODING);
		writer.openElement(cloneReport);
		writer.addAttribute(xmlns, "http://conqat.cs.tum.edu/ns/clonereport");
		if (systemDate != null) {
			writer.addAttribute(systemdate, new SimpleDateFormat(DATE_PATTERN)
					.format(systemDate));
		}

		// source files
		writeSourceFileDescriptors(sourceFileDescriptorsMap.values());
		// clone classes
		Collections.sort(cloneClasses, ECloneClassComparator.NORMALIZED_LENGTH);
		for (CloneClass cloneClass : cloneClasses) {
			writeCloneClass(cloneClass, sourceFileDescriptorsMap);
		}

		writer.closeElement(cloneReport);
		writer.close();
	}

	/** Writes a clone class to xml */
	private void writeCloneClass(CloneClass cloneClass,
			Map<CanonicalFile, SourceFileDescriptor> sourceFileDescriptorsMap) {
		writer.openElement(ECloneReportElement.cloneClass);
		writer.addAttribute(normalizedLength, cloneClass.getNormalizedLength());
		writer.addAttribute(id, cloneClass.getId());
		writer.addAttribute(fingerprint, cloneClass.getFingerprint());

		writeValues(cloneClass);

		for (Clone clone : cloneClass.getClones()) {
			writeClone(clone, sourceFileDescriptorsMap);
		}

		writer.closeElement(ECloneReportElement.cloneClass);
	}

	/** Writes stored values to xml */
	private void writeValues(KeyValueStoreBase store) {
		writer.openElement(values);

		for (String key : store.getKeyList()) {
			if (!store.getTransient(key)) {
				Object valueObject = store.getValue(key);
				CCSMAssert.isNotNull(valueObject, "Value stored under key "
						+ key + " is null");

				writer.openElement(value);

				writer.addAttribute(ECloneReportAttribute.key, key);
				writer.addAttribute(ECloneReportAttribute.value, valueObject);
				writer.addAttribute(ECloneReportAttribute.type, valueObject
						.getClass().getName());

				writer.closeElement(value);
			}
		}

		writer.closeElement(values);
	}

	/** Writes a clone to xml */
	private void writeClone(Clone clone,
			Map<CanonicalFile, SourceFileDescriptor> sourceFileDescriptorsMap) {
		writer.openElement(ECloneReportElement.clone);

		writer.addAttribute(id, clone.getId());
		writer.addAttribute(lineCount, clone.getLengthInFile());
		writer.addAttribute(fingerprint, clone.getFingerprint());
		writer.addAttribute(startLine, clone.getStartLineInFile());

		writer.addAttribute(sourceFileId, getSourceFileId(clone,
				sourceFileDescriptorsMap));
		writer.addAttribute(startUnitIndexInFile, clone
				.getStartUnitIndexInFile());
		writer.addAttribute(lengthInUnits, clone.getLengthInUnits());
		writer.addAttribute(deltaInUnits, clone.getDeltaInUnits());

		String gapString = ReportUtils.createGapOffsetString(clone);
		writer.addAttribute(ECloneReportAttribute.gaps, gapString);

		writeValues(clone);

		writer.closeElement(ECloneReportElement.clone);
	}

	/** Retrieves the source file id for a clone. */
	private int getSourceFileId(Clone clone,
			Map<CanonicalFile, SourceFileDescriptor> sourceFileDescriptorsMap) {
		CanonicalFile origin = clone.getFile();

		SourceFileDescriptor descriptor = sourceFileDescriptorsMap.get(origin);
		CCSMAssert.isNotNull(descriptor, "Inconsistent clone data: origin "
				+ origin + "unknown.");

		return descriptor.getId();
	}

	/** Write source file descriptor to xml */
	private void writeSourceFileDescriptors(
			Collection<SourceFileDescriptor> sourceFileDescriptors) {
		for (SourceFileDescriptor sourceFileInfo : sourceFileDescriptors) {
			writer.openElement(sourceFile, id, sourceFileInfo.getId(), path,
					sourceFileInfo.getFile().getCanonicalPath(), length,
					sourceFileInfo.getLength(), fingerprint, sourceFileInfo
							.getFingerprint());
			writer.closeElement(sourceFile);
		}
	}

	/** This class defines the xml format for clone detection result reports. */
	private class CloneReportResolver implements
			IXMLResolver<ECloneReportElement, ECloneReportAttribute> {

		/** {@inheritDoc} */
		public Class<ECloneReportAttribute> getAttributeClass() {
			return ECloneReportAttribute.class;
		}

		/** {@inheritDoc} */
		public String resolveAttributeName(ECloneReportAttribute attribute) {
			return attribute.name();
		}

		/** {@inheritDoc} */
		public String resolveElementName(ECloneReportElement element) {
			return element.name();
		}

	}

}

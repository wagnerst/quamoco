/*--------------------------------------------------------------------------+
   $Id: ERenderMode.java 25571 2010-01-26 13:45:39Z heineman $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.output;

import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.architecture.format.EAssessmentType;
import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.architecture.scope.DependencyPolicy;

/**
 * The mode used for rendering.
 * 
 * @author hummelb
 * @author $Author: heineman $
 * @version $Rev: 25571 $
 * @levd.rating GREEN Hash: D2A7D04FBFB1422E5A03A22109FD9702
 */
public enum ERenderMode {

	/** Renders plain policies. */
	POLICIES,

	/** Renders assessments (red, yellow, green). */
	ASSESSMENT,

	/** Renders violations only (red). */
	VIOLATIONS,

	/** Renders violations and tolerations (red, yellow). */
	VIOLATIONS_AND_TOLERATIONS;

	/**
	 * Returns whether a policy should be included when using this render mode.
	 */
	public boolean includePolicy(DependencyPolicy edge) {
		switch (this) {
		case POLICIES:
			return edge.getPolicyType() != EPolicyType.ALLOW_IMPLICIT
					&& edge.getPolicyType() != EPolicyType.DENY_IMPLICIT;
		case VIOLATIONS:
			return edge.getAssessment() == EAssessmentType.INVALID;
		case VIOLATIONS_AND_TOLERATIONS:
			return edge.getAssessment() == EAssessmentType.INVALID
					|| edge.getPolicyType() == EPolicyType.TOLERATE;
		default:
			return true;
		}
	}

	/** Returns the traffic light color used for a policy. */
	public ETrafficLightColor determineColor(DependencyPolicy edge) {
		if (this == POLICIES) {
			return edge.getPolicyType().toTrafficLightColor();
		}

		if (edge.getAssessment() == null) {
			return ETrafficLightColor.UNKNOWN;
		}
		if (edge.getAssessment() == EAssessmentType.INVALID) {
			return ETrafficLightColor.RED;
		}
		if (edge.getPolicyType() == EPolicyType.TOLERATE) {
			return ETrafficLightColor.YELLOW;
		}

		return ETrafficLightColor.GREEN;
	}
}
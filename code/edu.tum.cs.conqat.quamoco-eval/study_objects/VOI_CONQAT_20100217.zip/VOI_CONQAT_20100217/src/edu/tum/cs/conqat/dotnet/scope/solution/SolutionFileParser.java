/*--------------------------------------------------------------------------+
   $Id: SolutionFileParser.java 25134 2009-12-14 16:19:53Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope.solution;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;

/**
 * Reads Visual Studio.NET Solution files and extracts the project file names.
 * <p>
 * Consult the package documentation for a description of those aspects of the
 * VS.NET solution file format that are relevant for the extraction of project
 * file names.
 * <p>
 * This parser simply iterates the lines of the solution file. Lines that start
 * with {@value #PROJECT_DEFINITION_LINE_PREFIX} contain the
 * solution-file-relative path to the project file in the third string literal.
 * I.e., the line
 * 
 * <pre>
 * Project(&quot;{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}&quot;) = &quot;ILAnalyzerTest&quot;, &quot;ILAnalyzerTest\ILAnalyzerTest.csproj&quot;, &quot;{291BC6FE-152B-460A-AD21-EFD9AE3D02FC}&quot;
 * </pre>
 * 
 * points to the file <code>ILAnalyzerTest\ILAnalyzerTest.csproj</code>
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 25134 $
 * @levd.rating GREEN Hash: A001D32D47F79C6539F6FA87A6B5567B
 */
public class SolutionFileParser {

	/** Lines in the solution file that define projects start with this prefix */
	private static final String PROJECT_DEFINITION_LINE_PREFIX = "Project(\"{";

	/** The encoding used for reading the solution file. */
	private final Charset encoding;

	/** Version of solution file format */
	public static enum EFormatVersion {
		/** VS.NET 2003 format */
		VERSION_8,

		/** VS.NET 2005 format */
		VERSION_9,

		/** VS.NET 2008 format */
		VERSION_10,
	}

	/** String that identifies VS.NET 2008 solution file */
	public static final String SOLUTION_FILE_HEADER_10 = "Microsoft Visual Studio Solution File, Format Version 10.00";

	/** String that identifies VS.NET 2005 solution file */
	public static final String SOLUTION_FILE_HEADER_9 = "Microsoft Visual Studio Solution File, Format Version 9.00";

	/** String that identifies VS.NET 2003 solution file */
	public static final String SOLUTION_FILE_HEADER_8 = "Microsoft Visual Studio Solution File, Format Version 8.00";

	/** Special project names that are excluded */
	private static PatternList blacklist = new PatternList();
	static {
		blacklist.add(Pattern.compile(Pattern.quote("Solution Items")));
	}

	/** Constructor. */
	public SolutionFileParser(Charset encoding) {
		this.encoding = encoding;
	}

	/**
	 * Extracts the project file names from the solution file
	 * 
	 * @throws ConQATException
	 *             if the format of the solution file is not known
	 */
	public List<String> parse(CanonicalFile solutionFile)
			throws ConQATException {
		checkSolutionFileFormat(solutionFile);
		List<String> projectFilenames = new ArrayList<String>();
		for (String line : FileLibrary.getInstance().getLines(solutionFile,
				encoding)) {
			if (line.startsWith(PROJECT_DEFINITION_LINE_PREFIX)) {
				String relativeProjectFilename = retrieveRelativeProjectFilename(line);
				if (!blacklist.findsAnyIn(relativeProjectFilename)) {
					projectFilenames.add(FileLibrary.absoluteFilenameFrom(
							solutionFile.getCanonicalPath(),
							relativeProjectFilename));
				}
			}
		}
		return projectFilenames;
	}

	/**
	 * Retrieves the relative project name from a project definition line.
	 * <p>
	 * The relative project name is contained in the third string literal.
	 */
	private String retrieveRelativeProjectFilename(String line) {
		return retrieveStringLiterals(line).get(2).replaceAll("\"", "");
	}

	/** Returns an array of the string literals contained in the project line */
	private List<String> retrieveStringLiterals(String projectLine) {
		Pattern stringLiteralPattern = Pattern.compile("\\\"[^\\\"]*\\\"");
		Matcher matcher = stringLiteralPattern.matcher(projectLine);

		List<String> matches = new ArrayList<String>();
		while (matcher.find()) {
			matches.add(matcher.group());
		}

		return matches;
	}

	/**
	 * Determines the format of the solution file
	 * 
	 * @throws ConQATException
	 *             If the solution file format is not known
	 */
	public EFormatVersion checkSolutionFileFormat(CanonicalFile solutionFile)
			throws ConQATException {
		EFormatVersion formatVersion = null;

		String[] lines = FileLibrary.getInstance().getLines(solutionFile,
				encoding);

		if (lines[0].equals(SOLUTION_FILE_HEADER_10)
				|| lines[1].equals(SOLUTION_FILE_HEADER_10)) {
			formatVersion = EFormatVersion.VERSION_10;
		} else if (lines[0].equals(SOLUTION_FILE_HEADER_9)
				|| lines[1].equals(SOLUTION_FILE_HEADER_9)) {
			formatVersion = EFormatVersion.VERSION_9;
		} else if (lines[0].equals(SOLUTION_FILE_HEADER_8)
				|| lines[1].equals(SOLUTION_FILE_HEADER_8)) {
			formatVersion = EFormatVersion.VERSION_8;
		} else {
			throw new ConQATException("Format of solution file " + solutionFile
					+ " unknown");
		}

		return formatVersion;
	}

}

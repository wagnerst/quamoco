/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: EFindingTypeSpecType.java 25450 2010-01-26 10:00:39Z heineman $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.typespec;

/**
 * Enumeration of types for finding type spec keys.
 * 
 * @author hummelb
 * @author $Author: heineman $
 * @version $Rev: 25450 $
 * @levd.rating GREEN Hash: BE5B3318BA8EADD307755BDA2444F1BA
 */
public enum EFindingTypeSpecType {

	/** Textual type. */
	STRING("s"),

	/** Integral number. */
	INT("i"),

	/** Real number. */
	DOUBLE("d");

	/** The type name, which is used for serialization. */
	private final String typeName;

	/** Constructor. */
	private EFindingTypeSpecType(String typeName) {
		this.typeName = typeName;
	}

	/** Returns the type name for this type. */
	public String getTypeName() {
		return typeName;
	}

	/**
	 * Returns the format type for a given type name. If nothing matches,
	 * {@link #STRING} is returned.
	 */
	public static EFindingTypeSpecType parseTypeName(String typeName) {
		for (EFindingTypeSpecType type : values()) {
			if (type.getTypeName().equals(typeName)) {
				return type;
			}
		}
		return STRING;
	}
}

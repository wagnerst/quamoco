/*--------------------------------------------------------------------------+
   $Id: UnitProviderBase.java 25459 2010-01-26 10:12:01Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization;

import java.io.Serializable;

import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IUnitProvider;
import edu.tum.cs.conqat.clonedetective.normalization.provider.ProviderBase;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for {@link Unit} providers.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25459 $
 * @levd.rating GREEN Hash: 28245549520ADB72CE12A735E6A20C1C
 */
public abstract class UnitProviderBase<Element extends IFileSystemElement, Data extends Unit>
		extends ProviderBase<Element, Data, CloneDetectionException> implements
		IUnitProvider<Element, Data>, Serializable {
	// All functionality present in base class.
}

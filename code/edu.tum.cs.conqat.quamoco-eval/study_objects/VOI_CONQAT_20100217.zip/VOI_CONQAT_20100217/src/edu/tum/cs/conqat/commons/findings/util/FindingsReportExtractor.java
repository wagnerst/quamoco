/*--------------------------------------------------------------------------+
   $Id: FindingsReportExtractor.java 25337 2010-01-25 13:57:15Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.util;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 25337 $
 * @levd.rating GREEN Hash: 91BBBF4E4D2AC39E17AF35D58866CD4B
 */
@AConQATProcessor(description = ""
		+ "This processor extracts the findings report embedded in a ConQAT node structure.")
public class FindingsReportExtractor extends ConQATProcessorBase {

	/** The root node. */
	private IConQATNode root;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = ConQATParamDoc.INPUT_DESC)
	public void setRoot(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) IConQATNode root) {
		this.root = root;
	}

	/** {@inheritDoc} */
	public FindingReport process() {
		return NodeUtils.getFindingReport(root);
	}

}

/*--------------------------------------------------------------------------+
   $Id: SimulinkScope.java 25983 2010-02-06 20:28:29Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.scope;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

import edu.tum.cs.commons.factory.IFactory;
import edu.tum.cs.commons.factory.IParameterizedFactory;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.filesystem.scope.FileSystemScopeBase;
import edu.tum.cs.simulink.builder.SimulinkModelBuilder;
import edu.tum.cs.simulink.builder.SimulinkModelBuildingException;

/**
 * A processor for reading Simulink files.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * 
 * @version $Rev: 25983 $
 * @levd.rating GREEN Hash: 8D59B9B613808300775C347612377CFC
 */
@AConQATProcessor(description = "This processor reads multiple Simulink model "
		+ "files and returns them as a tree of Simulink model nodes.")
public class SimulinkScope extends FileSystemScopeBase {

	/** {@inheritDoc} */
	public ISimulinkElement process() throws ConQATException {
		return createScope();
	}

	/** Creates and returns the actual node tree. */
	@Override
	protected SimulinkElement createScope() throws ConQATException {

		IParameterizedFactory<SimulinkElement, String, ConQATException> factory = getFileElementFactory();

		SimulinkElement result = factory.create(rootDirectoryName);

		List<String> filenameList = FileLibrary.scanDirectory(
				rootDirectoryName, caseSensitive, includePatterns,
				excludePatterns);

		for (String filename : filenameList) {
			File file = new File(rootDirectoryName, filename);
			String parent = new File(filename).getParent();

			try {
				SimulinkModelElement model = readSimulinkFile(file);
				if (parent == null) {
					result.addChild(model);
				} else {
					FileLibrary.insertFile(result, parent, factory).addChild(
							model);
				}
			} catch (SimulinkModelBuildingException e) {
				getLogger().error(
						"Could not parse model file " + file + ": "
								+ e.getMessage(), e);
			}

		}
		return result;
	}

	/**
	 * Read Simulink file and returns a wrapping model node.
	 * 
	 * @param file
	 *            MDL file to read.
	 * @return parsed model.
	 * @throws ConQATException
	 *             if file could not be found.
	 * @throws SimulinkModelBuildingException
	 *             if model could not be parsed.
	 */
	private SimulinkModelElement readSimulinkFile(File file)
			throws ConQATException, SimulinkModelBuildingException {

		SimulinkModelBuilder modelBuilder = new SimulinkModelBuilder(file,
				getLogger());

		try {
			return new SimulinkModelElement(modelBuilder.buildModel(), file
					.getName(), encoding);
		} catch (FileNotFoundException e) {
			throw new ConQATException(e);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected IParameterizedFactory<SimulinkElement, String, ConQATException> getFileElementFactory() {
		return new ElementFactory();
	}

	/** Implementation of {@link IFactory} for {@link SimulinkElement}s */
	private class ElementFactory implements
			IParameterizedFactory<SimulinkElement, String, ConQATException> {

		/** {@inheritDoc} */
		public SimulinkElement create(String name) throws ConQATException {
			return new SimulinkElement(name, encoding);
		}
	}

}

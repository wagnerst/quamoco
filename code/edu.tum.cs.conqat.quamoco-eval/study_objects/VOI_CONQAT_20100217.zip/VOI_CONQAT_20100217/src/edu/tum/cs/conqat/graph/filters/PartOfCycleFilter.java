/*--------------------------------------------------------------------------+
   $Id: PartOfCycleFilter.java 23498 2009-08-07 16:13:56Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.filters;

import java.util.ArrayList;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.graph.algo.StrongConnectivity;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATVertex;

/**
 * This processor filters any nodes which are part of at least one cycle.
 * 
 * @author Benjamin Hummel
 * @author Tilman Seifert
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23498 $
 * @levd.rating GREEN Hash: 16675AC0A97C15C17C1DF83FE0511151
 */
@AConQATProcessor(description = "This processor removes any vertices which are part of "
		+ "at least one (directed) cycle.")
public class PartOfCycleFilter extends ConQATPipelineProcessorBase<ConQATGraph> {

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) {
		StrongConnectivity scc = new StrongConnectivity(graph);
		int[] componentSizes = scc.getComponentSizes();

		// copy the list as we remove vertices
		for (ConQATVertex vertex : new ArrayList<ConQATVertex>(graph
				.getVertices())) {
			if (componentSizes[scc.getComponent(vertex)] > 1) {
				vertex.remove();
			}
		}
	}
}

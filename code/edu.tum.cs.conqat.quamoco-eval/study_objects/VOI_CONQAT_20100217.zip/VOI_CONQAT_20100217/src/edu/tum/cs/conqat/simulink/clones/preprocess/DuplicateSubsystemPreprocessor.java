/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.simulink
 |                                                                       |
   $Id: DuplicateSubsystemPreprocessor.java 26079 2010-02-15 10:54:54Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.clones.preprocess;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import edu.tum.cs.commons.clone.IDeepCloneable;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.model_clones.detection.util.ICloneReporter;
import edu.tum.cs.conqat.model_clones.label.CanonicalLabelCreator;
import edu.tum.cs.conqat.model_clones.label.GraphLabel;
import edu.tum.cs.conqat.model_clones.model.IDirectedEdge;
import edu.tum.cs.conqat.model_clones.model.INode;
import edu.tum.cs.conqat.simulink.clones.model.SimulinkDirectedEdge;
import edu.tum.cs.conqat.simulink.clones.model.SimulinkNode;
import edu.tum.cs.conqat.simulink.clones.normalize.ISimulinkNormalizer;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;
import edu.tum.cs.simulink.model.SimulinkLine;
import edu.tum.cs.simulink.util.SimulinkUtils;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 26079 $
 * @levd.rating YELLOW Hash: DE52CDE108BCA1B37365D901C4760AB7
 */
@AConQATProcessor(description = ""
		+ "A preprocessor which attempts to find duplicate subsystems and reports them as clones.")
public class DuplicateSubsystemPreprocessor extends ConQATProcessorBase
		implements ISimulinkPreprocessor {

	/** Whether cloned subsystems should be removed. */
	private boolean removeClonedSubsystems = true;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "subsystems", maxOccurrences = 1, description = "Determines what happens with subsystems found.")
	public void setRemoveClonedSubsystems(
			@AConQATAttribute(name = "remove", description = "If this is set to true, duplicated subsystems are removed, which speeds up later clone detection. "
					+ "However, any clones to the removed subsystems will be list. Default is true.") boolean removeClonedSubsystems) {
		this.removeClonedSubsystems = removeClonedSubsystems;
	}

	/** {@inheritDoc} */
	@Override
	public ISimulinkPreprocessor process() {
		return this;
	}

	/** {@inheritDoc} */
	@Override
	public void preprocess(ISimulinkElement input,
			ISimulinkNormalizer normalizer, Set<SimulinkBlock> ignoredBlocks,
			ICloneReporter reporter) throws ConQATException {

		Map<SimulinkBlock, GraphLabel> subsystemToLabel = buildSubsystemToLabelMapping(
				input, normalizer, ignoredBlocks);
		HashedListMap<GraphLabel, SimulinkBlock> labelToSubsystems = invertLabelMap(subsystemToLabel);

		for (GraphLabel key : labelToSubsystems.getKeys()) {
			List<SimulinkBlock> list = labelToSubsystems.getList(key);
			if (list == null || list.size() < 2) {
				continue;
			}

			GraphLabel parentLabel = subsystemToLabel.get(list.get(0)
					.getParent());
			List<SimulinkBlock> parentList = labelToSubsystems
					.getList(parentLabel);
			if (parentList != null && parentList.size() >= list.size()) {
				// no need to report as parent will be reported already
				continue;
			}

			reportClones(list, subsystemToLabel, reporter);
		}

		if (removeClonedSubsystems) {
			removeClones(labelToSubsystems, ignoredBlocks);
		}
	}

	/** Builds the mapping from subsystems to graph labels. */
	private Map<SimulinkBlock, GraphLabel> buildSubsystemToLabelMapping(
			ISimulinkElement root, ISimulinkNormalizer normalizer,
			Set<SimulinkBlock> ignoredBlocks) throws ConQATException {
		Map<SimulinkBlock, GraphLabel> subsystemToLabel = new IdentityHashMap<SimulinkBlock, GraphLabel>();
		for (ISimulinkElement model : TraversalUtils.listLeavesDepthFirst(root)) {
			if (model instanceof SimulinkModelElement) {
				calculateSubsystemLabels(((SimulinkModelElement) model)
						.getModel(), normalizer, subsystemToLabel,
						ignoredBlocks);
			}
		}
		return subsystemToLabel;
	}

	/** Inverts the subsystem to label map. */
	private HashedListMap<GraphLabel, SimulinkBlock> invertLabelMap(
			Map<SimulinkBlock, GraphLabel> subsystemToLabel) {
		HashedListMap<GraphLabel, SimulinkBlock> labelToSubsystems = new HashedListMap<GraphLabel, SimulinkBlock>();
		for (Entry<SimulinkBlock, GraphLabel> entry : subsystemToLabel
				.entrySet()) {
			labelToSubsystems.add(entry.getValue(), entry.getKey());
		}
		return labelToSubsystems;
	}

	/**
	 * Calculates canonical labels for all subsystems and stores them in the map
	 * provided. The string hash for the subsystem is returned.
	 */
	private String calculateSubsystemLabels(SimulinkBlock block,
			ISimulinkNormalizer normalizer,
			Map<SimulinkBlock, GraphLabel> subsystemToLabel,
			Set<SimulinkBlock> ignoredBlocks) throws ConQATException {
		if (!block.hasSubBlocks()) {
			// return value not used in this case
			return null;
		}

		Map<SimulinkBlock, SimulinkNode> blockMap = new IdentityHashMap<SimulinkBlock, SimulinkNode>();

		for (SimulinkBlock child : block.getSubBlocks()) {
			if (ignoredBlocks.contains(child)) {
				continue;
			}

			SimulinkNode node;
			if (child.hasSubBlocks()) {
				node = new SimulinkNode(child, calculateSubsystemLabels(child,
						normalizer, subsystemToLabel, ignoredBlocks), 1);
			} else {
				node = new SimulinkNode(child,
						normalizer.normalizeBlock(child), 1);
			}
			blockMap.put(child, node);
		}

		GraphLabel label = CanonicalLabelCreator.getCanonicalLabel(blockMap
				.values(), buildEdges(blockMap, normalizer));
		subsystemToLabel.put(block, label);
		return label.getTextualHash();
	}

	/** Build the edges list for the given set of nodes. */
	private List<SimulinkDirectedEdge> buildEdges(
			Map<SimulinkBlock, SimulinkNode> blockMap,
			ISimulinkNormalizer normalizer) throws ConQATException {
		List<SimulinkDirectedEdge> edges = new ArrayList<SimulinkDirectedEdge>();
		for (SimulinkBlock block : blockMap.keySet()) {
			for (SimulinkLine line : block.getOutLines()) {
				SimulinkNode sourceNode = blockMap.get(line.getSrcPort()
						.getBlock());
				SimulinkNode targetNode = blockMap.get(line.getDstPort()
						.getBlock());

				if (sourceNode == null || targetNode == null) {
					// just ignore lines leaving the subsystem
					continue;
				}
				edges.add(new SimulinkDirectedEdge(line, normalizer
						.normalizeLine(line), sourceNode, targetNode));
			}
		}
		return edges;
	}

	/** Reports a list of clones. */
	private void reportClones(List<SimulinkBlock> list,
			Map<SimulinkBlock, GraphLabel> subsystemToLabel,
			ICloneReporter reporter) {
		List<List<INode>> nodeLists = new ArrayList<List<INode>>();
		List<List<IDirectedEdge>> edgeLists = new ArrayList<List<IDirectedEdge>>();
		for (SimulinkBlock subsystem : list) {
			List<INode> orderedNodes = extractOrderedNodes(subsystem,
					subsystemToLabel);
			nodeLists.add(orderedNodes);
			edgeLists.add(computeEdges(orderedNodes));
		}

		reporter.startModelCloneGroup(list.size(), nodeLists.get(0).size(),
				edgeLists.get(0).size());
		for (int i = 0; i < list.size(); ++i) {
			reporter.addModelCloneInstance(nodeLists.get(i), edgeLists.get(i));
		}
	}

	/**
	 * Extracts all nodes stored (recursively) under the given subsystem.
	 * Respects the order determined by the graph labels.
	 */
	private List<INode> extractOrderedNodes(SimulinkBlock subsystem,
			Map<SimulinkBlock, GraphLabel> subsystemToLabel) {
		List<INode> result = new ArrayList<INode>();

		GraphLabel label = subsystemToLabel.get(subsystem);
		for (INode node : label.getNodes()) {
			SimulinkBlock block = ((SimulinkNode) node).getBlock();
			if (block.hasSubBlocks()) {
				result.addAll(extractOrderedNodes(block, subsystemToLabel));
			} else {
				result.add(node);
			}
		}
		return result;
	}

	/** Computes the list of all edges for the given list of nodes. */
	private List<IDirectedEdge> computeEdges(List<INode> nodes) {
		List<IDirectedEdge> result = new ArrayList<IDirectedEdge>();
		Map<SimulinkBlock, SimulinkNode> blocks = new IdentityHashMap<SimulinkBlock, SimulinkNode>();
		for (INode node : nodes) {
			blocks.put(((SimulinkNode) node).getBlock(), (SimulinkNode) node);
		}

		for (SimulinkBlock block : blocks.keySet()) {
			for (SimulinkLine line : block.getOutLines()) {
				SimulinkNode source = blocks.get(line.getSrcPort().getBlock());
				SimulinkNode target = blocks.get(line.getDstPort().getBlock());
				if (source != null && target != null) {
					// We do not need valid labels for reporting
					String edgeLabel = StringUtils.EMPTY_STRING;
					result.add(new SimulinkDirectedEdge(line, edgeLabel,
							source, target));
				}
			}
		}

		return result;
	}

	/** Remove all clones from the model by adding them to the ignore list. */
	private void removeClones(
			HashedListMap<GraphLabel, SimulinkBlock> labelToSubsystems,
			Set<SimulinkBlock> ignoredBlocks) {
		for (GraphLabel key : labelToSubsystems.getKeys()) {
			List<SimulinkBlock> list = labelToSubsystems.getList(key);
			if (list != null && list.size() >= 2) {
				for (SimulinkBlock block : list) {
					ignoredBlocks.addAll(SimulinkUtils
							.listBlocksDepthFirst(block));
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Returns <code>this</code>
	 */
	@Override
	public IDeepCloneable deepClone() {
		return this;
	}
}

/*--------------------------------------------------------------------------+
   $Id: BooleanAssessor.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.assessment;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor creates an assessment based on a boolean value.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 846EBC529D2118972D01D5D3BF7810FB
 * 
 */
@AConQATProcessor(description = "This processor creates an assessment based "
		+ "on a boolean value stored in a key. The resulting assessment for "
		+ "a node is GREEN if the value is true, RED otherwise. "
		+ "Default is to assess all nodes.")
public class BooleanAssessor extends LocalAssessorBase<Boolean> {

	/** {@inheritDoc} */
	@Override
	protected Assessment assessValue(Boolean value) {
		if (value.booleanValue()) {
			return new Assessment(ETrafficLightColor.GREEN);
		}
		return new Assessment(ETrafficLightColor.RED);
	}

}

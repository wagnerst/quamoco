/*--------------------------------------------------------------------------+
   $Id: FxCopAnalyzer.java 26106 2010-02-16 12:49:34Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.fxcop;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.xml.IXMLElementProcessor;
import edu.tum.cs.commons.xml.XMLReader;
import edu.tum.cs.commons.xml.XMLResolver;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * This processor reads the output of FxCop and assigns the issues and an
 * assessment to the elements of a file system scope.
 * 
 * @author Alexander Steinhoff
 * @author Elmar Juergens
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 26106 $
 * @levd.rating YELLOW Hash: C9B4D4CD254048084C677404CE6790BE
 */
@AConQATProcessor(description = "This processor reads the ouput of"
		+ " FxCop and assigns the issues and an assessment to the elements of a file system scope.")
public class FxCopAnalyzer extends
		NodeTraversingProcessorBase<IFileSystemElement> {

	/** Issues key */
	@AConQATKey(description = "The key to add all issues found to.", type = "java.util.List<String>")
	public static final String ISSUES_KEY = "FxCop issues";

	/** Assessment key */
	@AConQATKey(description = "The key to add the assessment to.", type = "edu.tum.cs.commons.assessment.Assessment")
	public static final String ASSESSMENT_KEY = "FxCop assessment";

	/** Path to FxCop output file. */
	private String reportFilename;

	/**
	 * The issues aggregated by file, mapping from absolute file path to list of
	 * issues.
	 */
	private final HashedListMap<String, String> issues = new HashedListMap<String, String>();

	/** Specify CodeInspector output file. */
	@AConQATParameter(name = "report", minOccurrences = 1, maxOccurrences = 1, description = "The FxCop report file to be parsed.")
	public void setReportFilename(
			@AConQATAttribute(name = "file", description = "Path to FxCop report file.") String filename) {
		reportFilename = filename;
	}

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(IFileSystemElement root) throws ConQATException {
		super.setUp(root);
		NodeUtils.addToDisplayList(root, ASSESSMENT_KEY, ISSUES_KEY);
		new FxCopFileReader().parse();
	}

	/** {@inheritDoc} */
	@Override
	protected void finish(IFileSystemElement root) throws ConQATException {
		super.finish(root);

		for (String path : issues.getKeys()) {
			getLogger().warn("No node found for " + path);
		}
	}

	/** Traverse source tree and annotate elements. */
	public void visit(IFileSystemElement element) {

		File f = element.getFile();
		if (f == null) {
			return;
		}

		List<String> l = issues.getList(f.getAbsolutePath());
		if (l == null || l.isEmpty()) {
			element.setValue(ASSESSMENT_KEY, new Assessment(
					ETrafficLightColor.GREEN));
		} else {
			element.setValue(ASSESSMENT_KEY, new Assessment(
					ETrafficLightColor.RED));
			element.setValue(ISSUES_KEY, new ArrayList<String>(l));
			issues.removeList(f.getAbsolutePath());
		}
	}

	/** The relevant XML elements for FxCop reports. */
	private static enum EXMLElement {

		/** Issue */
		Issue,
	}

	/** The relevant XML attributes for FxCop reports. */
	private static enum EXMLAttribute {

		/** Path */
		Path,

		/** File */
		File,
	}

	/** The reader for FxCop reports. */
	private class FxCopFileReader extends
			XMLReader<EXMLElement, EXMLAttribute, ConQATException> {

		/** Constructor */
		public FxCopFileReader() {
			super(new File(reportFilename),
					new XMLResolver<EXMLElement, EXMLAttribute>(
							EXMLAttribute.class));
		}

		/** Start parsing. */
		public void parse() throws ConQATException {
			parseProjectFile();
			processDecendantElements(new IssueProcessor());
		}

		/** Parse XML file */
		private void parseProjectFile() throws ConQATException {
			try {
				parseFile();
			} catch (SAXParseException e) {
				throw new ConQATException("XML parsing exception at line "
						+ e.getLineNumber() + ", colum " + e.getColumnNumber()
						+ " (" + e.getMessage() + ")");
			} catch (SAXException e) {
				throw new ConQATException("XML parsing exception: "
						+ e.getMessage());
			} catch (IOException e) {
				throw new ConQATException("File " + reportFilename
						+ " could not be read: " + e.getMessage());
			}
		}

		/** XML processor for issue elements. */
		public class IssueProcessor implements
				IXMLElementProcessor<EXMLElement, ConQATException> {

			/** {@inheritDoc} */
			public EXMLElement getTargetElement() {
				return EXMLElement.Issue;
			}

			/** {@inheritDoc} */
			public void process() throws ConQATException {
				try {
					String path = getStringAttribute(EXMLAttribute.Path);
					String name = getStringAttribute(EXMLAttribute.File);

					// FxCop reports can contain mixed
					// "\" and "/" paths that cause problems on platforms that only accept "/"
					// in paths.
					path = path.replaceAll("\\\\", "/");
					String filename = new File(path, name).getCanonicalPath();
					issues.add(filename, getText());
				} catch (IOException e) {
					throw new ConQATException(e);
				}

			}

		}
	}

}

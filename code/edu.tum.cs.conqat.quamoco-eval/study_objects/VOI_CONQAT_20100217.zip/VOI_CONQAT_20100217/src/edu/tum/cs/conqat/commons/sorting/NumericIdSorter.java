/*--------------------------------------------------------------------------+
   $Id: NumericIdSorter.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.sorting;

import java.util.Comparator;

import edu.tum.cs.commons.clone.IDeepCloneable;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * A processor that sorts node by their numeric id. If nodes have a non-numeric
 * id, they are not sorted.
 * 
 * @author Florian Deissenboeck
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 55C96725AFF94D61090E89EF40CEC4A8
 */
@AConQATProcessor(description = "A processor that sorts node by their numeric id."
		+ "If nodes have a non-numeric id, they are not sorted. "
		+ "Correctly spoken the nodes are not sorted, but a "
		+ "corresponding comparator is assigned to all internal nodes which "
		+ "should be considered in the presentation.")
public class NumericIdSorter extends SorterBase {

	/** {@inheritDoc} */
	@Override
	protected Comparator<IConQATNode> getComparator(IConQATNode node) {
		return NumericIdComparator.INSTANCE;
	}

	/** The class used for sorting. */
	public static class NumericIdComparator implements Comparator<IConQATNode>,
			IDeepCloneable {

		/** The single instance. */
		private static final NumericIdComparator INSTANCE = new NumericIdComparator();

		/** Prevent instantiation. Use {@link #getInstance()} instead. */
		private NumericIdComparator() {
			// nothing to do
		}

		/** Returns the only instance of this class. */
		public static NumericIdComparator getInstance() {
			return INSTANCE;
		}

		/**
		 * Compares the numeric ids of to nodes. If they are not numeric, zero
		 * is returned.
		 */
		public int compare(IConQATNode node1, IConQATNode node2) {
			try {
				double numericId1 = Double.parseDouble(node1.getId());
				double numericId2 = Double.parseDouble(node2.getId());

				if (numericId1 > numericId2) {
					return 1;
				}

				if (numericId1 < numericId2) {
					return -1;
				}

				return 0;
			} catch (NumberFormatException ex) {
				return 0;
			}
		}

		/**
		 * Do not clone.
		 */
		public NumericIdComparator deepClone() {
			return this;
		}
	}
}

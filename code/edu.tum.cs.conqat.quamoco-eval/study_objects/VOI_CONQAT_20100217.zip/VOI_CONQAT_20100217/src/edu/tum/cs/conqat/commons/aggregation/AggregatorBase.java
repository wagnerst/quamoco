/*--------------------------------------------------------------------------+
   $Id: AggregatorBase.java 25931 2010-02-03 09:56:58Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.aggregation;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.NodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class to simplify building new aggregators. The output key is added to
 * the display list if it is not already present.
 * <p>
 * Aggregation is only performed for inner nodes. The tree is traversed depth
 * first, with child nodes visited first.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 25931 $
 * @levd.rating GREEN Hash: 1CFDB69DAF254F663F7168435D4E81A6
 * 
 * @param <E>
 *            the data type we aggregate on.
 */
public abstract class AggregatorBase<E> extends
		NodeTraversingProcessorBase<IConQATNode> {

	/**
	 * Value used to indicate that the output key is the same as the input key.
	 * This is package visible to make it usable from the tests.
	 */
	/* package */static final String DEFAULT_TARGET_KEY = "__INPUT_KEY__";

	/** Mapping from input keys to output (write) keys. */
	private final Map<String, String> keys = new LinkedHashMap<String, String>();

	/** Flag that determines whether missing values are logged */
	private boolean logMissingInputValue = true;

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getTargetNodes() {
		return ETargetNodes.INNER;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.READKEY_NAME, minOccurrences = 1, description = ""
			+ "The key to read the aggregation value from.")
	public void setReadKey(
			@AConQATAttribute(name = ConQATParamDoc.READKEY_KEY_NAME, description = ConQATParamDoc.READKEY_KEY_DESC) String readKey,
			@AConQATAttribute(name = "target", description = "This parameter can (optionally) give a key to which the aggregate "
					+ "values are written. If the value "
					+ DEFAULT_TARGET_KEY
					+ " is used, this is just the same as the input key.", defaultValue = DEFAULT_TARGET_KEY) String writeKey)
			throws ConQATException {
		if (DEFAULT_TARGET_KEY.equals(writeKey)) {
			writeKey = readKey;
		}
		if (keys.put(readKey, writeKey) != null) {
			throw new ConQATException("Duplicate read key: " + readKey);
		}
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "missing", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Logging behaviour")
	public void setLogMissingInputValue(
			@AConQATAttribute(name = "log", description = "Flag that determines whether missing values are logged", defaultValue = "true") boolean logMissingValue) {
		this.logMissingInputValue = logMissingValue;
	}

	/** Copy output key if required. */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		// add all new output keys.
		// next method ignores all keys which are already added
		NodeUtils.addToDisplayList(root, CollectionUtils.asUnmodifiable(keys
				.values()));
	}

	/** Returns the name of the first output key. */
	protected String getFirstOutputKey() {
		CCSMAssert.isFalse(keys.isEmpty(),
				"Multiplicity should ensure non-empty keys!");
		return keys.values().iterator().next();
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) throws ConQATException {
		for (Map.Entry<String, String> entry : keys.entrySet()) {
			aggregateForNode(node, entry.getKey(), entry.getValue());
		}
	}

	/**
	 * Performs aggregation on a single node using the given input/output key
	 * pair.
	 */
	private void aggregateForNode(IConQATNode node, String inputKey,
			String outputKey) throws ConQATException {
		List<E> childValues = new ArrayList<E>();
		for (IConQATNode child : node.getChildren()) {

			// determine key to use
			String key = inputKey;
			if (child.hasChildren()) {
				key = outputKey;
			}

			Object value = child.getValue(key);
			if (value != null) {
				@SuppressWarnings("unchecked")
				E e = (E) value;
				childValues.add(e);
			} else if (logMissingInputValue) {
				getLogger().info(
						"No value for key '" + key + "' at node: "
								+ child.getId());
			}
		}

		if (childValues.isEmpty()) {
			return;
		}

		try {
			E result = aggregate(childValues);
			node.setValue(outputKey, result);
		} catch (ClassCastException ex) {
			throw new ConQATException("Invalid value encoutered!");
		}
	}

	/**
	 * This method should calculate the aggregated value from the provided
	 * values. The provided list is guaranteed to have at least one entry.
	 */
	protected abstract E aggregate(List<E> values);
}

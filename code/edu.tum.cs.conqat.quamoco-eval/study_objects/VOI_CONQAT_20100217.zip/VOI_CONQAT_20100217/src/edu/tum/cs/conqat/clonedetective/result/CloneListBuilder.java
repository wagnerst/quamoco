/*--------------------------------------------------------------------------+
   $Id: CloneListBuilder.java 25622 2010-01-26 15:52:27Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.CloneClassList;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 25622 $
 * @levd.rating GREEN Hash: 54E4541D758A8541F8F7131918EAF64B
 */
@AConQATProcessor(description = "Creates a list of the clone classes from a simple list")
public class CloneListBuilder extends CloneListBuilderBase {

	/** List of clone classes. */
	private List<CloneClass> cloneClasses;

	/** ConQAT Parameter */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) CloneClassList cloneClasses) {
		this.cloneClasses = new ArrayList<CloneClass>(cloneClasses);
	}

	/** {@inheritDoc} */
	@Override
	protected List<CloneClass> getCloneClasses() {
		return cloneClasses;
	}

}

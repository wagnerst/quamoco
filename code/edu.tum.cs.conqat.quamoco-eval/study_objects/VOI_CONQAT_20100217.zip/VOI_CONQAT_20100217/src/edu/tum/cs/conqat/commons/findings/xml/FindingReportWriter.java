/*--------------------------------------------------------------------------+
   $Id: FindingReportWriter.java 25510 2010-01-26 11:17:02Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.xml;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.xml.XMLWriter;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingCategory;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.location.CodeLineLocation;
import edu.tum.cs.conqat.commons.findings.location.CodeRegionLocation;
import edu.tum.cs.conqat.commons.findings.location.FileLocation;
import edu.tum.cs.conqat.commons.findings.location.LocationBase;
import edu.tum.cs.conqat.commons.findings.location.QualifiedNameLocation;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.NodeConstants;

/**
 * Code for writing finding reports. This is package visible and only used by
 * the {@link FindingReportIO} class.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 25510 $
 * @levd.rating GREEN Hash: 46612A0D20D39AD4FDEE7D945CD45461
 */
/* package */class FindingReportWriter {

	/**
	 * Set of keys which are omitted during the export as they have no meaning
	 * for findings but may be added by other processors.
	 */
	private static final Set<String> FILTERED_KEYS = new HashSet<String>(Arrays
			.asList(NodeConstants.COMPARATOR, NodeConstants.HIDE_ROOT,
					NodeConstants.DISPLAY_LIST, NodeConstants.SUMMARY));

	/** The XML writer. */
	private final XMLWriter<EFindingElements, EFindingAttributes> writer;

	/** Constructor. */
	/* package */FindingReportWriter(OutputStream out) {
		this.writer = new XMLWriter<EFindingElements, EFindingAttributes>(
				new PrintWriter(new OutputStreamWriter(out, Charset
						.forName(FileSystemUtils.UTF8_ENCODING))),
				FindingReportIO.XML_RESOLVER);
	}

	/** Writes the report into the writer. */
	/* package */void write(FindingReport report) {
		try {
			writer.addHeader("1.0", FileSystemUtils.UTF8_ENCODING);
			String time = FindingReportIO.DATE_FORMAT.format(report.getTime());
			writer.openElement(EFindingElements.FINDING_REPORT,
					EFindingAttributes.TIME, time, EFindingAttributes.XMLNS,
					"http://conqat.cs.tum.edu/ns/findings");

			for (FindingCategory category : report.getChildren()) {
				if (category.hasChildren()) {
					writeCategory(category);
				}
			}

			writer.closeElement(EFindingElements.FINDING_REPORT);
		} finally {
			writer.close();
		}
	}

	/** Writes the category into the writer. */
	private void writeCategory(FindingCategory category) {
		writer.openElement(EFindingElements.FINDING_CATEGORY,
				EFindingAttributes.NAME, category.getName());

		for (FindingGroup group : category.getChildren()) {
			if (group.hasChildren()) {
				writeGroup(group);
			}
		}

		writer.closeElement(EFindingElements.FINDING_CATEGORY);
	}

	/** Writes the group into the writer. */
	private void writeGroup(FindingGroup group) {
		writer.openElement(EFindingElements.FINDING_GROUP,
				EFindingAttributes.DESCRIPTION, group.getName());

		writeKeyValues(group);

		for (Finding finding : group.getChildren()) {
			writeFinding(finding);
		}

		writer.closeElement(EFindingElements.FINDING_GROUP);
	}

	/** Writes the finding into the writer. */
	private void writeFinding(Finding finding) {
		writer.openElement(EFindingElements.FINDING,
				EFindingAttributes.ORIGIN_TOOL, finding.getOriginTool());

		writeKeyValues(finding);

		for (LocationBase location : finding.getLocations()) {
			writeLocation(location);
		}

		writer.closeElement(EFindingElements.FINDING);
	}

	/** Writes key/value pairs. */
	private void writeKeyValues(ConQATNodeBase node) {
		for (String key : node.getKeys()) {
			if (FILTERED_KEYS.contains(key)) {
				continue;
			}

			Object value = node.getValue(key);
			if (value != null) {
				writer.addClosedTextElement(EFindingElements.KEY_VALUE_PAIR,
						value.toString(), EFindingAttributes.KEY, key);
			}
		}
	}

	/** Writes the location to the writer. */
	private void writeLocation(LocationBase location) {
		if (location instanceof QualifiedNameLocation) {
			writer.addClosedElement(EFindingElements.QUALIFIED_NAME,
					EFindingAttributes.NAME, ((QualifiedNameLocation) location)
							.getQualifiedName());
		} else if (location instanceof CodeRegionLocation) {
			CodeRegionLocation crl = (CodeRegionLocation) location;
			writer.addClosedElement(EFindingElements.CODE_REGION,
					EFindingAttributes.FILE, crl.getFile().getCanonicalPath(),
					EFindingAttributes.START_LINE_NUMBER, crl.getFirstLine(),
					EFindingAttributes.END_LINE_NUMBER, crl.getLastLine(),
					EFindingAttributes.START_POSITION, crl.getFirstPosition(),
					EFindingAttributes.END_POSITION, crl.getLastPosition());

		} else if (location instanceof CodeLineLocation) {
			CodeLineLocation cll = (CodeLineLocation) location;
			writer.addClosedElement(EFindingElements.CODE_LINE,
					EFindingAttributes.FILE, cll.getFile().getCanonicalPath(),
					EFindingAttributes.LINE_NUMBER, cll.getFirstLine());
		} else if (location instanceof FileLocation) {
			writer.addClosedElement(EFindingElements.CODE_FILE,
					EFindingAttributes.FILE, ((FileLocation) location)
							.getFile().getCanonicalPath());
		} else {
			CCSMAssert.fail("Unknown subclass of LocationBase!");
		}
	}

}

/*--------------------------------------------------------------------------+
   $Id: PatternList.java 25346 2010-01-25 14:12:51Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.pattern;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.regex.Pattern;

import edu.tum.cs.commons.clone.IDeepCloneable;

/**
 * A list of RegEx pattern. This is useful for defining black lists, etc.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 25346 $
 * @levd.rating GREEN Hash: 2FCC308C797741288294DE9F51DE81B6
 * 
 * @see PatternListDef
 */
public class PatternList extends ArrayList<Pattern> implements IDeepCloneable,
		Serializable {

	/**
	 * Returns whether the given string matches at least one of the contained
	 * pattern. For this the <code>Matcher.matches()</code> method is used.
	 */
	public boolean matchesAny(String s) {
		for (Pattern p : this) {
			if (p.matcher(s).matches()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Returns whether in the given string at least one of the contained pattern
	 * is found. For this the <code>Matcher.find()</code> method is used.
	 */
	public boolean findsAnyIn(String s) {
		for (Pattern p : this) {
			if (p.matcher(s).find()) {
				return true;
			}
		}
		return false;
	}

	/** {@inheritDoc} */
	public PatternList deepClone() {
		PatternList result = new PatternList();
		result.addAll(this);
		return result;
	}
}
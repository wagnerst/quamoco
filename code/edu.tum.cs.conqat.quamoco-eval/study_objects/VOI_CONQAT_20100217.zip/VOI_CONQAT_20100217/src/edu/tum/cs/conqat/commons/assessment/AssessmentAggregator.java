/*--------------------------------------------------------------------------+
   $Id: AssessmentAggregator.java 25921 2010-02-02 17:19:00Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.assessment;

import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.conqat.commons.aggregation.AggregatorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * An aggreggator that works by summing up the assessments at every node.
 * 
 * @author Benjamin Hummel
 * @author $Author: deissenb $
 * @version $Rev: 25921 $
 * @levd.rating GREEN Hash: F99551D5503878020A5B4C0F01118BAC
 */
@AConQATProcessor(description = "This processor aggregates on assessments by "
		+ "recursively merging the assessments of the children of a node into "
		+ "the assessment of the current node. The behaviour can be compared to "
		+ "the SumAggregator. It additionally attaches a summary assessment to "
		+ "the root node, which is based on the aggregated value of the first key provided.")
public class AssessmentAggregator extends AggregatorBase<Assessment> {

	/** Finally set the summary. */
	@Override
	public void finish(IConQATNode root) {
		root
				.setValue(NodeConstants.SUMMARY, root
						.getValue(getFirstOutputKey()));
	}

	/** {@inheritDoc} */
	@Override
	protected Assessment aggregate(List<Assessment> values) {
		Assessment result = new Assessment();
		for (Assessment a : values) {
			result.add(a);
		}
		return result;
	}
}

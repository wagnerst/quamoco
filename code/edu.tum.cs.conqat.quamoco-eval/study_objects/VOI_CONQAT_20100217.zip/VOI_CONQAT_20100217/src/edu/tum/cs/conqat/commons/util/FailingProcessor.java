/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FailingProcessor.java 25266 2010-01-25 10:55:20Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.util;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25266 $
 * @levd.rating GREEN Hash: 97AF021CEEA8DB4F1D9AB89459D1B1A8
 */
@AConQATProcessor(description = "Processor that can throw a ConQATException. "
		+ "Use this processor to suppress the execution of a part of a configuration, "
		+ "e.g. during debugging to speed up execution.")
public class FailingProcessor extends ConQATPipelineProcessorBase<Object> {

	/** Flag that determines whether an exception gets thrown */
	private boolean throwException = false;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "fail", description = "Determines whether an exception gets thrown", minOccurrences = 1, maxOccurrences = 1)
	public void setThrowException(
			@AConQATAttribute(name = "value", description = "Default is false.") boolean throwException) {
		this.throwException = throwException;
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(Object input) throws ConQATException {
		if (throwException) {
			throw new ConQATException(
					"Aborting execution. Set parameter of this processor to false to turn of the exception.");
		}
	}

}

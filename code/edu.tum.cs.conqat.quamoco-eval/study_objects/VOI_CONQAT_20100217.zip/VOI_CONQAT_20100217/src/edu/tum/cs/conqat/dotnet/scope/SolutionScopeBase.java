/*--------------------------------------------------------------------------+
   $Id: SolutionScopeBase.java 25707 2010-01-27 10:28:56Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.factory.IParameterizedFactory;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.commons.CommonUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.scope.project.ProjectFileParser;
import edu.tum.cs.conqat.dotnet.scope.solution.SolutionFileParser;
import edu.tum.cs.conqat.dotnet.scope.solution.SolutionFileParser.EFormatVersion;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.filesystem.scope.FileSystemElement;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for solution scopes.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 25707 $
 * @levd.rating GREEN Hash: DDCFC9BA284C2991F64CDDF6479EBCD1
 */
public abstract class SolutionScopeBase<T extends FileSystemElement> extends
		ConQATProcessorBase {

	/**
	 * Patterns that govern which files are included. If null, all files files
	 * from a solution are included
	 */
	private PatternList includePatterns = null;

	/**
	 * Patterns that govern which files are excluded. If null, no files are
	 * excluded. Exclusion has priority over inclusion.
	 */
	private PatternList excludePatterns = null;

	/**
	 * Patterns that govern which project files are included. If null, all
	 * project files from a solution are included
	 */
	private PatternList projectIncludePatterns = null;

	/**
	 * Patterns that govern which project files are excluded. If null, no
	 * project files are excluded. Exclusion has priority over inclusion.
	 */
	private PatternList projectExcludePatterns = null;

	/** Encoding that gets used for parsing of VS.NET project files. */
	protected Charset encoding = null;

	/** Solution file name */
	protected File solutionFile = null;

	/** Set of solution files that get processed */
	protected final List<CanonicalFile> solutionFiles = new ArrayList<CanonicalFile>();

	/** ConQAT Parameter */
	@AConQATParameter(name = "solution", description = "VS.NET solution", minOccurrences = 0, maxOccurrences = 1)
	public void setSolutionFile(
			@AConQATAttribute(name = "file", description = "Name of the solution file") String solutionFilename)
			throws ConQATException {
		solutionFiles.add(FileLibrary.createCanonicalFile(solutionFilename));
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "solution-files-root", description = "File system tree containing VS.NET solution files", minOccurrences = 0, maxOccurrences = 1)
	public void setSolutionFiles(
			@AConQATAttribute(name = "files", description = "Typically produced by a file system scope processor") IFileSystemElement solutionFilesRoot) {
		List<IFileSystemElement> solutionElements = TraversalUtils
				.listLeavesDepthFirst(solutionFilesRoot);
		for (IFileSystemElement solutionElement : solutionElements) {
			if (solutionElement.getFile().isFile()) {
				solutionFiles.add(solutionElement.getFile());
			}
		}
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "include-files", description = ""
			+ "Patterns that govern which files (elements of the solution) are included.", minOccurrences = 0, maxOccurrences = 1)
	public void setIncludePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "If not set, all files from a solution are included") PatternList includePatterns) {
		this.includePatterns = includePatterns;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "exclude-files", description = ""
			+ "Patterns that govern which files (elements of the solution) are excluded. Exclusion has preference over inclusion.", minOccurrences = 0, maxOccurrences = 1)
	public void setExcludePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "If not set, no files from a solution are excluded") PatternList excludePatterns) {
		this.excludePatterns = excludePatterns;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "include-projects", description = ""
			+ "Patterns that govern which project files are included.", minOccurrences = 0, maxOccurrences = 1)
	public void setProjectIncludePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "If not set, all project files from a solution are included") PatternList projectIncludePatterns) {
		this.projectIncludePatterns = projectIncludePatterns;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "exclude-projects", description = ""
			+ "Patterns that govern which project files are excluded. Exclusion has preference over inclusion.", minOccurrences = 0, maxOccurrences = 1)
	public void setProjectExcludePatterns(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = "If not set, no project files from a solution are excluded") PatternList projectExcludePatterns) {
		this.projectExcludePatterns = projectExcludePatterns;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.ENCODING_PARAM_NAME, minOccurrences = 1, maxOccurrences = 1, description = "Set encoding for files in this scope")
	public void setEncoding(
			@AConQATAttribute(name = ConQATParamDoc.ENCODING_ATTR_NAME, description = "Encoding is mandatory, since .NET project files are typically not encoded in the default encoding.", defaultValue = FileSystemUtils.UTF8_ENCODING) String encodingName)
			throws ConQATException {
		encoding = CommonUtils.obtainEncoding(encodingName);
	}

	/** {@inheritDoc} */
	public T process() throws ConQATException {
		if (solutionFiles.isEmpty()) {
			throw new ConQATException("No solution file found");
		}

		// create root
		IParameterizedFactory<T, String, ConQATException> factory = createElementFactory();
		String rootDir = determineRootDirectory().getCanonicalPath();
		T root = factory.create(rootDir);

		// add files
		Iterable<String> filenamess = determineFilenamesFromSolutions();
		for (String filename : filenamess) {
			CanonicalFile file = FileLibrary.createCanonicalFile(filename);
			String relativeCanonicalFilename = relativePath(rootDir, file
					.getCanonicalPath());
			FileLibrary.insertFile(root, relativeCanonicalFilename, factory);
		}

		return root;
	}

	/**
	 * Template method that deriving classes override to provide the factory
	 * that creates the elements of type T.
	 */
	protected abstract IParameterizedFactory<T, String, ConQATException> createElementFactory();

	/** Get root directory for the solution */
	protected CanonicalFile determineRootDirectory() throws ConQATException {
		if (solutionFiles.size() == 1) {
			return FileLibrary.createCanonicalFile(solutionFiles.get(0)
					.getParentFile());
		}

		try {
			File rootDirectoy = FileSystemUtils.commonRoot(solutionFiles);
			return new CanonicalFile(rootDirectoy);
		} catch (IOException e) {
			throw new ConQATException("Cannot determine root directory", e);
		}
	}

	/**
	 * Computes a relative file name.
	 * 
	 * @param workingDir
	 *            Directory relative to which filename gets computed
	 * @param filename
	 *            File for which relative gets computed
	 * @return Path from working directory to file
	 */
	protected String relativePath(String workingDir, String filename) {
		String relativeFilename = filename.substring(workingDir.length());
		if (relativeFilename.startsWith(File.separator)) {
			relativeFilename = relativeFilename.substring(1);
		}
		return relativeFilename;
	}

	/** Determines the filenames contained in the scope */
	protected List<String> determineFilenamesFromSolutions()
			throws ConQATException {
		List<String> files = new ArrayList<String>();

		for (CanonicalFile solutionFile : solutionFiles) {
			getLogger()
					.debug(
							"Parsing solution file: "
									+ solutionFile.getCanonicalPath());
			files.addAll(parseSolutionFile(solutionFile));
		}

		return files;
	}

	/**
	 * Gets those elements (filenames) from a solution file that are contained
	 * in this scope.
	 * 
	 * @throws ConQATException
	 *             if the format of the solution file is unknown or if the
	 *             solution file cannot be read.
	 */
	protected List<String> parseSolutionFile(CanonicalFile solutionFile)
			throws ConQATException {
		List<String> filenames = new ArrayList<String>();

		SolutionFileParser solutionParser = new SolutionFileParser(encoding);
		EFormatVersion solutionFormat = solutionParser
				.checkSolutionFileFormat(solutionFile);

		for (String projectFilename : solutionParser.parse(solutionFile)) {
			if (projectFileContained(projectFilename)) {
				getLogger().debug("\tParsing project file: " + projectFilename);
				extractFilesFromProject(filenames, solutionFormat,
						projectFilename);
			} else {
				getLogger()
						.debug("\tExcluded project file: " + projectFilename);
			}
		}

		return filenames;
	}

	/**
	 * Gets those files (assemblies or source files) from a project file, that
	 * are included by the file- and project level include and exclude
	 * {@link PatternList}s
	 */
	private void extractFilesFromProject(List<String> files,
			EFormatVersion solutionFormat, String projectFilename) {
		ProjectFileParser projectParser = ProjectFileParser.create(
				solutionFormat, getLogger());
		projectParser.setEncoding(encoding.name());

		List<String> fileNames = null;

		try {
			fileNames = extractRelevantFilesFromProject(new File(
					projectFilename), projectParser);
		} catch (ConQATException e) {
			getLogger().warn(
					"Could not parse project file: " + projectFilename + ": "
							+ e.getMessage());
			return;
		}

		for (String filename : fileNames) {
			if (fileContained(filename)) {
				files.add(filename);
				getLogger().debug("\t\tIncluded file: " + filename);
			} else {
				getLogger().debug("\t\tExcluded file: " + filename);
			}
		}

	}

	/**
	 * Template method to extract the relevant files (source or assemblies) form
	 * a project
	 */
	abstract List<String> extractRelevantFilesFromProject(File projectFile,
			ProjectFileParser projectParser) throws ConQATException;

	/**
	 * Tests whether a project filename is contained in the scope by evaluating
	 * the project-level include and exclude {@link PatternList}s.
	 */
	private boolean projectFileContained(String projectFilename) {
		if (projectIncludePatterns != null
				&& !projectIncludePatterns.matchesAny(projectFilename)) {
			return false;
		}
		if (projectExcludePatterns != null
				&& projectExcludePatterns.matchesAny(projectFilename)) {
			return false;
		}
		return true;
	}

	/**
	 * Tests whether a filename (source code or assembly) is contained in the
	 * scope by evaluating the file level include and exclude
	 * {@link PatternList}s.
	 */
	private boolean fileContained(String filename) {
		if (includePatterns != null && !includePatterns.matchesAny(filename)) {
			return false;
		}
		if (excludePatterns != null && excludePatterns.matchesAny(filename)) {
			return false;
		}
		return true;
	}

}

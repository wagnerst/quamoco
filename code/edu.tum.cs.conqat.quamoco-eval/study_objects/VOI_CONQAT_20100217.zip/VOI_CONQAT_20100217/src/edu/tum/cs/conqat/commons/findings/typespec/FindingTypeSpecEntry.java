/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FindingTypeSpecEntry.java 25450 2010-01-26 10:00:39Z heineman $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.typespec;

/**
 * A single entry in a finding type spec.
 * 
 * @author hummelb
 * @author $Author: heineman $
 * @version $Rev: 25450 $
 * @levd.rating GREEN Hash: 81B61B86147DC097B69E3FE9C475B57B
 */
public final class FindingTypeSpecEntry {

	/** The key this refers to. */
	private final String key;

	/** Determines as which type the key should be interpreted. */
	private final EFindingTypeSpecType type;

	/** Constructor. */
	public FindingTypeSpecEntry(String key, EFindingTypeSpecType type) {
		this.key = key;
		this.type = type;
	}

	/**
	 * Constructs a new instance from the serialized string (inverse to
	 * {@link #toString()}).
	 */
	public FindingTypeSpecEntry(String serialized) {
		String[] parts = serialized.split(":", 2);
		this.key = parts[0];
		if (parts.length == 1) {
			this.type = EFindingTypeSpecType.STRING;
		} else {
			this.type = EFindingTypeSpecType.parseTypeName(parts[1]);
		}
	}

	/** Returns the key this refers to. */
	public String getKey() {
		return key;
	}

	/** Returns as which type the key should be interpreted. */
	public EFindingTypeSpecType getType() {
		return type;
	}

	/** {@inheritDoc} */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof FindingTypeSpecEntry)) {
			return false;
		}

		FindingTypeSpecEntry other = (FindingTypeSpecEntry) obj;
		return key.equals(other.key) && type == other.type;
	}

	/** {@inheritDoc} */
	@Override
	public int hashCode() {
		return key.hashCode() + 13 * type.hashCode();
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return key + ":" + type.getTypeName();
	}
}

/*--------------------------------------------------------------------------+
   $Id: AssessmentFileWriterProcessor.java 23504 2009-08-07 16:20:27Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.assessment;

import java.io.File;
import java.io.IOException;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.architecture.scope.ArchitectureDefinition;
import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: deissenb $
 * @version $Rev: 23504 $
 * @levd.rating GREEN Hash: 02C046C13879A5A0CFF7364F2A335E11
 */
@AConQATProcessor(description = "Writes an assessed architecture to a file.")
public class AssessmentFileWriterProcessor extends
		ConQATPipelineProcessorBase<ArchitectureDefinition> {

	/** File that gets written */
	private File targetFile;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "output", minOccurrences = 1, maxOccurrences = 1, description = "Name of the output directory")
	public void setOutputDirectory(
			@AConQATAttribute(name = "dir", description = "Name of the output directory") String outputDir,
			@AConQATAttribute(name = "filename", description = "Name of the file that gets written") String reportName) {

		targetFile = new File(outputDir, reportName);
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(ArchitectureDefinition arch)
			throws ConQATException {
		try {
			FileSystemUtils.ensureParentDirectoryExists(targetFile);
			AssessmentFileWriter writer = new AssessmentFileWriter(targetFile,
					arch, getLogger());
			writer.writeArchitecture();
			writer.close();
		} catch (IOException e) {
			throw new ConQATException("Could not write file", e);
		}
	}
}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: LoggingDistributableJob.java 25902 2010-02-02 14:44:46Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.distributed;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.distributed.IDistributableJob;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * A distributable job which handles errors by logging.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 25902 $
 * @levd.rating GREEN Hash: A0A590418D6DF5D458736BE5C051ACE7
 */
public abstract class LoggingDistributableJob<T extends RemoteJobBase>
		implements IDistributableJob<T> {

	/** The logger. */
	protected final IConQATLogger logger;

	/** The name of the remote worker we are about to work on. */
	private String loggingPrefix;

	/** Constructor. */
	protected LoggingDistributableJob(IConQATLogger logger) {
		this.logger = logger;
	}

	/** {@inheritDoc} */
	@Override
	public final T prepareRemoteJob(String workerName) {
		if (workerName == null) {
			loggingPrefix = StringUtils.EMPTY_STRING;
		} else {
			loggingPrefix = "[@" + workerName + "] ";
		}

		T job = createRemoteJob();
		job.init(logger.getMinLogLevel());
		return job;
	}

	/** Factory method for creating the remote job. */
	protected abstract T createRemoteJob();

	/** {@inheritDoc} */
	public final void processRemoteResult(T resultRunnable) {
		if (resultRunnable.getLogMessages() != null) {
			for (StoredLogMessage message : resultRunnable.getLogMessages()) {
				message.logTo(logger, loggingPrefix);
			}
		}

		Object result = resultRunnable.result;
		if (result instanceof ConQATException) {
			logger.warn(((ConQATException) result).getMessage());
		} else if (result instanceof Throwable) {
			Throwable e = (Throwable) result;
			logger.error(e.getMessage(), e);
		} else {
			processResult(result);
		}
	}

	/** Template method for processing the result from the remote runnable. */
	protected abstract void processResult(Object result);

}

/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: ENormalizationOption.java 25817 2010-01-27 22:15:27Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.token.configuration;

import java.util.EnumMap;
import java.util.Map;

/**
 * Enum constants for configuration of the normalization phase.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25817 $
 * @levd.rating GREEN Hash: 3B6842D8084D117A531C4091C16E88FB
 */
public enum ENormalizationOption {

	/** See documentation in {@link TokenConfigurationDef} */
	IGNORE_COMMENTS,

	/** See documentation in {@link TokenConfigurationDef} */
	IGNORE_DELIMITERS,

	/** See documentation in {@link TokenConfigurationDef} */
	IGNORE_PREPROCESSOR_DIRECTIVES,

	/** See documentation in {@link TokenConfigurationDef} */
	NORMALIZE_IDENTIFIERS,

	/** See documentation in {@link TokenConfigurationDef} */
	NORMALIZE_FULLY_QUALIFIED_TYPE_NAMES,

	/** See documentation in {@link TokenConfigurationDef} */
	NORMALIZE_TYPE_KEYWORDS,

	/** See documentation in {@link TokenConfigurationDef} */
	NORMALIZE_BOOLEAN_LITERALS,

	/** See documentation in {@link TokenConfigurationDef} */
	NORMALIZE_CHARACTER_LITERALS,

	/** See documentation in {@link TokenConfigurationDef} */
	NORMALIZE_NUMBER_LITERALS,

	/** See documentation in {@link TokenConfigurationDef} */
	NORMALIZE_STRING_LITERALS,

	/** See documentation in {@link TokenConfigurationDef} */
	IGNORE_THIS,

	/** See documentation in {@link TokenConfigurationDef} */
	IGNORE_VISIBILITY_MODIFIER,

	/** See documentation in {@link TokenConfigurationDef} */
	STEM_WORDS,

	/** See documentation in {@link TokenConfigurationDef} */
	IGNORE_STOP_WORDS,

	/** See documentation in {@link TokenConfigurationDef} */
	IGNORE_END_OF_STATEMENT_TOKENS;

	/** Creates a map with all normalization options set to true */
	public static Map<ENormalizationOption, Boolean> setAll() {
		Map<ENormalizationOption, Boolean> options = new EnumMap<ENormalizationOption, Boolean>(
				ENormalizationOption.class);
		for (ENormalizationOption option : ENormalizationOption.values()) {
			options.put(option, true);
		}
		return options;
	}

	/** Creates a map with the default normalization options set */
	public static Map<ENormalizationOption, Boolean> getDefaultOptions() {
		Map<ENormalizationOption, Boolean> defaultOptions = setAll();

		defaultOptions.put(IGNORE_END_OF_STATEMENT_TOKENS, false);
		defaultOptions.put(NORMALIZE_IDENTIFIERS, false);
		defaultOptions.put(NORMALIZE_FULLY_QUALIFIED_TYPE_NAMES, false);
		defaultOptions.put(STEM_WORDS, false);
		defaultOptions.put(IGNORE_STOP_WORDS, false);

		return defaultOptions;
	}

}

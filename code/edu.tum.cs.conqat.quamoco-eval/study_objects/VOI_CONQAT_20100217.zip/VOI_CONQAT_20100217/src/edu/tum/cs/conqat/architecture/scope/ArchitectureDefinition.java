/*--------------------------------------------------------------------------+
   $Id: ArchitectureDefinition.java 25487 2010-01-26 10:55:48Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.scope;

import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.architecture.format.EPolicyType;
import edu.tum.cs.conqat.architecture.format.EStereotype;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Architecture definition is the root element in an architecture.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 25487 $
 * @levd.rating GREEN Hash: CDE55341C8EEEFACD9C3F2347C755CDE
 */
public class ArchitectureDefinition extends ComponentNode {

	/** Creates a new architecture definition. */
	/* package */ArchitectureDefinition(EPolicyType defaultPolicyType) {
		super("<architecture>", defaultPolicyType, new Point(0, 0),
				new Dimension(0, 0), EStereotype.NONE);
	}

	/** Copy constructor. */
	private ArchitectureDefinition(ArchitectureDefinition other)
			throws DeepCloneException {
		// components are cloned in super 
		super(other);

		// cloning of dependency rules is initiated from the root node
		Collection<DependencyPolicy> policies = new ArrayList<DependencyPolicy>();
		other.collectPolicies(policies);
		Map<String, ComponentNode> nameLookup = new HashMap<String, ComponentNode>();
		fillNameLookup(nameLookup);

		for (DependencyPolicy policy : policies) {
			ComponentNode newFrom = nameLookup
					.get(policy.getSource().getName());
			ComponentNode newTo = nameLookup.get(policy.getTarget().getName());
			DependencyPolicy cloned = new DependencyPolicy(policy, newFrom,
					newTo);
			try {
				cloned.registerWithComponents();
			} catch (ConQATException e) {
				// use deep clone exception, as these are handled specifically in the driver
				throw new DeepCloneException(
						"This should not be possible, as the cloned architecture should be same!",
						e);
			}
		}
	}

	/** {@inheritDoc} */
	@Override
	public ArchitectureDefinition deepClone() throws DeepCloneException {
		return new ArchitectureDefinition(this);
	}
}

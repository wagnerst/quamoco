package edu.tum.cs.conqat.clonedetective.core.report.enums;

/**
 * Enumeration for three-values answers. Useful to perform studies that involve
 * manual developer ratings. Such studies typically contribute their views and
 * columns via a separate plugin that uses the extension points from this
 * plugin. To avoid classloader problems when opening a clone report however,
 * this class resides here and not in one of those plugins.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25575 $
 * @levd.rating GREEN Hash: 130DFE166E2D457E22FEA32A1D002CCB
 */
public enum EAnswer {

	/** Yes value*/
	YES,

	/** No value*/
	NO,

	/** Don't know */
	DONT_KNOW,

	/** Not yet decided */
	UNRATED
}

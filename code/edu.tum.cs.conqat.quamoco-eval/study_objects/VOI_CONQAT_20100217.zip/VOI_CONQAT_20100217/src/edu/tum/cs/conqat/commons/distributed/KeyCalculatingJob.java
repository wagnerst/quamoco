/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: KeyCalculatingJob.java 25901 2010-02-02 14:22:52Z deissenb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.distributed;

import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * A job used for calculating and persisting simple values as keys.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 25901 $
 * @levd.rating GREEN Hash: CE76E710A1BB6418056C741E8C1125A3
 */
public class KeyCalculatingJob<T extends RemoteJobBase> extends
		LoggingDistributableJob<T> {

	/** The remote job. */
	protected final T job;

	/** The node to store the result in. */
	protected final IConQATNode node;

	/** The key to store the result in. */
	protected final String key;

	/** Constructor. */
	public KeyCalculatingJob(T job, IConQATNode node, String key,
			IConQATLogger logger) {
		super(logger);
		this.job = job;
		this.node = node;
		this.key = key;
	}

	/** {@inheritDoc} */
	@Override
	public T createRemoteJob() {
		return job;
	}

	/** {@inheritDoc} */
	@Override
	protected void processResult(Object result) {
		node.setValue(key, result);
	}
}

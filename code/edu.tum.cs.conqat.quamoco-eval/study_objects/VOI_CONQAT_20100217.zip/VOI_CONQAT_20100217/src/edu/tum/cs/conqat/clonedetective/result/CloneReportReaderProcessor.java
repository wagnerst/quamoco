/*--------------------------------------------------------------------------+
   $Id: CloneReportReaderProcessor.java 25706 2010-01-27 10:28:20Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.clonedetective.core.report.CloneReportReader;
import edu.tum.cs.conqat.clonedetective.core.report.SourceFileDescriptor;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.CommonUtils;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.filesystem.library.FileLibrary;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;
import edu.tum.cs.conqat.sourcecode.scope.ISourceCodeElement;
import edu.tum.cs.conqat.sourcecode.scope.SourceCodeElement;
import edu.tum.cs.conqat.sourcecode.scope.SourceCodeElementFactory;
import edu.tum.cs.scanner.ELanguage;

/**
 * Processor that reads clone reports and creates a
 * {@link CloneDetectionResultElement} that can be used just as the result of a
 * clone detection processor.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 25706 $
 * @levd.rating GREEN Hash: 0007DE3B778A58F07F0617AB0B7B0129
 */
@AConQATProcessor(description = ""
		+ "Processor that reads clone reports and creates a"
		+ "{@link CloneDetectionResultElement} that can be used just as the result of a"
		+ "clone detection processor.")
public class CloneReportReaderProcessor extends ConQATProcessorBase {

	/** Name of the report file */
	private File reportFile;

	/** File encoding. */
	protected Charset encoding = Charset.defaultCharset();

	/** ConQAT Parameter */
	@AConQATParameter(name = "report", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Name of the report file")
	public void setReportFile(
			@AConQATAttribute(name = "filename", description = "Name of the report file") String reportFile) {
		this.reportFile = new File(reportFile);
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.ENCODING_PARAM_NAME, minOccurrences = 0, maxOccurrences = 1, description = ConQATParamDoc.ENCODING_PARAM_DESC)
	public void setEncoding(
			@AConQATAttribute(name = ConQATParamDoc.ENCODING_ATTR_NAME, description = ConQATParamDoc.ENCODING_ATTR_DESC) String encodingName)
			throws ConQATException {
		encoding = CommonUtils.obtainEncoding(encodingName);
	}

	/** {@inheritDoc} */
	public CloneDetectionResultElement process() throws ConQATException {
		CloneReportReader reader = new CloneReportReader(reportFile);

		IFileSystemElement root = createFileSystemTree(reader
				.getSourceFileDescriptors());

		CloneDetectionResultElement result = new CloneDetectionResultElement(
				reader.getSystemDate(), root, reader.getCloneClasses());

		return result;
	}

	/** Build a file system tree from the file information in the clone report */
	private ISourceCodeElement createFileSystemTree(
			List<SourceFileDescriptor> sourceFiles) throws ConQATException {

		String rootName = commonRoot(sourceFiles).getCanonicalPath();
		ELanguage language = ELanguage.fromFileExtension(sourceFiles.get(0)
				.getFile().getCanonicalPath());
		SourceCodeElement root = new SourceCodeElement(rootName, encoding,
				language);

		for (SourceFileDescriptor sourceFile : sourceFiles) {
			String filename = sourceFile.getFile().getCanonicalPath()
					.substring(rootName.length());
			language = ELanguage.fromFileExtension(filename);
			FileLibrary.insertFile(root, filename,
					new SourceCodeElementFactory(encoding, language));
		}

		return root;
	}

	/** Determines the common root directory for all source files */
	private CanonicalFile commonRoot(List<SourceFileDescriptor> sourceFiles)
			throws ConQATException {
		List<File> files = new ArrayList<File>();
		for (SourceFileDescriptor sourceFile : sourceFiles) {
			files.add(sourceFile.getFile());
		}

		CanonicalFile commonRoot;
		try {
			commonRoot = new CanonicalFile(FileSystemUtils.commonRoot(files));
		} catch (IOException e) {
			throw new ConQATException("Could not determine common root", e);
		}

		// the files originally stem from a file system element tree and as such
		// are expected to have a common root. if that is not the case,
		// something went wrong.
		CCSMAssert
				.isNotNull(commonRoot, "Source files must have a common root");

		return commonRoot;
	}

}

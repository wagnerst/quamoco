/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: RemoteJobBase.java 25902 2010-02-02 14:44:46Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.distributed;

import java.io.Serializable;

import edu.tum.cs.conqat.logging.ELogLevel;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Base class for remote jobs which supports transfer of results and logging.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 25902 $
 * @levd.rating GREEN Hash: 3B3325DEAF40448AEC8B882019F6CB39
 */
public abstract class RemoteJobBase implements Runnable, Serializable {

	/** The variable to store the result in. */
	protected Object result;

	/** The minimal level at which logging is supported. */
	private ELogLevel minLoggedLevel;

	/**
	 * The logger. This does not store relevant information and thus is
	 * transient and initialized lazy.
	 */
	private transient StoringConQATLogger logger;

	/** Transport object for stored log messages. */
	private StoredLogMessage[] logMessages;

	/**
	 * Lazy initialization. This is not performed in the constructor to avoid
	 * that all subclasses have to pass this parameter through.
	 */
	/* package */void init(ELogLevel minLoggedLevel) {
		this.minLoggedLevel = minLoggedLevel;
	}

	/** Returns the stored log messages (may be null). */
	public StoredLogMessage[] getLogMessages() {
		return logMessages;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * If the calculation causes an exception (Throwable), this is returned in
	 * the <code>result</code> attribute.
	 */
	public final void run() {
		try {
			result = calculateResult();
		} catch (Throwable t) {
			result = t;
		}
		if (logger != null) {
			logMessages = logger.obtainMessages();
		}
	}

	/** Template method for calculating the result. */
	protected abstract Object calculateResult() throws Exception;

	/** Returns the logger which can be used */
	protected IConQATLogger getLogger() {
		if (logger == null) {
			logger = new StoringConQATLogger(minLoggedLevel);
		}
		return logger;
	}
}

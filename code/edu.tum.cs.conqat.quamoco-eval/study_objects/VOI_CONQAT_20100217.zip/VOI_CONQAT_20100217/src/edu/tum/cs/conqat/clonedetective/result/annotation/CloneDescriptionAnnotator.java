/*--------------------------------------------------------------------------+
   $Id: CloneDescriptionAnnotator.java 23489 2009-08-07 16:09:49Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.region.Region;
import edu.tum.cs.commons.region.RegionSet;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Annotates each element in a file system tree with a human-readable
 * description of its clones.
 * 
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23489 $
 * @levd.rating GREEN Hash: 16DD0F4311CBF631D0FE5927BC2F162D
 */
@AConQATProcessor(description = "Annotates each element in a file system tree with a human-readable "
		+ "description of its clones.")
public class CloneDescriptionAnnotator extends CloneAnnotatorBase {

	/** Key for clone descriptions */
	@AConQATKey(description = "Contains human-readable descriptions of the clones of this elements, "
			+ "or empty list, if element has no clone", type = "java.util.List<String>")
	public static final String CLONES_DESCRIPTION_KEY = "Cloned Lines";

	/** Makes clone description visible */
	@Override
	protected String[] getKeys() {
		return new String[] { CLONES_DESCRIPTION_KEY };
	}

	/** Store description of clones at element */
	@Override
	protected void annotateClones(IFileSystemElement element,
			UnmodifiableList<Clone> clonesList) {
		element.setValue(CLONES_DESCRIPTION_KEY, prettyPrint(clonesList));
	}

	/** Creates a human readable representation of a list of clones */
	private List<String> prettyPrint(List<Clone> clones) {
		Map<CanonicalFile, RegionSet> cloneRegions = initializeCloneRegions(clones);

		List<String> descriptions = new ArrayList<String>();
		for (CanonicalFile file : CollectionUtils.sort(cloneRegions.keySet())) {
			int clonedLines = cloneRegions.get(file).getPositionCount();
			String description = file + ": " + clonedLines;
			descriptions.add(description);
		}

		return descriptions;
	}

	/** Create mapping from file to clone region sets */
	private Map<CanonicalFile, RegionSet> initializeCloneRegions(
			List<Clone> clones) {
		Map<CanonicalFile, RegionSet> cloneRegions = new HashMap<CanonicalFile, RegionSet>();

		for (Clone clone : clones) {
			for (Clone sibling : CloneUtils.getSiblings(clone)) {
				CanonicalFile file = sibling.getFile();
				RegionSet regions = getOrCreate(cloneRegions, file);
				regions.add(new Region(sibling.getStartLineInFile(), sibling
						.getLastLineInFile()));
			}
		}

		return cloneRegions;
	}

	/**
	 * Retrieves the {@link RegionSet} for a clone file. If no {@link RegionSet}
	 * is stored for a file, a new {@link RegionSet} is created.
	 */
	private RegionSet getOrCreate(Map<CanonicalFile, RegionSet> cloneRegions,
			CanonicalFile file) {
		if (!cloneRegions.containsKey(file)) {
			cloneRegions.put(file, new RegionSet());
		}
		return cloneRegions.get(file);
	}

}

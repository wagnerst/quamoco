/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: FileRemoteJob.java 25901 2010-02-02 14:22:52Z deissenb $            
 |                                                                       |
 | Copyright (c)  2004-2009 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.distributed;

import java.io.Serializable;
import java.nio.charset.Charset;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.distributed.JobDistributorBase;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * A job which calculates a value based on a single file.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 25901 $
 * @levd.rating GREEN Hash: F5B2A392CFFE940667E0C21EFA196500
 */
public abstract class FileRemoteJob extends
		RemoteJobBase {

	/** The file to work on. */
	protected final CanonicalFile file;

	/**
	 * The encoding to be used. We use a string (its name) instead of
	 * {@link Charset} as the later is not {@link Serializable}.
	 */
	protected final String encoding;

	/** Constructor. */
	public FileRemoteJob(CanonicalFile file, Charset encoding) {
		this.file = file;
		this.encoding = encoding.name();
	}

	/** {@inheritDoc} */
	@Override
	protected Object calculateResult() throws ConQATException {
		return calculateResult(file, encoding);
	}

	/** Calculates the result based on the given file. */
	protected abstract Object calculateResult(CanonicalFile file,
			String encoding) throws ConQATException;

	/** Convenience method used to schedule the job. */
	public void schedule(JobDistributorBase jobDistributor, IConQATNode node,
			String key, IConQATLogger logger) {
		jobDistributor.executeJob(new KeyCalculatingJob<FileRemoteJob>(this,
				node, key, logger), file);
	}
}

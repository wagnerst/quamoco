/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.commons
 |                                                                       |
   $Id: StoringConQATLogger.java 25929 2010-02-03 07:53:11Z deissenb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.distributed;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.logging.ConQATLoggerBase;
import edu.tum.cs.conqat.logging.ELogLevel;

/**
 * A ConQAT logger which stores all messages locally.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 25929 $
 * @levd.rating GREEN Hash: 3D6F94C97AE84F0B71554635A50167A0
 */
/* package */class StoringConQATLogger extends ConQATLoggerBase {

	/** The minimal level at which logging is performed. */
	private final ELogLevel minLoggedLevel;

	/** The log messages encountered so far. */
	private final List<StoredLogMessage> messages = new ArrayList<StoredLogMessage>();

	/** Constructor. */
	public StoringConQATLogger(ELogLevel minLoggedLevel) {
		this.minLoggedLevel = minLoggedLevel;
	}

	/** {@inheritDoc} */
	@Override
	public void log(ELogLevel level, Object message) {
		log(level, message, null);
	}

	/** {@inheritDoc} */
	@Override
	public void log(ELogLevel level, Object message, Throwable throwable) {
		// comparison is valid as log levels are sorted "correctly" in enum
		if (level.ordinal() >= minLoggedLevel.ordinal()) {
			messages.add(new StoredLogMessage(level, message, throwable));
		}
	}

	/** {@inheritDoc} */
	@Override
	public ELogLevel getMinLogLevel() {
		return minLoggedLevel;
	}

	/** Returns all log messages as an array (null in case of no messages). */
	public StoredLogMessage[] obtainMessages() {
		if (messages.isEmpty()) {
			return null;
		}
		return messages.toArray(new StoredLogMessage[messages.size()]);
	}
}

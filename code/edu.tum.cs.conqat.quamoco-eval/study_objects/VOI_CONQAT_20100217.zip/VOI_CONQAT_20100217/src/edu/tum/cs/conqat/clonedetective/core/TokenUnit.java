/*--------------------------------------------------------------------------+
   $Id: TokenUnit.java 25617 2010-01-26 15:03:01Z juergens $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.scanner.ETokenType;

/**
 * Unit-implementation for tokens.
 * 
 * @author Rainer Spitzhirn
 * @author $Author: juergens $
 * 
 * @version $Revision: 25617 $
 * @levd.rating GREEN Hash: E35CC4AB751A2F4C4D460BE51C3C3701
 */
public class TokenUnit extends Unit {

	/** Type of underlying token */
	private final ETokenType tokenType;

	/** Start position of token in its file */
	private final int offset;

	/**
	 * Create new {@link TokenUnit}.
	 * <p>
	 * Since we don't know how many lines a token spans, we always use 1 for
	 * covered lines.
	 * 
	 * @param content
	 *            the token's content
	 * @param startLineInFile
	 *            Line number of start of unit in file
	 * @param file
	 *            File this unit stems from
	 */
	public TokenUnit(String content, String unnormalizedContent, int offset,
			int startLineInFile, CanonicalFile file, ETokenType tokenType,
			int indexInFile) {
		super(startLineInFile, file, content, unnormalizedContent, 1,
				indexInFile);
		this.tokenType = tokenType;
		this.offset = offset;
	}

	/**
	 * Create new {@link TokenUnit} with same normalized and unnormalized
	 * content.
	 */
	public TokenUnit(String content, int offset, int startLineInFile,
			CanonicalFile file, ETokenType tokenType, int indexInFile) {
		this(content, content, offset, startLineInFile, file, tokenType,
				indexInFile);
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		String result = "TOKEN '" + getContent() + "' (" + getType() + ")";
		result += " \"" + getFile() + "\"" + " line " + getStartLineInFile();
		return result;
	}

	/** Returns type of underlying token. */
	public ETokenType getType() {
		return tokenType;
	}

	/** Returns offset. */
	public int getOffset() {
		return offset;
	}

}
/*--------------------------------------------------------------------------+
   $Id: NodeIdCopier.java 25266 2010-01-25 10:55:20Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.util;

import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor copies the node id to the key {@value #KEY}.
 * 
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 25266 $
 * @levd.rating GREEN Hash: 6D6D922B5D18030AA3F6B4C65A57A66D
 */
@AConQATProcessor(description = "Copies ID to key 'Id'.")
public class NodeIdCopier extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** The key. */
	@AConQATKey(description = "The node's id.", type = "java.lang.String")
	public final static String KEY = "Id";

	/** Add key to display list. */
	@Override
	protected void setUp(IConQATNode root) {
		NodeUtils.addToDisplayList(root, KEY);
	}

	/** Leaves are the target nodes. */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** Copy id to key. */
	public void visit(IConQATNode node) {
		node.setValue(KEY, node.getId());
	}

}

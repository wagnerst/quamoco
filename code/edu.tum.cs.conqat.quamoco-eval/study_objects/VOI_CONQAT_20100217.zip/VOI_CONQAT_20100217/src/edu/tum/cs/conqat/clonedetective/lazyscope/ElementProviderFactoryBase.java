/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.clonedetective
 |                                                                       |
   $Id: ElementProviderFactoryBase.java 25694 2010-01-27 08:45:10Z hummelb $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.filesystem.regions.RegionMarkerStrategyBase;
import edu.tum.cs.conqat.filesystem.scope.IFileSystemElement;

/**
 * Base class for element provider factories.
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 25694 $
 * @levd.rating GREEN Hash: BDEE6F99B027980D99FE034B612D7BD5
 */
public abstract class ElementProviderFactoryBase<Element extends IFileSystemElement>
		extends ConQATProcessorBase {

	/** List of strategies that get evaluated */
	protected final List<RegionMarkerStrategyBase<Element>> strategies = new ArrayList<RegionMarkerStrategyBase<Element>>();

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "region-marker", description = "Add region-marker strategy", minOccurrences = 0)
	public void addAnnotationStrategy(
			@AConQATAttribute(name = "strategy", description = ConQATParamDoc.INPUT_REF_NAME) RegionMarkerStrategyBase<Element> strategy) {
		this.strategies.add(strategy);
	}

}
/*--------------------------------------------------------------------------+
   $Id: DateValueSeriesCreator.java 25259 2010-01-25 10:36:08Z hummelb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.statistics;

import java.util.Date;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * @version $Rev: 25259 $
 * @levd.rating GREEN Hash: DE6CA447FE3983D2550C3334458E8214
 */
@AConQATProcessor(description = "Creates a DateValueSeries of date/y values from IConQATNode leaves.")
public class DateValueSeriesCreator extends ConQATProcessorBase {

	/** Root node of input tree */
	private IConQATNode root;

	/** The key for the property which will be used as x */
	private String dateKey;

	/** The key for the property which will be used as y */
	private String yKey;

	/** Value that is used if no value can be retrieved */
	private double defaultValue = 0;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "root", minOccurrences = 1, maxOccurrences = 1, description = "IConQATNode and the read keys")
	public void setInput(
			@AConQATAttribute(name = "ref", description = "IConQATNode") IConQATNode input,
			@AConQATAttribute(name = "dateKey", description = "The key for the property which will be used as date") String dateKey,
			@AConQATAttribute(name = "yKey", description = "The key for the property which will be used as y") String yKey) {

		root = input;
		this.dateKey = dateKey;
		this.yKey = yKey;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "default", minOccurrences = 0, maxOccurrences = 1, description = "Value that is used if no value can be retrieved")
	public void setDefaultValue(
			@AConQATAttribute(name = "value", description = "If not set, default value is 0.") double defaultValue) {
		this.defaultValue = defaultValue;
	}

	/** {@inheritDoc} */
	public DateValueSeries process() throws ConQATException {
		DateValueSeries series = new DateValueSeries();

		for (IConQATNode leaf : TraversalUtils.listLeavesDepthFirst(root)) {
			Date date = NodeUtils.getDateValue(leaf, dateKey);
			double value = NodeUtils
					.getDoubleValue(leaf, yKey, defaultValue);
			series.addValue(date, value);
		}

		return series;
	}

}

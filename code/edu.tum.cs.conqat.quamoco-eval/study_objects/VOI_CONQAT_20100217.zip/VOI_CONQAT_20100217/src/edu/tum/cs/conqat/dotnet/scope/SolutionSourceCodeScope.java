/*--------------------------------------------------------------------------+
   $Id: SolutionSourceCodeScope.java 23868 2009-08-28 10:37:50Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.scope;

import java.io.File;
import java.util.List;

import edu.tum.cs.commons.factory.IParameterizedFactory;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.scope.project.ProjectFileParser;
import edu.tum.cs.conqat.sourcecode.scope.SourceCodeElement;
import edu.tum.cs.conqat.sourcecode.scope.SourceCodeElementFactory;
import edu.tum.cs.scanner.ELanguage;

/**
 * Creates a source code scope of all VS.NET solution files contained in a file
 * system tree. If any file is contained in multiple included projects, it only
 * occurs once in the scope.
 * <p>
 * Currently, only a single language is supported for the entire scope.
 * 
 * @author Elmar Juergens
 * @author juergens
 * @author $Author: deissenb $
 * @version $Rev: 23868 $
 * @levd.rating GREEN Hash: 9DEFFAADC6625DBE4C1ED88A412B9E78
 */
@AConQATProcessor(description = "Creates a source code scope of all VS.NET solution files contained in a file"
		+ "system tree. If any file is contained in multiple included projects, it only"
		+ "occurs once in the scope."
		+ "Currently, only a single language is supported for the entire scope.")
public class SolutionSourceCodeScope extends
		SolutionScopeBase<SourceCodeElement> {

	/** Language of the files contained in the solution scope */
	private ELanguage language;

	/** ConQAT Parameter */
	@AConQATParameter(name = "language", minOccurrences = 1, maxOccurrences = 1, description = "Define programming language.")
	public void setLanguage(
			@AConQATAttribute(name = "name", description = ""
					+ "A programming language of enum type edu.tum.cs.scanner.ELanguage") ELanguage language) {

		this.language = language;
	}

	/**
	 * {@inheritDoc} This method is required since ConQAT does not support type
	 * checking on generics.
	 */
	@Override
	public SourceCodeElement process() throws ConQATException {
		return super.process();
	}

	/** Template method that extracts the source files from a project file */
	@Override
	public List<String> extractRelevantFilesFromProject(File projectFile,
			ProjectFileParser projectParser) throws ConQATException {
		return projectParser.extractSourceFilenames(projectFile);
	}

	/** {@inheritDoc} */
	@Override
	protected IParameterizedFactory<SourceCodeElement, String, ConQATException> createElementFactory() {
		return new SourceCodeElementFactory(encoding, language);
	}

}

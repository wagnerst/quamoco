/*-----------------------------------------------------------------------+
 | edu.tum.cs.conqat.cpp
 |                                                                       |
   $Id: ReportReaderBase.java 26013 2010-02-10 12:40:02Z juergens $            
 |                                                                       |
 | Copyright (c)  2004-2010 Technische Universitaet Muenchen             |
 |                                                                       |
 | Technische Universitaet Muenchen               #########  ##########  |
 | Institut fuer Informatik - Lehrstuhl IV           ##  ##  ##  ##  ##  |
 | Prof. Dr. Manfred Broy                            ##  ##  ##  ##  ##  |
 | Boltzmannstr. 3                                   ##  ##  ##  ##  ##  |
 | 85748 Garching bei Muenchen                       ##  ##  ##  ##  ##  |
 | Germany                                           ##  ######  ##  ##  |
 +-----------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for processors that read one or many reports and produce findings.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 26013 $
 * @levd.rating YELLOW Hash: ACBBBC7A21BC43EA5E7A530B857E0A93
 */
public abstract class ReportReaderBase extends ConQATProcessorBase {

	/** The reports to read. */
	protected final List<File> reports = new ArrayList<File>();

	/** The report created. */
	protected final FindingReport findingReport = new FindingReport();

	/** Finding groups created so far. */
	private final Map<String, FindingGroup> findingGroups = new HashMap<String, FindingGroup>();

	/** The finding category used. */
	protected FindingCategory findingCategory;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "report", minOccurrences = 1, description = "Loads findbug reports to be converted.")
	public void addReport(
			@AConQATAttribute(name = "file", description = "The location of the report") String report)
			throws ConQATException {
		File reportFile = new File(report);
		if (!(reportFile.isFile() && reportFile.canRead())) {
			throw new ConQATException("Report file " + reportFile
					+ " could not be read!");
		}
		reports.add(reportFile);
	}

	/** {@inheritDoc} */
	public FindingReport process() throws ConQATException {
		findingCategory = findingReport.getOrCreateCategory("PCLint");

		for (File pclintReport : reports) {
			loadReport(pclintReport);
		}

		return findingReport;
	}

	/** Template method that deriving classes override */
	protected abstract void loadReport(File pclintReport)
			throws ConQATException;

	/** Returns the finding group for a given bug type. */
	protected FindingGroup getFindingGroup(String groupCode)
			throws ConQATException {
		FindingGroup group = findingGroups.get(groupCode);
		if (group == null) {
			group = findingCategory.createFindingGroup(resolveRule(groupCode));
			findingGroups.put(groupCode, group);
		}
		return group;
	}

	/**
	 * Resolve group code to group description. Default implementation does not
	 * perform any resolution.
	 */
	@SuppressWarnings("unused")
	protected String resolveRule(String groupCode) throws ConQATException {
		return groupCode;
	}

}
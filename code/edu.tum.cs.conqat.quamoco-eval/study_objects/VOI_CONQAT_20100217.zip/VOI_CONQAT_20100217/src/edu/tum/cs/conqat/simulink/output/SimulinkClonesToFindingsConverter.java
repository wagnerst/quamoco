/*--------------------------------------------------------------------------+
   $Id: SimulinkClonesToFindingsConverter.java 25878 2010-02-01 14:54:31Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.output;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.findings.EFindingKeys;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingCategory;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.location.QualifiedNameLocation;
import edu.tum.cs.conqat.commons.findings.typespec.EFindingTypeSpecType;
import edu.tum.cs.conqat.commons.findings.typespec.FindingTypeSpec;
import edu.tum.cs.conqat.commons.findings.typespec.FindingTypeSpecEntry;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.simulink.clones.result.SimulinkClone;
import edu.tum.cs.conqat.simulink.clones.result.SimulinkCloneResultNode;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 25878 $
 * @levd.rating GREEN Hash: DFF7C1B67ACE6A8D6421BF00893BACA3
 */
@AConQATProcessor(description = "Processor for converting a Simulink clone result to a finding report.")
public class SimulinkClonesToFindingsConverter extends ConQATProcessorBase {

	/** The clones */
	private SimulinkCloneResultNode cloneResult;

	/** The category to add to. */
	private FindingCategory category;

	/** Counter for the clone groups. */
	private int numGroups = 0;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = "The simulink clone result.")
	public void setCloneResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) SimulinkCloneResultNode cloneResult) {
		this.cloneResult = cloneResult;
	}

	/** {@inheritDoc} */
	public FindingReport process() {
		FindingReport report = new FindingReport();
		category = report.getOrCreateCategory("Simulink Clones");
		for (SimulinkClone clone : cloneResult.getChildren()) {
			convertClone(clone);
		}
		return report;
	}

	/** Converts a clone to a finding group. */
	private void convertClone(SimulinkClone clone) {
		FindingGroup group = category.createFindingGroup("Clone Group "
				+ ++numGroups);
		for (UnmodifiableList<SimulinkBlock> blocks : clone.getBlockLists()) {
			Finding finding = group
					.createFinding("ConQAT Model Clone Detective");
			for (SimulinkBlock block : blocks) {
				finding.addLocation(new QualifiedNameLocation(block.getId()));
			}
		}

		FindingTypeSpec format = new FindingTypeSpec();
		// just copy everything looking numeric
		for (String key : NodeUtils.getDisplayList(cloneResult)) {
			Object value = group.getValue(key);
			if (value instanceof Number) {
				group.setValue(key, value);
				format.addEntry(new FindingTypeSpecEntry(key,
						EFindingTypeSpecType.DOUBLE));
			}
		}

		group.setValue(EFindingKeys.TYPESPEC.name(), format);
	}
}

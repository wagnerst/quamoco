/*--------------------------------------------------------------------------+
   $Id: FileLocation.java 23491 2009-08-07 16:11:14Z deissenb $
 |                                                                          |
 | Copyright 2005-2009 Technische Universitaet Muenchen                     |
 |                                                                          |
 | Licensed under the Apache License, Version 2.0 (the "License");          |
 | you may not use this file except in compliance with the License.         |
 | You may obtain a copy of the License at                                  |
 |                                                                          |
 |    http://www.apache.org/licenses/LICENSE-2.0                            |
 |                                                                          |
 | Unless required by applicable law or agreed to in writing, software      |
 | distributed under the License is distributed on an "AS IS" BASIS,        |
 | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
 | See the License for the specific language governing permissions and      |
 | limitations under the License.                                           |
 +--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.findings.location;

import edu.tum.cs.commons.filesystem.CanonicalFile;

/**
 * Location for a file (without exact position).
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 23491 $
 * @levd.rating GREEN Hash: 587D0F28B44A95C5713F896CB5D7BA95
 */
public class FileLocation extends LocationBase {

	/** The file. */
	private final CanonicalFile file;

	/** Constructor. */
	public FileLocation(CanonicalFile file) {
		this.file = file;
	}

	/** Returns the file. */
	public CanonicalFile getFile() {
		return file;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return file.getName();
	}
}

package tvbrowser.extras.programinfo;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.Borders;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.l2fprod.common.swing.plaf.LookAndFeelAddons;

import util.program.ProgramTextCreator;
import util.ui.FontChooserPanel;
import util.ui.OrderChooser;
import util.ui.PictureSettingsPanel;

import devplugin.Plugin;
import devplugin.ProgramFieldType;
import devplugin.SettingsTab;

/**
 * The order settings for the ProgramInfo.
 * 
 * @author Ren� Mach
 *
 */
public class ProgramInfoOrderSettingsTab implements SettingsTab {
  
  private OrderChooser mList;
  private String mOldOrder, mOldSetupState;
  
  /*Font*/
  private JCheckBox mUserFont, mAntiAliasing;
  private FontChooserPanel mTitleFont, mBodyFont;
  
  private String mOldTitleFont, mOldBodyFont,
  mOldTitleFontSize, mOldBodyFontSize, mOldUserFontSelected,
  mOldAntiAliasingSelected;
  
  private Properties mSettings;
  
  /*Design*/
  private String mOldLook;
  
  private JComboBox mLook;
  
  private String[] mLf = {
      "com.l2fprod.common.swing.plaf.aqua.AquaLookAndFeelAddons",
      "com.l2fprod.common.swing.plaf.metal.MetalLookAndFeelAddons",
      "com.l2fprod.common.swing.plaf.motif.MotifLookAndFeelAddons",
      "com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons",
      "com.l2fprod.common.swing.plaf.windows.WindowsClassicLookAndFeelAddons"
  };
  
  private JCheckBox mShowFunctions, mShowTextSearchButton;
  
  /** Picture settings */
  private PictureSettingsPanel mPictureSettings;
  private JCheckBox mZoomEnabled;
  private JSpinner mZoomValue;
  
  public JPanel createSettingsPanel() {
    CellConstraints cc = new CellConstraints();
    PanelBuilder pb1a = new PanelBuilder(new FormLayout("5dlu,12dlu,pref,2dlu,pref:grow","pref,2dlu,pref"));
    
    pb1a.add(mZoomEnabled = new JCheckBox(ProgramInfo.mLocalizer.msg("scaleImage","Scale picture:"), ProgramInfo.getInstance().getProperty("zoom","false").compareTo("true") == 0), cc.xyw(2,1,4));
    pb1a.add(mZoomValue = new JSpinner(new SpinnerNumberModel(Integer.parseInt(ProgramInfo.getInstance().getProperty("zoomValue","100")),50,300,1)), cc.xy(3,3));
    final JLabel label = pb1a.addLabel("%",cc.xy(5,3));

    mZoomEnabled.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        mZoomValue.setEnabled(mZoomEnabled.isSelected());
        label.setEnabled(mZoomEnabled.isSelected());
      }
    });
    
    mZoomValue.setEnabled(mZoomEnabled.isSelected());
    label.setEnabled(mZoomEnabled.isSelected());
    
    mPictureSettings = new PictureSettingsPanel(ProgramInfo.getInstance().getProgramPanelSettings(), true, true , pb1a.getPanel());
    
    mSettings = ProgramInfo.getInstance().getSettings();
    
    mOldOrder = ProgramInfo.getInstance().getProperty("order", "");
    mOldSetupState = ProgramInfo.getInstance().getProperty("setupwasdone","false");        
    
    Object[] order;
    
    if (mOldOrder.indexOf(";") == -1) {
      if(mOldSetupState.compareTo("false") == 0)
        order = ProgramTextCreator.getDefaultOrder();
      else
        order = new Object[0];
      
      mList = new OrderChooser(order,ProgramTextCreator.getDefaultOrder(),true);
    }
    else {
      String[] id = mOldOrder.trim().split(";");
      order = new Object[id.length];
      for (int i = 0; i < order.length; i++)
        try {
          order[i] = ProgramFieldType
              .getTypeForId(Integer.parseInt((String) id[i]));
          
          if(((ProgramFieldType)order[i]).getTypeId() == ProgramFieldType.UNKOWN_FORMAT)
            order[i] = ProgramTextCreator.getDurationTypeString();
          
        } catch (Exception e) {
          order[i] = id[i];
        }
      mList = new OrderChooser(order,ProgramTextCreator.getDefaultOrder(),true);
    }
    
    JButton previewBtn = new JButton(ProgramInfo.mLocalizer.msg("preview", "Prewview"));
    previewBtn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        saveSettings();
        ProgramInfo.getInstance().showProgramInformation(
            Plugin.getPluginManager().getExampleProgram(), false);
        restoreSettings();
      }
    });

    JButton defaultBtn = new JButton(ProgramInfo.mLocalizer.msg("default", "Default"));
    defaultBtn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        resetSettings();
      }
    });
    
    PanelBuilder builder = new PanelBuilder(new FormLayout("5dlu,pref:grow,5dlu","5dlu,fill:pref:grow,10dlu,pref"));
    builder.setDefaultDialogBorder();
    
    builder.add(mList, cc.xy(2,2));
    
    JTabbedPane tabbedPane = new JTabbedPane();
    
    tabbedPane.addTab(ProgramInfo.mLocalizer.msg("orderSettings","Info selection/ordering"),builder.getPanel());
    
    JPanel formating = new JPanel(new FormLayout("default:grow","default,10dlu,default,10dlu,default"));
    
    formating.add(createFontSettings(), cc.xy(1,1));
    formating.add(createDesginSettings(), cc.xy(1,3));
    formating.add(createFunctionsPanel(), cc.xy(1,5));
    
    tabbedPane.addTab(ProgramInfo.mLocalizer.msg("formating","Formating"),formating);
    
    tabbedPane.addTab(ProgramInfo.mLocalizer.msg("pictures","Pictures"), mPictureSettings);
    
    JPanel main = new JPanel(new FormLayout("default:grow","fill:default:grow,10dlu,pref"));
    main.setBorder(Borders.DIALOG_BORDER);
    main.add(tabbedPane, cc.xy(1,1));
    
    FormLayout layout = new FormLayout("pref,pref:grow,pref","pref");
    layout.setColumnGroups(new int[][] {{1,3}});
    JPanel buttonPn = new JPanel(layout);
    buttonPn.add(previewBtn, cc.xy(3,1));
    buttonPn.add(defaultBtn, cc.xy(1,1));
    
    main.add(buttonPn, cc.xy(1,3));
    
    return main;
  }

  private void resetSettings() {
    mList.setOrder(ProgramTextCreator.getDefaultOrder(),ProgramTextCreator.getDefaultOrder());
    
    mAntiAliasing.setSelected(false);
    mUserFont.setSelected(false);
    
    String look = LookAndFeelAddons.getBestMatchAddonClassName();
    
    for(int i = 0; i < mLf.length; i++)
      if(look.toLowerCase().indexOf(mLf[i].toLowerCase()) != -1) {
        mLook.setSelectedIndex(i);
        break;
      }
  }

  public void saveSettings() {
    Object[] o = mList.getOrder();

    String temp = "";

    for (int i = 0; i < o.length; i++)
      if (o[i] instanceof String)
        temp += ProgramFieldType.UNKOWN_FORMAT + ";";        
      else
        temp += ((ProgramFieldType) o[i]).getTypeId() + ";";

    ProgramInfo.getInstance().getSettings().setProperty("order", temp);
    ProgramInfo.getInstance().getSettings().setProperty("setupwasdone", "true");
    ProgramInfo.getInstance().setOrder();
    
    mSettings.setProperty("antialiasing", String.valueOf(mAntiAliasing
        .isSelected()));
    mSettings.setProperty("userfont", String.valueOf(mUserFont.isSelected()));

    Font f = mTitleFont.getChosenFont();
    mSettings.setProperty("titlefont", f.getFamily());
    mSettings.setProperty("title", String.valueOf(f.getSize()));

    f = mBodyFont.getChosenFont();
    mSettings.setProperty("bodyfont", f.getFamily());
    mSettings.setProperty("small", String.valueOf(f.getSize()));
    
    ProgramInfo.getInstance().getSettings().setProperty("look", mLf[mLook.getSelectedIndex()]);
    ProgramInfo.getInstance().setLook();
    
    ProgramInfo.getInstance().getSettings().setProperty("pictureType", String.valueOf(mPictureSettings.getPictureShowingType()));
    ProgramInfo.getInstance().getSettings().setProperty("pictureTimeRangeStart", String.valueOf(mPictureSettings.getPictureTimeRangeStart()));
    ProgramInfo.getInstance().getSettings().setProperty("pictureTimeRangeEnd", String.valueOf(mPictureSettings.getPictureTimeRangeEnd()));
    ProgramInfo.getInstance().getSettings().setProperty("pictureShowsDescription", String.valueOf(mPictureSettings.getPictureIsShowingDescription()));
    ProgramInfo.getInstance().getSettings().setProperty("pictureDuration", String.valueOf(mPictureSettings.getPictureDurationTime()));
    ProgramInfo.getInstance().getSettings().setProperty("zoom", String.valueOf(mZoomEnabled.isSelected()));
    ProgramInfo.getInstance().getSettings().setProperty("zoomValue", String.valueOf(mZoomValue.getValue()));
    
    if(PictureSettingsPanel.typeContainsType(mPictureSettings.getPictureShowingType(),PictureSettingsPanel.SHOW_FOR_PLUGINS)) {
      StringBuffer temp1 = new StringBuffer();
      
      String[] plugins = mPictureSettings.getClientPluginIds();
      
      for(int i = 0; i < plugins.length; i++)
        temp1.append(plugins[i]).append(";;");
      
      if(temp.toString().endsWith(";;"))
        temp1.delete(temp.length()-2,temp.length());
      
      ProgramInfo.getInstance().getSettings().setProperty("clientPlugins", temp1.toString());
    }
  }

  private void restoreSettings() {
    ProgramInfo.getInstance().getSettings().setProperty("setupwasdone", mOldSetupState);
    ProgramInfo.getInstance().getSettings().setProperty("order", mOldOrder);
    ProgramInfo.getInstance().setOrder();
    
    mSettings.setProperty("antialiasing", mOldAntiAliasingSelected);
    mSettings.setProperty("userfont", mOldUserFontSelected);
    mSettings.setProperty("titlefont", mOldTitleFont);
    mSettings.setProperty("title", mOldTitleFontSize);
    mSettings.setProperty("bodyfont", mOldBodyFont);
    mSettings.setProperty("small", mOldBodyFontSize); 
    
    ProgramInfo.getInstance().getSettings().setProperty("look", mOldLook);
    ProgramInfo.getInstance().setLook();
  }

  public Icon getIcon() {
    return ProgramInfo.getInstance().getIcon();
  }

  public String getTitle() {
    return ProgramInfo.mLocalizer.msg("pluginName","Program details");
  }
  
  private JPanel createFontSettings() {
    mOldAntiAliasingSelected = mSettings.getProperty("antialiasing", "false");
    mOldUserFontSelected = mSettings.getProperty("userfont", "false");
    mOldTitleFontSize = mSettings.getProperty("title", "18");
    mOldBodyFontSize = mSettings.getProperty("small", "11");
    mOldTitleFont = mSettings.getProperty("titlefont", "Verdana");
    mOldBodyFont = mSettings.getProperty("bodyfont", "Verdana");  
    
    mAntiAliasing = new JCheckBox(ProgramInfo.mLocalizer
        .msg("antialiasing", "Antialiasing"));
    mAntiAliasing.setSelected(mOldAntiAliasingSelected.compareToIgnoreCase("true") == 0);

    mUserFont = new JCheckBox(ProgramInfo.mLocalizer.msg("userfont", "Use user fonts"));
    mUserFont.setSelected(mOldUserFontSelected.compareToIgnoreCase("true") == 0);

    int size = Integer.parseInt(mOldTitleFontSize);

    mTitleFont = new FontChooserPanel(null,
        new Font(mOldTitleFont, Font.PLAIN, size), false);
    mTitleFont.setMaximumSize(mTitleFont.getPreferredSize());
    mTitleFont.setAlignmentX(FontChooserPanel.LEFT_ALIGNMENT);
    mTitleFont.setBorder(BorderFactory.createEmptyBorder(5, 20, 0, 0));

    size = Integer.parseInt(mOldBodyFontSize);
    
    mBodyFont = new FontChooserPanel(null, new Font(mOldBodyFont,
            Font.PLAIN, size), false);
    mBodyFont.setMaximumSize(mBodyFont.getPreferredSize());
    mBodyFont.setAlignmentX(FontChooserPanel.LEFT_ALIGNMENT);
    mBodyFont.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

    mTitleFont.setEnabled(mUserFont.isSelected());
    mBodyFont.setEnabled(mUserFont.isSelected());
    
    CellConstraints cc = new CellConstraints();
    PanelBuilder builder = new PanelBuilder(new FormLayout("5dlu,10dlu,pref,pref,pref:grow,5dlu","pref,5dlu,pref,pref,pref,pref"));
    builder.setDefaultDialogBorder();
    
    builder.addSeparator(ProgramInfo.mLocalizer.msg("font","Font settings"), cc.xyw(1,1,6));
    builder.add(mAntiAliasing, cc.xyw(2,3,4));
    builder.add(mUserFont, cc.xyw(2,4,4));
    final JLabel titleLabel = builder.addLabel(ProgramInfo.mLocalizer.msg("title", "Title font"), cc.xy(3,5));
    builder.add(mTitleFont, cc.xy(4,5));
    final JLabel bodyLabel = builder.addLabel(ProgramInfo.mLocalizer.msg("body", "Description font"), cc.xy(3,6));
    builder.add(mBodyFont, cc.xy(4,6));
    
    mUserFont.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        mTitleFont.setEnabled(mUserFont.isSelected());
        mBodyFont.setEnabled(mUserFont.isSelected());
        titleLabel.setEnabled(mUserFont.isSelected());
        bodyLabel.setEnabled(mUserFont.isSelected());
      }
    });
    
    mTitleFont.setEnabled(mUserFont.isSelected());
    mBodyFont.setEnabled(mUserFont.isSelected());
    titleLabel.setEnabled(mUserFont.isSelected());
    bodyLabel.setEnabled(mUserFont.isSelected());
    
    return builder.getPanel();
  }
  
  private JPanel createDesginSettings() {
    mOldLook = ProgramInfo.getInstance().getProperty("look", "");
    
    String[] lf = {"Aqua", "Metal", "Motif", "Windows XP",
    "Windows Classic"};
    
    mLook = new JComboBox(lf);
    
    String look = mOldLook.length() > 0 ? mOldLook : LookAndFeelAddons.getBestMatchAddonClassName();
    
    for(int i = 0; i < mLf.length; i++)
      if(look.toLowerCase().indexOf(mLf[i].toLowerCase()) != -1) {
        mLook.setSelectedIndex(i);
        break;
      }
    
    CellConstraints cc = new CellConstraints();
    PanelBuilder builder = new PanelBuilder(new FormLayout("5dlu,pref,pref:grow","pref,5dlu,pref"));
    builder.setDefaultDialogBorder();
    
    builder.addSeparator(ProgramInfo.mLocalizer.msg("design","Design"), cc.xyw(1,1,3));
    builder.add(mLook, cc.xy(2,3));
    
    return builder.getPanel();
  }
  
  private JPanel createFunctionsPanel() {
    CellConstraints cc = new CellConstraints();
    PanelBuilder builder = new PanelBuilder(new FormLayout("5dlu,10dlu,pref:grow,5dlu","pref,5dlu,pref,1dlu,pref"));
    builder.setDefaultDialogBorder();
    
    mShowFunctions = new JCheckBox(ProgramInfo.mLocalizer.msg("showFunctions","Show Functions"),ProgramInfo.getInstance().isShowFunctions());
    mShowTextSearchButton  = new JCheckBox(ProgramInfo.mLocalizer.msg("showTextSearchButton","Show \"Search in program\""),ProgramInfo.getInstance().isShowTextSearchButton());
        
    builder.addSeparator(ProgramInfoDialog.mLocalizer.msg("functions","Functions"), cc.xyw(1,1,3));
    builder.add(mShowFunctions, cc.xyw(2,3,2));
    builder.add(mShowTextSearchButton, cc.xy(3,5));
    
    mShowTextSearchButton.setEnabled(mShowFunctions.isSelected());
    
    mShowFunctions.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        mShowTextSearchButton.setEnabled(mShowFunctions.isSelected());
      }
    });
    
    return builder.getPanel();
  }

}

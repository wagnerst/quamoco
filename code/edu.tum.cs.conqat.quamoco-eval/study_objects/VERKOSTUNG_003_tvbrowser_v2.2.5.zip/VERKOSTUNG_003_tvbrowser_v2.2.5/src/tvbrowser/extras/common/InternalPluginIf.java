package tvbrowser.extras.common;

import javax.swing.Icon;

/**
 * A interface that all internal plugins have to implement.
 * 
 * @author Ren� Mach
 * @since 2.2.5
 */
public interface InternalPluginIf {
  public String getTitle();
  
  public String getDescription();
  
  public Icon getIcon();
}

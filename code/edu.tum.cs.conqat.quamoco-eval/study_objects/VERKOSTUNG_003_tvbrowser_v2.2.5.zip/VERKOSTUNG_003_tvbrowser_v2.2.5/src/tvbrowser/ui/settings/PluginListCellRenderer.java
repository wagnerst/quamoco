/*
 * TV-Browser
 * Copyright (C) 04-2003 Martin Oberhauser (darras@users.sourcceforge.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * CVS information:
 *  $RCSfile$
 *   $Source$
 *     $Date: 2007-11-02 20:08:16 +0100 (Fr, 02. Nov 2007) $
 *   $Author: ds10 $
 * $Revision: 4042 $
 */
package tvbrowser.ui.settings;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.Action;
import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import tvbrowser.core.plugin.PluginProxy;
import tvbrowser.extras.common.InternalPluginIf;
import util.ui.UiUtilities;

import com.jgoodies.forms.factories.Borders;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

import devplugin.ActionMenu;

/**
 * The CellRenderer for the Plugin-List
 * 
 * @author bodum
 */
public class PluginListCellRenderer extends DefaultListCellRenderer {
  /** Translation */
  private static final util.ui.Localizer mLocalizer
  = util.ui.Localizer.getLocalizerFor(PluginListCellRenderer.class);
  /** Panel that shows the Informations*/
  private JPanel panel;
  /** Description */
  private JTextArea desc;
  /** Icon */
  private JLabel icon;
  /** Name */
  private JLabel name;
  /** Cell-Constraints*/
  private CellConstraints cc = new CellConstraints();
  
  public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
      boolean cellHasFocus) {

    JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
try {    
    if (value instanceof PluginProxy || value instanceof InternalPluginIf) {
      Icon ico = null;
      String description = null;
      String nam = null;
      boolean activated = true;
      
      if(value instanceof PluginProxy) {
        PluginProxy plugin = (PluginProxy) value;
       
        ActionMenu actionMenu = plugin.getButtonAction();
        Action action = null;
        if (actionMenu !=null) {
          action = actionMenu.getAction();
        }

        if (action != null) {
          ico = (Icon) action.getValue(Action.SMALL_ICON);
        }
        
        if (ico == null) {
          // The plugin has no button icon -> Try the mark icon
          ico = plugin.getMarkIcon();
        }
        
        description = plugin.getInfo().getDescription();
        
        activated = plugin.isActivated();
        
        nam = plugin.getInfo().getName() + " " + plugin.getInfo().getVersion();
      }
      else {        
        nam = ((InternalPluginIf)value).getTitle();
        description = ((InternalPluginIf)value).getDescription();
        ico = ((InternalPluginIf)value).getIcon();
      }

      if (panel == null) {
        icon = new JLabel();
        name = new JLabel();
        name.setFont(label.getFont().deriveFont(Font.BOLD, label.getFont().getSize2D()+2));
        
        panel = new JPanel(new FormLayout("default, 2dlu, fill:pref:grow","default, 2dlu, default"));
        panel.setBorder(Borders.DLU2_BORDER);
        
        panel.add(icon, cc.xy(1,1));
        panel.add(name, cc.xy(3,1));
      }
      
      
      if (ico == null) {
        ico = new ImageIcon("imgs/Jar16.gif");
      }
      
      icon.setOpaque(label.isOpaque());
      icon.setBackground(label.getBackground());
      icon.setIcon(ico);

      if (desc != null)
        panel.remove(desc);
      desc = UiUtilities.createHelpTextArea(description);
      desc.setMinimumSize(new Dimension(100, 10));
      desc.setOpaque(false);
      desc.setForeground(label.getForeground());
      desc.setBackground(label.getBackground());
      panel.add(desc, cc.xy(3,3));

      name.setOpaque(false);
      name.setForeground(label.getForeground());
      name.setBackground(label.getBackground());
      
      if (activated) {
        name.setText(nam);
        name.setEnabled(true);                
      } else {
        name.setText(nam + " ["+mLocalizer.msg("deactivated", "Deactivated")+"]");
        name.setEnabled(false);
      }
      
      panel.setOpaque(label.isOpaque());
      panel.setBackground(label.getBackground());
      
      return panel;
    }
}catch(Exception e) {e.printStackTrace();}
    return label;
  }


}

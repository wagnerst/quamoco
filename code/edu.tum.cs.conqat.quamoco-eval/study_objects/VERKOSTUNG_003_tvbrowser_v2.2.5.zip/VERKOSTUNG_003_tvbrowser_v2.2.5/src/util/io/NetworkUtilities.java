/*
 * TV-Browser
 * Copyright (C) 04-2003 Martin Oberhauser (martin@tvbrowser.org)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * CVS information:
 *  $RCSfile$
 *   $Source$
 *     $Date: 2006-03-14 18:22:30 +0100 (Di, 14. Mär 2006) $
 *   $Author: troggan $
 * $Revision: 1978 $
 */
package util.io;

import java.net.URL;


/**
 * Network Helper Class with some utility functions
 * 
 * @author bodum
 * @since 2.2
 */
public class NetworkUtilities {

  /**
   * Checks if a internet connection can be established
   * 
   * @return true, if a connection can be established
   */
  public static boolean checkConnection() {
    return new CheckNetworkConnection().checkConnection();
  }

  /**
   * Checks if a internet connection to a specific Server can be established
   * 
   * @param url check this Server
   * @return true, if a connection can be established
   */
  public static boolean checkConnection(URL url) {
    return new CheckNetworkConnection().checkConnection(url);
  }

}
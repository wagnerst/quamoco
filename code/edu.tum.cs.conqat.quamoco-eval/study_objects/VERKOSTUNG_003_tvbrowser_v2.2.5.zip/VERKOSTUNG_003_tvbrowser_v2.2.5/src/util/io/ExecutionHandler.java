/*
 * TV-Browser
 * Copyright (C) 04-2003 Martin Oberhauser (darras@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * CVS information:
 *     $Date: 2007-12-08 13:47:47 +0100 (Sa, 08. Dez 2007) $
 *   $Author: ds10 $
 * $Revision: 4082 $
 */
package util.io;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Handles the execution of external processes.
 * 
 * @author Ren� Mach
 * @since 2.6.1/2.2.5
 */
public class ExecutionHandler {
  private String[] mParameter;
  private File mRuntimeDirectory;
  private StreamReaderThread mInputStream;
  private StreamReaderThread mErrorStream;
  
  private Process mProcess;

  /**
   * Creates an instance of this class.
   * 
   * @param parameter The parameter to parse to the application.
   * @param programPath The path to the application.
   */
  public ExecutionHandler(String parameter, String programPath) {
    this(parameter, programPath, (File) null);
    
    if(programPath.indexOf(File.separator) != -1) {
      String path = programPath.substring(0,programPath.lastIndexOf(File.separator) + 1);
      
      if(path == null || path.length() < 1 || !(new File(path).isDirectory()))
        path = System.getProperty("user.dir");
      
      mRuntimeDirectory = new File(path);
    }
  }
  
  /**
   * Creates an instance of this class.
   * 
   * @param parameter The parameter to parse to the application.
   * @param programPath The path to the application.
   * @param runtimeDirectory The runtime directory for the application.
   */
  public ExecutionHandler(String parameter, String programPath, String runtimeDirectory) {
    this(parameter, programPath, new File(runtimeDirectory));
  }

  /**
   * Creates an instance of this class.
   * 
   * @param parameter The parameter to parse to the application.
   * @param programPath The path to the application.
   * @param runtimeDirectory The runtime directory for the application.
   */
  public ExecutionHandler(String parameter, String programPath, File runtimeDirectory) {
    mParameter = calculateParamter(parameter, programPath);
    mRuntimeDirectory = runtimeDirectory;
  }
  
  /**
   * Creates an instance of this class.
   * 
   * @param parameterWithProgramPath The parameter to parse to the application with the path to the program.
   */
  public ExecutionHandler(String[] parameterWithProgramPath) {
    this(parameterWithProgramPath, (File) null);
  }
  
  /**
   * Creates an instance of this class.
   * 
   * @param parameterWithProgramPath The parameter to parse to the application with the path to the program.
   * @param runtimeDirectory The runtime directory for the application.
   */
  public ExecutionHandler(String[] parameterWithProgramPath, String runtimeDirectory) {
    this(parameterWithProgramPath, new File(runtimeDirectory));
  }
  
  /**
   * Creates an instance of this class.
   * 
   * @param parameterWithProgramPath The parameter to parse to the application with the path to the program.
   * @param runtimeDirectory The runtime directory for the application.
   */
  public ExecutionHandler(String[] parameterWithProgramPath, File runtimeDirectory) {
    mParameter = parameterWithProgramPath;
    mRuntimeDirectory = runtimeDirectory;
  }

  /**
   * Executes the given application with the given parameters in the given runtime directory.
   * @throws IOException Thrown if something went wrong on process building.
   */
  public void execute() throws IOException {
    execute(false,false);
  }
  
  /**
   * Executes the given application with the given parameters in the given runtime directory.
   * @param logInputStream <code>True</code> means that the console output of the output stream
   * of the process will be logged and can be get after the process was stopped (it's output stream
   * is an input stream for the process starter).
   * 
   * @throws IOException Thrown if something went wrong on process building.
   */  
  public void execute(boolean logInputStream) throws IOException {
    execute(true,false);
  }

  /**
   * Executes the given application with the given parameters in the given runtime directory.
   * @param logInputStream <code>True</code> means that the console output of the output stream
   * of the process will be logged and can be get after the process was stopped (it's output stream
   * is an input stream for the process starter).
   * @param logErrorStream <code>True</code> means that the console output of the error stream
   * of the process will be logged and can be get after the process was stopped.
   * 
   * @throws IOException Thrown if something went wrong on process building.
   */  
  public void execute(boolean logInputStream, boolean logErrorStream) throws IOException {
    mProcess = Runtime.getRuntime().exec(mParameter,null,mRuntimeDirectory);
    
    mInputStream = new StreamReaderThread(mProcess.getInputStream(),logInputStream);
    mErrorStream = new StreamReaderThread(mProcess.getErrorStream(),logErrorStream);
    
    mInputStream.start();
    mErrorStream.start();
  }
  
  /**
   * Gets the started process.
   * 
   * @return The started proccess or <code>null</code> if the process wasn't started.
   */
  public Process getProcess() {
    return mProcess;
  }
  
  /**
   * The exit vaule of the process.
   * 
   * @return The exit value of the process.
   * @throws IllegalThreadStateException Thrown if the process wasn't started or is not finished.
   */
  public int exitValue() throws IllegalThreadStateException {
    if(mProcess == null) {
      throw new IllegalThreadStateException("Process wasn't started.");
    }
    
    return mProcess.exitValue();
  }
  
  /**
   * Gets the input stream reader thread (it logs the console output of the process).
   * 
   * @return The input stream reader thread.
   */
  public StreamReaderThread getInputStreamReaderThread() {
    return mInputStream;
  }
  
  /**
   * Gets the error stream reader thread.
   * 
   * @return The error stream reader thread.
   */
  public StreamReaderThread getErrorStreamReaderThread() {
    return mErrorStream;
  }
  
  private String[] calculateParamter(String parameter, String programPath) {
    StringBuffer lastString = null;
    ArrayList args = new ArrayList();
    
    args.add(programPath);
    
    String[] paras = parameter.split(" ");
    
    for (int i = 0; i < paras.length; i++) {
      String part = paras[i];
      
      if (part.length() > 0 && part.charAt(0) == '"') {
        if (part.charAt(part.length()-1) == '"') {
          args.add(part);
        } else {
          lastString = new StringBuffer(part);
          lastString.deleteCharAt(0);
        }
      } else if (lastString != null) {
        lastString.append(' ');
        lastString.append(part);
        if (part.charAt(part.length()-1) == '"') {
          lastString.deleteCharAt(lastString.length() - 1);
          args.add(lastString.toString());
          lastString = null;
        }
      } else {
        args.add(part);
      }
    }
    
    return (String[])args.toArray(new String[args.size()]);
  }
}

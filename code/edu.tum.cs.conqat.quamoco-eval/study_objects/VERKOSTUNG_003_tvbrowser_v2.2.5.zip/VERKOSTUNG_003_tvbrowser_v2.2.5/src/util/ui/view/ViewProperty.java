package util.ui.view;

import util.settings.Property;
import util.settings.PropertyManager;


public abstract class ViewProperty extends Property {

    
    public ViewProperty(PropertyManager manager, String key) {
        super(manager, key);
    }
    
  
  
  
}
package util.ui.html;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import util.io.IOUtilities;

/**
 * This is a Helper-Class for converting Text to HMTL
 * 
 * @author bodum
 * @since 2.1
 */
public class HTMLTextHelper {

  /**
   * Convert Text to HTML. > and < will be convertet to &lt; and &gt;
   * \n will be &gt;br&lt;
   * 
   * If createLinks is true, it will try to find Links and create a href-Elements
   * 
   * @param text Text-Files
   * @param createLinks if true, it will create Links
   * @return Result
   */
  public static String convertTextToHtml(String text, boolean createLinks) {
    // Disarm html entities
    text = IOUtilities.replace(text.trim(), "<", "&lt;");
    text = IOUtilities.replace(text.trim(), ">", "&gt;");

    // Translate line breaks to html breaks
    text = IOUtilities.replace(text.trim(), "\n", "<br>");

    // Create links for URLs
    if (createLinks) {
      
      Matcher matcher = Pattern.compile("(http://|www.)[^\\s<]*").matcher(text);
      
      StringBuffer result = new StringBuffer();
      
      int end = 0;
      
      while (matcher.find()) {
        result.append(text.substring(end, matcher.start()));
        result.append("<a href=\"");
        
        String linkText = text.substring(matcher.start(), matcher.end());
      
        if (!linkText.startsWith("http://")) {
          result.append("http://");
        }
        
        result.append(linkText);
        result.append("\">");
        result.append(linkText);
        result.append("</a>");
        end = matcher.end();
      }

      result.append(text.substring(end));
      
      text = result.toString();
    }

    return text;
  }
  
}

package util.ui.progress;


public interface Progress {
  
  public void run();
   
}
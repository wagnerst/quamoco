/*
 * TV-Browser
 * Copyright (C) 04-2003 Martin Oberhauser (martin_oat@yahoo.de)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * CVS information:
 *  $RCSfile$
 *   $Source$
 *     $Date: 2006-09-07 16:26:30 +0200 (Do, 07. Sep 2006) $
 *   $Author: ds10 $
 * $Revision: 2730 $
 */
package tvdataservice;

import java.util.ArrayList;
import java.util.Iterator;

//import util.io.IOUtilities;
import devplugin.Channel;
import devplugin.ChannelDayProgram;
import devplugin.Program;

/**
 * A list of the programs of one channel and one day.
 * <p>
 * This implementation is mutable, meaning you can add programs. These programs are
 * automatically sorted by time.
 *
 * @author Til Schneider, www.murfman.de
 */
public class MutableChannelDayProgram implements ChannelDayProgram {

  /** The date of this program list. */
  private devplugin.Date mDate;

  /** The channel of this program list. */
  private Channel mChannel;

  /** The program list itself. */
  private ArrayList mProgramList;

  private boolean mLastProgramHadEndOnUpdate, mWasChangedByPlugin;

  /**
   * Creates a new instance of MutableChannelDayProgram.
   *
   * @param date The date
   * @param channel The channel
   */
  public MutableChannelDayProgram(devplugin.Date date,
    devplugin.Channel channel)
  {
    mDate = date;
    mChannel = channel;
    mLastProgramHadEndOnUpdate = false;
    mWasChangedByPlugin = false;
    
    mProgramList = new ArrayList();
  }



  /**
   * Returns the channel of this day program.
   *
   * @return  the channel of this day program.
   */
  public devplugin.Channel getChannel() {
    return mChannel;
  }



  /**
   * Returns the date of this day program.
   *
   * @return  the date of this day program.
   */
  public devplugin.Date getDate() {
    return mDate;
  }



  /**
   * Returns the program object having the specified ID.
   *
   * @param progID The ID of the wanted program.
   * @return  the program object having the specified ID.
   */
  public Program getProgram(String progID) {
    Iterator iter = mProgramList.iterator();
    while(iter.hasNext()) {
      Program prog = (Program) iter.next();
      String id = prog.getID();
      
      int idlength = progID.split("_").length;
      
      if(idlength < 4) {
        String[] temp = id.split("_");
       
        id = temp[temp.length - 2] + "_" + temp[temp.length - 1];
      }
      else if(idlength == 4) {
        String[] temp = id.split("_");
        
        id = temp[0] + "_" + temp[1] + "_" + temp[temp.length - 2] + "_" + temp[temp.length - 1];        
      }
      
      if (progID.compareTo(id) == 0) {
        return prog;
      }
    }

    // nothing found
    return null;
  }



  /**
   * Gets the number of programs in this list.
   *
   * @return the number of programs.
   */
  public int getProgramCount() {
    return mProgramList.size();
  }

  
  
  /**
   * Returns the program at the specified index.
   *
   * @param index The index of the wanted program.
   * @return The program at the specified index.
   */
  public Program getProgramAt(int index) {
    return (Program) mProgramList.get(index);
  }
  


  /**
   * Adds a program.
   *
   * @param program The program to add. This program will automatically be put
   *        in the right position in the list, so the list stays ordered.
   */
  public void addProgram(Program program) {
    // find the index where to add the program
    // We search backwards, because the data may come already ordered. And if
    // this is the case we only have to compare once.
    int addIdx;
    int time = program.getHours() * 60 + program.getMinutes();
    for (addIdx = mProgramList.size(); addIdx > 0; addIdx--) {
      Program cmp = (Program) mProgramList.get(addIdx - 1);
      int cmpTime = cmp.getHours() * 60 + cmp.getMinutes();
	  	  
	  if (program.getDate().compareTo(cmp.getDate())>0) {
        break; // insert here
      }
      else if (program.getDate().compareTo(cmp.getDate())<0) {
        continue;
      } 
	  
      if (cmpTime == time) {
        // We already have this program
        return;
      }
      if (cmpTime < time) {
        break;
      }
    }

    mProgramList.add(addIdx, program);
  }


  /**
   * Removes all programs from this day program.
   */
  public void removeAllPrograms() {
    mProgramList.clear();
  }


  /**
   * Returns an iterator containing all programms. Each iterator item is a
   * devplugin.Program object.
   *
   * @return An iterator through the program list.
   */
  public java.util.Iterator getPrograms() {

    return mProgramList.iterator();
  }



  /**
   * Returns whether this channel day program is complete.
   * <p>
   * Return true if the last program ends afer midnight. Future implementations
   * may check for gaps too.
   */
  public boolean isComplete() {
    int size = mProgramList.size();
    if (size == 0) {
      return false;
    } else {
      Program lastProgram = (Program) mProgramList.get(size - 1);
      int endTime = lastProgram.getHours() * 60 + lastProgram.getMinutes()
        + lastProgram.getLength();

      return endTime >= (23 * 60);
    }
  }
  

  /**
   * Sets the last program end time state on data update.
   * 
   * @param value If the last program had end time on data update.
   * @since 2.2
   */
  public void setLastProgramHadEndOnUpdate(boolean value) {
    mLastProgramHadEndOnUpdate = value;
  }
  
  /**
   * Gets the last program end time state on data update.
   * 
   * @return If the last program had ent time on data update
   * @since 2.2
   */
  public boolean getLastProgramHadEndOnUpdate() {
    return mLastProgramHadEndOnUpdate;
  }

  /**
   * Sets the changed state to let the day program 
   * be saved again to take over the changes.
   *
   * This works only if called from 
   * devplugin.Plugin#handleTvDataAdded(ChannelDayProgram)
   * otherwise the changes won't be saved.
   * 
   * @since 2.2.2
   */
  public void setWasChangedByPlugin() {
    mWasChangedByPlugin = true;
  }
  
  /**
   * Get if the day program was changed by a 
   * plugin and reset the changed state.
   * 
   * @return If this day program was changed by a plugin.
   * @since 2.2.2
   */
  public boolean getAndResetChangedByPluginState() {
    boolean temp = mWasChangedByPlugin;
    mWasChangedByPlugin = false;
    
    return temp;
  }
}

package printplugin.settings;


public interface Settings {

}

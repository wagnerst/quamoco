/*
 * TV-Browser
 * Copyright (C) 04-2003 Martin Oberhauser (martin@tvbrowser.org)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * CVS information:
 *  $RCSfile$
 *   $Source$
 *     $Date: 2007-09-17 13:17:46 +0200 (Mo, 17. Sep 2007) $
 *   $Author: ds10 $
 * $Revision: 3832 $
 */


 /**
  * TV-Browser
  * @author Martin Oberhauser
  */

package devplugin;

import java.lang.reflect.Method;

/**
 * This class provides information about a plugin.
 */
public final class PluginInfo {

    private Version mVersion = null;
    private String mName = "";
    private String mDescription = "";
    private String mAuthor = "";
    private String mLicense = null;

    public PluginInfo() {
      this("");
    }

    /**
     * 
     * @param name
     * @deprecated since 2.2.4
     */
    public PluginInfo(String name) {
      this(Class.class, name);
    }
    
    /**
     * @param name
     * @param desc
     * @deprecated since 2.2.4
     */
    public PluginInfo(String name, String desc) {
      this(Class.class,name,desc,"",null,null);
    }
    
    /**
     * 
     * @param name
     * @param desc
     * @param author
     * @deprecated since 2.2.4
     */
    public PluginInfo(String name, String desc, String author) {
      this(Class.class,name,desc,author,null,null);
    }
    
    /**
     * 
     * @param name
     * @param desc
     * @param author
     * @param version
     * @deprecated since 2.2.4
     */
    public PluginInfo(String name, String desc, String author, Version version) {
      this(Class.class,name,desc,author,version,null);
    }
    
    /**
     * 
     * @param name
     * @param desc
     * @param author
     * @param version
     * @param license
     * @deprecated since 2.2.4
     */
    public PluginInfo(String name, String desc, String author, Version version, String license) {
      this(Class.class,name,desc,author,version,null);
    }
    
    public PluginInfo(Class caller, String name) {
      this(caller,name,"");
    }
    
    public PluginInfo(Class caller, String name, String desc) {
      this(caller,name,"","");
    }
    
    public PluginInfo(Class caller, String name, String desc, String author) {
      this(caller, name, desc, author, null, null);
    }
    
    public PluginInfo(Class caller, String name, String desc, String author, String license) {
      this(caller, name, desc, author, null, license);
    }
    
    private PluginInfo(Class caller, String name, String desc, String author, Version version, String license) {
      mName = name;
      mDescription = desc;
      mAuthor = author;
      
      if(caller != null && caller.getSuperclass() != null && 
          (caller.getSuperclass().equals(Plugin.class) ||
              caller.getSuperclass().equals(AbstractTvDataService.class))) {
        try {
          Method m = caller.getMethod("getVersion", new Class[0]);
          Version pluginVersion = (Version)m.invoke(caller,new Object[0]);
          
          if(version != null && version.compareTo(pluginVersion) > 0) {
            mVersion = version;
          }
          else {
            mVersion = pluginVersion;
          }
          
        }catch(Exception e) {e.printStackTrace();
          mVersion = version;
        }
      }
      else {
        mVersion = version;
      }
      
      mLicense = license;
    }

    public Version getVersion() { return mVersion; }
    public String getName() { return mName; }
    public String getDescription() { return mDescription; }
    public String getAuthor() { return mAuthor; }
    public String getLicense() { return mLicense; }

}
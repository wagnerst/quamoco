package newsplugin;

import java.util.ArrayList;

/**
 * A class with the news in a backward time sorted list.
 * 
 * @author Ren� Mach
 */
public class NewsList {
  ArrayList mList = new ArrayList();
  
  /**
   * Adds a news sorted into the list.
   * 
   * @param news The news to add.
   */
  public void add(News news) {
    int i;
    
    for(i = 0; i < mList.size(); i++) {
      int compareValue = ((News)mList.get(i)).compareTo(news);
      
      if(compareValue < 0) {
        mList.add(i,news);
        break;
      }
      else if(compareValue == 0) {
        return;
      }
    }
    
    if(i == mList.size())
      mList.add(news);
  }
  
  /**
   * Gets the ArrayList with the news.
   * @return The ArrayList with the news
   */
  public ArrayList getList() {
    return mList;
  }
  
  /**
   * Gets the last news time.
   * 
   * @param defaultValue The default value to return if there are
   *                     no news. 
   * @return The last news time.
   */
  public long getLastNewsTime(long defaultValue) {
    if(mList.isEmpty()) {
      return defaultValue;
    }
    
    return ((News)mList.get(0)).getTime().getTime();
  }
}

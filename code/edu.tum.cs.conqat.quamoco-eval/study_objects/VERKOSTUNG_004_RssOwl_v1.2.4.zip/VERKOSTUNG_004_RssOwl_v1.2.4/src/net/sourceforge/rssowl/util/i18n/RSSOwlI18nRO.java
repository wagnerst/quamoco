/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2008 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Eclipse Public License 1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/epl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file epl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.util.i18n;

import net.sourceforge.rssowl.util.GlobalSettings;

/**
 * Romanian internationalization for RSSOwl (i18n) <br />
 * Supported Languages <br />
 * ------------------- <br />
 * <br />
 * o German - by Benjamin P. RSSOwl Administrator/Developer <br />
 * o English - by Benjamin P. RSSOwl Developer and Christian Hochhold <br />
 * o French - by Christophe Dumez RSSOwl Doc Translator (French) <br />
 * o Spanish - by José Domínguez and Ruben <br />
 * o Galician - by José Domínguez <br />
 * o Danish - by Tonny Bredsgaard RSSOwl Doc Translator (Danish) <br />
 * o Italian - by Claudio Fontana <br />
 * o Dutch - by Joris Kluivers and Toon Geens <br />
 * o Greek - by Jacaranda Bill <br />
 * o Russian - by Sergey Rozenblat and Alexandr <br />
 * o Portugues (Brasil) - by Marcelo Fenoll Ramal Tradutor <br />
 * o Bulgarian - by Valeri Damianov <br />
 * o Norwegian (Bokmål) - by Eivind Syverts <br />
 * o Chinese Simplified - by Merlin Ran <br />
 * o Japanese - by Takashi Komatsubara <br />
 * o Korean - by Geon Goo <br />
 * o Polish - by Ryszard Sierotnik <br />
 * o Bangla (Bengali) - by Omi Azad <br />
 * o Swedish - by Patrik Johansson <br />
 * o Chinese Traditional - by Jerry Giant <br />
 * o Finnish - by Samu Reinikainen <br />
 * o Ukrainian - by Alexandr <br />
 * o Czech - by Lukas Petrovicky <br />
 * o Serbian - by Aleksandar Urošević <br />
 * o Slovenian - by Jure Zemljič <br />
 * o Turkish - by Engin Erenturk <br />
 * o Hungarian - by Balázs <br />
 * o Thai - by Patipat Susumpow <br />
 * o Croatian - by Neven Zitek<br />
 * o Slovak - by Vlado Jasaň<br />
 * o Romanian - by Claudiu Paiu<br />
 * <br />
 * If you would like to add another language to RSSOwl, feel free to contact me
 * (http://www.rssowl.org).
 *
 * @author <a href="mailto:bpasero@rssowl.org">Benjamin Pasero </a>
 * @version 1.2.4
 */
public class RSSOwlI18nRO extends Translation {

  /**
   * Instantiate a new translation for a locale
   *
   * @param language two-letter ISO-639 code
   * @param country two-letter ISO-3166 code
   */
  public RSSOwlI18nRO(String language, String country) {
    super(language, country);
  }

  /** Set up the i18n hashtable */
  protected void initTranslation() {

    /** RSSOwl Top Menu */
    translation.put("MENU_FILE", "Fişier");
    translation.put("MENU_SAVE", "Salvare ca");
    translation.put("MENU_QUICKVIEW", "Vedere rapidă");
    translation.put("MENU_TOOLBAR", "Bară de instrumente");
    translation.put("MENU_GENERATE_PDF", "Generează PDF");
    translation.put("MENU_GENERATE_HTML", "Generează HTML");
    translation.put("MENU_GENERATE_RTF", "Generează RTF");
    translation.put("MENU_IMPORT", "Import setări");
    translation.put("MENU_EXPORT", "Export setări");
    translation.put("MENU_EXIT", "Ieşire");
    translation.put("MENU_WINDOW", "Vedere");
    translation.put("MENU_PREFERENCES", "Preferinţe");
    translation.put("MENU_BROWSER", "Browser");
    translation.put("MENU_SELECT_EXTERNAL_BROWSER", "Selectează browser extern");
    translation.put("MENU_FONT", "Font");
    translation.put("MENU_ENCODING", "Codificare text");
    translation.put("MENU_LANGUAGE", "Limba");
    translation.put("MENU_PROXY", "Proxy");
    translation.put("MENU_MISC", "Altele");
    translation.put("MENU_DIRECTOPEN", "Deschide automat în browser ştirile fără descriere");
    translation.put("MENU_DIRECTOPENEACH", "Deschide automat în browser ştirile selectate");
    translation.put("MENU_SYSTRAY", "Plasează RSSOwl în tray la minimizare");
    translation.put("MENU_CHANNELINFO", "Arată informaţii despre canalul de ştiri (newsfeed)");
    translation.put("MENU_OPENNEW_BROWSER", "Deschide întotdeauna browserul intern intru-un tab nou");
    translation.put("MENU_BROWSER_EXTERN", "Utilizează browser extern");
    translation.put("MENU_BROWSER_FOR_NEWSTEXT", "Afişează textul ştirii în browser");
    translation.put("MENU_CHECK_UPDATE", "Verifică disponibilitate actualizări după pornire program");
    translation.put("MENU_INFO", "Ajutor");
    translation.put("MENU_ABOUT", "Despre RSSOwl");
    translation.put("MENU_LICENSE", "Licenţă");
    translation.put("MENU_UPDATE", "Verifică disponibilitate actualizări");
    translation.put("MENU_WELCOME", "Bine aţi venit");
    translation.put("MENU_DONATE", "Donează");
    translation.put("MENU_TOOLS", "Instrumente");
    translation.put("MENU_FEEDSEARCH", "Caută canale de ştiri (Newsfeeds)");
    translation.put("MENU_MINIMIZE_RSSOWL", "Minimizare RSSOwl");
    translation.put("MENU_GOTO", "MergiLa");
    translation.put("MENU_NEXT_NEWS", "Următoarea ştire");
    translation.put("MENU_NEXT_UNREAD_NEWS", "Următoarea ştire necitită");
    translation.put("MENU_CLOSE", "Închide");
    translation.put("MENU_CLOSE_ALL", "Închide tot");
    translation.put("MENU_PREVIOUS_TAB", "Tabul precedent");
    translation.put("MENU_NEXT_TAB", "Tabul următor");
    translation.put("MENU_HOTKEYS", "Taste comenzi rapide");
    translation.put("MENU_NEWSTIP_MAIL", "Format NewsTip Mail");
    translation.put("MENU_TELL_FRIENDS", "Spune prietenului meu...");
    translation.put("MENU_RELOAD", "Reîncarcă");
    translation.put("MENU_GENERATE_PDF_SELECTION", "Generează PDF din ştirile selectate");
    translation.put("MENU_GENERATE_HTML_SELECTION", "Generează HTML din ştirile selectate");
    translation.put("MENU_GENERATE_RTF_SELECTION", "Generează RTF din ştirile selectate");
    translation.put("MENU_MAILING_LIST", "Lista de e-mail");
    translation.put("MENU_TUTORIAL", "Tutorial");
    translation.put("MENU_COLORS", "Culori");
    translation.put("MENU_BLOGGER", "Blogger");
    translation.put("MENU_WORKBENCH", "General");
    translation.put("MENU_IMPORT_OPML", "Import din OPML");
    translation.put("MENU_VALIDATE", "Validare canal de ştiri (Newsfeed)");
    translation.put("MENU_FEED_DISCOVERY", "Descoperă canal de ştiri (Newsfeeds) în sit web");
    translation.put("MENU_DISPLAY_FEED_PDF", "Afişează canal de ştiri (Newsfeeds) în PDF");
    translation.put("MENU_DISPLAY_FEED_RTF", "Afişează canal de ştiri (Newsfeeds) în RTF");
    translation.put("MENU_DISPLAY_FEED_HTML", "Afişează canal de ştiri (Newsfeeds) în HTML");
    translation.put("MENU_NEW_FAVORITE", "Favorite noi");
    translation.put("MENU_EDIT", "Editare");
    translation.put("MENU_EDIT_COPY", "Copie");
    translation.put("MENU_EDIT_PASTE", "Lipeşte");
    translation.put("MENU_EDIT_SELECT_ALL", "Selectează tot");
    translation.put("MENU_EDIT_DELETE", "Şterge");
    translation.put("MENU_EDIT_CUT", "Taie");
    translation.put("MENU_CONNECTION", "Conexiune");
    translation.put("MENU_EDIT_RENAME", "Redenumeşte");
    translation.put("MENU_WORK_OFFLINE", "Lucrează deconectat (offline)");
    translation.put("MENU_WORK_ONLINE", "Lucrează conectat (online)");

    /** ToolBar */
    translation.put("TOOL_MARK", "Marcare");
    translation.put("TOOL_NEXT", "Următor");
    translation.put("TOOL_SEPARATOR", "Separator");
    translation.put("TOOL_ICONS_TEXT", "Pictograme şi Text");
    translation.put("TOOL_ICONS", "Pictograme");
    translation.put("TOOL_TEXT", "Text");
    translation.put("TOOL_RATE", "Notează");
    translation.put("TOOL_HISTORY", "Istoric");

    /** Popup Menu */
    translation.put("POP_NEW", "Nou");
    translation.put("POP_SUB_CATEGORY", "Subcategorie");
    translation.put("POP_UNSUBSCRIBE", "Dezabonare");
    translation.put("POP_USEPROXY", "Foloseşte proxy");
    translation.put("POP_AGGREGATE_FAV", "Concatenare favorite");
    translation.put("POP_AUTO_UPDATE", "Auto actualizare");
    translation.put("POP_UPDATE_ONSTARTUP", "la pornire");
    translation.put("POP_IMPORT", "Import");
    translation.put("POP_FROM_OPML", "Din fişier OPML");
    translation.put("POP_EXPORT_OPML", "Către fişier OPML");
    translation.put("POP_COPY", "Copie");
    translation.put("POP_OPEN_IN_BROWSER", "Deschide selecţia în browser");
    translation.put("POP_MARK_UNREAD", "Marchează ca necitit");
    translation.put("POP_COPY_NEWS_URL", "Copie legătura");
    translation.put("POP_RATE_NEWS", "Notează noutăţile");
    translation.put("POP_MAIL_LINK", "Trimite la un prieten email cu NewsTip");
    translation.put("POP_OPEN_EXTERN", "Deschide extern");
    translation.put("POP_BLOG_NEWS", "Noutăţi Blog");
    translation.put("POP_OPEN_STARTUP", "Deschide la pornire");
    translation.put("POP_KEEP_CURRENT", "Închide altele");
    translation.put("POP_KEEP_NEWSFEEDS", "Închide toate exceptând cele care afişează ştiri");
    translation.put("POP_MARK_ALL_READ", "Marchează toate ca citite");
    translation.put("POP_MARK_CATEGORY_READ", "Marchează categoria citită");
    translation.put("POP_TAB_POSITION", "Poziţia");
    translation.put("POP_TAB_POS_TOP", "Sus");
    translation.put("POP_TAB_POS_BOTTOM", "Jos");
    translation.put("POP_PROPERTIES", "Proprietăţi");
    translation.put("POP_MARK_FAVORITE_READ", "Marchează favorit ca citit");
    translation.put("POP_IMPORT_BLOGROLL", "Sincronizează Blogroll");
    translation.put("POP_SYNCHRONIZE", "Sincronizează");
    translation.put("POP_CUSTOMIZE_TOOLBAR", "Particularizează bara de instrumente");
    translation.put("POP_CLEAR_HISTORY", "Şterge istoric");

    /** Errors in RSSOwl */
    translation.put("ERROR_UNEXPECTED", "A apărut o eroare neaşteptată! RSSOwl se va închide dar, setările au fost salvate.\nEroarea a fost înregistrată în '" + GlobalSettings.WORKING_DIR + GlobalSettings.PATH_SEPARATOR + "rssowllog.log'.\n\nDoriţi transmiterea raportului referitor la eroare către echipa RSSOwl?");
    translation.put("MESSAGE_BOX_TITLE_ERROR", "Eroare");
    translation.put("ERROR_NO_NEWS_FOUND", "Eroare: nicio ştire!");
    translation.put("ERROR_CAT_EXISTS", "O categorie cu acelaşi nume există deja!");
    translation.put("ERROR_FAV_TITLE_EXISTS", "O înregistrare favorită cu acelaşi titlu există deja!");
    translation.put("ERROR_FAV_URL_EXISTS", "O înregistrare favorită cu acest URL există deja!");
    translation.put("ERROR_CONNECTION_FAILED", "Conectare nereuşită!");
    translation.put("ERROR_GRABTITLE_FAILED", "Titlul indisponibil!");
    translation.put("ERROR_NEWSFEED_GENERAL", "RSSOwl nu a reuşit afişarea canalului de ştiri (newsfeed).");
    translation.put("ERROR_FILE_NOT_FOUND", "Fişierul nu poate fi găsit");
    translation.put("ERROR_AUTH_REQUIRED", "Canalul de ştiri este protejat şi necesită autentificare");
    translation.put("ERROR_REASON", "Motiv");
    translation.put("ERROR_LOADING_FEED", "Eroare în timpul încărcării canalului de ştiri (Newsfeed) \"%TITLE%\"");
    translation.put("ERROR_HTTP_STATUS", "Stare");
    translation.put("ERROR_WORKING_OFFLINE", "Canalul de ştiri nu pote fi încărcat offline");
    translation.put("ERROR_NOT_A_XML", "Fişierul nu este document XML valid");
    translation.put("ERROR_NOT_A_RSS", "Documentul XML nu este canal de ştiri tip RSS, RDF sau Atom");
    translation.put("ERROR_NOT_A_OPML", "Documentul XML nu este fişier OPML");
    translation.put("ERROR_SUB_EXISTS", "Există deja subscriere pentru acest Blogroll!");

    /** Labels */
    translation.put("LABEL_URL_PATH", "URL / Cale");
    translation.put("LABEL_CATEGORY", "Categorie");
    translation.put("LABEL_NO_INFOS", "Fără informaţii adiţionale!");
    translation.put("LABEL_FAVORITE", "Favorit");
    translation.put("LABEL_TITLE", "Titlu");
    translation.put("LABEL_USE_PROXY", "Foloseşte proxy");
    translation.put("LABEL_PROXY_AUTHENTIFICATION", "Proxy necesită autentificare");
    translation.put("LABEL_USERNAME", "Utilizator");
    translation.put("LABEL_PASSWORD", "Parolă");
    translation.put("LABEL_PROXY_HOST", "Proxy Host");
    translation.put("LABEL_PROXY_PORT", "Proxy Port");
    translation.put("LABEL_CATEGORY", "Categorie");
    translation.put("LABEL_USE_PROXY_FOR_ALL", "Foloseşte proxy pentru toate favoritele");
    translation.put("LABEL_NEWS_RATED", "Evaluare ştiri");
    translation.put("LABEL_SEARCH_TOPIC", "Specificaţi ce doriţi să căutaţi");
    translation.put("LABEL_SEARCH_FINISHED", "Căutare terminată.");
    translation.put("LABEL_SEARCH_RUNNING", "Se caută...");
    translation.put("LABEL_INTENSIVE_SEARCH", "Căutare intensivă");
    translation.put("LABEL_PREFERED_LANGUAGE", "Limba preferată");
    translation.put("LABEL_DESCRIPTION", "Descriere");
    translation.put("LABEL_CREATED", "Creat");
    translation.put("LABEL_LAST_VISIT", "Ultima vizită");
    translation.put("LABEL_USED_BY", "Folosită de");
    translation.put("LABEL_NAME", "Nume");
    translation.put("LABEL_KEY_SEQUENCE", "Secvenţa de taste");
    translation.put("LABEL_INVALID_KEYSEQUENCE", "Secvenţa de taste este invalidă!");
    translation.put("LABEL_SIZE", "Dimensiune");
    translation.put("LABEL_STYLE", "Stil");
    translation.put("LABEL_SELECT_ENCODING", "Selectează codificarea textului");
    translation.put("LABEL_MAIL_SUBJECT", "Subiect");
    translation.put("LABEL_MAIL_BODY", "Corp");
    translation.put("LABEL_MAIL_USAGE", "Foloseşte [TITLE], [LINK] şi [DESCRIPTION] ca parametri înlocuibili pentru informaţiile despre ştiri");
    translation.put("LABEL_EMPTY_LINK", "Nu a fost dată nicio legătură");
    translation.put("LABEL_USE_SYSTEM_FONT", "Foloseşte fonturile sistem");
    translation.put("LABEL_HTML_FORMAT_MAIL", "HTML Format Mail");
    translation.put("LABEL_CURRENT_COLOR", "Culoare curentă");
    translation.put("LABEL_OPTIONS", "Opţiuni");
    translation.put("LABEL_SEARCH_RESULTS", "Căutarea pentru \"%TERM%\" a produs %NUM% rezultate");
    translation.put("LABEL_SEARCH_EMPTY", "Căutarea pentru \"%TERM%\" nu a întors niciun rezultat.");
    translation.put("LABEL_SELECT_WINDOW_LAYOUT", "Selectaţi unul din cele două formate de afişare");
    translation.put("LABEL_SINGLE_CLICK", "Un singur clic");
    translation.put("LABEL_DOUBLE_CLICK", "Dublu clic");
    translation.put("LABEL_SELECT_BLOGGER", "Selectaţi un blogger extern");
    translation.put("LABEL_BLOGGER_USAGE", "Foloseşte [NEWSLINK], [FEEDLINK] şi [TITLE] ca parametri înlocuibili pentru informaţiile despre ştiri.");
    translation.put("LABEL_REOPEN_DISPLAYED_FEEDS", "Redeschide ultimul canal de sţiri citit la pornire");
    translation.put("LABEL_TRADITIONAL_TABS", "Taburi tradiţionale");
    translation.put("LABEL_CURVED_TABS", "Taburi curbate");
    translation.put("LABEL_READY", "Gata");
    translation.put("LABEL_VALIDATION_FINISHED", "Validare terminată");
    translation.put("LABEL_VALIDATING", "Validare");
    translation.put("LABEL_FEED_TYPE", "Tipul canalului de ştiri (Newsfeed)");
    translation.put("LABEL_OVERRIDE_DTD", "Suprascrie declaraţia de tip document (Doctype)");
    translation.put("LABEL_ADDRESS", "Adresa");
    translation.put("LABEL_BROWSER_USAGE", "Foloseşte [URL] ca parametru pentru URL.");
    translation.put("LABEL_OLD_ID", "Vechiul ID utilizator (opţional)");
    translation.put("LABEL_AMPHETARATE_ID", "ID utilizator");
    translation.put("LABEL_SORT_EXPLANATION", "Ordinea de sortare. RSSOwl încearcă mai întâi sortare după primul criteriu. Dacă nu este posibil, se încearcă sortarea după următorul criteriu din listă.");
    translation.put("LABEL_SORT_ORDER", "Sortare ştiri");
    translation.put("LABEL_REMEMBER_AUTH", "Ţine minte numele de utilizator şi parola");
    translation.put("LABEL_NOT_UNSUPPORTED", "Nu este încă suportat de sistemul de operare");
    translation.put("LABEL_KEY_DEL", "Del");
    translation.put("LABEL_TEMPLATE_EXPLANATION", "Valorile modificabile aici vor fi considerate ca valori iniţiale pentru oricare favorit nou.");
    translation.put("LABEL_RESTART", "Modificările necesită repornirea programului RSSOwl");
    translation.put("LABEL_WELCOME_TITLE", "Bine aţi venit! RSSOwl - Newsreader (cititor de ştiri) pentru RSS / RDF / Atom Newsfeeds");
    translation.put("LABEL_FIRST_STEPS", "Primii paşi");
    translation.put("LABEL_NEWS", "Noutăţi");
    translation.put("LABEL_RSSOWL_NEWSFEED", "RSSOwl Newsfeed");
    translation.put("LABEL_SUPPORT", "Suport");
    translation.put("LABEL_DISCUSSION_FORUM", "Forum de discuţii");
    translation.put("LABEL_PROMOTION", "Promoţie");
    translation.put("LABEL_CONTACT", "Contact");
    translation.put("LABEL_START", "Start");
    translation.put("LABEL_DOWNLOAD", "Descarcă");
    translation.put("LABEL_MAX_CONNECTIONS", "Numărul maxim de conexiuni (conectări)");
    translation.put("LABEL_CON_TIMEOUT", "Timeout conexiune în secunde");
    translation.put("LABEL_DELETE_FAVORITE", "Şterge un favorit");
    translation.put("LABEL_DELETE_CATEGORY", "Şterge o categorie");
    translation.put("LABEL_DELETE_SUBSCRIPTION", "Şterge un Blogroll");
    translation.put("LABEL_REGISTRATION_SUCCESS", "Înregistrare reuşită");
    translation.put("LABEL_SHOW", "Arată");
    translation.put("LABEL_SEARCH_IN", "Caută în");
    translation.put("LABEL_DOMAIN", "Domain");

    /** Buttons */
    translation.put("BUTTON_OPEN", "Deschide");
    translation.put("BUTTON_RELOAD_CAT", "Reîncarcă favorite");
    translation.put("BUTTON_ADD", "Adaugă");
    translation.put("BUTTON_FILE", "Deschide fişier");
    translation.put("BUTTON_SEARCH", "Caută");
    translation.put("BUTTON_RELOAD", "Reîncarcă ştiri");
    translation.put("BUTTON_CANCLE", "Anulare");
    translation.put("BUTTON_EXPORT", "Export");
    translation.put("BUTTON_STOP_SEARCH", "Opreşte căutarea");
    translation.put("BUTTON_CLEAR_RESULTS", "Şterge rezultatele");
    translation.put("BUTTON_EXPORT_TO_OPML", "Exportă OPML");
    translation.put("BUTTON_ADDTO_FAVORITS", "Adaugă la favorite");
    translation.put("BUTTON_ASSIGN", "Asignare");
    translation.put("BUTTON_RESTORE_DEFAULTS", "Revenire la setările implicite");
    translation.put("BUTTON_APPLY", "Aplică");
    translation.put("BUTTON_CHANGE_FONT", "Schimbă fontul");
    translation.put("BUTTON_OK", "OK");
    translation.put("BUTTON_VALIDATE", "Validare");
    translation.put("BUTTON_STOP_VALIDATION", "Oprire validare");
    translation.put("BUTTON_FOCUS_TABS", "Setează focus la noile taburi");
    translation.put("BUTTON_DISPLAY_TABS", "Afişează canalele de ştiri (newsfeeds) în taburi");
    translation.put("BUTTON_TRAY_STARTUP", "Pune RSSOwl în system tray la pornire");
    translation.put("BUTTON_TRAY_EXIT", "Pune RSSOwl în system tray la ieşire");
    translation.put("BUTTON_SHOW_ERRORS", "Afişare erori în tabfolder");
    translation.put("BUTTON_CHANGE", "Schimbă");
    translation.put("BUTTON_MARK_ALL_READ", "Marchează toate categoriile citite");
    translation.put("BUTTON_AGGREGATE_ALL", "Agregare toate categoriile");
    translation.put("BUTTON_RELOAD_ALL", "Reîncarcă toate categoriile");
    translation.put("BUTTON_SEARCH_ALL", "Caută în toate categoriile");
    translation.put("BUTTON_READ_ON_MINIMIZE", "La minimizare, marchează toate ştirile ca citite");
    translation.put("BUTTON_TRAY_POPUP", "Arată fereastră popup la când sunt ştiri necitite");
    translation.put("BUTTON_READ_ON_CLOSE", "Marcare ca citit la închidere tab");
    translation.put("BUTTON_UP", "Sus");
    translation.put("BUTTON_DOWN", "Jos");
    translation.put("BUTTON_CREATE_ACCOUNT", "Creare cont");
    translation.put("BUTTON_AUTOCLOSE_POPUP", "Închide automat ferestrele popup");
    translation.put("BUTTON_CACHE_FEEDS", "Salvare automată a canalului de ştiri pentru citire în mod deconectat (offline)");
    translation.put("BUTTON_OPEN_IN_BROWSER", "Deschide în browser");
    translation.put("BUTTON_SHOW_TAB_CLOSE", "Arată butonul de închidere la taburi");
    translation.put("BUTTON_DELETE_FAVORITE", "La ştergerea unui favorit");
    translation.put("BUTTON_DELETE_CATEGORY", "La ştergerea unei categorii");
    translation.put("BUTTON_DELETE_SUBSCRIPTION", "La ştergerea unui Blogroll");
    translation.put("BUTTON_NEVER_ASK_AGAIN", "Nu mai întreba, ţine minte răspunsul");
    translation.put("BUTTON_BLOCK_POPUPS", "Blochează ferestrele Popup");
    translation.put("BUTTON_ANIMATE_POPUP", "Animare fereastră popup");
    translation.put("BUTTON_REMOVE", "Îndepărtează");
    translation.put("BUTTON_SMALL_ICONS", "Foloseşte pictograme mici");
    translation.put("BUTTON_LINK_TAB", "Link with displayed Feed");
    translation.put("BUTTON_CLEAR", "Şterge");
    translation.put("BUTTON_NO_SORT", "Nu sorta automat Newsfeeds");

    /** Header */
    translation.put("HEADER_NEWS", "Newsheader");
    translation.put("HEADER_RSS_FAVORITES", "Favorite");

    /** Tooltips */
    translation.put("TOOLTIP_URLOPEN", "Clic pentru deschidere sit!");
    translation.put("TOOLTIP_PRINT", "Tipărire ştiri");
    translation.put("TOOLTIP_RATE", "Clic pentru evaluare");
    translation.put("TOOLTIP_GRAB_TITLE", "Foloseşte titlul din canalul de ştiri (newsfeed)");
    translation.put("TOOLTIP_UNREAD_AVAILABLE", "Ştiri necitite disponibile");
    translation.put("TOOLTIP_SKIP", "Omite");
    translation.put("TOOLTIP_OPEN_TAB", "Deschide un tab nou");
    translation.put("TOOLTIP_QUICKSEARCH", "Căutare rapidă");
    translation.put("TOOL_NEWSTIP", "NewsTip");

    /** Tableheader */
    translation.put("TABLE_HEADER_PUBDATE", "Data publicării");
    translation.put("TABLE_HEADER_AUTHOR", "Autor");
    translation.put("TABLE_HEADER_CATEGORY", "Categorie");
    translation.put("TABLE_HEADER_PUBLISHER", "Editor");
    translation.put("TABLE_HEADER_NEWSTITLE", "Newsheader");
    translation.put("TABLE_HEADER_FEED", "Newsfeed");
    translation.put("TABLE_HEADER_FEEDURL", "Newsfeed URL");
    translation.put("TABLE_HEADER_FEEDTITLE", "Newsfeed Titlu");
    translation.put("TABLE_HEADER_LINE", "Line");
    translation.put("TABLE_HEADER_STATUS", "Stare citire");

    /** Channelinfo / Newsitem info */
    translation.put("CHANNEL_INFO_HOMEPAGE", "Homepage");
    translation.put("CHANNEL_INFO_PUBDATE", "Data publicării");
    translation.put("CHANNEL_INFO_LASTBUILDDATE", "Ultima modificare a canalului de ştiri");
    translation.put("CHANNEL_INFO_MANAGINGEDITOR", "Managing editor");
    translation.put("CHANNEL_INFO_WEBMASTER", "Webmaster");
    translation.put("CHANNEL_INFO_CATEGORY", "Categorie");
    translation.put("CHANNEL_INFO_DOCS", "Docs");
    translation.put("CHANNEL_INFO_TTL", "Perioadă valabilitate canal de ştiri");
    translation.put("CHANNEL_INFO_RSSVERSION", "Format");
    translation.put("CHANNEL_INFO_GENERATOR", "RSS Generator");
    translation.put("CHANNEL_INFO_PUBLISHER", "Editor");
    translation.put("CHANNEL_INFO_LANGUAGE", "Limba");
    translation.put("CHANNEL_INFO_CREATOR", "Creator");
    translation.put("CHANNEL_INFO_UPDATE_PERIOD", "Actualizare");
    translation.put("CHANNEL_INFO_UPDATE_FREQUENCY", "ori");
    translation.put("NEWS_ITEM_INFO_SOURCE", "Sursa");
    translation.put("NEWS_ITEM_INFO_ENCLOSURE", "Îngrădire");
    translation.put("NEWS_ITEM_INFO_COMMENTS", "Comentarii");

    /** Messagebox / Dialogs */
    translation.put("MESSAGEBOX_TITLE_ATTENTION", "Atenţie");
    translation.put("MESSAGEBOX_FILL_URL", "Introduce-ţi un URL sau o cale");
    translation.put("MESSAGEBOX_CAT_EXISTS", "O categorie cu acest nume există deja");
    translation.put("MESSAGEBOX_SELECT_CAT", "Setaţi o categorie");
    translation.put("MESSAGEBOX_FILE_EXISTS", "Fişierul există deja. Se suprascrie?");
    translation.put("MESSAGEBOX_WRONG_IMPORT", "Fişierul nu conţine setări RSSOwl!");
    translation.put("MESSAGEBOX_IMPORT_SUCCESS", "Importul setărilor reuşit!");
    translation.put("MESSAGEBOX_PRINT_EMPTYTEXT", "Textul ştirii este gol! Selectaţi o ştire.");
    translation.put("DIALOG_ADD_FAVORITE_TITLE", "Adaugă un favorit nou");
    translation.put("DIALOG_ADD_CATEGORY_TITLE", "Adaugă o categorie nouă");
    translation.put("DIALOG_ADD_CATEGORY_MESSAGE", "Te rog introdu titlul");
    translation.put("DIALOG_ADD_SUBSCRIPTION_MESSAGE", "Te rog introdu url / cale şi titlul");
    translation.put("BASE_AUTH_TITLE", "Situl dorit necesită autorizare!");
    translation.put("BASE_AUTH_MESSAGE", "Introduceţi numele de utilizator şi parola.");
    translation.put("MESSAGEBOX_ERROR_SAVE_RSS", "Nu a fost selectat un RSS valid în tabfolder!");
    translation.put("MESSAGEBOX_TITLE_CONFIRM_DELETE", "Confirmare");
    translation.put("SEARCH_DIALOG_TITLE", "Caută");
    translation.put("SEARCH_DIALOG_MESSAGE", "Foloseşte AND, OR şi NOT pentru căutări!");
    translation.put("SEARCH_DIALOG_SEARCH_FOR", "Caută pentru");
    translation.put("SEARCH_DIALOG_EINTRE_WORDS", "Tot cuvântul doar");
    translation.put("SEARCH_DIALOG_CASESENSITIVE", "Se iau în consideraţie majusculele");
    translation.put("SEARCH_DIALOG_REGEX", "Foloseşte expresii regulate");
    translation.put("MESSAGEBOX_TITLE_UPDATE", "Nicio versiune nouă");
    translation.put("MESSAGEBOX_MESSAGE_UPDATE", "Este deja instalată ultima versiune a programului RSSOwl!");
    translation.put("MESSAGEBOX_TITLE_INFORMATION", "Informaţii");
    translation.put("DIALOG_EDIT_CATEGORY_TITLE", "Editare categorie");
    translation.put("DIALOG_EDIT_FAVORITE_TITLE", "Editare favorit");
    translation.put("DIALOG_TITLE_UPDATE", "Există o versiune nouă a programului RSSOwl");
    translation.put("DIALOG_SELECT_EXTERNAL_BROWSER", "Introduce-ţi calea către executabil");
    translation.put("MESSAGEBOX_MESSAGE_CON_ERROR", "Nu se poate contacta http://www.rssowl.org");
    translation.put("DIALOG_ID_ATTENTION", "Mai întâi trebuie setat ID-ul utilizator AmphetaRate!");
    translation.put("DIALOG_MESSAGE_CAT_EMPTY", "Categoria nu conţine niciun favorit!");
    translation.put("DIALOG_MESSAGE_KEYSEQUENCE", "Introduceţi o secvenţă de taste");
    translation.put("DIALOG_BROWSERSTART_FAILED", "Browserul nu a putut fi pornit!\nSelectaţi un browser în &apos;Preferinţe&apos;");
    translation.put("DIALOG_BLOGGER_ATTENTION", "Trebuie setat mai întâi un blogger!");
    translation.put("DIALOG_TITLE_CATEGORY", "Selectează o categorie");
    translation.put("DIALOG_ID_ATTENTION", "Trebuie creat mai întâi un cont AmphetaRate!");
    translation.put("DIALOG_MESSAGE_ENTER_URL", "Introduceţi URL pentru website");
    translation.put("MESSAGEBOX_LAUNCH_FAILED", "RSSOwl nu a găsit nicio aplicaţie pentru afişarea %FORMAT%");
    translation.put("DIALOG_EDIT_BLOGROLL_TITLE", "Editare Blogroll");
    translation.put("DIALOG_ERROR_INTERNALBROWSER", "Nu s-a reuşit încărcarea browserului intern!");
    translation.put("DIALOG_ADD_SUBSCRIPTION_TITLE", "Adaugă un Blogroll nou");
    translation.put("QUESTION_DEL_FAV", "Sunteţi sigur că doriţi ştergerea acestui favorit \"%NAME%\"?");
    translation.put("QUESTION_DEL_CAT", "Sunteţi sigur că doriţi ştergerea acestei categorii \"%NAME%\"?");
    translation.put("QUESTION_DEL_SUB", "Sunteţi sigur că doriţi ştergerea acestui Blogroll?");

    /** Browser */
    translation.put("BROWSER_BACK", "Înapoi");
    translation.put("BROWSER_FORWARD", "Înainte");
    translation.put("BROWSER_STOP", "Stop");

    /** AmphetaRate rating levels */
    translation.put("RATE_FANTASTIC", "Fantastic");
    translation.put("RATE_GOOD", "Bun");
    translation.put("RATE_MODERATE", "Moderat");
    translation.put("RATE_BAD", "Rău");
    translation.put("RATE_VERY_BAD", "Foarte rău");

    /** Update interval */
    translation.put("UPDATE_INTERVAL_NO", "fără");
    translation.put("UPDATE_INTERVAL_ONE", "după 1 minut");
    translation.put("UPDATE_INTERVAL_FIVE", "după 5 minute");
    translation.put("UPDATE_INTERVAL_FIFTEEN", "după 15 minute");
    translation.put("UPDATE_INTERVAL_THIRTY", "la fiecare 30 minute");
    translation.put("UPDATE_INTERVAL_ONEHOUR", "după 1 oră");
    translation.put("UPDATE_INTERVAL_THREEHOURS", "după 3 ore");
    translation.put("UPDATE_INTERVAL_SIXHOURS", "la fiecare 6 ore");
    translation.put("UPDATE_INTERVAL_TWELVEHOURS", "după 12 ore");
    translation.put("UPDATE_INTERVAL_ONEDAY", "după 24 ore");

    /** Keyboard keys */
    translation.put("LABEL_KEY_CONTROL", "Ctrl");
    translation.put("LABEL_KEY_SHIFT", "Shift");
    translation.put("LABEL_KEY_ARROW_UP", "Săgeată_Sus");
    translation.put("LABEL_KEY_ARROW_DOWN", "Săgeată_Jos");
    translation.put("LABEL_KEY_ARROW_LEFT", "Săgeată_Stânga");
    translation.put("LABEL_KEY_ARROW_RIGHT", "Săgeată_Dreapta");
    translation.put("LABEL_KEY_PAGE_UP", "Page_Up");
    translation.put("LABEL_KEY_PAGE_DOWN", "Page_Down");
    translation.put("LABEL_KEY_SPACE", "Spaţiu");
    translation.put("LABEL_KEY_INSERT", "Insert");
    translation.put("LABEL_KEY_PAUSE", "Pause");
    translation.put("LABEL_KEY_NUMPAD", "Numpad");
    translation.put("LABEL_KEY_COMMAND", "Cmd");
    translation.put("LABEL_KEY_DEL", "Del");

    /** Font Settings */
    translation.put("FONT_AREA_TEXT", "Fontul textului");
    translation.put("FONT_AREA_DIALOG", "Fontul dialogului");
    translation.put("FONT_AREA_TREE", "Fontul arborelui");
    translation.put("FONT_AREA_TABLE", "Fontul tabelului");
    translation.put("FONT_AREA_HEADER", "Fontul antetului");
    translation.put("FONT_AREA_TEXT_DESCRIPTION", "Fontul text este utilizat pentru ştiri, informaţii referitoare la canalul de ştiri, mesaje şi erori.");
    translation.put("FONT_AREA_DIALOG_DESCRIPTION", "Fontul dialog este folosit în toate dialogurile.");
    translation.put("FONT_AREA_TREE_DESCRIPTION", "Fontul arbore este utilizat pentru arborele care conţine favoritele.");
    translation.put("FONT_AREA_TABLE_DESCRIPTION", "Fontul tabelă este pentru tabela care conţine ştirile din canalul de ştiri.");
    translation.put("FONT_AREA_HEADER_DESCRIPTION", "Fontul antet este utilizat pentru secţiunea antet.");
    translation.put("FONT_STYLE_BOLD", "Bold");
    translation.put("FONT_STYLE_ITALIC", "Italic");
    translation.put("FONT_STYLE_NORMAL", "Normal");

    /** Groups */
    translation.put("GROUP_COMMAND", "Comanda");
    translation.put("GROUP_SELECTED_FONT", "Fontul selectat");
    translation.put("GROUP_FONT_AREA", "Font");
    translation.put("GROUP_WINDOW_LAYOUT", "Window Layout");
    translation.put("GROUP_OPEN_MODE", "Mod deschidere");
    translation.put("GROUP_ARGUMENTS", "Argumente");
    translation.put("GROUP_LINK_COLOR", "Culoare legătură (Link)");
    translation.put("GROUP_SYNTAXHIGHLIGHT_COLOR", "Culoarea termenilor căutaţi");
    translation.put("GROUP_TAB_LAYOUT", "Tab Layout");
    translation.put("GROUP_TRAY", "Sistem Tray");
    translation.put("GROUP_GENERAL", "General");
    translation.put("GROUP_EXISTING_ACCOUNT", "Contul existent");
    translation.put("GROUP_NEW_ACCOUNT", "Creare cont nou");
    translation.put("GROUP_NEWS_POPUP", "News popup");
    translation.put("GROUP_CONFIRM_DIALOG", "Arată dialogul de confirmare");

    /** Languages */
    translation.put("de", "Germană");
    translation.put("da", "Daneză");
    translation.put("el", "Greacă");
    translation.put("en", "Engleză");
    translation.put("es", "Spaniolă");
    translation.put("fr", "Franceză");
    translation.put("gl", "Galeză");
    translation.put("it", "Italiană");
    translation.put("nl", "Olandeză");
    translation.put("pt", "Portugheză (Brazilia)");
    translation.put("ru", "Rusă");
    translation.put("bg", "Bulgară");
    translation.put("zhcn", "Chineză simplificată");
    translation.put("zhtw", "Chineză tradiţională");
    translation.put("ja", "Japoneză");
    translation.put("ko", "Coreană");
    translation.put("pl", "Poloneză");
    translation.put("no", "Norvegiană");
    translation.put("sv", "Suedeză");
    translation.put("bn", "Bengaleză");
    translation.put("fi", "Finladeză");
    translation.put("uk", "Ucrainiană");
    translation.put("tr", "Turcă");
    translation.put("hu", "Maghiară");
    translation.put("sl", "Slovacă");
    translation.put("cs", "Cehă");
    translation.put("hu", "Maghiară");
    translation.put("th", "Tailandeză");
    translation.put("sr", "Sârbă (alfabet chirilic)");
    translation.put("sh", "Sârbă (alfabet latin)");
    translation.put("ro", "Română");

    /** Misc. */
    translation.put("NEWS_NO_DESCRIPTION", "Descriere indisponibilă!");
    translation.put("LOAD_FEED", "Încărcare");
    translation.put("SEARCH_FEED", "Căutare");
    translation.put("RELOAD_FEED", "Reîmprospătare");
    translation.put("PRINTED_FROM_RSSOWL", "Tipărit de RSSOwl (http://www.rssowl.org)");
    translation.put("PRINTJOB_NAME", "Printare ştiri de la RSSOwl (http://www.rssowl.org)");
    translation.put("SYSTRAY_SHOW", "Arată RSSOwl");
    translation.put("TAB_WELCOME", "Bine aţi venit");
    translation.put("DOCUMENT_GENERATED_FROM", "Document generat de RSSOwl");
    translation.put("NO_TITLE", "Fără titlu");
    translation.put("RECOMMENDED_ARTICLES", "Articole recomandate");
    translation.put("RSSOWL_TEASER", "RSSOwl este un cititor de ştiri (newsreader) RSS şi RDF gratuit, opensource. Dintre facilităţile sale, amintim:\n\n- Export în formate PDF, HTML, RTF, OPML\n- Import favorite din OPML\n- Căutare în text cu sublinierea rezultatelor\n- Puternic motor de căutare RSS şi RDF\n- Browser intern pentru afişare ştiri\n- Gruparea favoritelor în categorii\n- Rulează pe Windows, Linux, Solaris şi Mac\n\nPentru o listă completă a facilităţilor, a se vedea: http://www.rssowl.org/features.html\n\nDescărcare de la: http://sourceforge.net/project/showfiles.php?group_id=86683");
    translation.put("MAIL_ERROR_BODY", "Ataşează '" + GlobalSettings.WORKING_DIR + GlobalSettings.PATH_SEPARATOR + "rssowllog.log' la acest mail impreună cu o scurtă descriere a ceea ce făcea RSSOwl înainte de eroare. Mulţumesc!");
    translation.put("FORMAT_AUTO_DETECT", "Detectare automată");
    translation.put("NEWSFEED_VALID", "Canalul de ştiri (NewsFeed) este valid");
    translation.put("OPML_IMPORTED", "Importat");
    translation.put("ENTIRE_NEWS", "Toate ştirile");
    translation.put("SEARCH_AND", "AND");
    translation.put("SEARCH_OR", "OR");
    translation.put("SEARCH_NOT", "NOT");
  }
}
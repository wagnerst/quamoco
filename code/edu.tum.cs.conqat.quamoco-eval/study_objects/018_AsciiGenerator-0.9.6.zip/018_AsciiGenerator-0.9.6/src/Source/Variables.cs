﻿//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: Variables.cs,v 1.82 2008/01/31 15:32:02 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Globalization;
using System.Collections;
using System.Drawing;
using System.Xml;
using System.Windows.Forms;
using System.IO;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Abstract class containing global variables for the program
	/// </summary>
	public abstract class Variables
	{
		/// <summary>
		/// Read the default settings from an XML file
		/// </summary>
		/// <param name="filename">the filename to read from</param>
		public static bool ReadXML(string filename) {
			XmlDocument doc = new XmlDocument();

			try {
				doc.Load(filename);

				// check doc.DocumentElement.Attributes["version"]

				CheckForNewVersions = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/checkfornewversions"), CheckForNewVersions);

				TranslationFile = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/translationfile"), TranslationFile, true);

				CheckForTranslationFiles();

				InitialInputDirectory = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/input/initialdirectory"),
					InitialInputDirectory, true);

				LoadImageBrightnessContrast = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/input/brightnesscontrast/load"),
					LoadImageBrightnessContrast);

				if (LoadImageBrightnessContrast) {
					DefaultImageBrightness = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/input/brightnesscontrast/brightness"),
						-200, 200, DefaultImageBrightness);

					DefaultImageContrast = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/input/brightnesscontrast/contrast"),
						-100, 100, DefaultImageContrast);
				}

				InitialOutputDirectory = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/initialdirectory"),
					InitialOutputDirectory, true);

				Prefix = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/prefix"),
					Prefix, true);

				MaximumWidth = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/maximumwidth"),
					1, 99999, MaximumWidth);

				MaximumHeight = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/maximumheight"),
					1, 99999, MaximumHeight);

				LoadOutputSize = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/size/load"),
					LoadOutputSize);

				if (LoadOutputSize) {
					DefaultWidth = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/size/width"),
						-1, MaximumWidth, DefaultWidth);

					if (DefaultWidth == 0) DefaultWidth = 1;

					DefaultHeight = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/size/height"),
						-1, MaximumHeight, DefaultHeight);

					if (DefaultHeight == 0) DefaultHeight = 1;

					if (DefaultWidth == -1 && DefaultHeight == -1) {
						DefaultWidth = 150;
					}
				}

				FontStyle style = FontStyle.Regular;

				if (XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/font/italic"), DefaultFont.Italic)) {
					style = style | FontStyle.Italic;
				}

				if (XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/font/bold"), DefaultFont.Bold)) {
					style = style | FontStyle.Bold;
				}

				if (XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/font/strikeout"), DefaultFont.Strikeout)) {
					style = style | FontStyle.Strikeout;
				}

				if (XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/font/underline"), DefaultFont.Underline)) {
					style = style | FontStyle.Underline;
				}

				DefaultFont = new Font(
					XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/font/name"), DefaultFont.Name, false),
					XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/font/size"), 1f, 200f, DefaultFont.Size),
					style);

				LoadTextBrightnessContrast = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/brightnesscontrast/load"),
					LoadTextBrightnessContrast);

				if (LoadTextBrightnessContrast) {
					DefaultTextBrightness = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/brightnesscontrast/brightness"),
						-200, 200, DefaultTextBrightness);

					DefaultTextContrast = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/brightnesscontrast/contrast"),
						-100, 100, DefaultTextContrast);
				}

				LoadLevels = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/levels/load"), LoadLevels);

				if (LoadLevels) {
					DefaultMinLevel = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/levels/min"),
						0, 254, DefaultMinLevel);

					DefaultMaxLevel = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/levels/max"),
						DefaultMinLevel + 1, 255, DefaultMaxLevel);

					DefaultMedianLevel = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/levels/med"),
						0.0f, 1.0f, DefaultMedianLevel);
				}

				DefaultDitheringLevel = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/dither/amount"),
						0, 25, DefaultDitheringLevel);

				DefaultDitheringRandom = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/dither/random"),
						0, 20, DefaultDitheringRandom);

				Stretch = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/stretch"), Stretch);

				Sharpen = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/sharpen"), Sharpen);

				UnsharpMask = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/unsharp"), UnsharpMask);

				FlipHorizontally = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/fliphorizontally"), FlipHorizontally);

				FlipVertically = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/flipvertically"), FlipVertically);

				BlackTextOnWhite = !XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/output/invertcolors"), !BlackTextOnWhite);

				XmlNodeList nodes = doc.SelectNodes("ascgen2/asciiramps/ramp");
				if (nodes != null) {
					ArrayList ramps = new ArrayList(nodes.Count);

					foreach (XmlNode node in nodes) {
						if (node.InnerText.Length > 0) {
							ramps.Add(node.InnerText);
						}
					}

					if (ramps.Count > 0) {
						DefaultRamps = ramps;
					}
				}

				CurrentSelectedRamp = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/asciiramps/selectedramp"),
					-1, DefaultRamps.Count - 1, CurrentSelectedRamp);

				if (CurrentSelectedRamp == -1) {
					CurrentRamp = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/asciiramps/currentramp"),
						CurrentRamp, true);
				}

				if (CurrentSelectedRamp == -1 && CurrentRamp.Length == 0) {
					CurrentSelectedRamp = 0;
				}

				UseGeneratedRamp = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/rampgeneration/generate"), UseGeneratedRamp);

				nodes = doc.SelectNodes("ascgen2/rampgeneration/validcharacters");
				if (nodes != null) {
					ArrayList validchars = new ArrayList(nodes.Count);

					foreach (XmlNode node in nodes) {
						if (node.InnerText.Length > 0) {
							validchars.Add(node.InnerText);
						}
					}

					if (validchars.Count > 0) {
						DefaultValidCharacters = validchars;
					}
				}

				CurrentSelectedValidCharacters = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/rampgeneration/selectedcharacters"),
					-1, DefaultValidCharacters.Count - 1, CurrentSelectedValidCharacters);

				if (CurrentSelectedValidCharacters == -1) {
					CurrentCharacters = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/rampgeneration/currentcharacters"),
						CurrentCharacters, true);
				}

				if (CurrentSelectedValidCharacters == -1 && CurrentCharacters.Length == 0) {
					CurrentSelectedValidCharacters = 0;
				}

				ConfirmOnClose = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/confirmclose"), ConfirmOnClose);

				ShowBCWidgetImage = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/showimagebrightnesscontrast"), ShowBCWidgetImage);

				ShowWidgetText = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/showtextwidget"), ShowWidgetText);

				SelectionBorderColor = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/selectionbordercolor"), SelectionBorderColor);

				SelectionFillColor = XmlProcessor.ReadNode(doc.SelectSingleNode("ascgen2/FormConvertImage/selectionfillcolor"), SelectionFillColor);

				return true;
			}
			catch (System.Xml.XmlException) {
				MessageBox.Show(Resource.GetString("Invalid settings file. Please delete it or save a new one"),
					Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}
			catch (System.IO.FileNotFoundException) {
				CheckForTranslationFiles();

				return false;
			}
		}

		/// <summary>
		/// If TranslationFile is not set, check the directory for a translation.*.xml file to use if one exists
		/// </summary>
		private static void CheckForTranslationFiles() {
			if (TranslationFile.Length > 0) {
				return;
			}

			DirectoryInfo dir = new DirectoryInfo(Application.StartupPath);

			FileInfo[] files = dir.GetFiles("translation.*.xml");

			if (files.Length == 1) {
				TranslationFile = files[0].Name;
			}
			else {
				TranslationFile = "translation.xml";
			}
		}

		/// <summary>
		/// Save the current settings as XML
		/// </summary>
		/// <param name="filename">the filename to use for the output</param>
		public static bool WriteXML(string filename) {
			try {
				XmlTextWriter writer = new XmlTextWriter(Application.StartupPath + "\\" + filename, System.Text.Encoding.Unicode);
				writer.Formatting = Formatting.Indented;

				writer.WriteStartDocument();
				writer.WriteStartElement("ascgen2");
				writer.WriteAttributeString("version", Variables.Version.GetVersion());
				writer.WriteElementString("checkfornewversions", (Variables.CheckForNewVersions).ToString(Variables.Culture));
				writer.WriteElementString("translationfile", Variables.TranslationFile);

				writer.WriteStartElement("input");
				writer.WriteElementString("initialdirectory", Variables.InitialInputDirectory);

				writer.WriteStartElement("brightnesscontrast");
				writer.WriteElementString("brightness", DefaultImageBrightness.ToString(Variables.Culture));
				writer.WriteElementString("contrast", DefaultImageContrast.ToString(Variables.Culture));
				writer.WriteElementString("load", Variables.LoadImageBrightnessContrast.ToString(Variables.Culture));
				writer.WriteEndElement();   //brightnesscontrast
				writer.WriteEndElement();   //input

				writer.WriteStartElement("output");
				writer.WriteElementString("initialdirectory", Variables.InitialOutputDirectory);

				writer.WriteElementString("prefix", Variables.Prefix);

				writer.WriteStartElement("size");

				writer.WriteElementString("width", Variables.DefaultWidth.ToString(Variables.Culture));
				writer.WriteElementString("height", Variables.DefaultHeight.ToString(Variables.Culture));
				writer.WriteElementString("load", Variables.LoadOutputSize.ToString(Variables.Culture));
				writer.WriteEndElement();   //size

				writer.WriteElementString("maximumwidth", Variables.MaximumWidth.ToString(Variables.Culture));
				writer.WriteElementString("maximumheight", Variables.MaximumHeight.ToString(Variables.Culture));

				writer.WriteStartElement("font");
				writer.WriteElementString("name", DefaultFont.Name);
				writer.WriteElementString("size", DefaultFont.Size.ToString(Variables.Culture));
				writer.WriteElementString("italic", DefaultFont.Italic.ToString(Variables.Culture));
				writer.WriteElementString("bold", DefaultFont.Bold.ToString(Variables.Culture));
				writer.WriteElementString("strikeout", DefaultFont.Strikeout.ToString(Variables.Culture));
				writer.WriteElementString("underline", DefaultFont.Underline.ToString(Variables.Culture));
				writer.WriteEndElement();	//font

				writer.WriteStartElement("brightnesscontrast");
				writer.WriteElementString("brightness", DefaultTextBrightness.ToString(Variables.Culture));
				writer.WriteElementString("contrast", DefaultTextContrast.ToString(Variables.Culture));
				writer.WriteElementString("load", Variables.LoadTextBrightnessContrast.ToString(Variables.Culture));
				writer.WriteEndElement();   //brightnesscontrast

				writer.WriteStartElement("levels");
				writer.WriteElementString("min", Variables.DefaultMinLevel.ToString(Variables.Culture));
				writer.WriteElementString("med", Variables.DefaultMedianLevel.ToString(Variables.Culture));
				writer.WriteElementString("max", Variables.DefaultMaxLevel.ToString(Variables.Culture));
				writer.WriteElementString("load", Variables.LoadLevels.ToString(Variables.Culture));
				writer.WriteEndElement();   //levels

				writer.WriteStartElement("dither");
				writer.WriteElementString("amount", DefaultDitheringLevel.ToString(Variables.Culture));
				writer.WriteElementString("random", DefaultDitheringRandom.ToString(Variables.Culture));
				writer.WriteEndElement();   //dither

				writer.WriteElementString("stretch", Variables.Stretch.ToString(Variables.Culture));
				writer.WriteElementString("sharpen", Variables.Sharpen.ToString(Variables.Culture));
				writer.WriteElementString("unsharp", Variables.UnsharpMask.ToString(Variables.Culture));
				writer.WriteElementString("fliphorizontally", Variables.FlipHorizontally.ToString(Variables.Culture));
				writer.WriteElementString("flipvertically", Variables.FlipVertically.ToString(Variables.Culture));
				writer.WriteElementString("invertcolors", (!Variables.BlackTextOnWhite).ToString(Variables.Culture));
				writer.WriteEndElement();   //output

				writer.WriteStartElement("asciiramps");
				foreach (string s in Variables.DefaultRamps) {
					writer.WriteElementString("ramp", s);
				}

				writer.WriteElementString("selectedramp", Variables.CurrentSelectedRamp.ToString(Variables.Culture));
				writer.WriteElementString("currentramp", Variables.CurrentRamp);
				writer.WriteEndElement();   //asciiramps

				writer.WriteStartElement("rampgeneration");
				writer.WriteElementString("generate", Variables.UseGeneratedRamp.ToString(Variables.Culture));

				foreach (string s in DefaultValidCharacters) {
					writer.WriteElementString("validcharacters", s);
				}

				writer.WriteElementString("selectedcharacters", CurrentSelectedValidCharacters.ToString(Variables.Culture));
				writer.WriteElementString("currentcharacters", CurrentCharacters);
				writer.WriteEndElement();   //rampgeneration

				writer.WriteStartElement("FormConvertImage");
				writer.WriteElementString("showimagebrightnesscontrast", ShowBCWidgetImage.ToString(Variables.Culture));
				writer.WriteElementString("showtextwidget", ShowWidgetText.ToString(Variables.Culture));
				writer.WriteElementString("selectionbordercolor", ColorTranslator.ToHtml(Variables.SelectionBorderColor));
				writer.WriteElementString("selectionfillcolor", ColorTranslator.ToHtml(Variables.SelectionFillColor));
				writer.WriteElementString("confirmclose", Variables.ConfirmOnClose.ToString(Variables.Culture));
				writer.WriteEndElement();   //mainform

				writer.WriteEndElement();   //ascgen2
				writer.WriteEndDocument();

				writer.Flush();
				writer.Close();

				return true;
			}
			catch (Exception e) {
				MessageBox.Show(e.Message, "Error");
				return false;
			}
		}


		#region Properties and Variables

		/// <summary>The program name</summary>
		public const string ProgramName = "ASCII Generator dotNET";

		/// <summary>
		/// Class Holding the current application version
		/// </summary>
		public abstract class Version
		{
			/// <summary>
			/// Build and return the current application version
			/// </summary>
			/// <returns>The current version as a string</returns>
			public static string GetVersion() {
				return Major.ToString() + "." + Minor.ToString() + "." + Patch.ToString() + Suffix;
			}

			/// <summary>Major version number</summary>
			public const int Major = 0;

			/// <summary>Minor version number</summary>
			public const int Minor = 9;

			/// <summary>Patch version number</summary>
			public const int Patch = 6;

			/// <summary>Version Suffix</summary>
			public const string Suffix = "";

			/// <summary>Version Suffix Number</summary>
			public const int SuffixNumber = 0;
		}

		/// <summary>Default value for if the program will check the website for a new version</summary>
		public static bool CheckForNewVersions = true;

		/// <summary>The current culture of the program</summary>
		public static CultureInfo Culture = CultureInfo.InvariantCulture;

		/// <summary>Default output width (-1 to autocalculate from height, but only if DefaultHeight > 0)</summary>
		public static int DefaultWidth = 150;

		/// <summary>Default output height (-1 to autocalculate from width, but only if DefaultWidth > 0)</summary>
		public static int DefaultHeight = -1;

		/// <summary>Maximum width of the output image</summary>
		public static int MaximumWidth = 999;

		/// <summary>Maximum height of the output image</summary>
		public static int MaximumHeight = 999;

		/// <summary>Default value for whether the output size should be loaded from the settings</summary>
		public static bool LoadOutputSize = true;

		/// <summary>The default font to be used for conversions</summary>
		public static System.Drawing.Font DefaultFont = new System.Drawing.Font("Lucida Console", 9f);

		/// <summary>Default settings used for all ASCII ramp valid character strings</summary>
		public static ArrayList DefaultValidCharacters = new ArrayList(
			new string[] {
                " #,.0123456789:;@ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz$",
                " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
                " 1234567890",
                "M@WB08Za2SX7r;i:;. ",
                "@#MBHAGh93X25Sisr;:, ",
                "█▓▒░ "}
			);

		/// <summary>The default selected string from DefaultValidCharacters (0 to DefaultValidCharacters.Length - 1)</summary>
		public static int CurrentSelectedValidCharacters = 0;

		/// <summary>The ramp used if CurrentSelectedValidCharacters is -1 (not in the list)</summary>
		public static string CurrentCharacters = String.Empty;

		/// <summary>Default brightness used for the input image (-200 to 200)</summary>
		public static int DefaultImageBrightness = 0;

		/// <summary>Default contrast used for the input image (-100 to 100)</summary>
		public static int DefaultImageContrast = 0;

		/// <summary>Default value for whether brightness and contrast should be loaded from the settings</summary>
		public static bool LoadImageBrightnessContrast = false;

		/// <summary>Default brightness used for the output text (-200 to 200)</summary>
		public static int DefaultTextBrightness = 0;

		/// <summary>Default contrast used for the output text (-100 to 100)</summary>
		public static int DefaultTextContrast = 0;

		/// <summary>Default value for whether the text brightness and contrast should be loaded from the settings</summary>
		public static bool LoadTextBrightnessContrast = false;

		/// <summary>Default minimum level value for the output text (0 to 253)</summary>
		public static int DefaultMinLevel = 0;

		/// <summary>Default median level value for the output text (0.0 to 1.0)</summary>
		public static float DefaultMedianLevel = 0.5f;

		/// <summary>Default maximum level value for the output text (2 to 255)</summary>
		public static int DefaultMaxLevel = 255;

		/// <summary>Default value for whether the levels should be loaded from the settings</summary>
		public static bool LoadLevels = false;

		/// <summary>Default dithering used for the output image</summary>
		public static int DefaultDitheringLevel = 5;

		/// <summary>Default maximum random level for dithering</summary>
		public static int DefaultDitheringRandom = 3;

		/// <summary>Default value for whether the output should be stretched</summary>
		public static bool Stretch = true;

		/// <summary>Default value for whether the output should be sharpened</summary>
		public static bool Sharpen = false;

		/// <summary>Default value for whether the output should be sharpened with an unsharp mask</summary>
		public static bool UnsharpMask = true;

		/// <summary>Default value for whether the output should be flipped horizontally</summary>
		public static bool FlipHorizontally = false;

		/// <summary>Default value for whether the output should be flipped vertically</summary>
		public static bool FlipVertically = false;

		/// <summary>Default value for whether the output is black text on a white background</summary>
		public static bool BlackTextOnWhite = true;

		/// <summary>Default value for whether we should automatically generate a ramp</summary>
		public static bool UseGeneratedRamp = true;

		/// <summary>Default list of ramps</summary>
		public static ArrayList DefaultRamps = new ArrayList(
			new string[] {
                "MMMMMMM@@@@@@@WWWWWWWWWBBBBBBBB000000008888888ZZZZZZZZZaZaaaaaa2222222SSSSSSSXXXXXXXXXXX7777777rrrrrrr;;;;;;;;iiiiiiiii:::::::,:,,,,,,.........       ",
				"@@@@@@@######MMMBBHHHAAAA&&GGhh9933XXX222255SSSiiiissssrrrrrrr;;;;;;;;:::::::,,,,,,,........        ",
				"#WMBRXVYIti+=;:,. ",
				"##XXxxx+++===---;;,,...    ",
				"@%#*+=-:. ",
				"#¥¥®®ØØ$$ø0oo°++=-,.    ",
				"# ",
				"01 ",
                "█▓▒░ "}
			);

		/// <summary>The default selected string from DefaultRamps (0 to DefaultRamps.Length - 1)</summary>
		public static int CurrentSelectedRamp = 0;

		/// <summary>The ramp used if CurrentSelectedRamp is -1 (not in the list)</summary>
		public static string CurrentRamp = String.Empty;

		/// <summary>Default directory to use when loading an image (empty string = use current directory)</summary>
		public static string InitialInputDirectory = String.Empty;

		/// <summary>Default directory to use when saving (empty string = use current directory)</summary>
		public static string InitialOutputDirectory = String.Empty;

		/// <summary>Text added to the beginning of the output filenames</summary>
		public static string Prefix = "ASCII-";

		/// <summary>Default value for if the user should be asked to confirm when closing an unsaved image</summary>
		public static bool ConfirmOnClose = true;

		/// <summary>Optional xml file containing the translation strings to be used</summary>
		public static string TranslationFile = "";

		/// <summary>Default value for whether the images brightness/contrast widget is visible</summary>
		public static bool ShowBCWidgetImage = true;

		/// <summary>Default value for whether the texts widget is visible</summary>
		public static bool ShowWidgetText = true;

		/// <summary>Default colour for the selection area border</summary>
		public static Color SelectionBorderColor = Color.DarkBlue;

		/// <summary>Default colour for the selection area</summary>
		public static Color SelectionFillColor = Color.FromArgb(128, 173, 216, 230);

		/// <summary>Filename for the settings</summary>
		public static string SettingsFile = "settings.xml";

		#endregion
	}
}
//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: WidgetBrightnessContrast.Designer.cs,v 1.9 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Windows.Forms;
using System.ComponentModel;
using JMSoftware.AsciiGeneratorDotNet;

namespace JMSoftware.Widgets
{
	/// <summary>
	/// Widget to provide controls for adjusting Brightness/Contrast
	/// </summary>
	public partial class WidgetBrightnessContrast : BaseWidget
	{

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.jmBrightnessContrast1 = new JMSoftware.Controls.JMBrightnessContrast();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.cmenuReset = new System.Windows.Forms.ToolStripMenuItem();
			this.contextMenuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// jmBrightnessContrast1
			// 
			this.jmBrightnessContrast1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.jmBrightnessContrast1.ContextMenuStrip = this.contextMenuStrip1;
			this.jmBrightnessContrast1.Location = new System.Drawing.Point(0, 0);
			this.jmBrightnessContrast1.MinimumSize = new System.Drawing.Size(120, 86);
			this.jmBrightnessContrast1.Name = "jmBrightnessContrast1";
			this.jmBrightnessContrast1.Size = new System.Drawing.Size(120, 86);
			this.jmBrightnessContrast1.Suspended = false;
			this.jmBrightnessContrast1.TabIndex = 0;
			this.jmBrightnessContrast1.BrightnessChanging += new System.EventHandler(this.jmBrightnessContrast1_BrightnessChanging);
			this.jmBrightnessContrast1.ValueChanged += new System.EventHandler(this.jmBrightnessContrast1_ValueChanged);
			this.jmBrightnessContrast1.ContrastChanged += new System.EventHandler(this.jmBrightnessContrast1_ContrastChanged);
			this.jmBrightnessContrast1.BrightnessChanged += new System.EventHandler(this.jmBrightnessContrast1_BrightnessChanged);
			this.jmBrightnessContrast1.ContrastChanging += new System.EventHandler(this.jmBrightnessContrast1_ContrastChanging);
			this.jmBrightnessContrast1.ValueChanging += new System.EventHandler(this.jmBrightnessContrast1_ValueChanging);
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmenuReset});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(140, 26);
			this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
			// 
			// cmenuReset
			// 
			this.cmenuReset.Name = "cmenuReset";
			this.cmenuReset.Size = new System.Drawing.Size(139, 22);
			this.cmenuReset.Text = "cmenuReset";
			this.cmenuReset.Click += new System.EventHandler(this.cmenuReset_Click);
			// 
			// WidgetBrightnessContrast
			// 
			this.ClientSize = new System.Drawing.Size(120, 88);
			this.Controls.Add(this.jmBrightnessContrast1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.MinimumSize = new System.Drawing.Size(136, 122);
			this.Name = "WidgetBrightnessContrast";
			this.contextMenuStrip1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		private JMSoftware.Controls.JMBrightnessContrast jmBrightnessContrast1;
		private ContextMenuStrip contextMenuStrip1;
		private IContainer components;
		private ToolStripMenuItem cmenuReset;
	}
}
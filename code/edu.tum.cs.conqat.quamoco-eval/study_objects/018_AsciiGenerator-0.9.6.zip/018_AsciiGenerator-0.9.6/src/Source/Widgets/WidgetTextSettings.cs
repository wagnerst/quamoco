//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: WidgetTextSettings.cs,v 1.12 2008/02/10 14:10:30 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using JMSoftware.AsciiGeneratorDotNet;
using JMSoftware.Interfaces;

namespace JMSoftware.Widgets
{
	/// <summary>
	/// Widget class to display the text adjustment controls
	/// </summary>
	public partial class WidgetTextSettings : BaseWidget, IBrightnessContrast, ILevels, IDither
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public WidgetTextSettings()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		public void UpdateUI() {
			jmBrightnessContrast1.BrightnessLabel = Resource.GetString("Brightness") + ":";
			jmBrightnessContrast1.ContrastLabel = Resource.GetString("Contrast") + ":";
			jmDithering1.DitheringLabel = Resource.GetString("Dithering Amount") + ":";
			jmDithering1.RandomLabel = Resource.GetString("Random") + ":";

			cmenuDitherReset.Text = cmenuBCReset.Text = cmenuLevelsReset.Text = Resource.GetString("Reset");
		}

		private void UpdateLevelsContextMenu() {
			cmenuMinimum.Text = Resource.GetString("Minimum") + ": " + Minimum.ToString(Variables.Culture);
			cmenuMedian.Text = Resource.GetString("Median") + ": " + Math.Round(Median, 2).ToString(Variables.Culture);
			cmenuMaximum.Text = Resource.GetString("Maximum") + ": " + Maximum.ToString(Variables.Culture);
		}

		private void cmenuLevels_Opening(object sender, CancelEventArgs e) {
			cmenuLevelsReset.Enabled = Enabled && (Minimum != 0 || Median != 0.5f || Maximum != 255);
			UpdateLevelsContextMenu();
		}

		private void jmLevels1_ValueChanged() {
			if (LevelsChanged != null) {
				LevelsChanged(this, new EventArgs());
			}
		}

		private void jmBrightnessContrast1_BrightnessChanged(object sender, EventArgs e) {
			if (BrightnessChanged != null) {
				BrightnessChanged(this, EventArgs.Empty);
			}
		}

		private void jmBrightnessContrast1_ContrastChanged(object sender, EventArgs e) {
			if (ContrastChanged != null) {
				ContrastChanged(this, EventArgs.Empty);
			}
		}

		private void jmBrightnessContrast1_ValueChanged(object sender, EventArgs e) {
			if (ValueChanged != null) {
				ValueChanged(this, new EventArgs());
			}
		}

		private void jmBrightnessContrast1_BrightnessChanging(object sender, EventArgs e) {
			if (BrightnessChanging != null) {
				BrightnessChanging(this, EventArgs.Empty);
			}
		}

		private void jmBrightnessContrast1_ContrastChanging(object sender, EventArgs e) {
			if (ContrastChanging != null) {
				ContrastChanging(this, EventArgs.Empty);
			}
		}

		private void jmBrightnessContrast1_ValueChanging(object sender, EventArgs e) {
			if (ValueChanging != null) {
				ValueChanging(this, new EventArgs());
			}
		}

		private void cmenuLevelsReset_Click(object sender, System.EventArgs e) {
			jmLevels1.Reset();

			if (LevelsChanged != null) {
				LevelsChanged(this, new EventArgs());
			}
		}

		private void cmenuBrightnessContrast_Opening(object sender, CancelEventArgs e) {
			cmenuBCReset.Enabled = jmBrightnessContrast1.Brightness != 0 || jmBrightnessContrast1.Contrast != 0;
		}

		private void cmenuBCReset_Click(object sender, EventArgs e) {
			jmBrightnessContrast1.Reset();
		}

		private void jmDithering1_DitheringChanging(object sender, EventArgs e) {
			if (DitheringChanging != null) {
				DitheringChanging(this, new EventArgs());
			}
		}

		private void jmDithering1_DitheringChanged(object sender, EventArgs e) {
			if (DitheringChanged != null) {
				DitheringChanged(this, new EventArgs());
			}
		}

		private void jmDithering1_RandomChanged(object sender, EventArgs e) {
			if (DitheringRandomChanged != null) {
				DitheringRandomChanged(this, new EventArgs());
			}
		}

		private void cmenuDitherResetToolStripMenuItem_Click(object sender, EventArgs e) {
			jmDithering1.Reset();
		}

		private void cmenuDither_Opening(object sender, CancelEventArgs e) {
			cmenuDither.Enabled = (jmDithering1.DitherAmount != 5) || (jmDithering1.DitherRandom != 3);
		}

		#region Properties and Variables

		/// <summary>Get or set the array of values for the levels</summary>
		public int[] LevelsArray {
			get { return jmLevels1.Array; }
			set { jmLevels1.Array = value; }
		}

		/// <summary>
		/// Get or set the Minimum value
		/// </summary>
		public int Minimum {
			get { return jmLevels1.Minimum; }
			set { jmLevels1.Minimum = value; }
		}

		/// <summary>
		/// Get or set the Maximum value
		/// </summary>
		public int Maximum {
			get { return jmLevels1.Maximum; }
			set { jmLevels1.Maximum = value; }
		}

		/// <summary>
		/// Get or set the median value (0.0 to 1.0)
		/// </summary>
		public float Median {
			get { return jmLevels1.Median; }
			set { jmLevels1.Median = value; }
		}

		private bool _Enabled = true;
		/// <summary>
		/// Get or set whether the form is enabled
		/// </summary>
		public new bool Enabled {
			get { return _Enabled; }
			set { jmDithering1.Enabled = jmLevels1.Enabled = jmBrightnessContrast1.Enabled = _Enabled = value; }
		}

		/// <summary>Get and set the current Brightness</summary>
		public int Brightness {
			get { return jmBrightnessContrast1.Brightness; }
			set { jmBrightnessContrast1.Brightness = value; }
		}

		/// <summary>Get and set the current Contrast</summary>
		public int Contrast {
			get { return jmBrightnessContrast1.Contrast; }
			set { jmBrightnessContrast1.Contrast = value; }
		}

		/// <summary>Get and set the maximum value</summary>
		public int MaximumBrightness {
			get { return jmBrightnessContrast1.MaximumBrightness; }
			set { jmBrightnessContrast1.MaximumBrightness = value; }
		}

		/// <summary>Get and set the minimum value</summary>
		public int MinimumBrightness {
			get { return jmBrightnessContrast1.MinimumBrightness; }
			set { jmBrightnessContrast1.MinimumBrightness = value; }
		}

		/// <summary>Get and set the maximum value</summary>
		public int MaximumContrast {
			get { return jmBrightnessContrast1.MaximumContrast; }
			set { jmBrightnessContrast1.MaximumContrast = value; }
		}

		/// <summary>Get and set the minimum value</summary>
		public int MinimumContrast {
			get { return jmBrightnessContrast1.MinimumContrast; }
			set { jmBrightnessContrast1.MinimumContrast = value; }
		}

		/// <summary>Get and set the current Dithering level</summary>
		public int DitherAmount {
			get { return jmDithering1.DitherAmount; }
			set { jmDithering1.DitherAmount = value; }
		}

		/// <summary>Get and set the random level for the dithering</summary>
		public int DitherRandom {
			get { return jmDithering1.DitherRandom; }
			set { jmDithering1.DitherRandom = value; }
		}

		/// <summary>Event that fires when the minimum, maximum, or median levels value changes</summary>
		[Browsable(true), Description("Fires when the minimum, maximum, or median levels value changes")]
		public event EventHandler LevelsChanged = null;

		/// <summary>Event raised when the brightness has changed</summary>
		[Browsable(true), Description("Event raised when the brightness has changed")]
		public event EventHandler BrightnessChanged;

		/// <summary>Event raised when the contrast has changed</summary>
		[Browsable(true), Description("Event raised when the contrast has changed")]
		public event EventHandler ContrastChanged;

		/// <summary>Event raised when a value has changed</summary>
		[Browsable(true), Description("Event raised when a value has changed")]
		public event EventHandler ValueChanged;

		/// <summary>Event raised when the dithering has changed</summary>
		[Browsable(true), Description("Event raised when the dithering has changed")]
		public event EventHandler DitheringChanged;

		/// <summary>Event raised while the brightness is changing</summary>
		[Browsable(true), Description("Event raised while the brightness is changing")]
		public event EventHandler BrightnessChanging;

		/// <summary>Event raised while the contrast is changing</summary>
		[Browsable(true), Description("Event raised while the contrast is changing")]
		public event EventHandler ContrastChanging;

		/// <summary>Event raised while a value is changing</summary>
		[Browsable(true), Description("Event raised while a value is changing")]
		public event EventHandler ValueChanging;

		/// <summary>Event raised while the dithering is changing</summary>
		[Browsable(true), Description("Event raised while the dithering is changing")]
		public event EventHandler DitheringChanging;

		/// <summary>Event raised while the random value for dithering has changed</summary>
		[Browsable(true), Description("Event raised while the random value for dithering has changed")]
		public event EventHandler DitheringRandomChanged;
		
		#endregion
	}
}
﻿//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: WidgetPreview.cs,v 1.2 2008/02/10 14:10:30 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using JMSoftware.Interfaces;

namespace JMSoftware.Widgets
{
	/// <summary>
	/// Widget for displaying the colour preview controls
	/// </summary>
	public partial class WidgetPreview : BaseWidget, IZoomLevel
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public WidgetPreview() {
			InitializeComponent();
		}

		private void btnClose_Click(object sender, EventArgs e) {
			if (CloseForm != null) {
				CloseForm(this, new EventArgs());
			}
		}

		private void btnZoomIn_Click(object sender, EventArgs e) {
			Amount += 0.1f;
		}

		private void btnZoomOut_Click(object sender, EventArgs e) {
			Amount -= 0.1f;
		}

		#region Properties and Variables

		private float _Amount = 1.0f;
		/// <summary>Get and set the current Zoom amount</summary>
		public float Amount {
			get {
				return _Amount;
			}

			set {
				if (value != _Amount && value > 0.0 && value < 3.0) {
					_Amount = value;

					btnZoomIn.Enabled = Amount < 2.9;
					btnZoomOut.Enabled = Amount > 0.1;

					if (ZoomChanged != null) {
						ZoomChanged(this, new EventArgs());
					}
				}
			}
		}

		/// <summary>Event raised when the zoom amount has changed</summary>
		[Browsable(true), Description("Event raised when the zoom amount has changed")]
		public event EventHandler ZoomChanged;

		/// <summary>Event raised when the close button has been pressed</summary>
		[Browsable(true), Description("Event raised when the close button has been pressed")]
		public event EventHandler CloseForm;

		/// <summary>
		/// Get and set the text for the Close button
		/// </summary>
		[Browsable(true), Description("Text for the Close button")]
		public string CloseText {
			get {
				return btnClose.Text;
			}

			set {
				btnClose.Text = value;
				toolTip1.SetToolTip(btnClose, value);
			}
		}

		/// <summary>
		/// Get and set the text for the Zoom In button
		/// </summary>
		[Browsable(true), Description("Text for the Zoom In button")]
		public string ZoomInText {
			get {
				return toolTip1.GetToolTip(btnZoomIn);
			}

			set {
				toolTip1.SetToolTip(btnZoomIn, value);
			}
		}

		/// <summary>
		/// Get and set the text for the Zoom Out button
		/// </summary>
		[Browsable(true), Description("Text for the Zoom Out button")]
		public string ZoomOutText {
			get {
				return toolTip1.GetToolTip(btnZoomOut);
			}

			set {
				toolTip1.SetToolTip(btnZoomOut, value);
			}
		}

		#endregion
	}
}
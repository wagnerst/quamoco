//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: Resource.cs,v 1.9 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Resources;
using System.Collections.Generic;
using System.Xml;
using System.Windows.Forms;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Class to handle accessing of the programs resources
	/// </summary>
	public abstract class Resource
	{
		/// <summary>
		/// The root location of the localization resources
		/// </summary>
		public static string Location = "AscGenDotNet.Resources.Localization.Localization";

		/// <summary>
		/// Get the string named 'key' from the resource file
		/// </summary>
		/// <param name="key">Name of the string to return</param>
		/// <returns>Specified string value from the resource file</returns>
		public static string GetString(string key) {
			ResourceManager _ResourceManager =
				new ResourceManager(Location,
				System.Reflection.Assembly.GetExecutingAssembly());

			string value;

			if (Translations.ContainsKey(key)) {
				value = Translations[key];
			}
			else {
				value = _ResourceManager.GetString(key, Variables.Culture);

				if (value == null || value.Length == 0) {
					value = key;
				}
			}

			return value;
		}

		/// <summary>Have we attempted to load the translation file?</summary>
		public static bool TranslationFileChecked = false;

		private static Dictionary<string, string> _Translations = null;
		/// <summary>Contains translated strings</summary>
		public static Dictionary<string, string> Translations {
			get {
				if (_Translations == null) {
					_Translations = new Dictionary<string, string>();

					if (!TranslationFileChecked) {
						XmlDocument doc = new XmlDocument();

						try {
							doc.Load(Variables.TranslationFile);

							foreach (XmlNode node in doc.DocumentElement.ChildNodes) {
								_Translations.Add(node.Attributes[0].InnerText, node.InnerText);
							}
						}
						catch (XmlException ex) {
							MessageBox.Show(ex.Message, string.Format(GetString("Error with settings file '{0}'"), Variables.TranslationFile), MessageBoxButtons.OK, MessageBoxIcon.Error);
						}
						catch (System.IO.FileNotFoundException) {
							if (Variables.TranslationFile != "translation.xml") {
								MessageBox.Show(string.Format(GetString("Could not load translation file '{0}'"), Variables.TranslationFile),
									GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
							}
						}
						catch (ArgumentException) {
						}
						finally {
							TranslationFileChecked = true;
						}
					}
				}

				return _Translations;
			}
		}
	}
}
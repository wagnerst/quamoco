//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: XmlProcessor.cs,v 1.3 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Xml;
using System.Drawing;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Class to process xml nodes
	/// </summary>
	public abstract class XmlProcessor {
		private XmlProcessor() {
		}

		/// <summary>
		/// Reads the node and returns the int value
		/// </summary>
		/// <param name="node">Node to read</param>
		/// <param name="min">Lowest acceptable value</param>
		/// <param name="max">Highest acceptable value</param>
		/// <param name="current">Value to use if node is invalid</param>
		/// <returns>An integer for the node</returns>
		public static int ReadNode(XmlNode node, int min, int max, int current) {
			int result = current;

			if (node != null) {
				try {
					result = XmlConvert.ToInt32(node.InnerText);

					if (result < min) result = min;
					if (result > max) result = max;
				}
				catch (System.FormatException) {
				}
			}

			return result;
		}

		/// <summary>
		/// Reads the node and returns the float value
		/// </summary>
		/// <param name="node">Node to read</param>
		/// <param name="min">Lowest acceptable value</param>
		/// <param name="max">Highest acceptable value</param>
		/// <param name="current">Value to use if node is invalid</param>
		/// <returns>A float for the node</returns>
		public static float ReadNode(XmlNode node, float min, float max, float current) {
			float result = current;

			if (node != null) {
				try {
					result = (float)XmlConvert.ToDouble(node.InnerText);

					if (result < min) result = min;
					if (result > max) result = max;
				}
				catch (System.FormatException) {
				}
			}

			return result;
		}

		/// <summary>
		/// Reads the node and returns the boolean value
		/// </summary>
		/// <param name="node">Node to read</param>
		/// <param name="current">Value to use if node is invalid</param>
		/// <returns>A boolean for the node</returns>
		public static bool ReadNode(XmlNode node, bool current) {
			bool result = current;

			if (node != null) {
				try {
					result = XmlConvert.ToBoolean(node.InnerText.ToLower(Variables.Culture));
				}
				catch (System.FormatException) {
				}
			}

			return result;
		}

		/// <summary>
		/// Reads the node and returns the string value
		/// </summary>
		/// <param name="node">Node to read</param>
		/// <param name="current">Value to use if node is invalid</param>
		/// <param name="allowempty">Should we return an empty string if it is empty?</param>
		/// <returns>A string for the node</returns>
		public static string ReadNode(XmlNode node, string current, bool allowempty) {
			if (node != null) {
				return (!allowempty && (node.InnerText.Length == 0)) ? current : node.InnerText;
			}
			else {
				return current;
			}
		}

		/// <summary>
		/// Reads the node and returns the Color value
		/// </summary>
		/// <param name="node">Node to read</param>
		/// <param name="current">Value to use if node is invalid</param>
		/// <returns>A Color for the node</returns>
		public static Color ReadNode(XmlNode node, Color current) {
			Color result = current;

			if (node != null && node.InnerText.Length > 0) {
				try {
					result = ColorTranslator.FromHtml(node.InnerText);
				}
				catch (System.Exception) {
				}
			}

			return result;
		}
	}
}
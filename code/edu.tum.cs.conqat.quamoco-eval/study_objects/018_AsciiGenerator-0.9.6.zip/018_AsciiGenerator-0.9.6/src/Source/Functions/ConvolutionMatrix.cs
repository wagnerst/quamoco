//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: ConvolutionMatrix.cs,v 1.18 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;

namespace JMSoftware
{
	/// <summary>
	/// Basic class for 3x3 convolution matricies
	/// </summary>
	public class ConvolutionMatrix
	{
		/// <summary>
		/// Default Constructor
		/// </summary>
		public ConvolutionMatrix()
			: this(new int[,] { { 0, 0, 0 }, { 0, 1, 0 }, { 0, 0, 0 } }, 1) {
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="values">3x3 array of values for the matrix</param>
		/// <param name="factor">Initial matrix factor</param>
		public ConvolutionMatrix(int[,] values, int factor) {
			_Matrix = new int[9];
			int pos = 0;

			for (int row = 0; row < 3; row++) {
				for (int col = 0; col < 3; col++) {
					_Matrix[pos++] = values[col, row];
				}
			}

			Factor = factor;
		}

		/// <summary>
		/// Apply a ConvolutionMatrix to the array of values
		/// </summary>
		/// <param name="values">Values to be processed</param>
		/// <returns>Array containing the altered values</returns>
		public byte[,] Apply(byte[,] values) {
			if (values == null) {
				return null;
			}

			int ArrayWidth = values.GetLength(0);
			int ArrayHeight = values.GetLength(1);

			byte[,] Result = new byte[ArrayWidth, ArrayHeight];

			int pixel;

			// variables factored out of the loops
			int maxwidth = ArrayWidth - 1;
			int maxheight = ArrayHeight - 1;
			float factor = (float)_Factor;
			float offset = (float)_Offset + 0.5f;
			int x, y, col, row, pos;

			for (y = 1; y < maxheight; y++) {
				for (x = 1; x < maxwidth; x++) {
					pixel = 0;
					pos = 0;

					for (row = -1; row < 2; row++) {
						for (col = -1; col < 2; col++) {
							// multiple the matrix value by the corresponding pixel centered around x,y
							pixel += _Matrix[pos++] * values[x + col, y + row];
						}
					}

					pixel = (int)(((float)pixel / factor) + offset);

					// if pixel is between 0 to 255
					if ((pixel & 0xff) == pixel) {
						Result[x, y] = (byte)pixel;
					}
					else if (pixel > 255) {
						Result[x, y] = 255;
					}
					else {
						Result[x, y] = 0;
					}
				}
			}

			if (maxheight > 1 && maxwidth > 1) {
				// do the edges separately to avoid min/max calc in the main loop
				// TODO: Do this but better
				int[] x_inc = { 1, maxwidth };
				int[] y_inc = { maxheight, 1 };

				for (int i = 0; i < 2; i++) {
					for (x = 0; x < ArrayWidth; x += x_inc[i]) {
						for (y = 0; y < ArrayHeight; y += y_inc[i]) {
							pixel = 0;
							pos = 0;

							for (row = -1; row < 2; row++) {
								for (col = -1; col < 2; col++) {
									// limit x, y to be between 0 and max
									pixel += _Matrix[pos++] *
										values[x + col > maxwidth ? maxwidth : (x + col < 0 ? 0 : x + col),
												y + row > maxheight ? maxheight : (y + row < 0 ? 0 : y + row)];
								}
							}

							pixel = (int)(((float)pixel / factor) + offset);

							// if pixel is between 0 to 255
							if ((pixel & 0xff) == pixel) {
								Result[x, y] = (byte)pixel;
							}
							else if (pixel > 255) {
								Result[x, y] = 255;
							}
							else {
								Result[x, y] = 0;
							}
						}
					}
				}
			}

			return Result;
		}

		#region Properties and Variables

		private int _Factor = 1;
		/// <summary>Matrix factor - should be equal to the sum of the matrix values</summary>
		public int Factor {
			get { return _Factor; }
			set { _Factor = value; }
		}

		private int _Offset = 0;
		/// <summary></summary>
		public int Offset {
			get { return _Offset; }
			set { _Offset = value; }
		}

		private int[] _Matrix;

		#endregion
	}
}
//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: ImageFunctions.cs,v 1.2 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace JMSoftware
{
	/// <summary>
	/// Class containing image related functions
	/// </summary>
	public abstract class ImageFunctions
	{
		/// <summary>
		/// Save the passed image into the specified filename/type
		/// </summary>
		/// <param name="image"></param>
		/// <param name="filename"></param>
		public static void SaveImage(Image image, string filename) {
		}

		/// <summary>
		/// Get the image format for the passed extension string
		/// </summary>
		/// <param name="extension"></param>
		/// <returns></returns>
		public static ImageFormat GetImageFormat(string extension) {
			Guid result;

			switch (extension) {
				case ".png":
					result = ImageFormat.Png.Guid;
					break;
				case ".jpg":
				case ".jpeg":
				case ".jpe":
					result = ImageFormat.Jpeg.Guid;
					break;
				case ".gif":
					result = ImageFormat.Gif.Guid;
					break;
				case ".tif":
				case ".tiff":
					result = ImageFormat.Tiff.Guid;
					break;
				case ".bmp":
				case ".rle":
				case ".dib":
				default:
					result = ImageFormat.Bmp.Guid;
					break;
			}

			return new ImageFormat(result);
		}
	}
}
//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormTextSettings.cs,v 1.31 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using JMSoftware.AsciiConversion;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Summary description for FormTextSettings.
	/// </summary>
	public class FormTextSettings : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnDefault;
		private System.Windows.Forms.Label lblBrightness;
		private System.Windows.Forms.CheckBox cbxStretch;
		private System.Windows.Forms.TextBox tbxBrightness;
		private System.Windows.Forms.TextBox tbxContrast;
		private System.Windows.Forms.CheckBox cbxFlipHorizontal;
		private System.Windows.Forms.CheckBox cbxFlipVertical;
		private System.Windows.Forms.Label lblContrast;
		private System.Windows.Forms.GroupBox gbxSharpening;
		private System.Windows.Forms.RadioButton rbNone;
		private System.Windows.Forms.RadioButton rbSharpen;
		private System.Windows.Forms.RadioButton rbUnsharp;
		private System.Windows.Forms.CheckBox cbxBlackTextOnWhite;
		private System.Windows.Forms.Button btnFont;
		private System.Windows.Forms.TextBox tbxFont;
		private System.Windows.Forms.FontDialog dialogFont;
		private System.Windows.Forms.Label lblRamp;
		private System.Windows.Forms.CheckBox cbxAuto;
        private System.Windows.Forms.ComboBox cmbRamp;
		private System.Windows.Forms.TextBox tbxPrefix;
		private System.Windows.Forms.TextBox tbxSuffix;
		private System.Windows.Forms.Label lblSuffix;
		private System.Windows.Forms.Label lblPrefix;
		private System.Windows.Forms.ComboBox cmbSuffix;
		private System.Windows.Forms.CheckBox cbxAutoSuffix;
		private System.Windows.Forms.TextBox tbxCharacterWidth;
		private System.Windows.Forms.Label lblX;
		private System.Windows.Forms.TextBox tbxCharacterHeight;
		private System.Windows.Forms.CheckBox cbxAutoCharSize;
		private System.Windows.Forms.GroupBox gbxLevels;
		private System.Windows.Forms.Label lblMax;
		private System.Windows.Forms.Label lblMed;
		private System.Windows.Forms.Label lblMin;
		private System.Windows.Forms.TextBox tbxMin;
		private System.Windows.Forms.TextBox tbxMed;
		private System.Windows.Forms.TextBox tbxMax;
        private ContextMenuStrip cmenuStripAuto;
        private IContainer components;
        private ToolStripMenuItem cmenuAutoCopy;
        private ToolStripMenuItem cmenuAutoValidChars;
		private System.Windows.Forms.Button btnOk;

		/// <summary>Constructor</summary>
		public FormTextSettings(TextProcessingSettings settings) {
			InitializeComponent();

			cmbRamp.Items.Clear();
			cmbRamp.Items.AddRange(Variables.DefaultRamps.ToArray());
			if (settings.IsGeneratedRamp) cmbRamp.SelectedIndex = Variables.CurrentSelectedRamp;

			UpdateUI();

			cmbSuffix.SelectedIndex = 0;

			Settings = settings;

			UpdateCharacterSize();

			UpdateOkButton();
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnDefault = new System.Windows.Forms.Button();
            this.cbxFlipHorizontal = new System.Windows.Forms.CheckBox();
            this.cbxFlipVertical = new System.Windows.Forms.CheckBox();
            this.lblBrightness = new System.Windows.Forms.Label();
            this.tbxBrightness = new System.Windows.Forms.TextBox();
            this.tbxContrast = new System.Windows.Forms.TextBox();
            this.lblContrast = new System.Windows.Forms.Label();
            this.cbxStretch = new System.Windows.Forms.CheckBox();
            this.gbxSharpening = new System.Windows.Forms.GroupBox();
            this.rbUnsharp = new System.Windows.Forms.RadioButton();
            this.rbSharpen = new System.Windows.Forms.RadioButton();
            this.rbNone = new System.Windows.Forms.RadioButton();
            this.cbxBlackTextOnWhite = new System.Windows.Forms.CheckBox();
            this.btnFont = new System.Windows.Forms.Button();
            this.tbxFont = new System.Windows.Forms.TextBox();
            this.dialogFont = new System.Windows.Forms.FontDialog();
            this.lblRamp = new System.Windows.Forms.Label();
            this.cbxAuto = new System.Windows.Forms.CheckBox();
            this.cmenuStripAuto = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmenuAutoCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.cmenuAutoValidChars = new System.Windows.Forms.ToolStripMenuItem();
            this.cmbRamp = new System.Windows.Forms.ComboBox();
            this.tbxSuffix = new System.Windows.Forms.TextBox();
            this.tbxPrefix = new System.Windows.Forms.TextBox();
            this.lblSuffix = new System.Windows.Forms.Label();
            this.lblPrefix = new System.Windows.Forms.Label();
            this.cbxAutoSuffix = new System.Windows.Forms.CheckBox();
            this.cmbSuffix = new System.Windows.Forms.ComboBox();
            this.tbxCharacterWidth = new System.Windows.Forms.TextBox();
            this.lblX = new System.Windows.Forms.Label();
            this.tbxCharacterHeight = new System.Windows.Forms.TextBox();
            this.cbxAutoCharSize = new System.Windows.Forms.CheckBox();
            this.gbxLevels = new System.Windows.Forms.GroupBox();
            this.tbxMax = new System.Windows.Forms.TextBox();
            this.tbxMed = new System.Windows.Forms.TextBox();
            this.lblMax = new System.Windows.Forms.Label();
            this.lblMed = new System.Windows.Forms.Label();
            this.tbxMin = new System.Windows.Forms.TextBox();
            this.lblMin = new System.Windows.Forms.Label();
            this.gbxSharpening.SuspendLayout();
            this.cmenuStripAuto.SuspendLayout();
            this.gbxLevels.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(183, 305);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 27;
            this.btnCancel.Text = "btnCancel";
            // 
            // btnOk
            // 
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOk.Location = new System.Drawing.Point(8, 305);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 25;
            this.btnOk.Text = "btnOk";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnDefault
            // 
            this.btnDefault.Location = new System.Drawing.Point(96, 305);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(75, 23);
            this.btnDefault.TabIndex = 26;
            this.btnDefault.Text = "btnDefault";
            this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
            // 
            // cbxFlipHorizontal
            // 
            this.cbxFlipHorizontal.Location = new System.Drawing.Point(24, 207);
            this.cbxFlipHorizontal.Name = "cbxFlipHorizontal";
            this.cbxFlipHorizontal.Size = new System.Drawing.Size(112, 24);
            this.cbxFlipHorizontal.TabIndex = 11;
            this.cbxFlipHorizontal.Text = "cbxFlipHorizontal";
            // 
            // cbxFlipVertical
            // 
            this.cbxFlipVertical.Location = new System.Drawing.Point(160, 207);
            this.cbxFlipVertical.Name = "cbxFlipVertical";
            this.cbxFlipVertical.Size = new System.Drawing.Size(93, 24);
            this.cbxFlipVertical.TabIndex = 12;
            this.cbxFlipVertical.Text = "cbxFlipVertical";
            // 
            // lblBrightness
            // 
            this.lblBrightness.Location = new System.Drawing.Point(24, 12);
            this.lblBrightness.Name = "lblBrightness";
            this.lblBrightness.Size = new System.Drawing.Size(64, 20);
            this.lblBrightness.TabIndex = 0;
            this.lblBrightness.Text = "lblBrightness";
            this.lblBrightness.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbxBrightness
            // 
            this.tbxBrightness.Location = new System.Drawing.Point(88, 12);
            this.tbxBrightness.MaxLength = 4;
            this.tbxBrightness.Name = "tbxBrightness";
            this.tbxBrightness.Size = new System.Drawing.Size(32, 20);
            this.tbxBrightness.TabIndex = 1;
            this.tbxBrightness.Text = "0";
            this.tbxBrightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxBrightness.TextChanged += new System.EventHandler(this.tbxBrightness_TextChanged);
            // 
            // tbxContrast
            // 
            this.tbxContrast.Location = new System.Drawing.Point(206, 12);
            this.tbxContrast.MaxLength = 4;
            this.tbxContrast.Name = "tbxContrast";
            this.tbxContrast.Size = new System.Drawing.Size(32, 20);
            this.tbxContrast.TabIndex = 3;
            this.tbxContrast.Text = "0";
            this.tbxContrast.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxContrast.TextChanged += new System.EventHandler(this.tbxContrast_TextChanged);
            // 
            // lblContrast
            // 
            this.lblContrast.Location = new System.Drawing.Point(152, 12);
            this.lblContrast.Name = "lblContrast";
            this.lblContrast.Size = new System.Drawing.Size(56, 20);
            this.lblContrast.TabIndex = 2;
            this.lblContrast.Text = "lblContrast";
            this.lblContrast.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbxStretch
            // 
            this.cbxStretch.Location = new System.Drawing.Point(24, 183);
            this.cbxStretch.Name = "cbxStretch";
            this.cbxStretch.Size = new System.Drawing.Size(80, 24);
            this.cbxStretch.TabIndex = 9;
            this.cbxStretch.Text = "cbxStretch";
            // 
            // gbxSharpening
            // 
            this.gbxSharpening.Controls.Add(this.rbUnsharp);
            this.gbxSharpening.Controls.Add(this.rbSharpen);
            this.gbxSharpening.Controls.Add(this.rbNone);
            this.gbxSharpening.Location = new System.Drawing.Point(8, 127);
            this.gbxSharpening.Name = "gbxSharpening";
            this.gbxSharpening.Size = new System.Drawing.Size(250, 48);
            this.gbxSharpening.TabIndex = 8;
            this.gbxSharpening.TabStop = false;
            this.gbxSharpening.Text = "gbxSharpening";
            // 
            // rbUnsharp
            // 
            this.rbUnsharp.Location = new System.Drawing.Point(148, 16);
            this.rbUnsharp.Name = "rbUnsharp";
            this.rbUnsharp.Size = new System.Drawing.Size(96, 24);
            this.rbUnsharp.TabIndex = 2;
            this.rbUnsharp.Text = "rbUnsharp";
            // 
            // rbSharpen
            // 
            this.rbSharpen.Location = new System.Drawing.Point(75, 16);
            this.rbSharpen.Name = "rbSharpen";
            this.rbSharpen.Size = new System.Drawing.Size(72, 24);
            this.rbSharpen.TabIndex = 1;
            this.rbSharpen.Text = "rbSharpen";
            // 
            // rbNone
            // 
            this.rbNone.Location = new System.Drawing.Point(16, 16);
            this.rbNone.Name = "rbNone";
            this.rbNone.Size = new System.Drawing.Size(56, 24);
            this.rbNone.TabIndex = 0;
            this.rbNone.Text = "rbNone";
            // 
            // cbxBlackTextOnWhite
            // 
            this.cbxBlackTextOnWhite.Location = new System.Drawing.Point(124, 183);
            this.cbxBlackTextOnWhite.Name = "cbxBlackTextOnWhite";
            this.cbxBlackTextOnWhite.Size = new System.Drawing.Size(128, 24);
            this.cbxBlackTextOnWhite.TabIndex = 10;
            this.cbxBlackTextOnWhite.Text = "cbxBlackTextOnWhite";
            // 
            // btnFont
            // 
            this.btnFont.Location = new System.Drawing.Point(8, 237);
            this.btnFont.Name = "btnFont";
            this.btnFont.Size = new System.Drawing.Size(48, 22);
            this.btnFont.TabIndex = 13;
            this.btnFont.Text = "btnFont";
            this.btnFont.Click += new System.EventHandler(this.btnFont_Click);
            // 
            // tbxFont
            // 
            this.tbxFont.Location = new System.Drawing.Point(64, 238);
            this.tbxFont.Name = "tbxFont";
            this.tbxFont.ReadOnly = true;
            this.tbxFont.Size = new System.Drawing.Size(82, 20);
            this.tbxFont.TabIndex = 14;
            // 
            // dialogFont
            // 
            this.dialogFont.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dialogFont.FontMustExist = true;
            // 
            // lblRamp
            // 
            this.lblRamp.Location = new System.Drawing.Point(24, 102);
            this.lblRamp.Name = "lblRamp";
            this.lblRamp.Size = new System.Drawing.Size(48, 16);
            this.lblRamp.TabIndex = 5;
            this.lblRamp.Text = "lblRamp";
            // 
            // cbxAuto
            // 
            this.cbxAuto.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbxAuto.Checked = true;
            this.cbxAuto.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxAuto.ContextMenuStrip = this.cmenuStripAuto;
            this.cbxAuto.Location = new System.Drawing.Point(202, 96);
            this.cbxAuto.Name = "cbxAuto";
            this.cbxAuto.Size = new System.Drawing.Size(36, 25);
            this.cbxAuto.TabIndex = 7;
            this.cbxAuto.Text = "cbxAuto";
            this.cbxAuto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbxAuto.CheckedChanged += new System.EventHandler(this.cbxAuto_CheckedChanged);
            // 
            // cmenuStripAuto
            // 
            this.cmenuStripAuto.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmenuAutoCopy,
            this.cmenuAutoValidChars});
            this.cmenuStripAuto.Name = "cmenuStripAuto";
            this.cmenuStripAuto.Size = new System.Drawing.Size(179, 48);
            // 
            // cmenuAutoCopy
            // 
            this.cmenuAutoCopy.Image = global::AscGenDotNet.Properties.Resources.page_white_copy;
            this.cmenuAutoCopy.Name = "cmenuAutoCopy";
            this.cmenuAutoCopy.Size = new System.Drawing.Size(178, 22);
            this.cmenuAutoCopy.Text = "cmenuAutoCopy";
            this.cmenuAutoCopy.Click += new System.EventHandler(this.cmenuAutoCopy_Click);
            // 
            // cmenuAutoValidChars
            // 
            this.cmenuAutoValidChars.Image = global::AscGenDotNet.Properties.Resources.textfield;
            this.cmenuAutoValidChars.Name = "cmenuAutoValidChars";
            this.cmenuAutoValidChars.Size = new System.Drawing.Size(178, 22);
            this.cmenuAutoValidChars.Text = "cmenuAutoValidChars";
            this.cmenuAutoValidChars.Click += new System.EventHandler(this.cmenuAutoValidChars_Click);
            // 
            // cmbRamp
            // 
            this.cmbRamp.DropDownWidth = 200;
            this.cmbRamp.Enabled = false;
            this.cmbRamp.Location = new System.Drawing.Point(61, 98);
            this.cmbRamp.Name = "cmbRamp";
            this.cmbRamp.Size = new System.Drawing.Size(140, 21);
            this.cmbRamp.TabIndex = 6;
            this.cmbRamp.TextChanged += new System.EventHandler(this.cmbRamp_TextChanged);
            // 
            // tbxSuffix
            // 
            this.tbxSuffix.Location = new System.Drawing.Point(126, 271);
            this.tbxSuffix.Name = "tbxSuffix";
            this.tbxSuffix.Size = new System.Drawing.Size(42, 20);
            this.tbxSuffix.TabIndex = 22;
            // 
            // tbxPrefix
            // 
            this.tbxPrefix.Location = new System.Drawing.Point(44, 271);
            this.tbxPrefix.Name = "tbxPrefix";
            this.tbxPrefix.Size = new System.Drawing.Size(42, 20);
            this.tbxPrefix.TabIndex = 20;
            // 
            // lblSuffix
            // 
            this.lblSuffix.Location = new System.Drawing.Point(92, 271);
            this.lblSuffix.Name = "lblSuffix";
            this.lblSuffix.Size = new System.Drawing.Size(40, 20);
            this.lblSuffix.TabIndex = 21;
            this.lblSuffix.Text = "lblSuffix";
            this.lblSuffix.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPrefix
            // 
            this.lblPrefix.Location = new System.Drawing.Point(8, 271);
            this.lblPrefix.Name = "lblPrefix";
            this.lblPrefix.Size = new System.Drawing.Size(40, 20);
            this.lblPrefix.TabIndex = 19;
            this.lblPrefix.Text = "lblPrefix";
            this.lblPrefix.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbxAutoSuffix
            // 
            this.cbxAutoSuffix.Location = new System.Drawing.Point(171, 272);
            this.cbxAutoSuffix.Name = "cbxAutoSuffix";
            this.cbxAutoSuffix.Size = new System.Drawing.Size(16, 20);
            this.cbxAutoSuffix.TabIndex = 23;
            this.cbxAutoSuffix.CheckedChanged += new System.EventHandler(this.cbxAutoSuffix_CheckedChanged);
            // 
            // cmbSuffix
            // 
            this.cmbSuffix.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSuffix.Enabled = false;
            this.cmbSuffix.Location = new System.Drawing.Point(187, 271);
            this.cmbSuffix.Name = "cmbSuffix";
            this.cmbSuffix.Size = new System.Drawing.Size(71, 21);
            this.cmbSuffix.TabIndex = 24;
            // 
            // tbxCharacterWidth
            // 
            this.tbxCharacterWidth.Location = new System.Drawing.Point(153, 238);
            this.tbxCharacterWidth.MaxLength = 3;
            this.tbxCharacterWidth.Name = "tbxCharacterWidth";
            this.tbxCharacterWidth.ReadOnly = true;
            this.tbxCharacterWidth.Size = new System.Drawing.Size(25, 20);
            this.tbxCharacterWidth.TabIndex = 15;
            this.tbxCharacterWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxCharacterWidth.TextChanged += new System.EventHandler(this.tbxCharacterWidth_TextChanged);
            // 
            // lblX
            // 
            this.lblX.Location = new System.Drawing.Point(175, 237);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(16, 20);
            this.lblX.TabIndex = 16;
            this.lblX.Text = "x";
            this.lblX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxCharacterHeight
            // 
            this.tbxCharacterHeight.Location = new System.Drawing.Point(190, 238);
            this.tbxCharacterHeight.MaxLength = 3;
            this.tbxCharacterHeight.Name = "tbxCharacterHeight";
            this.tbxCharacterHeight.ReadOnly = true;
            this.tbxCharacterHeight.Size = new System.Drawing.Size(25, 20);
            this.tbxCharacterHeight.TabIndex = 17;
            this.tbxCharacterHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxCharacterHeight.TextChanged += new System.EventHandler(this.tbxCharacterHeight_TextChanged);
            // 
            // cbxAutoCharSize
            // 
            this.cbxAutoCharSize.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbxAutoCharSize.Checked = true;
            this.cbxAutoCharSize.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxAutoCharSize.Location = new System.Drawing.Point(222, 238);
            this.cbxAutoCharSize.Name = "cbxAutoCharSize";
            this.cbxAutoCharSize.Size = new System.Drawing.Size(36, 20);
            this.cbxAutoCharSize.TabIndex = 18;
            this.cbxAutoCharSize.Text = "cbxAutoCharSize";
            this.cbxAutoCharSize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbxAutoCharSize.CheckedChanged += new System.EventHandler(this.cbxAutoCharSize_CheckedChanged);
            // 
            // gbxLevels
            // 
            this.gbxLevels.Controls.Add(this.tbxMax);
            this.gbxLevels.Controls.Add(this.tbxMed);
            this.gbxLevels.Controls.Add(this.lblMax);
            this.gbxLevels.Controls.Add(this.lblMed);
            this.gbxLevels.Controls.Add(this.tbxMin);
            this.gbxLevels.Controls.Add(this.lblMin);
            this.gbxLevels.Location = new System.Drawing.Point(8, 38);
            this.gbxLevels.Name = "gbxLevels";
            this.gbxLevels.Size = new System.Drawing.Size(250, 48);
            this.gbxLevels.TabIndex = 4;
            this.gbxLevels.TabStop = false;
            this.gbxLevels.Text = "gbxLevels";
            // 
            // tbxMax
            // 
            this.tbxMax.Location = new System.Drawing.Point(203, 16);
            this.tbxMax.MaxLength = 3;
            this.tbxMax.Name = "tbxMax";
            this.tbxMax.Size = new System.Drawing.Size(32, 20);
            this.tbxMax.TabIndex = 6;
            this.tbxMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxMax.TextChanged += new System.EventHandler(this.tbxMax_TextChanged);
            // 
            // tbxMed
            // 
            this.tbxMed.Location = new System.Drawing.Point(122, 16);
            this.tbxMed.MaxLength = 4;
            this.tbxMed.Name = "tbxMed";
            this.tbxMed.Size = new System.Drawing.Size(32, 20);
            this.tbxMed.TabIndex = 5;
            this.tbxMed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxMed.TextChanged += new System.EventHandler(this.tbxMed_TextChanged);
            // 
            // lblMax
            // 
            this.lblMax.Location = new System.Drawing.Point(172, 19);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(32, 16);
            this.lblMax.TabIndex = 4;
            this.lblMax.Text = "lblMax";
            // 
            // lblMed
            // 
            this.lblMed.Location = new System.Drawing.Point(90, 19);
            this.lblMed.Name = "lblMed";
            this.lblMed.Size = new System.Drawing.Size(32, 16);
            this.lblMed.TabIndex = 2;
            this.lblMed.Text = "lblMed";
            // 
            // tbxMin
            // 
            this.tbxMin.Location = new System.Drawing.Point(40, 16);
            this.tbxMin.MaxLength = 3;
            this.tbxMin.Name = "tbxMin";
            this.tbxMin.Size = new System.Drawing.Size(32, 20);
            this.tbxMin.TabIndex = 1;
            this.tbxMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbxMin.TextChanged += new System.EventHandler(this.tbxMin_TextChanged);
            // 
            // lblMin
            // 
            this.lblMin.Location = new System.Drawing.Point(12, 19);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(24, 16);
            this.lblMin.TabIndex = 0;
            this.lblMin.Text = "lblMin";
            // 
            // FormTextSettings
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(264, 336);
            this.ControlBox = false;
            this.Controls.Add(this.gbxLevels);
            this.Controls.Add(this.tbxCharacterWidth);
            this.Controls.Add(this.tbxCharacterHeight);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.cmbSuffix);
            this.Controls.Add(this.cbxAutoSuffix);
            this.Controls.Add(this.tbxSuffix);
            this.Controls.Add(this.tbxPrefix);
            this.Controls.Add(this.lblPrefix);
            this.Controls.Add(this.lblSuffix);
            this.Controls.Add(this.cbxAuto);
            this.Controls.Add(this.tbxFont);
            this.Controls.Add(this.tbxContrast);
            this.Controls.Add(this.tbxBrightness);
            this.Controls.Add(this.cmbRamp);
            this.Controls.Add(this.lblRamp);
            this.Controls.Add(this.btnFont);
            this.Controls.Add(this.cbxBlackTextOnWhite);
            this.Controls.Add(this.gbxSharpening);
            this.Controls.Add(this.cbxStretch);
            this.Controls.Add(this.lblContrast);
            this.Controls.Add(this.lblBrightness);
            this.Controls.Add(this.cbxFlipVertical);
            this.Controls.Add(this.cbxFlipHorizontal);
            this.Controls.Add(this.btnDefault);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.cbxAutoCharSize);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FormTextSettings";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormTextSettings";
            this.gbxSharpening.ResumeLayout(false);
            this.cmenuStripAuto.ResumeLayout(false);
            this.gbxLevels.ResumeLayout(false);
            this.gbxLevels.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>Update the controls for the current language</summary>
		private void UpdateUI() {
			this.Text = Resource.GetString("Text Settings");
			lblBrightness.Text = Resource.GetString("Brightness") + ":";
			lblContrast.Text = Resource.GetString("Contrast") + ":";
			gbxLevels.Text = Resource.GetString("Levels");
			lblMin.Text = Resource.GetString("Min");
			lblMed.Text = Resource.GetString("Med");
			lblMax.Text = Resource.GetString("Max");
			lblRamp.Text = Resource.GetString("Ramp") + ":";
			cbxAuto.Text = Resource.GetString("Auto");
			gbxSharpening.Text = Resource.GetString("Sharpening Method");
			rbNone.Text = Resource.GetString("None");
			rbSharpen.Text = Resource.GetString("Sharpen");
			rbUnsharp.Text = Resource.GetString("Unsharp Mask");
			cbxStretch.Text = Resource.GetString("Stretch");
			cbxBlackTextOnWhite.Text = Resource.GetString("Black Text on White");
			cbxFlipHorizontal.Text = Resource.GetString("Flip Horizontally");
			cbxFlipVertical.Text = Resource.GetString("Flip Vertically");
			btnFont.Text = Resource.GetString("Font") + "...";
			lblPrefix.Text = Resource.GetString("Prefix") + ":";
			lblSuffix.Text = Resource.GetString("Suffix") + ":";

			cmbSuffix.Items.Add(Resource.GetString("Random"));
			cmbSuffix.Items.Add(Resource.GetString("Date/Time"));

			btnOk.Text = Resource.GetString("&Ok");
			btnDefault.Text = Resource.GetString("&Default");
			btnCancel.Text = Resource.GetString("&Cancel");
			cmenuAutoCopy.Text = Resource.GetString("Copy Ramp to Clipboard");
			cmenuAutoValidChars.Text = Resource.GetString("Valid Characters") + "...";
			cbxAutoCharSize.Text = Resource.GetString("Auto");
		}

		/// <summary>Update the controls from _Settings</summary>
		private void UpdateControls() {
			tbxMin.Text = _Settings.MinimumLevel.ToString(Variables.Culture);
			tbxMed.Text = _Settings.MedianLevel.ToString(Variables.Culture);
			tbxMax.Text = _Settings.MaximumLevel.ToString(Variables.Culture);
			tbxBrightness.Text = _Settings.Brightness.ToString(Variables.Culture);
			tbxContrast.Text = _Settings.Contrast.ToString(Variables.Culture);
			rbSharpen.Checked = _Settings.Sharpen;
			rbUnsharp.Checked = _Settings.Unsharp;
			rbNone.Checked = (!_Settings.Unsharp && !_Settings.Sharpen);
			cbxStretch.Checked = _Settings.Stretch;
			cbxBlackTextOnWhite.Checked = _Settings.IsBlackTextOnWhite;
			cbxFlipHorizontal.Checked = _Settings.FlipHorizontally;
			cbxFlipVertical.Checked = _Settings.FlipVertically;
			cbxAuto.Checked = _Settings.IsGeneratedRamp;

			if (!_Settings.IsGeneratedRamp) {
				cmbRamp.Text = _Settings.Ramp;
			}

			dialogFont.Font = _Settings.Font;
			_ValidCharacters = _Settings.ValidCharacters;

			cbxAutoCharSize.Checked = _Settings.CalculateCharacterSize;

			if (!_Settings.CalculateCharacterSize) {
				tbxCharacterWidth.Text = _Settings.CharacterSize.Width.ToString(Variables.Culture);
				tbxCharacterHeight.Text = _Settings.CharacterSize.Height.ToString(Variables.Culture);
			}

			UpdateFont();
		}

		private void btnDefault_Click(object sender, System.EventArgs e) {
			Default();
		}

		/// <summary>Set all values to the default settings</summary>
		public void Default() {
			tbxMin.Text = Variables.DefaultMinLevel.ToString(Variables.Culture);
			tbxMed.Text = Variables.DefaultMedianLevel.ToString(Variables.Culture);
			tbxMax.Text = Variables.DefaultMaxLevel.ToString(Variables.Culture);
			tbxBrightness.Text = Variables.DefaultTextBrightness.ToString(Variables.Culture);
			tbxContrast.Text = Variables.DefaultTextContrast.ToString(Variables.Culture);
			rbUnsharp.Checked = Variables.UnsharpMask;
			cbxStretch.Checked = Variables.Stretch;
			cbxBlackTextOnWhite.Checked = Variables.BlackTextOnWhite;
			cbxFlipHorizontal.Checked = Variables.FlipHorizontally;
			cbxFlipVertical.Checked = Variables.FlipVertically;
			cmbRamp.SelectedIndex = Variables.CurrentSelectedRamp;
			if (Variables.CurrentSelectedRamp == -1) {
				cmbRamp.Text = Variables.CurrentRamp;
			}
			dialogFont.Font = Variables.DefaultFont;
			cbxAuto.Checked = Variables.UseGeneratedRamp;
			UpdateFont();
			tbxPrefix.Text = Variables.Prefix;
			tbxSuffix.Text = String.Empty;
			cbxAutoSuffix.Checked = false;
			cmbSuffix.SelectedIndex = 0;
			cbxAutoCharSize.Checked = true;
		}

		private void btnFont_Click(object sender, System.EventArgs e) {
			if (dialogFont.ShowDialog() == DialogResult.OK) {
				UpdateFont();
			}
		}

		/// <summary>Recreate the text in tbxFont and the ramp</summary>
		private void UpdateFont() {
			tbxFont.Text = dialogFont.Font.Name + String.Format(Variables.Culture, " {0}pt", dialogFont.Font.Size) +
				(dialogFont.Font.Bold ? ", bold" : "") + (dialogFont.Font.Italic ? ", italic" : "") +
				(dialogFont.Font.Underline ? ", underline" : "") +
				(dialogFont.Font.Strikeout ? ", strikeout" : "") + ".";

			_IsFixedWidth = FontFunctions.IsFixedWidth(dialogFont.Font);

			if (_IsFixedWidth) {
				UpdateRamp();
			}

			UpdateCharacterSize();
		}

		private void btnOk_Click(object sender, System.EventArgs e) {
			_Settings.MinimumLevel = _Minimum;
			_Settings.MedianLevel = _Median;
			_Settings.MaximumLevel = _Maximum;
			_Settings.Brightness = _Brightness;
			_Settings.Contrast = _Contrast;
			_Settings.Sharpen = rbSharpen.Checked;
			_Settings.Unsharp = rbUnsharp.Checked;
			_Settings.Stretch = cbxStretch.Checked;
			_Settings.IsBlackTextOnWhite = cbxBlackTextOnWhite.Checked;
			_Settings.FlipHorizontally = cbxFlipHorizontal.Checked;
			_Settings.FlipVertically = cbxFlipVertical.Checked;
			_Settings.Font = dialogFont.Font;
			_Settings.ValidCharacters = _ValidCharacters;

			if (_Settings.IsFixedWidth) {
				_Settings.IsGeneratedRamp = cbxAuto.Checked;

				if (_Ramp != null) {
					_Settings.Ramp = (cbxAuto.Checked) ? _Ramp : cmbRamp.Text;
				}

				_Settings.CalculateCharacterSize = cbxAutoCharSize.Checked;
			}

			if (_Settings.CharacterSize != _CharacterSize) {
				_Settings.CharacterSize = _CharacterSize;
			}
		}

		private void tbxBrightness_TextChanged(object sender, System.EventArgs e) {
			try {
				_Brightness = Convert.ToInt32(tbxBrightness.Text, Variables.Culture);
				_ValidBrightness = !(_Brightness > 255 || _Brightness < -255);
                tbxBrightness.BackColor = _ValidBrightness ? SystemColors.Window : Color.LightCoral;
			}
			catch (FormatException) {
				_Brightness = 0;
				_ValidBrightness = false;
                tbxBrightness.BackColor = Color.LightCoral;
			}

			UpdateOkButton();
		}

		private void tbxContrast_TextChanged(object sender, System.EventArgs e) {
			try {
				_Contrast = Convert.ToInt32(tbxContrast.Text, Variables.Culture);
				_ValidContrast = !(_Contrast > 255 || _Contrast < -255);
                tbxContrast.BackColor = _ValidContrast ? SystemColors.Window : Color.LightCoral;
			}
			catch (FormatException) {
				_Contrast = 0;
				_ValidContrast = false;
                tbxContrast.BackColor = Color.LightCoral;
			}

			UpdateOkButton();
		}

		private void UpdateOkButton() {
			btnOk.Enabled = _ValidBrightness && _ValidContrast && (cmbRamp.Text.Length > 1)
                && _ValidCharWidth && _ValidCharHeight
				&& _ValidMinimum && _ValidMedian && _ValidMaximum && (_Maximum > _Minimum);

			if (_Settings != null && !_Settings.CalculateCharacterSize) {
				btnOk.Enabled = btnOk.Enabled && _CharacterSize.Width > 0 && _CharacterSize.Height > 0;
			}
		}

		private void cbxAuto_CheckedChanged(object sender, System.EventArgs e) {
			cmbRamp.Enabled = !cbxAuto.Checked;

			cbxAuto.Refresh();

			UpdateRamp();
		}

		/// <summary>Recreate _Ramp</summary>
		private void UpdateRamp() {
			_Ramp = (cbxAuto.Checked) ?
				AsciiRampCreator.CreateRamp(dialogFont.Font, _ValidCharacters) : "";
		}

		private void cmbRamp_TextChanged(object sender, System.EventArgs e) {
			UpdateOkButton();
		}

		private void cmenuAutoCopy_Click(object sender, System.EventArgs e) {
			Clipboard.SetDataObject(((cbxAuto.Checked) ? _Ramp : cmbRamp.Text), true);
		}

		private void cmenuAutoValidChars_Click(object sender, System.EventArgs e) {
			ValidRampCharsDialog dlgValidChars = new ValidRampCharsDialog();

			dlgValidChars.Characters = _ValidCharacters;

			if (dlgValidChars.ShowDialog() == DialogResult.OK) {
				_ValidCharacters = dlgValidChars.Characters;

				UpdateRamp();
			}
		}

		private void cbxAutoSuffix_CheckedChanged(object sender, System.EventArgs e) {
			tbxSuffix.Enabled = !(cmbSuffix.Enabled = cbxAutoSuffix.Checked);
		}

		private void cbxAutoCharSize_CheckedChanged(object sender, System.EventArgs e) {
			tbxCharacterWidth.ReadOnly = tbxCharacterHeight.ReadOnly = cbxAutoCharSize.Checked;

			UpdateCharacterSize();

			UpdateOkButton();

            tbxCharacterWidth.BackColor = tbxCharacterHeight.BackColor =
                (cbxAutoCharSize.Checked) ? SystemColors.Control : SystemColors.Window;
		}

		/// <summary>Update the character size if necessary</summary>
		private void UpdateCharacterSize() {
			if (!_IsFixedWidth || cbxAutoCharSize.Checked) {
				_CharacterSize = FontFunctions.MeasureText("W", dialogFont.Font);

				if (!_IsFixedWidth) {
					_CharacterSize.Width = ValuesToVariableWidthTextConverter.CharacterWidth;
				}

				tbxCharacterWidth.Text = _CharacterSize.Width.ToString(Variables.Culture);
                _ValidCharWidth = _CharacterSize.Width > 0;
				tbxCharacterHeight.Text = _CharacterSize.Height.ToString(Variables.Culture);
                _ValidCharHeight = _CharacterSize.Height > 0;
			}
		}

		private void tbxCharacterWidth_TextChanged(object sender, System.EventArgs e) {
			if (!cbxAutoCharSize.Checked) {
				try {
					_CharacterSize.Width = Convert.ToInt32(tbxCharacterWidth.Text);
                    _ValidCharWidth = _CharacterSize.Width > 0;
                    tbxCharacterWidth.BackColor = _ValidCharWidth ? SystemColors.Window : Color.LightCoral;
				}
				catch (FormatException) {
					_CharacterSize.Width = -1;
                    tbxCharacterWidth.BackColor = Color.LightCoral;
                    _ValidCharWidth = false;
				}

				UpdateOkButton();
			}
		}

		private void tbxCharacterHeight_TextChanged(object sender, System.EventArgs e) {
			if (!cbxAutoCharSize.Checked) {
				try {
					_CharacterSize.Height = Convert.ToInt32(tbxCharacterHeight.Text);
                    _ValidCharHeight = _CharacterSize.Height > 0;
                    tbxCharacterHeight.BackColor = _ValidCharHeight ? SystemColors.Window : Color.LightCoral;
				}
				catch (FormatException) {
					_CharacterSize.Height = -1;
                    tbxCharacterHeight.BackColor = Color.LightCoral;
                    _ValidCharHeight = false;
				}

				UpdateOkButton();
			}
		}

		private void tbxMin_TextChanged(object sender, System.EventArgs e) {
			try {
				_Minimum = Convert.ToInt32(tbxMin.Text);
				_ValidMinimum = _Minimum > -1 && _Minimum < 256;
                tbxMin.BackColor = _ValidMinimum ? SystemColors.Window : Color.LightCoral;
			}
			catch (FormatException) {
				_Minimum = -1;
				_ValidMinimum = false;
                tbxMin.BackColor = Color.LightCoral;
			}

			UpdateOkButton();
		}

		private void tbxMed_TextChanged(object sender, System.EventArgs e) {
			try {
                string separator = System.Globalization.NumberFormatInfo.CurrentInfo.NumberDecimalSeparator;
                _Median = (float)Convert.ToDecimal(tbxMed.Text.Replace(".", separator));
				_ValidMedian = _Median >= 0 && _Median <= 1;
                tbxMed.BackColor = _ValidMedian ? SystemColors.Window : Color.LightCoral;
			}
			catch (FormatException) {
				_Median = -1;
				_ValidMedian = false;
                tbxMed.BackColor = Color.LightCoral;
			}

			UpdateOkButton();
		}

		private void tbxMax_TextChanged(object sender, System.EventArgs e) {
			try {
				_Maximum = Convert.ToInt32(tbxMax.Text);
				_ValidMaximum = _Maximum > -1 && _Maximum < 256;
                tbxMax.BackColor = _ValidMaximum ? SystemColors.Window : Color.LightCoral;
			}
			catch (FormatException) {
				_Maximum = -1;
				_ValidMaximum = false;
                tbxMax.BackColor = Color.LightCoral;
			}

			UpdateOkButton();
		}

		#region Properties and Variables

		private TextProcessingSettings _Settings;
		/// <summary>Get and set the settings</summary>
		public TextProcessingSettings Settings {
			get {
				return _Settings;
			}

			set {
				_Settings = value;
				UpdateControls();
			}
		}

		/// <summary>Used to store the generated ramp (String.Empty if not auto generated</summary>
		private string _Ramp;

		/// <summary>Valid characters used to generate the ramp</summary>
		private string _ValidCharacters;

		private int _Brightness = 0;
		private bool _ValidBrightness = true;
		private int _Contrast = 0;
		private bool _ValidContrast = true;

		private int _Minimum = 0;
		private bool _ValidMinimum = true;
		private float _Median = 0.5f;
		private bool _ValidMedian = true;
		private int _Maximum = 255;
		private bool _ValidMaximum = true;

		private bool _IsFixedWidth = true;

        private bool _ValidCharWidth = true;
        private bool _ValidCharHeight = true;

		/// <summary>Get and set the prefix</summary>
		public string Prefix {
			get {
				return tbxPrefix.Text;
			}

			set {
				tbxPrefix.Text = value;
			}
		}

		/// <summary>Get and set the suffix</summary>
		public string Suffix {
			get {
				return tbxSuffix.Text; 
			}

			set {
				tbxSuffix.Text = value;
			}
		}

		/// <summary>Possible types of suffixes</summary>
		public enum SuffixTypes {
			/// <summary>Use the string stored in Suffix</summary>
			UserDefined = -1,
			/// <summary>Use a random string</summary>
			Random = 0,
			/// <summary>Use a date/time string</summary>
			DateTime = 1
		};

		/// <summary>Get and set the suffix type</summary>
		public SuffixTypes SuffixType {
			get {
				return cbxAutoSuffix.Checked ? (SuffixTypes)cmbSuffix.SelectedIndex : SuffixTypes.UserDefined;
			}

			set {
				if (value == SuffixTypes.UserDefined) {
					cbxAutoSuffix.Checked = false;
				}
				else {
					cmbSuffix.SelectedIndex = (int)value;
					cbxAutoSuffix.Checked = true;
				}
			}
		}

		/// <summary>Size of one character in the current font</summary>
		private Size _CharacterSize;

		#endregion
	}
}
//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormSaveAs.cs,v 1.6 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Windows.Forms;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Form to show the different save as types
	/// </summary>
	public partial class FormSaveAs : Form
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public FormSaveAs() {
			InitializeComponent();
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		public void UpdateUI() {
			this.Text = Resource.GetString("Save As");

			rbBlackWhite.Text = Resource.GetString("Black and White");
			rbColour.Text = Resource.GetString("Colour");

			rbText.Text = Resource.GetString("Text");
			rbImage.Text = Resource.GetString("Image");

			btnOk.Text = Resource.GetString("&Ok");
			btnCancel.Text = Resource.GetString("&Cancel");
		}

		/// <summary>
		/// Get and set if the output is in colour rather then black and white
		/// </summary>
		public bool IsColour {
			get { return rbColour.Checked; }

			set {
				rbColour.Checked = value;
				rbBlackWhite.Checked = !value;
			}
		}

		/// <summary>
		/// Get and set if the output is in text rather then as an image
		/// </summary>
		public bool IsText {
			get { return rbText.Checked; }

			set {
				rbText.Checked = value;
				rbImage.Checked = !value;
			}
		}

		/// <summary>
		/// Is the output going to be fixed width?
		/// </summary>
		public bool IsFixedWidth {
			get {
				return rbColour.Enabled;
			}

			set {
				rbColour.Enabled = value;

				if (!value) {
					rbBlackWhite.Checked = true;
				}
			}
		}
	}
}
//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormBatchConvert.cs,v 1.57 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Threading;
using JMSoftware.AsciiConversion;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	partial class FormBatchConvert : System.Windows.Forms.Form {
		/// <summary>
		/// Constructor
		/// </summary>
		public FormBatchConvert() {
			InitializeComponent();

			_Settings = new TextProcessingSettings();

			_Settings.ValidCharacters = _Settings.ValidCharacters;

			cmbImageType.SelectedIndex = 1;

			tbxWidth.MaxLength = Variables.MaximumWidth.ToString(Variables.Culture).Length;

			tbxHeight.MaxLength = Variables.MaximumHeight.ToString(Variables.Culture).Length;


			if (_Settings.Width == -1 && _Settings.Height == -1) {
				if (Variables.DefaultWidth != -1) {
					tbxHeight.Text = String.Empty;
					tbxWidth.Text = Variables.DefaultWidth.ToString(Variables.Culture);
				}
				else if (Variables.DefaultHeight != -1) {
					tbxHeight.Text = Variables.DefaultHeight.ToString(Variables.Culture);
					tbxWidth.Text = String.Empty;
				}
				else {
					tbxHeight.Text = String.Empty;
					tbxWidth.Text = "150";
				}

				cbxLocked.Checked = true;
			}
			else {
				if (_Settings.Width > 0 && _Settings.Height > 0) {
					cbxLocked.Checked = false;
					tbxHeight.Text = _Settings.Height.ToString(Variables.Culture);
					tbxWidth.Text = _Settings.Width.ToString(Variables.Culture);
				}
				else {
					cbxLocked.Checked = true;

					if (_Settings.Height > 0) {
						tbxHeight.Text = _Settings.Height.ToString(Variables.Culture);
					}

					if (_Settings.Width > 0) {
						tbxWidth.Text = _Settings.Width.ToString(Variables.Culture);
					}
				}
			}

			UpdateFont();
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="settings">Settings to use for the images</param>
		public FormBatchConvert(TextProcessingSettings settings) {
			InitializeComponent();

			_Settings = settings;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) {
			if( disposing ) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		private void FormBatchConvert_Load(object sender, System.EventArgs e) {
			tbxOutputDirectory.Text = Variables.InitialOutputDirectory;
			dialogAddDirectory.SelectedPath = dialogAddFiles.InitialDirectory = Variables.InitialInputDirectory;
		}

		private void FormBatchConvert_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
			if (_Thread != null && _Thread.IsAlive) {
				_Thread.Abort();
			}
		}

		/// <summary>
		/// Update settings for the font
		/// </summary>
		private void UpdateFont() {
			rbColour.Enabled = _Settings.IsFixedWidth;

			if (!_Settings.IsFixedWidth) {
				rbBlackWhite.Checked = true;
				rbColour.Enabled = false;
			}
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		public void UpdateUI() {
			this.Text = Resource.GetString("Batch Conversion");
			btnAddFile.Text = cmenuFileAdd.Text = Resource.GetString("&Add File") + "...";
			btnRemove.Text = cmenuFilesRemove.Text = Resource.GetString("&Remove");
			cmenuFilesRemoveAll.Text = Resource.GetString("Remove All");
			cmenuFilesRemoveAfter.Text = Resource.GetString("Remove File After Conversion");
			btnAddDirectory.Text = cmenuFilesAddDirectory.Text = Resource.GetString("Add &Directory") + "...";
			lblOutputSize.Text = Resource.GetString("Output Size") + ":";
			btnSettings.Text = Resource.GetString("&Settings") + "...";
			lblFiles.Text = Resource.GetString("Files to be converted") + ":";
			lblOutput.Text = Resource.GetString("Output Directory") + ":";
			btnConvert.Text = Resource.GetString("&Convert");
			btnCancel.Text = Resource.GetString("&Cancel");
			btnClose.Text = Resource.GetString("C&lose");
			lblOutputAs.Text = Resource.GetString("Output as") + ":";
			rbOutputAsText.Text = Resource.GetString("Text");
			rbBlackWhite.Text = Resource.GetString("Black and White");
			rbColour.Text = Resource.GetString("Colour");

			cmenuFilesSelectAll.Text = Resource.GetString("Select All");
			cmenuFilesSelectNone.Text = Resource.GetString("Select None");
			cmenuFilesInvertSelection.Text = Resource.GetString("Invert Selection");
			cmenuFilesShowPath.Text = Resource.GetString("Show Full Path");
			cmenuFilesShowExtension.Text = Resource.GetString("Show Extension");

			cmenuLogClear.Text = Resource.GetString("Clear");
			cmenuLogSaveAs.Text = Resource.GetString("Save Log As") + "...";

			dialogAddFiles.Filter =
				Resource.GetString("Image Files") + "|*.bmp;*.rle;*.dib;*.exif;*.gif;*.jpg;*.jpeg;*.jpe;*.png;*.tif;*.tiff;*.wmf;*.emf|" +
				Resource.GetString("Bitmap Images") + " (*.bmp, *.rle, *.dib)|*.bmp;*.rle;*.dib|" +
				Resource.GetString("Exchangeable Image Files") + " (*.exif)|*.exif|" +
				Resource.GetString("GIF Images") + " (*.gif)|*.gif|" +
				Resource.GetString("JPEG Images") + " (*.jpg, *.jpeg, *.jpe)|*.jpg;*.jpeg;*.jpg|" +
				Resource.GetString("Portable Network Graphics Images") + " (*.png)|*.png|" +
				Resource.GetString("TIF Images") + " (*.tif, *.tiff)|*.tif;*.tiff|" +
				Resource.GetString("Windows Metafile Images") + " (*.emf, *.wmf)|*.emf;*.wmf|" +
				Resource.GetString("Image Files") + " (*.*)|*.*";

			dialogOpenDirectory.Description = Resource.GetString("Select the directory in which to save the converted images");
			dialogAddDirectory.Description = Resource.GetString("Select a directory from which to import image files");
		}

		private void btnAddFile_Click(object sender, System.EventArgs e) {
			AddFiles();
		}

		/// <summary>Show the add files dialog and process the results</summary>
		private void AddFiles() {
			if (dialogAddFiles.ShowDialog() == DialogResult.OK) {
				foreach (string s in dialogAddFiles.FileNames) {
					if (!lbxFiles.Items.Contains(s)) {
						lbxFiles.Items.Add(s);
					}
				}

				UpdateConvertButton();
			}
		}

		private void btnAddDirectory_Click(object sender, System.EventArgs e) {
			AddDirectory();
		}

		private void AddDirectory() {
			if (dialogAddDirectory.ShowDialog() == DialogResult.OK) {
				lbxFiles.SuspendLayout();

				string[] Files = Directory.GetFiles(dialogAddDirectory.SelectedPath);

				foreach (string str in Files) {
					string s = Path.GetExtension(str).ToLower(Variables.Culture);

					if (s == ".bmp" || s == ".rle" || s == ".dib" || s == ".exif" || s == ".gif" ||
							s == ".jpg" || s == ".jpeg" || s == ".jpe" || s == ".png" ||
							s == ".tif" || s == ".tiff" || s == ".wmf" || s == ".emf") {
						if (!lbxFiles.Items.Contains(str)) {
							lbxFiles.Items.Add(str);
						}
					}
				}

				lbxFiles.ResumeLayout();

				UpdateConvertButton();
			}
		}

		private void btnClose_Click(object sender, System.EventArgs e) {
			Close();
		}

		private void btnConvert_Click(object sender, System.EventArgs e) {
			if (tbxOutputDirectory.Text.Length == 0) {
				MessageBox.Show(Resource.GetString("Please enter an output directory"),
					Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);

				tbxOutputDirectory.Focus();
				return;
			}

			if (!System.IO.Directory.Exists(tbxOutputDirectory.Text)) {
				MessageBox.Show(Resource.GetString("Invalid Output Directory"),
					Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);

				tbxOutputDirectory.Focus();
				return;
			}

			ProcessBatch();
		}

		private void btnSettings_Click(object sender, System.EventArgs e) {
			FormTextSettings settingsDialog = new FormTextSettings(_Settings);

			settingsDialog.Prefix = _Prefix;
			settingsDialog.Suffix = _Suffix;
			settingsDialog.SuffixType = _SuffixType;

			if (settingsDialog.ShowDialog() == DialogResult.OK) {
				_Settings = settingsDialog.Settings;
				_Prefix = settingsDialog.Prefix;
				_Suffix = settingsDialog.Suffix;
				_SuffixType = settingsDialog.SuffixType;

				UpdateFont();
			}
		}

		private void ProcessBatch() {
			if (tbxOutputDirectory.Text == null || tbxOutputDirectory.Text.Length == 0 ||
					!System.IO.Directory.Exists(tbxOutputDirectory.Text) || lbxFiles.Items == null) {
				return;
			}

			if ((cbxLocked.Checked && (_OutputSize.Width < 1 && _OutputSize.Height < 1)) ||
					(!cbxLocked.Checked && (_OutputSize.Width < 1 || _OutputSize.Height < 1))) {
				MessageBox.Show(Resource.GetString("Invalid Output Size"),
					Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);

				return;
			}

			_Thread = new Thread(new ThreadStart(ConversionThread));
			_Thread.Name = String.Format(Variables.Culture, "BatchConversionThread{0:HHmmss}", DateTime.Now);
			_Thread.Start();
		}

		private void ConversionThread() {
            CheckForIllegalCrossThreadCalls = false;
			pnlMain.Enabled = btnClose.Enabled = btnConvert.Enabled = false;
			btnCancel.Enabled = true;

			progressConversion.Value = 0;
			progressConversion.Maximum = lbxFiles.Items.Count;

			int Errors = 0;
			int NumberConverted = 0;
			int Count = 0;
			bool BlackOnWhite = rbBlackWhite.Checked;

			if (lbxLog.Items.Count > 0) {
				AddLogString("");
			}
			else {
				AddLogString(Variables.ProgramName + " " + Variables.Version.GetVersion() + " " + Resource.GetString("Batch Conversion") + " " + Resource.GetString("Log"));
			}

			AddLogString("----------------------------------------------------------");

			AddLogString(String.Format(Variables.Culture, Resource.GetString("Batch conversion started, {0} file(s) to process"), lbxFiles.Items.Count));

			AddLogString(Resource.GetString("Output Directory") + ": " + tbxOutputDirectory.Text);
			AddLogString(Resource.GetString("Saving output as") + " " + (rbOutputAsText.Checked ? "txt" : cmbImageType.SelectedItem));

			if (rbOutputAsImage.Checked) {
				if (_ImageScalePercent < 100) {
					AddLogString(" (" + String.Format(Variables.Culture, Resource.GetString("shrunk to {0}%") + ")", _ImageScalePercent.ToString(Variables.Culture)), true);
				}
			}

			AddLogString(String.Format(Variables.Culture, Resource.GetString("Target Font: {0} {1}pt{2}{3}{4}{5}") + ".",
				_Settings.Font.Name, _Settings.Font.Size.ToString(Variables.Culture),
				(_Settings.Font.Bold ? ", " + Resource.GetString("bold") : ""), (_Settings.Font.Italic ? ", " + Resource.GetString("italic") : ""),
				(_Settings.Font.Underline ? ", " + Resource.GetString("underline") : ""), (_Settings.Font.Strikeout ? ", " + Resource.GetString("strikeout") : "")));

			AddLogString(String.Format(Variables.Culture, Resource.GetString("Target Character Size: {0}x{1} pixels{2}"),
				_Settings.CharacterSize.Width.ToString(Variables.Culture),
				_Settings.CharacterSize.Height.ToString(Variables.Culture),
				(_Settings.CalculateCharacterSize ? " (" + Resource.GetString("automatically calculated") + ")." : ".")));

			AddLogString(Resource.GetString("ASCII Ramp") + (_Settings.IsGeneratedRamp ? " (" + Resource.GetString("Generated") + ")" : "") + ": " + _Settings.Ramp);

			AddLogString(String.Format(Variables.Culture, Resource.GetString("Text Brightness: {0}, Text Contrast: {1}"), _Settings.Brightness, _Settings.Contrast));
			AddLogString(String.Format(Variables.Culture, Resource.GetString("Output Levels - Minimum: {0}, Median: {1}, Maximum: {2}"),
				_Settings.MinimumLevel, _Settings.MedianLevel, _Settings.MaximumLevel));

			AddLogString(Resource.GetString("Effects") + ": " +
				(_Settings.IsBlackTextOnWhite ? Resource.GetString("Black Text on White Background") : Resource.GetString("White Text on Black Background")) +
				(_Settings.Stretch ? ", " + Resource.GetString("Stretched") : "") +
				(_Settings.Sharpen ? ", " + Resource.GetString("Sharpened") : "") +
				(_Settings.Unsharp ? ", " + Resource.GetString("Unsharp Mask") : "") +
				(_Settings.FlipHorizontally ? ", " + Resource.GetString("Flipped Horizontally") : "") +
				(_Settings.FlipVertically ? ", " + Resource.GetString("Flipped Vertically") : "") + ".");

			if (!cbxLocked.Checked) {
				AddLogString(String.Format(Variables.Culture,
					Resource.GetString("Output Size: {0}x{1} characters"),
					_OutputSize.Width, _OutputSize.Height));
			}

			AddLogString("----------------------------------------------------------");

			Image image;
			string outputfilename;

			StringCollection files = new StringCollection();

			// copy the strings into the new collection so we can remove them from the listbox
			foreach (string s in lbxFiles.Items) {
				files.Add(s);
			}

			foreach (string s in files) {
				Count++;
				progressConversion.Value++;

				AddLogString(Count.ToString(Variables.Culture) + ". " + Path.GetFileName(s) + ": ");

				outputfilename = tbxOutputDirectory.Text;

				if (outputfilename[outputfilename.Length - 1] != Path.DirectorySeparatorChar) {
					outputfilename += Path.DirectorySeparatorChar;
				}

				outputfilename += _Prefix + Path.GetFileNameWithoutExtension(s);
				
				switch (_SuffixType) {
					case FormTextSettings.SuffixTypes.UserDefined:
					default:
						outputfilename += _Suffix;
						break;

					case FormTextSettings.SuffixTypes.Random:
						outputfilename += "-" + GetRandomString(6);
						break;

					case FormTextSettings.SuffixTypes.DateTime:
						outputfilename += String.Format(Variables.Culture, "-" + Resource.GetString("{0:yyyyMMddHHmmss}"), DateTime.Now);
						break;
				}

				if (BlackOnWhite) {
					outputfilename += rbOutputAsText.Checked ? ".txt" : "." + cmbImageType.SelectedItem;
				}
				else {
					outputfilename += rbOutputAsText.Checked ? ".html" : "." + cmbImageType.SelectedItem;
				}

				if (System.IO.File.Exists(outputfilename)) {
					// TODO: If outputfilename exists create one that doesn't
					AddLogString(Resource.GetString("Error") + ": " + outputfilename + " " + Resource.GetString("already exists") + ")");
					Errors++;
					continue;
				}

				AddLogString("Loading... ", true);

				try {
					image = Image.FromFile(s);
				}
				catch (System.IO.FileNotFoundException) {
					AddLogString(Resource.GetString("Error") + ": " + Resource.GetString("File Not Found") + ".", true);
					Errors++;
					continue;
				}
				catch (System.OutOfMemoryException) {
					AddLogString(Resource.GetString("Error") + ": " + Resource.GetString("Invalid or unsupported file") + ".", true);
					Errors++;
					continue;
				}

				AddLogString(Resource.GetString("Converting"), true);

				// if width not set XOR height not set...
				if (_OutputSize.Width == -1 ^ _OutputSize.Height == -1) {
					if (_OutputSize.Height == -1) {
						_Settings.Width = _OutputSize.Width;

						_Settings.Height = AscgenConverter.CalculateOtherDimension(_Settings.Width,
							image.Width, image.Height, _Settings.CharacterSize.Width, _Settings.CharacterSize.Height);
					}
					else { // (_outputSize.Width == -1)
						_Settings.Height = _OutputSize.Height;

						_Settings.Width = AscgenConverter.CalculateOtherDimension(_Settings.Height,
							image.Height, image.Width, _Settings.CharacterSize.Height, _Settings.CharacterSize.Width);
					}

					AddLogString(String.Format(Variables.Culture,
						" ({0}x{1})", _Settings.Width, _Settings.Height), true);
				}
				else {
					_Settings.Size = _OutputSize;
				}

				AddLogString("... ", true);

				string[] text = AscgenConverter.Convert(image, _Settings);

				if (text == null) {
					AddLogString(Resource.GetString("Error converting the image"));
					Errors++;
				}
				else {
					AddLogString(Resource.GetString("Saving") + "... ", true);

					bool Saved = false;

					if (BlackOnWhite) {
						if (rbOutputAsText.Checked) {
							StreamWriter writer = new StreamWriter(outputfilename);

							foreach (string line in text) {
								writer.WriteLine(line);
							}

							writer.Close();

							Saved = true;
						}
						else {
							System.Text.StringBuilder builder = new System.Text.StringBuilder();

							for (int i = 0; i < text.Length; i++) {
								builder.Append(text[i]);

								if (i < text.Length - 1) {
									builder.Append(Environment.NewLine);
								}
							}

							Saved = TextToImage.Save(builder.ToString(), outputfilename, _Settings.Font,
								_Settings.IsBlackTextOnWhite ? Color.Black : Color.White,
								_Settings.IsBlackTextOnWhite ? Color.White : Color.Black,
								(float)_ImageScalePercent, true);
						}
					}
					else {
						Color[,] colors;

						if (rbOutputAsText.Checked) {
							colors = ImageToColors.Convert(image, new Size(_Settings.Width, _Settings.Height), true);

							string output = OutputCreator.CreateHTML(text, colors,
								_Settings.IsBlackTextOnWhite ? Color.White : Color.Black, _Settings, s);

							StreamWriter writer = new StreamWriter(outputfilename);

							writer.Write(output);

							writer.Close();

							Saved = true;
						}
						else {
							colors = ImageToColors.Convert(image, new Size(_Settings.Width, _Settings.Height), false);

							Image outputimage = TextToColorImage.Convert(text, _Settings.Font,
									colors, _Settings.IsBlackTextOnWhite ? Color.White : Color.Black,
									(float)_ImageScalePercent);

							outputimage.Save(outputfilename, ImageFunctions.GetImageFormat(Path.GetExtension(outputfilename).ToLower()));

							Saved = true;
						}
					}

					image.Dispose();

					if (Saved) {
						AddLogString(" - " + Path.GetFileName(outputfilename) + " " + Resource.GetString("saved") + ".");
					}
					else {
						AddLogString(" * " + string.Format(Resource.GetString("Error saving to {0}"), Path.GetFileName(outputfilename)));
					}

					NumberConverted++;

					if (cmenuFilesRemoveAfter.Checked) {
						lbxFiles.Items.Remove(s);
					}
				}
			}

			AddLogString("----------------------------------------------------------");
			AddLogString(Resource.GetString("Batch finished") + ", " +
				String.Format(Variables.Culture, Resource.GetString("{0} file(s) converted, {1} error(s)"), NumberConverted, Errors));

			pnlMain.Enabled = btnClose.Enabled = btnConvert.Enabled = true;
			btnCancel.Enabled = false;

			if (cmenuFilesRemoveAfter.Checked) {
				UpdateConvertButton();
			}

            CheckForIllegalCrossThreadCalls = true;
		}

		private void btnCancel_Click(object sender, System.EventArgs e) {
			if (_Thread != null && _Thread.IsAlive) {
				_Thread.Abort();
				AddLogString("*** " + Resource.GetString("Batch conversion cancelled") + " ***");

				pnlMain.Enabled = btnClose.Enabled = btnConvert.Enabled = true;
				btnCancel.Enabled = false;
			}
		}

		private void btnOutputDirectory_Click(object sender, System.EventArgs e) {
			dialogOpenDirectory.SelectedPath = tbxOutputDirectory.Text;

			if (dialogOpenDirectory.ShowDialog() == DialogResult.OK) {
				tbxOutputDirectory.Text = dialogOpenDirectory.SelectedPath;
			}
		}

		/// <summary>
		/// Add a string to the listbox log
		/// </summary>
		/// <param name="s">String to add</param>
		private void AddLogString(string s) {
			AddLogString(s, false);
		}

		/// <summary>
		/// Add a string to the listbox log
		/// </summary>
		/// <param name="s">String to add</param>
		/// <param name="append">Append the string on to the end of last line</param>
		private void AddLogString(string s, bool append) {
			if (append) {
				lbxLog.Items[lbxLog.Items.Count - 1] = lbxLog.Items[lbxLog.Items.Count - 1].ToString() + s;
			}
			else {
				lbxLog.Items.Add(s);
			}

			lbxLog.TopIndex = lbxLog.Items.Count - 1;
		}

		private void btnRemove_Click(object sender, System.EventArgs e) {
			RemoveSelectedFiles();
		}

		/// <summary>Remove all selected files from the list</summary>
		private void RemoveSelectedFiles() {
			while (lbxFiles.SelectedItems.Count > 0) {
				if (lbxFiles.Items.Count == 1)	// workaround removing last item problem
					lbxFiles.Items.Clear();
				else
					lbxFiles.Items.Remove(lbxFiles.SelectedItem);
			}

			btnRemove.Enabled = false;

			UpdateConvertButton();
		}

		private void lbxFiles_SelectedIndexChanged(object sender, System.EventArgs e) {
			btnRemove.Enabled = (lbxFiles.SelectedItems.Count > 0);
			btnRemove.Refresh();
		}

		private void tbxWidth_TextChanged(object sender, System.EventArgs e) {
			if (!_SizeChanging) {
				_SizeChanging = true;

				_WidthChangedLast = true;

				try {
					_OutputSize.Width = Convert.ToInt32(tbxWidth.Text, Variables.Culture);
				}
				catch (FormatException) {
					_OutputSize.Width = -1;
				}

				if (cbxLocked.Checked) {
					_OutputSize.Height = -1;
					tbxHeight.Text = String.Empty;

					tbxWidth.BackColor = System.Drawing.SystemColors.Window;
					tbxHeight.BackColor = System.Drawing.SystemColors.Control;
				}
				else {
					tbxWidth.BackColor = System.Drawing.SystemColors.Window;
					tbxHeight.BackColor = System.Drawing.SystemColors.Window;
				}

				UpdateConvertButton();

				_SizeChanging = false;
			}
		}

		private void tbxHeight_TextChanged(object sender, System.EventArgs e) {
			if (!_SizeChanging) {
				_SizeChanging = true;

				_WidthChangedLast = false;

				try {
					_OutputSize.Height = Convert.ToInt32(tbxHeight.Text, Variables.Culture);
				}
				catch (FormatException) {
					_OutputSize.Height = -1;
				}

				if (cbxLocked.Checked) {
					_OutputSize.Width = -1;
					tbxWidth.Text = String.Empty;

					tbxWidth.BackColor = System.Drawing.SystemColors.Control;
					tbxHeight.BackColor = System.Drawing.SystemColors.Window;
				}
				else {
					tbxWidth.BackColor = System.Drawing.SystemColors.Window;
					tbxHeight.BackColor = System.Drawing.SystemColors.Window;
				}

				UpdateConvertButton();

				_SizeChanging = false;
			}		
		}

		private void cbxLocked_CheckedChanged(object sender, System.EventArgs e) {
			if (cbxLocked.Checked) {
				if (_WidthChangedLast) {
					tbxWidth.BackColor = System.Drawing.SystemColors.Window;
					tbxHeight.BackColor = System.Drawing.SystemColors.Control;

					_SizeChanging = true;
					tbxHeight.Text = String.Empty;
					_OutputSize.Height = -1;
					_SizeChanging = false;
				}
				else {
					tbxWidth.BackColor = System.Drawing.SystemColors.Control;
					tbxHeight.BackColor = System.Drawing.SystemColors.Window;

					_SizeChanging = true;
					tbxWidth.Text = String.Empty;
					_OutputSize.Width = -1;
					_SizeChanging = false;
				}
			}
			else {
				tbxWidth.BackColor = System.Drawing.SystemColors.Window;
				tbxHeight.BackColor = System.Drawing.SystemColors.Window;
			}

			UpdateConvertButton();
		}

		/// <summary>
		/// Check and update the Convert button Enabled property
		/// </summary>
		private void UpdateConvertButton() {
			bool Result = lbxFiles.Items.Count > 0 && tbxOutputDirectory.Text.Length > 0;

			if (cbxLocked.Checked) {
				Result = Result && ((_OutputSize.Width > 0 && _OutputSize.Height == -1) ||
					(_OutputSize.Width == -1 && _OutputSize.Height > 0));
			}
			else {
				Result = Result && (_OutputSize.Width > 0 && _OutputSize.Height > 0);
			}

			if (rbOutputAsImage.Checked) {
				Result = Result && (_ImageScalePercent > 0);
			}

			btnConvert.Enabled = Result;
		}

		private void tbxOutputDirectory_TextChanged(object sender, System.EventArgs e) {
			UpdateConvertButton();
		}

		private void lbxFiles_DragDrop(object sender, System.Windows.Forms.DragEventArgs e) {
			string[] filenames = (string[])e.Data.GetData(DataFormats.FileDrop);

			foreach (string s in filenames) {
				if (!lbxFiles.Items.Contains(s))
					lbxFiles.Items.Add(s);
			}

			UpdateConvertButton();
		}

		private void lbxFiles_DragOver(object sender, System.Windows.Forms.DragEventArgs e) {
			e.Effect = DragDropEffects.Copy;
		}

		private void cmenuFiles_Popup(object sender, System.EventArgs e) {
			cmenuFilesShowExtension.Checked = lbxFiles.DisplayExtension;
			cmenuFilesShowPath.Checked = lbxFiles.DisplayPath;

			cmenuFilesSelectNone.Enabled = cmenuFilesRemove.Enabled =
				lbxFiles.SelectedItems.Count > 0;

			cmenuFilesRemoveAll.Enabled = cmenuFilesInvertSelection.Enabled = lbxFiles.Items.Count > 0;

			cmenuFilesSelectAll.Enabled = lbxFiles.SelectedItems.Count < lbxFiles.Items.Count;
		}

		private void cmenuFilesAdd_Click(object sender, System.EventArgs e) {
			AddFiles();
		}

		private void cmenuFilesAddDirectory_Click(object sender, System.EventArgs e) {
			AddDirectory();
		}

		private void cmenuFilesRemove_Click(object sender, System.EventArgs e) {
			RemoveSelectedFiles();
		}

		private void cmenuFilesRemoveAll_Click(object sender, System.EventArgs e) {
			lbxFiles.Items.Clear();
			UpdateConvertButton();
		}

		private void cmenuFilesSelectAll_Click(object sender, System.EventArgs e) {
			for (int i = 0; i < lbxFiles.Items.Count; i++) {
				lbxFiles.SetSelected(i, true);
			}
		}

		private void cmenuFilesSelectNone_Click(object sender, System.EventArgs e) {
			lbxFiles.ClearSelected();
		}

		private void cmenuFilesInvertSelection_Click(object sender, System.EventArgs e) {
			for (int i = 0; i < lbxFiles.Items.Count; i++) {
				lbxFiles.SetSelected(i, !lbxFiles.GetSelected(i));
			}
		}

		private void cmenuFilesShowPath_Click(object sender, System.EventArgs e) {
			lbxFiles.DisplayPath = !lbxFiles.DisplayPath;
		}

		private void cmenuFilesShowExtension_Click(object sender, System.EventArgs e) {
			lbxFiles.DisplayExtension = !lbxFiles.DisplayExtension;
		}

		private void cmenuLog_Popup(object sender, System.EventArgs e) {
			cmenuLogClear.Enabled = cmenuLogSaveAs.Enabled = (lbxLog.Items.Count > 0 && !_Thread.IsAlive);
		}

		private void cmenuLogClear_Click(object sender, System.EventArgs e) {
			lbxLog.Items.Clear();
		}

		private void cmenuLogSaveAs_Click(object sender, System.EventArgs e) {
			dialogSaveLog.FileName = String.Format(Variables.Culture, "Log{0:yyyyMMddHHmmss}", System.DateTime.Now);

			if (dialogSaveLog.ShowDialog() == DialogResult.OK) {
				StreamWriter logwriter = new StreamWriter(dialogSaveLog.FileName);

				foreach (string s in lbxLog.Items) {
					logwriter.WriteLine(s);
				}
							
				logwriter.Close();
			}
		}

		private void cmenuFilesRemoveAfter_Click(object sender, System.EventArgs e) {
			cmenuFilesRemoveAfter.Checked = !cmenuFilesRemoveAfter.Checked;
		}

		private void rbOutputAsImage_CheckedChanged(object sender, System.EventArgs e) {
			cmbImageType.Enabled = tbxPercent.Enabled = rbOutputAsImage.Checked;

			UpdateConvertButton();
		}

		private void tbxPercent_TextChanged(object sender, System.EventArgs e) {
			try {
				_ImageScalePercent = Convert.ToInt32(tbxPercent.Text, Variables.Culture);

				if (_ImageScalePercent < 1 || _ImageScalePercent > 100) {
					_ImageScalePercent = -1;
				}
			}
			catch (FormatException) {
				_ImageScalePercent = -1;
			}

			UpdateConvertButton();
		}

		private string GetRandomString(int length) {
			string RandomString = String.Empty;
			string validchars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

			System.Random random = new Random();

			for (int i = 0; i < length; i++) {
				RandomString += validchars[random.Next(validchars.Length - 1)];
			}

			return RandomString;
		}

		#region Properties and Variables

		private TextProcessingSettings _Settings;

		/// <summary>Size of the output images (-1 to calculate the dimension)</summary>
		private Size _OutputSize = new Size(Variables.DefaultWidth, Variables.DefaultHeight);

		private bool _SizeChanging;

		private bool _WidthChangedLast = true;

		private Thread _Thread;

		private string _Prefix = Variables.Prefix;

		private string _Suffix = String.Empty;

		private int _ImageScalePercent = 75;

		private FormTextSettings.SuffixTypes _SuffixType = FormTextSettings.SuffixTypes.UserDefined;

		#endregion
	}
}
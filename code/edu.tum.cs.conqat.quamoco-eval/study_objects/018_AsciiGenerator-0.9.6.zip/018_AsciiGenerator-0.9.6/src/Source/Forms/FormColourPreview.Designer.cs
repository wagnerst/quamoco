﻿namespace JMSoftware.AsciiGeneratorDotNet
{
	partial class FormColourPreview
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.pnlImage = new System.Windows.Forms.Panel();
			this.jmPictureBox1 = new JMSoftware.CustomControl.JMPictureBox();
			this.pnlImage.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlImage
			// 
			this.pnlImage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.pnlImage.AutoScroll = true;
			this.pnlImage.Controls.Add(this.jmPictureBox1);
			this.pnlImage.Location = new System.Drawing.Point(12, 12);
			this.pnlImage.Name = "pnlImage";
			this.pnlImage.Size = new System.Drawing.Size(660, 542);
			this.pnlImage.TabIndex = 1;
			this.pnlImage.SizeChanged += new System.EventHandler(this.pnlImage_SizeChanged);
			// 
			// jmPictureBox1
			// 
			this.jmPictureBox1.BackColor = System.Drawing.SystemColors.Control;
			this.jmPictureBox1.DrawingImage = true;
			this.jmPictureBox1.Location = new System.Drawing.Point(0, 0);
			this.jmPictureBox1.MinimumSize = new System.Drawing.Size(50, 50);
			this.jmPictureBox1.Name = "jmPictureBox1";
			this.jmPictureBox1.Size = new System.Drawing.Size(313, 241);
			this.jmPictureBox1.SizeMode = JMSoftware.CustomControl.JMPictureBox.JMPictureBoxSizeMode.Stretch;
			this.jmPictureBox1.TabIndex = 0;
			// 
			// FormColourPreview
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.ClientSize = new System.Drawing.Size(684, 566);
			this.Controls.Add(this.pnlImage);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Name = "FormColourPreview";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FormColourPreview";
			this.pnlImage.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private JMSoftware.CustomControl.JMPictureBox jmPictureBox1;
		private System.Windows.Forms.Panel pnlImage;
	}
}
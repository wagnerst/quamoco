//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormConvertImage.cs,v 1.300 2008/02/19 00:36:26 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Xml;
using System.Net;
using System.Text;
using System.Threading;
using System.Drawing.Printing;
using JMSoftware.CustomControl;
using JMSoftware.Widgets;
using JMSoftware.AsciiConversion;
using JMSoftware.AsciiConversion.Filters;
using JMSoftware.Interfaces;

namespace JMSoftware.AsciiGeneratorDotNet {
	/// <summary>
	/// Main conversion form
	/// </summary>
	partial class FormConvertImage : System.Windows.Forms.Form {
        /// <summary>
        /// Constructor
        /// </summary>
        public FormConvertImage(string[] args) {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

			rtbxConvertedText.AllowDrop = true;
			rtbxConvertedText.DragDrop += new DragEventHandler(rtbxConvertedText_DragDrop);
			rtbxConvertedText.DragEnter += new DragEventHandler(rtbxConvertedText_DragEnter);

			_TextViewer = rtbxConvertedText;

            _Args = args;
        }

        private void formMain_Load(object sender, System.EventArgs e) {
			ReadXML(Variables.SettingsFile);

			splitContainer1.Orientation = (Screen.PrimaryScreen.Bounds.Width > Screen.PrimaryScreen.Bounds.Height) ?
				Orientation.Vertical : Orientation.Horizontal;

			if (splitContainer1.Orientation == Orientation.Horizontal) {
				splitContainer1.SplitterDistance = 300;
			}

			_BatchConverter = new FormBatchConvert();
			_FormSaveAs = new FormSaveAs();

			_TextSettings = new TextProcessingSettings();

			Text = Variables.ProgramName + " v" + Variables.Version.GetVersion();

			pbxMain.AllowDrop = true;

			tsbBlackOnWhite.Checked = !Variables.BlackTextOnWhite;
			_TextViewer.BackgroundColor = (_TextSettings.IsBlackTextOnWhite) ? Color.White : Color.Black;
			_TextViewer.TextColor = (_TextSettings.IsBlackTextOnWhite) ? Color.Black : Color.White;

			_TextSettings.Ramp = cmbRamp.Text;

            // remove and readd the toolstrips to get the desired layout (it adds from the bottom up)
            toolStripContainer1.TopToolStripPanel.Controls.Clear();
            toolStripContainer1.TopToolStripPanel.Join(mainMenu1);
			toolStripContainer1.TopToolStripPanel.Join(tstripAlterInputImage, 1);
            toolStripContainer1.TopToolStripPanel.Join(tstripButtons, 1);
            toolStripContainer1.TopToolStripPanel.Join(tstripRamp, 1);
            toolStripContainer1.TopToolStripPanel.Join(tstripCharacters, 1);
            toolStripContainer1.TopToolStripPanel.Join(tstripOutputSize, 1);

			_AlterInputImageToolStripIsEnabled = false;

			SetFont(Variables.DefaultFont);

            cmbRamp.Items.Clear();
			cmbRamp.Items.AddRange(Variables.DefaultRamps.ToArray());

			if (Variables.CurrentSelectedRamp == -1) {
				cmbRamp.Text = Variables.CurrentRamp;
			}
			else {
				cmbRamp.SelectedIndex = Variables.CurrentSelectedRamp;
			}

			cmbRamp.Select(0, 0);	// make sure the text isn't selected
			chkGenerate.Checked = Variables.UseGeneratedRamp;

			cmbCharacters.Items.Clear();
			cmbCharacters.Items.AddRange(Variables.DefaultValidCharacters.ToArray());

			if (Variables.CurrentSelectedValidCharacters == -1) {
				cmbCharacters.Text = Variables.CurrentCharacters;
			}
			else {
				cmbCharacters.SelectedIndex = Variables.CurrentSelectedValidCharacters;
			}

			cmbCharacters.Select(0, 0);	// make sure the text isn't selected

			_WidgetImageBrightnessContrast.BrightnessChanging += new EventHandler(ImageBrightnessChanging);
			_WidgetImageBrightnessContrast.BrightnessChanged += new EventHandler(ImageBrightnessChanged);

			_WidgetImageBrightnessContrast.ContrastChanging += new EventHandler(ImageContrastChanging);
			_WidgetImageBrightnessContrast.ContrastChanged += new EventHandler(ImageContrastChanged);

			_WidgetImageBrightnessContrast.Left = pnlMain.Width - _WidgetImageBrightnessContrast.Width - 4;
			_WidgetImageBrightnessContrast.Top = pnlMain.Height - _WidgetImageBrightnessContrast.Height - 4;
			_WidgetImageBrightnessContrast.MaximumBrightness = 200;
			_WidgetImageBrightnessContrast.MinimumBrightness = -200;
			_WidgetImageBrightnessContrast.MaximumContrast = 100;
			_WidgetImageBrightnessContrast.MinimumContrast = -100;

			_ImageBrightnessContrast = _WidgetImageBrightnessContrast;
			_ImageBrightnessContrast.Brightness = Variables.DefaultImageBrightness;
			_ImageBrightnessContrast.Contrast = Variables.DefaultImageContrast;

			// check if an image was loaded in the constructor
			_WidgetImageBrightnessContrast.Enabled = pbxMain.Image != null;

			_WidgetTextSettings.ValueChanging += new EventHandler(ApplyTextBrightnessContrast);
			_WidgetTextSettings.ValueChanged += new EventHandler(ApplyTextBrightnessContrast);

			_WidgetTextSettings.LevelsChanged += new EventHandler(LevelsChanged);

			_WidgetTextSettings.DitheringChanging += new EventHandler(DitheringChanging);
			_WidgetTextSettings.DitheringChanged += new EventHandler(DitheringChanging);
			_WidgetTextSettings.DitheringRandomChanged += new EventHandler(DitheringRandomChanged);

			_WidgetTextSettings.MaximumBrightness = 200;
			_WidgetTextSettings.MinimumBrightness = -200;
			_WidgetTextSettings.MaximumContrast = 100;
			_WidgetTextSettings.MinimumContrast = -100;

			_WidgetTextSettings.Left = 4;
			_WidgetTextSettings.Top = pnlMain.Height - _WidgetTextSettings.Height - 4;
			_WidgetTextSettings.BringToFront();
			_WidgetTextSettings.Enabled = false;

			_BrightnessContrast = _WidgetTextSettings;
			_BrightnessContrast.Brightness = Variables.DefaultTextBrightness;
			_BrightnessContrast.Contrast = Variables.DefaultTextContrast;

			_Levels = _WidgetTextSettings;
			_Levels.Minimum = Variables.DefaultMinLevel;
			_Levels.Maximum = Variables.DefaultMaxLevel;
			_Levels.Median = Variables.DefaultMedianLevel;

			_Dither = _WidgetTextSettings;
			_Dither.DitherAmount = Variables.DefaultDitheringLevel;
			_Dither.DitherRandom = Variables.DefaultDitheringRandom;


			_InputDirectory = Variables.InitialInputDirectory;

			_OutputDirectory = Variables.InitialOutputDirectory;

			UpdateUI();

			UpdateMenus();

			pnlMain.Controls.AddRange(new Control[] { _WidgetImageBrightnessContrast, _WidgetTextSettings });

			splitContainer1.SendToBack();

			_ClientSize = pnlMain.ClientSize;

			// load a filename if one was passed
			if (_Args.Length == 1) {
				LoadImage(_Args[0]);
			}

			pbxMain.Select();

            if (Variables.CheckForNewVersions) {
                _VersionCheckThread = new Thread(CheckForNewVersion);
                _VersionCheckThread.Name = String.Format(Variables.Culture, "VersionCheckThread{0:HHmmss}", DateTime.Now);
                _VersionCheckThread.Start();
            }
		}

		/// <summary>
		/// Save the current settings as XML
		/// </summary>
		/// <param name="filename">the filename to use for the output</param>
		/// <returns>Did the xml file save correctly?</returns>
		private bool WriteXML(string filename) {
			UpdateVariables();

			return Variables.WriteXML(filename);
		}

		// update the variables from the current settings
		private void UpdateVariables() {
			Variables.DefaultImageBrightness = _ImageBrightnessContrast.Brightness;
			Variables.DefaultImageContrast = _ImageBrightnessContrast.Contrast;

			int width = _TextSettings.Width, height = _TextSettings.Height;

			if (_Locked) {
				if (_WidthChangedLast) {
					if (width == -1) width = 150;
					height = -1;
				}
				else {
					if (height == -1) height = 150;
					width = -1;
				}
			}

			Variables.DefaultWidth = width;
			Variables.DefaultHeight = height;

			Variables.DefaultFont = _TextSettings.Font;

			Variables.DefaultTextBrightness = _TextSettings.Brightness;
			Variables.DefaultTextContrast = _TextSettings.Contrast;

			Variables.DefaultMinLevel = _TextSettings.MinimumLevel;
			Variables.DefaultMedianLevel = _TextSettings.MedianLevel;
			Variables.DefaultMaxLevel = _TextSettings.MaximumLevel;

			Variables.DefaultDitheringLevel = _TextSettings.Dithering;
			Variables.DefaultDitheringRandom = _TextSettings.DitheringRandom;

			Variables.Stretch = _TextSettings.Stretch;
			Variables.Sharpen = _TextSettings.Sharpen;
			Variables.UnsharpMask = _TextSettings.Unsharp;

			Variables.FlipHorizontally = _TextSettings.FlipHorizontally;
			Variables.FlipVertically = _TextSettings.FlipVertically;

			Variables.BlackTextOnWhite = _TextSettings.IsBlackTextOnWhite;

			Variables.DefaultRamps = new ArrayList(cmbRamp.Items);

			Variables.CurrentSelectedRamp = cmbRamp.SelectedIndex;
			Variables.CurrentRamp = cmbRamp.SelectedIndex == -1 ? cmbRamp.Text : String.Empty;

			Variables.UseGeneratedRamp = _TextSettings.IsGeneratedRamp;

			Variables.DefaultValidCharacters = new ArrayList(cmbCharacters.Items);

			Variables.CurrentSelectedValidCharacters = cmbCharacters.SelectedIndex;
			Variables.CurrentCharacters = (Variables.CurrentSelectedValidCharacters == -1 ? cmbCharacters.Text : String.Empty);

			Variables.ShowBCWidgetImage = _WidgetImageBrightnessContrast.Visible;
			Variables.ShowWidgetText = _WidgetTextSettings.Visible;

			Variables.SelectionBorderColor = pbxMain.SelectionBorderColor;
			Variables.SelectionFillColor = pbxMain.SelectionFillColor;
		}

		/// <summary>
		/// Read the default settings from an XML file
		/// </summary>
		/// <param name="filename">the filename to read from</param>
		private bool ReadXML(string filename) {
			bool result = Variables.ReadXML(filename);

			if (result) {
				tbxWidth.MaxLength = Variables.MaximumWidth.ToString(Variables.Culture).Length;

				tbxHeight.MaxLength = Variables.MaximumHeight.ToString(Variables.Culture).Length;

				cbxLocked.Checked = (Variables.DefaultWidth == -1 ^ Variables.DefaultHeight == -1);

				_WidgetImageBrightnessContrast.Visible = Variables.ShowBCWidgetImage;

				_WidgetTextSettings.Visible = Variables.ShowWidgetText;

				pbxMain.SelectionBorderColor = Variables.SelectionBorderColor;

				pbxMain.SelectionFillColor = Variables.SelectionFillColor;
			}

			return result;
		}

		private void ImageBrightnessChanging(object sender, EventArgs e) {
			AppyImageBrightness();
		}

		private void ImageBrightnessChanged(object sender, EventArgs e) {
			AppyImageBrightness();
			DoConvert();
		}

		private void AppyImageBrightness() {
			pbxMain.Brightness = (float)_ImageBrightnessContrast.Brightness / (float)255;
			_InputChanged = true;
			_ImageSaved = false;
		}

		private void ImageContrastChanging(object sender, EventArgs e) {
			AppyImageContrast();
		}

		private void ImageContrastChanged(object sender, EventArgs e) {
			AppyImageContrast();
			DoConvert();
		}

		private void AppyImageContrast() {
			pbxMain.Contrast = ((float)_ImageBrightnessContrast.Contrast / (float)113) + 1f;
			_InputChanged = true;
			_ImageSaved = false;
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		private void UpdateUI() {
			menuFile.Text = Resource.GetString("&File");
			menuFileLoad.Text = Resource.GetString("&Load Image") + "...";
			menuFileClose.Text = Resource.GetString("&Close");
			menuFileSaveAs.Text = "&" + Resource.GetString("Save As") + "...";
			menuFileExit.Text = Resource.GetString("E&xit");
			menuFileImportClipboard.Text = Resource.GetString("I&mport from Clipboard");
			menuFileBatchConversion.Text = Resource.GetString("Batch Conversion") + "...";
			menuFilePrint.Text = Resource.GetString("Print") + "...";
			menuFilePrintPreview.Text = Resource.GetString("Print Preview") + "...";
			menuFilePrintColour.Text = Resource.GetString("Print Colour") + "...";
			menuFilePrintPreviewColour.Text = Resource.GetString("Colour Print Preview") + "...";
			menuFilePageSetup.Text = Resource.GetString("Page Setup") + "...";

			menuEdit.Text = "&" + Resource.GetString("Edit");
			menuEditFlipHorizontal.Text = Resource.GetString("Flip Horizontally");
			menuEditFlipVertical.Text = Resource.GetString("Flip Vertically");
			menuEditInput.Text = Resource.GetString("Input");
			menuEditInputRotate90.Text = Resource.GetString("Rotate") + " 90�";
			menuEditInputRotate180.Text = Resource.GetString("Rotate") + " 180�";
			menuEditInputRotate270.Text = Resource.GetString("Rotate") + " 270�";
			menuEditInputFlipHorizontal.Text = Resource.GetString("Flip Horizontally");
			menuEditInputFlipVertical.Text = Resource.GetString("Flip Vertically");
			menuEditOutput.Text = Resource.GetString("Output");
			menuEditSharpeningMethod.Text = Resource.GetString("Sharpening Method");
			menuEditSharpeningMethodNone.Text = Resource.GetString("None");
			menuEditSharpeningMethodSharpen.Text = Resource.GetString("Sharpen");
			menuEditSharpeningMethodUnsharp.Text = Resource.GetString("Unsharp Mask");
			menuEditFontsSpecifyCharSize.Text = Resource.GetString("Specify Character Size") + "...";
			menuEditStretch.Text = Resource.GetString("Stretch");
            menuEditRamps.Text = Resource.GetString("Ramps");
			menuEditRampsValidChars.Text = Resource.GetString("Valid Characters") + "...";
            menuEditRampsCopyRamp.Text = Resource.GetString("Copy Ramp to Clipboard");
            menuEditFontsFont.Text = Resource.GetString("Font") + "...";
            menuEditFonts.Text = Resource.GetString("Fonts");
			menuEditEditSettings.Text = Resource.GetString("Edit Settings") + "...";
			menuEditSaveSettings.Text = Resource.GetString("Save Settings as Default");

			menuView.Text = Resource.GetString("&View");
			menuViewColourPreview.Text = Resource.GetString("Colour Preview") + "...";
			menuViewICBC.Text = Resource.GetString("Image") + " " +
				Resource.GetString("Brightness") + "/" + Resource.GetString("Contrast");

			menuViewText.Text = Resource.GetString("Text Settings");

			menuViewFullScreen.Text = Resource.GetString("&Full Screen");
			menuViewImage.Text = Resource.GetString("Input Image");
			menuViewImagePosition.Text = Resource.GetString("Input Image Position");

			menuHelp.Text = Resource.GetString("&Help");
            menuHelpDonate.Text = Resource.GetString("&Donate") + "...";
            menuHelpReportBug.Text = Resource.GetString("Report a Bug") + "...";
            menuHelpRequestFeature.Text = Resource.GetString("Request a Feature") + "...";
			menuHelpTutorials.Text = Resource.GetString("Tutorials") + "...";
			menuHelpCheckForNewVersionToolStrip.Text = Resource.GetString("Check for a New Version") + "...";
			menuHelpAbout.Text = Resource.GetString("&About") + "...";

			lblOutputSize.Text = Resource.GetString("Size") + ":";
			lblRamp.Text = Resource.GetString("Ramp") + ":";
			tsbFont.Text = Resource.GetString("Font") + "...";
			chkGenerate.Text = Resource.GetString("Auto");

			lblCharacters.Text = Resource.GetString("Characters") + ":";

			cmenuTextCopy.Text = Resource.GetString("Copy");
			cmenuTextSelectAll.Text = Resource.GetString("Select All");
			cmenuTextSelectNone.Text = Resource.GetString("Select None");
			cmenuTextStretch.Text = Resource.GetString("Stretch");
			cmenuTextSharpening.Text = Resource.GetString("Sharpening Method");
			cmenuTextSharpeningNone.Text = Resource.GetString("None");
			cmenuTextSharpeningSharpen.Text = Resource.GetString("Sharpen");
			cmenuTextSharpeningUnsharp.Text = Resource.GetString("Unsharp Mask");
			cmenuTextFont.Text = Resource.GetString("Font") + "...";
			cmenuTextVertical.Text = Resource.GetString("Flip Vertically");
			cmenuTextHorizontal.Text = Resource.GetString("Flip Horizontally");

			cmenuImageLoad.Text =  Resource.GetString("&Load Image") + "...";
			cmenuImageRotate90.Text = Resource.GetString("Rotate") + " 90�";
			cmenuImageRotate180.Text = Resource.GetString("Rotate") + " 180�";
			cmenuImageRotate270.Text = Resource.GetString("Rotate") + " 270�";
			cmenuImageFlipHorizontal.Text = Resource.GetString("Flip Horizontally");
			cmenuImageFlipVertical.Text = Resource.GetString("Flip Vertically");
			cmenuTextHorizontal.Text = Resource.GetString("Flip Horizontally");
			cmenuImageSelectNone.Text = Resource.GetString("Remove Selection");
			cmenuImageSelectionLocked.Text = Resource.GetString("Lock Selected Area");
			cmenuImageSelectionShow.Text = Resource.GetString("Fill Selected Area");
			cmenuImageSelectionFillColor.Text = Resource.GetString("Selection Area Fill Colour") + "...";
			cmenuImageSelectionBorderColor.Text = Resource.GetString("Selection Area Border Colour") + "...";

			tsbColourPreview.ToolTipText = Resource.GetString("Colour Preview");
			tsbFont.ToolTipText = Resource.GetString("Choose the Font");
			tsbBlackOnWhite.ToolTipText = Resource.GetString("Invert the Output");
			tsbFullScreen.ToolTipText = Resource.GetString("Full Screen");
			tsbImageVisible.ToolTipText = Resource.GetString("Show the Input Image");

			tsbRotateClockwise.ToolTipText = Resource.GetString("Rotate Clockwise");
			tsbRotateAnticlockwise.ToolTipText = Resource.GetString("Rotate Anticlockwise");
			tsbFlipHorizontally.ToolTipText = Resource.GetString("Flip Horizontally");
			tsbFlipVertically.ToolTipText = Resource.GetString("Flip Vertically");

			dialogSaveText.Title = Resource.GetString("Save to a Text File") + "...";

			pbxMain.Text = Resource.GetString("Doubleclick to load an image, or drag and drop here.") +
				Environment.NewLine + Environment.NewLine + Resource.GetString("Click and drag on an image to select an area");

			dialogLoadImage.Filter =
				Resource.GetString("Image Files") + "|*.bmp;*.rle;*.dib;*.exif;*.gif;*.jpg;*.jpeg;*.jpe;*.png;*.tif;*.tiff;*.wmf;*.emf|" +
				Resource.GetString("Bitmap Images") + " (*.bmp, *.rle, *.dib)|*.bmp;*.rle;*.dib|" +
				Resource.GetString("Exchangeable Image Files") + " (*.exif)|*.exif|" +
				Resource.GetString("GIF Images") + " (*.gif)|*.gif|" +
				Resource.GetString("JPEG Images") + " (*.jpg, *.jpeg, *.jpe)|*.jpg;*.jpeg;*.jpg|" +
				Resource.GetString("Portable Network Graphics Images") + " (*.png)|*.png|" +
				Resource.GetString("TIF Images") + " (*.tif, *.tiff)|*.tif;*.tiff|" +
				Resource.GetString("Windows Metafile Images") + " (*.emf, *.wmf)|*.emf;*.wmf|" +
				Resource.GetString("All Files") + " (*.*)|*.*";

			dialogSaveImage.Filter =
				Resource.GetString("Bitmap Images") + " (*.bmp, *.rle, *.dib)|*.bmp;*.rle;*.dib|" +
				Resource.GetString("GIF Images") + " (*.gif)|*.gif|" +
				Resource.GetString("JPEG Images") + " (*.jpg, *.jpeg, *.jpe)|*.jpg;*.jpeg;*.jpg|" +
				Resource.GetString("Portable Network Graphics Images") + " (*.png)|*.png|" +
				Resource.GetString("TIF Images") + " (*.tif, *.tiff)|*.tif;*.tiff|" + 
				Resource.GetString("All Files") + " (*.*)|*.*";

			dialogSaveImage.FilterIndex = 2;	// gif = smallest

            dialogSaveText.Filter = Resource.GetString("Plain Text") + "|*.txt|" +
                Resource.GetString("Plain Text") + " (Unicode)|*.txt|" +
				"NFO|*.nfo|" +
                Resource.GetString("Rich Text") + "|*.rtf|" +
                "XHTML 1.1|*.html|" +
                Resource.GetString("All Files") + "|*.*";
            dialogSaveText.FilterIndex = 1;

            dialogSaveColour.Filter = "XHTML 1.1 (8-bit)|*.html|" +
                Resource.GetString("Rich Text") + " (8-bit)|*.rtf|" +
                "XHTML 1.1 (24-bit)|*.html|" +
                Resource.GetString("Rich Text") + " (24-bit)|*.rtf";
            dialogSaveColour.FilterIndex = 1;

			_WidgetTextSettings.Text = Resource.GetString("Text");
			_WidgetImageBrightnessContrast.Text = Resource.GetString("Image");

			_WidgetTextSettings.UpdateUI();
			_WidgetImageBrightnessContrast.UpdateUI();

			_BatchConverter.UpdateUI();
			_FormSaveAs.UpdateUI();
		}

		/// <summary>
		/// Load an image into the picturebox, and setup the form etc.
		/// </summary>
		/// <param name="image">The image to load</param>
		/// <returns>Did everything work correctly?</returns>
		public bool LoadImage(Image image) {
			if (CloseImage()) {
				pbxMain.DrawingImage = false;

				pbxMain.Image = image;

				this.Text = Path.GetFileName(_Filename) + " - " + Variables.ProgramName + " v" + Variables.Version.GetVersion();

				pbxMain.DrawingImage = true;

				if (tbxWidth.Text.Length == 0 && tbxHeight.Text.Length == 0) {
					if (Variables.DefaultWidth > 0 && Variables.DefaultHeight > 0) {
						cbxLocked.Checked = false;
						Locked = false;

						_SizeIsChanging = true;
						tbxWidth.Text = Variables.DefaultWidth.ToString(Variables.Culture);
						_TextSettings.Width = Variables.DefaultWidth;
						tbxHeight.Text = Variables.DefaultHeight.ToString(Variables.Culture);
						_TextSettings.Height = Variables.DefaultHeight;
						_SizeIsChanging = false;

						_WidthChangedLast = true;
					}
					else {
						if (Variables.DefaultWidth > 0 && Variables.DefaultHeight == -1) {
							_SizeIsChanging = true;
							tbxWidth.Text = Variables.DefaultWidth.ToString(Variables.Culture);
							_TextSettings.Width = Variables.DefaultWidth;
							_TextSettings.Height = -1;
							_SizeIsChanging = false;
							_WidthChangedLast = true;
						}
						else if (Variables.DefaultHeight > 0 && Variables.DefaultWidth == -1) {
							_SizeIsChanging = true;
							tbxHeight.Text = Variables.DefaultHeight.ToString(Variables.Culture);
							_TextSettings.Height = Variables.DefaultHeight;
							_TextSettings.Width = -1;
							_SizeIsChanging = false;
							_WidthChangedLast = false;
						}
						else {
							MessageBox.Show(Resource.GetString("DefaultWidth and/or DefaultHeight must be > 0"),
								Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);

							_SizeIsChanging = true;
							tbxWidth.Text = "150";
							_TextSettings.Width = 150;
							_TextSettings.Height = -1;
							_SizeIsChanging = false;
							_WidthChangedLast = true;
						}

						Locked = true;
					}
				}

				UpdateOutputDimensions();

				_AlterInputImageToolStripIsEnabled =
					_WidgetTextSettings.Enabled = _WidgetImageBrightnessContrast.Enabled = true;

				_WidgetImageBrightnessContrast.Refresh();
				_WidgetTextSettings.Refresh();

				UpdateMenus();

				return DoConvert();
			}
			else {
				return false;
			}
		}

		/// <summary>
		/// Load the specified image into the picturebox, and setup the form etc.
		/// </summary>
		/// <param name="filename">Path to the image</param>
		/// <returns>Did the image load correctly?</returns>
		public bool LoadImage(string filename) {
			try {
                Image image;

                using (Image loadedimage = Image.FromFile(filename)) {
                    Size size;

                    if (loadedimage.GetType() == typeof(Metafile)) {
                        size = new Size(1000, (int)((1000f * ((float)loadedimage.Height / (float)loadedimage.Width)) + 0.5f));
                    }
                    else {
                        size = new Size(loadedimage.Width, loadedimage.Height);
                    }

                    image = new Bitmap(size.Width, size.Height);

                    using (Graphics g = Graphics.FromImage(image)) {
                        g.Clear(_TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black);
                        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                        g.DrawImage(loadedimage, 0, 0, size.Width, size.Height);
                    }
                }

				dialogLoadImage.FileName = _Filename = filename;

				return LoadImage(image);
			}
			catch (OutOfMemoryException) {	// Catch any bad image files					
				MessageBox.Show(Resource.GetString("Unknown or Unsupported File"),
					Resource.GetString("Error"),
					MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}
			catch (FileNotFoundException) {
				MessageBox.Show(Resource.GetString("File Not Found"),
					Resource.GetString("Error"),
					MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}
		}

		/// <summary>
		/// Process the conversion
		/// </summary>
		/// <returns>Did the conversion succeed?</returns>
		private bool DoConvert() {
			// no image to convert
			if (pbxMain.Image == null) {
				return false;
			}

			// if conversion is unnecessary
			if(!_InputChanged) {
				return true;
			}

			if (_TextSettings.Width == -1 || _TextSettings.Height == -1) {
				_TextViewer.Clear();

				tbxWidth.Focus();

				return false;
			}

			Rectangle Section = (pbxMain.SelectedArea.Width == 0 || pbxMain.SelectedArea.Height == 0) ?
				new Rectangle(0, 0, pbxMain.Image.Width, pbxMain.Image.Height) : pbxMain.SelectedArea;

			// convert the image into values
			_Values = ImageToValues.Convert((Bitmap)pbxMain.Image,
				new Size(_TextSettings.Width, _TextSettings.Height),
				JMSoftware.Matrices.BrightnessContrast(pbxMain.Brightness, pbxMain.Contrast), Section);

			if (_Values == null) {
				_TextViewer.Clear();

				MessageBox.Show(Resource.GetString("Out of Memory, Could not convert the image"),
					Resource.GetString("Error"),
					MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}

			UpdateLevelsArray();

			ApplyTextEffects();

			_InputChanged = false;
			_ImageSaved = false;

			return true;
		}

		private void ApplyTextEffects() {
			if (_Values == null) {
				return;
			}

			_TextViewer.Lines = AscgenConverter.Convert(_Values, _TextSettings);
		}

		private void UpdateLevelsArray() {
			if (_Values == null) return;

			byte[,] values;

			if (_TextSettings.Brightness != 0 || _TextSettings.Contrast != 0) {
                BrightnessContrast filter = new BrightnessContrast(
                    _TextSettings.IsBlackTextOnWhite ? _TextSettings.Brightness : -_TextSettings.Brightness,
                    _TextSettings.IsBlackTextOnWhite ? _TextSettings.Contrast : -_TextSettings.Contrast);

                values = filter.Apply(_Values);
			}
			else {
				values = _Values;
			}

			if (_TextSettings.Stretch) {
                Stretch filter = new Stretch();
				values = filter.Apply(values);
			}

			// Update the levels graph
			int[] Levels = new int[256];

			for (int y = 0; y < _TextSettings.Height; y++) {
				for (int x = 0; x < _TextSettings.Width; x++) {
					Levels[(int)values[x, y]]++;
				}
			}

			_WidgetTextSettings.LevelsArray = Levels;
		}

		private void pbxMain_DragOver(object sender, System.Windows.Forms.DragEventArgs e) {
			HandleDragOver(e);
		}

		private void pbxMain_DragDrop(object sender, System.Windows.Forms.DragEventArgs e) {
			HandleDragDrop(e);
		}

		void rtbxConvertedText_DragEnter(object sender, DragEventArgs e) {
			HandleDragOver(e);
		}

		void rtbxConvertedText_DragDrop(object sender, DragEventArgs e) {
			HandleDragDrop(e);
		}

		void HandleDragDrop(DragEventArgs e) {
			string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);

			if (fileNames.Length == 1) {
				LoadImage(fileNames[0]);
			}
		}

		void HandleDragOver(DragEventArgs e) {
			if (e.Data.GetDataPresent("FileNameW") && ((string[])e.Data.GetData(DataFormats.FileDrop)).Length == 1) {
				e.Effect = DragDropEffects.Copy;
			}
			else {
				e.Effect = DragDropEffects.None;
			}
		}

		private void menuFileExit_Click(object sender, System.EventArgs e) {
			Close();
		}

		private void menuFileSave_Click(object sender, System.EventArgs e) {
			ShowSaveDialog();
		}
		
		private bool ShowSaveDialog() {
			bool is_text = _FormSaveAs.IsText;
			bool is_colour = _FormSaveAs.IsColour;
			Size form_size = _FormSaveAs.Size;
			bool saved = false;

			_FormSaveAs.IsFixedWidth = _TextSettings.IsFixedWidth;

			if (_FormSaveAs.ShowDialog() == DialogResult.OK) {
				string filename = Variables.Prefix + Path.GetFileNameWithoutExtension(_Filename);

				if (_FormSaveAs.IsText) {
					if (_FormSaveAs.IsColour) {
						saved = SaveColourTextDialog(filename);
					}
					else {
						saved = SaveTextDialog(filename);
					}
				}
				else {
					saved = SaveAsImage(filename, _FormSaveAs.IsColour);
				}
			}

			if (!saved) {
				_FormSaveAs.IsText = is_text;
				_FormSaveAs.IsColour = is_colour;
				_FormSaveAs.Size = form_size;
			}

			return saved;
		}

		/// <summary>
		/// Show and process the dialog to save as text
		/// </summary>
		/// <param name="file">Default filename for the output</param>
		/// <returns>Was the file saved?</returns>
		private bool SaveTextDialog(string file) {
			bool result = false;

			if (CheckIfSavable()) {
				dialogSaveText.FileName = file;

				if (dialogSaveText.ShowDialog() == DialogResult.OK) {
                    RichTextBoxStreamType StreamType = RichTextBoxStreamType.PlainText;
                    bool saved = false;

					switch (dialogSaveText.FilterIndex) {
						case 1:	// plain text
							StreamType = RichTextBoxStreamType.PlainText;
							break;

						case 2:	// plain text (unicode)
						case 3:	// nfo
							StreamType = RichTextBoxStreamType.UnicodePlainText;
							break;

						case 4:	// rich text
							StreamType = RichTextBoxStreamType.RichText;
							break;

                        case 5: // XHTML
                            using (StreamWriter writer = new StreamWriter(dialogSaveText.FileName)) {
                                writer.Write(OutputCreator.CreateHTML(_TextViewer.Lines, null,
									_TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black, _TextSettings,
									Path.GetFileNameWithoutExtension(_Filename)));
                            }

                            saved = true;
                            break;
					}

                    if (!saved) {
                        rtbxConvertedText.SaveFile(dialogSaveText.FileName, StreamType);
                    }

					result = true;

					_ImageSaved = true;

					_OutputDirectory = Path.GetDirectoryName(dialogSaveText.FileName);
				}
			}

			return result;
		}

		/// <summary>
		/// Show and process the dialog to save as colour text
		/// </summary>
		/// <param name="file">Default filename for the output</param>
		/// <returns>Was the file saved?</returns>
		private bool SaveColourTextDialog(string file) {
			if (!_TextSettings.IsFixedWidth) {
				throw new Exception("Cannot use colour with variable width conversions");
			}

			bool result = false;

			if (CheckIfSavable() && _TextSettings.IsFixedWidth) {
				dialogSaveColour.FileName = file;

				if (dialogSaveColour.ShowDialog() == DialogResult.OK) {
					Rectangle Section = (pbxMain.SelectedArea.Width == 0 || pbxMain.SelectedArea.Height == 0) ?
						new Rectangle(0, 0, pbxMain.Image.Width, pbxMain.Image.Height) : pbxMain.SelectedArea;

					// create the array of Colors
					Color[,] colors = ImageToColors.Convert((Bitmap)pbxMain.BCImage,
						new Size(_TextSettings.Width, _TextSettings.Height), Section, (dialogSaveColour.FilterIndex == 1 || dialogSaveColour.FilterIndex == 2));

					string[] strings = AscgenConverter.Convert(_Values, _TextSettings);

					string output;

					System.Text.Encoding Encoding;

					switch (dialogSaveColour.FilterIndex) {
						case 2: // rtf 256 color
						case 4: // rtf 24-bit
							output = OutputCreator.CreateRTF(strings, colors, _TextSettings);

							Encoding = System.Text.Encoding.ASCII;

							break;

						case 1: // html 256 color
						case 3: // html 24-bit
						default:
							output = OutputCreator.CreateHTML(strings, colors,
								_TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black, _TextSettings,
								Path.GetFileNameWithoutExtension(_Filename));

							Encoding = System.Text.Encoding.UTF8;

							break;
					}

					using (StreamWriter writer = new StreamWriter(dialogSaveColour.FileName, false, Encoding)) {
						writer.Write(output);
					}

					_ImageSaved = true;

					_OutputDirectory = Path.GetDirectoryName(dialogSaveColour.FileName);

					result = true;
				}
			}

			return result;
		}

		/// <summary>
		/// Update and check if the text image is valid
		/// </summary>
		/// <returns>Is it ok for the text image to be saved?</returns>
		private bool CheckIfSavable() {
			if (!DoConvert()) {
				if (_TextViewer.IsEmpty) {
					MessageBox.Show(this, Resource.GetString("Invalid Output Size"),
						Resource.GetString("Error"),
						MessageBoxButtons.OK, MessageBoxIcon.Error);
				}

				return false;
			}
			else {
				if (_TextSettings.Ramp.Length < 1) {
					MessageBox.Show(this, Resource.GetString("Invalid ASCII Ramp"),
						Resource.GetString("Error"),
						MessageBoxButtons.OK, MessageBoxIcon.Error);

					cmbRamp.Focus();

					return false;
				}
			}

			return true;
		}

		private void menuFileLoad_Click(object sender, System.EventArgs e) {
			LoadDialog();
		}

		/// <summary>
		/// Show the load dialog, and process its result
		/// </summary>
		private void LoadDialog() {
			// show the load image dialog and check its result
			if (dialogLoadImage.ShowDialog() == DialogResult.OK) {
				LoadImage(dialogLoadImage.FileName);
			}
		}

		private void cmbSharpening_SelectionChangeCommitted(object sender, System.EventArgs e) {
			ApplyTextEffects();
		}

		/// <summary>
		/// Show and process the dialog to save as an image
		/// </summary>
		/// <param name="file">Default filename for the output</param>
		/// <param name="UseColour">Output as colour instead of black and white?</param>
		/// <returns>Was the file saved?</returns>
		private bool SaveAsImage(string file, bool UseColour) {
			if (UseColour && !_TextSettings.IsFixedWidth) {
				throw new Exception("Cannot use colour with variable width conversions");
			}

			bool result = false;

			if (CheckIfSavable()) {
				using (TextImageMagnificationDialog dialogChooseTextZoom = new TextImageMagnificationDialog(_TextSettings.Font)) {
					dialogChooseTextZoom.TextColor = _TextSettings.IsBlackTextOnWhite ? Color.Black : Color.White;
					dialogChooseTextZoom.BackgroundColor = _TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black;

					dialogChooseTextZoom.InputSize =
						FontFunctions.MeasureText(_TextViewer.Text, _TextSettings.Font);

					if (dialogChooseTextZoom.ShowDialog() == DialogResult.OK) {
						dialogSaveImage.FileName = file;

						if (dialogSaveImage.ShowDialog() == DialogResult.OK) {
							string filename = dialogSaveImage.FileName;
							string extension = Path.GetExtension(filename).ToLower(Variables.Culture);

							switch (dialogSaveImage.FilterIndex) {
								case 1:
									if (extension != ".bmp" && extension != ".rle" && extension != ".dib") {
										filename += ".bmp";
									}

									break;

								case 2:
									if (extension != ".gif") {
										filename += ".gif";
									}

									break;

								case 3:
									if (extension != ".jpg" && extension != ".jpeg" && extension != ".jpe") {
										filename += ".jpg";
									}

									break;

								case 4:
									if (extension != ".png") {
										filename += ".png";
									}

									break;

								case 5:
									if (extension != ".tif") {
										filename += ".tif";
									}

									break;
							}

							bool saved = false;

							if (UseColour) {
								Image image = CreateColourImage(dialogChooseTextZoom.Value);

								image.Save(filename, ImageFunctions.GetImageFormat(extension));

								saved = true;
							}
							else {
								saved = TextToImage.Save(_TextViewer.Text,
									filename, _TextSettings.Font,
									dialogChooseTextZoom.TextColor, dialogChooseTextZoom.BackgroundColor,
									dialogChooseTextZoom.Value, true);
							}

							result = _ImageSaved = saved || _ImageSaved;

							if (_ImageSaved) {
								_OutputDirectory = Path.GetDirectoryName(dialogSaveImage.FileName);
							}
						}
					}
				}
			}

			return result;
		}

		private Image CreateColourImage(float zoom) {
			Rectangle Section =
				(pbxMain.SelectedArea.Width == 0 || pbxMain.SelectedArea.Height == 0) ?
					new Rectangle(0, 0, pbxMain.Image.Width, pbxMain.Image.Height) :
					pbxMain.SelectedArea;

			Color[,] colors = ImageToColors.Convert((Bitmap)pbxMain.BCImage,
				new Size(_TextSettings.Width, _TextSettings.Height),
				Section, (dialogSaveColour.FilterIndex == 1 || dialogSaveColour.FilterIndex == 2));

			string[] strings = AscgenConverter.Convert(_Values, _TextSettings);

			Image image = TextToColorImage.Convert(_TextViewer.Lines, _TextSettings.Font,
				colors, _TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black,
				zoom);

			return image;
		}

		private void menuHelpAbout_Click(object sender, System.EventArgs e) {
			using (AboutDialog frmAbout = new AboutDialog()) {
				frmAbout.ShowDialog();
			}
		}

		private void menuFile_Popup(object sender, System.EventArgs e) {
            // enable the import item if an image is on the clipboard
			IDataObject data = Clipboard.GetDataObject();
			menuFileImportClipboard.Enabled = data.GetDataPresent(DataFormats.Bitmap, true);
		}

		/// <summary>
		/// Set enabled status for the menus
		/// </summary>
		private void UpdateMenus() {
			menuFileSaveAs.Enabled =
				menuFileClose.Enabled =
				menuFilePrint.Enabled =
				menuFilePrintPreview.Enabled =
				(pbxMain.Image != null);

			tsbColourPreview.Enabled = menuViewColourPreview.Enabled =
				menuFilePrintColour.Enabled = menuFilePrintPreviewColour.Enabled =
				_TextSettings.IsFixedWidth && pbxMain.Image != null;
		}

		private void pbxMain_DoubleClick(object sender, System.EventArgs e) {
			LoadDialog();
		}

		private void cmenuCopy_Click(object sender, System.EventArgs e) {
			_TextViewer.Copy();
		}

		private void cmenuSelectAll_Click(object sender, System.EventArgs e) {
			_TextViewer.SelectAll();
		}

		private void cmenuSelectNone_Click(object sender, System.EventArgs e) {
			_TextViewer.SelectNone();
		}

		private void contextMenuText_Popup(object sender, System.EventArgs e) {
			cmenuTextFont.Enabled = cmenuTextSelectAll.Enabled = (!_TextViewer.IsEmpty);

			cmenuTextCopy.Enabled = cmenuTextSelectNone.Enabled = (_TextViewer.SelectionLength > 0);

			cmenuTextStretch.Checked = _TextSettings.Stretch;

			cmenuTextStretch.Enabled = cmenuTextSharpening.Enabled =
				cmenuTextSharpeningNone.Enabled = cmenuTextSharpeningSharpen.Enabled =
				cmenuTextSharpeningUnsharp.Enabled =
				cmenuTextHorizontal.Enabled = cmenuTextVertical.Enabled =
				(pbxMain.Image != null);

			cmenuTextSharpeningNone.Checked = !_TextSettings.Sharpen && !_TextSettings.Unsharp;
			cmenuTextSharpeningSharpen.Checked = _TextSettings.Sharpen;
			cmenuTextSharpeningUnsharp.Checked = _TextSettings.Unsharp;

			cmenuTextHorizontal.Checked = _TextSettings.FlipHorizontally;
			cmenuTextVertical.Checked = _TextSettings.FlipVertically;
		}

		private void cmenuLoad_Click(object sender, System.EventArgs e) {
			LoadDialog();
		}

		private void cmenuTextSharpeningNone_Click(object sender, System.EventArgs e) {
			_TextSettings.Unsharp = _TextSettings.Sharpen = false;
			ApplyTextEffects();
		}

		private void cmenuTextSharpeningSharpen_Click(object sender, System.EventArgs e) {
			_TextSettings.Sharpen = true;
			_TextSettings.Unsharp = false;
			ApplyTextEffects();
		}

		private void cmenuTextSharpeningUnsharp_Click(object sender, System.EventArgs e) {
			_TextSettings.Sharpen = false;
			_TextSettings.Unsharp = true;
			ApplyTextEffects();
		}

		private void cmenuTextStretch_Click(object sender, System.EventArgs e) {
			_TextSettings.Stretch = !_TextSettings.Stretch;
			ApplyTextEffects();
			UpdateLevelsArray();
		}

		/// <summary>
		/// Overriden OnResize to handle widget positions
		/// </summary>
		/// <param name="e"></param>
		protected override void OnResize(EventArgs e) {
			if (WindowState == FormWindowState.Minimized)
				return;

			base.OnResize(e);
        }

        private void pnlMain_Resize(object sender, EventArgs e) {
            RearrangeWidgets();
        }

        /// <summary>
        /// Update the positions of the widgets
        /// </summary>
        private void RearrangeWidgets() {
			SuspendLayout();

			foreach (Control control in pnlMain.Controls) {
				if (control.GetType().BaseType == typeof(BaseWidget)) {
					if (control.Left > (_ClientSize.Width - control.Right)) {
						control.Left = pnlMain.ClientSize.Width - (_ClientSize.Width - control.Left);
					}
						
					if (control.Top > (_ClientSize.Height - control.Bottom)) {
						control.Top = pnlMain.ClientSize.Height - (_ClientSize.Height - control.Top);
					}

					control.Refresh();
				}
			}

			ResumeLayout();

			_ClientSize = pnlMain.ClientSize;
		}

		private void cmbRamp_DropDown(object sender, System.EventArgs e) {
			int iWidth = cmbRamp.Width;

			foreach (string ramp in cmbRamp.Items) {
                Size size = FontFunctions.MeasureText(ramp + "  ", cmbRamp.Font);

                if (size.Width > iWidth) {
                    iWidth = size.Width;
                }
			}

			cmbRamp.DropDownWidth = iWidth;		
		}

		private void cmenuTextFont_Click(object sender, System.EventArgs e) {
			ShowFontDialog();
		}

        private void menuEditFont_Click(object sender, EventArgs e) {
            ShowFontDialog();
        }

		/// <summary>
		/// Display the font dialog and process the result
		/// </summary>
		public void ShowFontDialog() {
			try {
				if (dialogChooseFont.ShowDialog() == DialogResult.OK) {
					SetFont(dialogChooseFont.Font);
				}
			}
			catch (System.ArgumentException) {
				MessageBox.Show(Resource.GetString("Unable to select this font"), Resource.GetString("Error"),
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		/// <summary>
		/// Set the font and update everything
		/// </summary>
		/// <param name="font">New font to be used</param>
		private void SetFont(Font font) {
			_TextSettings.Font = _TextViewer.Font = Variables.DefaultFont = dialogChooseFont.Font = font;

			tstripRamp.Visible = chkGenerate.Visible = lblRamp.Visible = cmbRamp.Visible = _TextSettings.IsFixedWidth;

			tstripCharacters.Visible = lblCharacters.Visible = cmbCharacters.Visible = !_TextSettings.IsFixedWidth;

			if (_TextSettings.IsFixedWidth) {
				_TextSettings.Ramp = (_TextSettings.IsGeneratedRamp) ?
					AsciiRampCreator.CreateRamp(_TextSettings.Font, _TextSettings.ValidCharacters) : cmbRamp.Text;
			}

			UpdateOutputDimensions();

			UpdateMenus();

			DoConvert();
		}

		private void cmbRamp_SelectedIndexChanged(object sender, System.EventArgs e) {
			_TextSettings.Ramp = cmbRamp.Text;

			if (_TextSettings.IsFixedWidth) {
				ApplyTextEffects();
			}
		}

		private void cmbRamp_TextChanged(object sender, System.EventArgs e) {
			_TextSettings.Ramp = cmbRamp.Text;

			if (_TextSettings.IsFixedWidth) {
				ApplyTextEffects();
			}
		}

		private void pbxMain_SelectionChanged(object sender, System.EventArgs e) {
			UpdateOutputDimensions();
			DoConvert();

			_InputChanged = true;
			_ImageSaved = false;
		}

		private void pbxMain_SelectionChanging(object sender, EventArgs e) {
			UpdateOutputDimensions();

			_InputChanged = true;
			_ImageSaved = false;
		}

		private Size InputSize {
			get {
				if (pbxMain.Image == null) {
					return new Size(0, 0);
				}
				else {
					if (pbxMain.SelectedArea.Width > 0 || pbxMain.SelectedArea.Height > 0) {
						return pbxMain.SelectedArea.Size;
					}
					else {
						return pbxMain.Image.Size;
					}
				}
			}
		}

		private void cmenuImageSelectNone_Click(object sender, System.EventArgs e) {
			pbxMain.SelectNothing();
		}

		private void contextMenuImage_Popup(object sender, System.EventArgs e) {
			cmenuImageSelectionLocked.Enabled =
				cmenuImageSelectionShow.Enabled =
				cmenuImageSelectNone.Enabled =
				(pbxMain.SelectedArea.Width > 0 || pbxMain.SelectedArea.Height > 0);

			cmenuImageRotate90.Enabled = cmenuImageRotate180.Enabled = cmenuImageRotate270.Enabled =
				cmenuImageFlipHorizontal.Enabled = cmenuImageFlipVertical.Enabled =
					(pbxMain.Image != null);

			cmenuImageSelectionLocked.Checked = pbxMain.SelectionLocked;

			cmenuImageSelectionShow.Checked = pbxMain.FillSelectionRectangle;
		}

		private void cmenuImageSelectionLocked_Click(object sender, System.EventArgs e) {
			pbxMain.SelectionLocked = !pbxMain.SelectionLocked;
		}

		private void menuView_Popup(object sender, System.EventArgs e) {
			menuViewICBC.Checked = _WidgetImageBrightnessContrast.Visible;
			menuViewText.Checked = _WidgetTextSettings.Visible;
			menuViewFullScreen.Checked = (_PreviousFormPosition != Rectangle.Empty);
			menuViewImage.Checked = tsbImageVisible.Checked;
			menuViewImagePosition.Checked = splitContainer1.Orientation == Orientation.Horizontal;
		}

		private void menuViewICBC_Click(object sender, System.EventArgs e) {
			_WidgetImageBrightnessContrast.Visible = !_WidgetImageBrightnessContrast.Visible;
			_WidgetImageBrightnessContrast.BringToFront();
		}

		private void menuViewText_Click(object sender, System.EventArgs e) {
			_WidgetTextSettings.Visible = !_WidgetTextSettings.Visible;
			_WidgetTextSettings.BringToFront();
		}

		private void tbxWidth_TextChanged(object sender, System.EventArgs e) {
			if (_SizeIsChanging) return;

            tbxWidth.Invalidate();
            tstripOutputSize.Refresh();

			_InputChanged = true;
			_ImageSaved = false;
			_WidthChangedLast = true;

			try {
				_TextSettings.Width = Convert.ToInt32(tbxWidth.Text, Variables.Culture);

				if (_TextSettings.Width < 1 || _TextSettings.Width > Variables.MaximumWidth) {
					_TextSettings.Width = -1;
				}

				if (UpdateHeight()) {
					DoConvert();
				}

				tbxWidth.Focus();
			}
			catch (FormatException) {
				_TextSettings.Width = -1;

				if (Locked) {
					_SizeIsChanging = true;
					tbxHeight.Text = string.Empty;
					_TextSettings.Height = -1;
					_SizeIsChanging = false;
				}
			}
		}

		private void tbxHeight_TextChanged(object sender, System.EventArgs e) {
			if (_SizeIsChanging) return;

			tbxHeight.Invalidate();
            tstripOutputSize.Refresh();

			_InputChanged = true;
			_ImageSaved = false;
			_WidthChangedLast = false;

			try {
				_TextSettings.Height = Convert.ToInt32(tbxHeight.Text, Variables.Culture);

				if (_TextSettings.Height < 1 || _TextSettings.Height > Variables.MaximumHeight) {
					_TextSettings.Height = -1;
				}

				if (UpdateWidth()) {
					DoConvert();
				}

				tbxHeight.Focus();
			}
			catch (FormatException) {
				_TextSettings.Height = -1;

				if (Locked) {
					_SizeIsChanging = true;
					tbxWidth.Text = string.Empty;
					_TextSettings.Width = -1;
					_SizeIsChanging = false;
				}
			}
		}

		/// <summary>
		/// Recalculate and update the width or height
		/// </summary>
		private void UpdateOutputDimensions() {
			if (_WidthChangedLast) {
				UpdateHeight();
			}
			else {
				UpdateWidth();
			}
		}

		/// <summary>
		/// Recalculate the height from the current width
		/// </summary>
		/// <returns>Were we able to calculate the height?</returns>
		private bool UpdateHeight() {
			if (pbxMain.Image == null)
				return false;

			if ((!_SizeIsChanging)&&(_Locked)) {
				// make sure nothing else will change the width
				_SizeIsChanging = true;

				_TextSettings.Height = AscgenConverter.CalculateOtherDimension(_TextSettings.Width,
					InputSize.Width, InputSize.Height,
					_TextSettings.CharacterSize.Width, _TextSettings.CharacterSize.Height);

				if (_TextSettings.Height > Variables.MaximumHeight) {
					_TextSettings.Height = -1;
					tbxHeight.Text = string.Empty;
					_SizeIsChanging = false;
					return false;
				}
				else if (_TextSettings.Height < 1) {
					_TextSettings.Height = 1;
				}

				tbxHeight.Text = _TextSettings.Height.ToString(Variables.Culture);						
				_SizeIsChanging = false;
				tbxHeight.Invalidate();
                tstripOutputSize.Refresh();

				_InputChanged = true;
				_ImageSaved = false;
			}

			return true;
		}

		/// <summary>
		/// Recalculate the width from the current height
		/// </summary>
		/// <returns>Were we able to calculate the width?</returns>
		private bool UpdateWidth() {
			if (pbxMain.Image == null)
				return false;

			if ((!_SizeIsChanging)&&(_Locked)) {
				// make sure nothing else will change the height
				_SizeIsChanging = true;

				_TextSettings.Width = AscgenConverter.CalculateOtherDimension(_TextSettings.Height,
					InputSize.Height, InputSize.Width,
					_TextSettings.CharacterSize.Height, _TextSettings.CharacterSize.Width);

				if (_TextSettings.Width > Variables.MaximumWidth) {
					_TextSettings.Width = -1;
					tbxWidth.Text = string.Empty;
					_SizeIsChanging = false;
					return false;
				}
				else if (_TextSettings.Width < 1) {
					_TextSettings.Width = 1;
				}
					
				tbxWidth.Text = _TextSettings.Width.ToString(Variables.Culture);
				_SizeIsChanging = false;
                tbxWidth.Invalidate();
                tstripOutputSize.Refresh();

				_InputChanged = true;
				_ImageSaved = false;
			}

			return true;
		}

		private void tsbFont_Click(object sender, System.EventArgs e) {
			ShowFontDialog();
		}

		private bool CloseImage() {
			if (pbxMain.Image != null) {
				if (CheckCloseWithoutSaving()) {
					pbxMain.Image = null;

					_TextViewer.Clear();

					_Values = null;

					Text = Variables.ProgramName + " v" + Variables.Version.GetVersion();

					_ImageBrightnessContrast.Brightness = Variables.DefaultImageBrightness;
					_ImageBrightnessContrast.Contrast = Variables.DefaultImageContrast;

					_BrightnessContrast.Brightness = Variables.DefaultTextBrightness;
					_BrightnessContrast.Contrast = Variables.DefaultTextContrast;

					_TextSettings.MinimumLevel = _Levels.Minimum = Variables.DefaultMinLevel;
					_TextSettings.MaximumLevel = _Levels.Maximum = Variables.DefaultMaxLevel;
					_TextSettings.MedianLevel = _Levels.Median = Variables.DefaultMedianLevel;

					_WidgetImageBrightnessContrast.Refresh();
					_WidgetTextSettings.Refresh();

					_AlterInputImageToolStripIsEnabled =
						_WidgetTextSettings.Enabled = _WidgetImageBrightnessContrast.Enabled = false;

					UpdateMenus();

					return true;
				}
				else {
					return false;
				}
			}
			else {
				return true;
			}
		}

		private bool CheckCloseWithoutSaving() {
			if (!_ImageSaved && pbxMain.Image != null && Variables.ConfirmOnClose) {
                switch (MessageBox.Show(Resource.GetString("Save the output before closing") + "?",
						Resource.GetString("Warning"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning,
						MessageBoxDefaultButton.Button1)) {
                    case DialogResult.Yes:	// save then close if save dialog ok
						return ShowSaveDialog();

					case DialogResult.No:	// close
                        return true;

					default:
					case DialogResult.Cancel:	// don't do anything
						return false;
				}
			}
			else {
				return true;
			}
		}

		private void menuFileClose_Click(object sender, System.EventArgs e) {
			if (CloseImage()) {
				_WidgetTextSettings.LevelsArray = new int[256];

				if (Locked) {
					_SizeIsChanging = true;
				
					if (_WidthChangedLast) {
						if (tbxWidth.Text == Variables.DefaultWidth.ToString(Variables.Culture)) {
							tbxWidth.Text = string.Empty;
						}

						tbxHeight.Text = string.Empty;
					}
					else {
						if (tbxHeight.Text == Variables.DefaultHeight.ToString(Variables.Culture)) {
							tbxHeight.Text = string.Empty;
						}

						tbxWidth.Text = string.Empty;
					}

					_SizeIsChanging = false;
				}

				_Filename = String.Empty;
			}
		}

		private void cbxLocked_CheckedChanged(object sender, System.EventArgs e) {
			Locked = !Locked;
		}

		private void menuViewFullScreen_Click(object sender, System.EventArgs e) {
			SwitchFullScreen();
		}

		private void tsbFullScreen_CheckedChanged(object sender, System.EventArgs e) {
			SwitchFullScreen();
		}

		private void SwitchFullScreen() {
			if (!_FullScreenChanging) {
				_FullScreenChanging = true;
				if (_PreviousFormPosition == Rectangle.Empty) {
					_PreviousWindowState = WindowState;

					if (WindowState == FormWindowState.Maximized) {
						WindowState = FormWindowState.Normal;
					}

					_PreviousFormPosition = new Rectangle(Location, Size);

					FormBorderStyle = FormBorderStyle.None;

					Location = new Point(0, 0);
					Size = new Size(Screen.PrimaryScreen.Bounds.Width,
						Screen.PrimaryScreen.Bounds.Height);

					tsbFullScreen.Checked = true;
				}
				else {
					FormBorderStyle = FormBorderStyle.Sizable;

					Location = _PreviousFormPosition.Location;
					Size = _PreviousFormPosition.Size;

					WindowState = _PreviousWindowState;

					_PreviousFormPosition = Rectangle.Empty;

					tsbFullScreen.Checked = false;

					Focus();
				}

				_FullScreenChanging = false;
			}
		}

		private void cmenuImageSelectionShow_Click(object sender, System.EventArgs e) {
			pbxMain.FillSelectionRectangle = !pbxMain.FillSelectionRectangle;
		}

		private void chkGenerate_CheckedChanged(object sender, System.EventArgs e) {
			_TextSettings.IsGeneratedRamp = chkGenerate.Checked;

			cmbRamp.Enabled = !_TextSettings.IsGeneratedRamp;

			if (_TextSettings.IsFixedWidth) {
				_TextSettings.Ramp = (_TextSettings.IsGeneratedRamp) ?
					AsciiRampCreator.CreateRamp(_TextSettings.Font, _TextSettings.ValidCharacters) : cmbRamp.Text;

				_InputChanged = true;
				_ImageSaved = false;

				ApplyTextEffects();
			}
		}

		private void menuEditValidChars_Click(object sender, System.EventArgs e) {
			ValidRampCharsDialog dlgValidChars = new ValidRampCharsDialog();

			dlgValidChars.Font = _TextSettings.Font;
			dlgValidChars.Characters = _TextSettings.ValidCharacters;

			if (dlgValidChars.ShowDialog() == DialogResult.OK) {
				SetValidCharacters(dlgValidChars.Characters);
				cmbCharacters.Text = dlgValidChars.Characters;
			}
		}

		private void SetValidCharacters(string characters) {
			if (characters == null || _TextSettings.ValidCharacters == characters) return;

			_TextSettings.ValidCharacters = characters;

			ApplyTextEffects();
		}

		private void cmbCharacters_TextChanged(object sender, System.EventArgs e) {
			if (cmbCharacters.Visible && cmbCharacters.Text.Length > 0) {
				SetValidCharacters(cmbCharacters.Text);
			}
		}

		private void menuFileImportClipboard_Click(object sender, System.EventArgs e) {
			_Filename = string.Format(Variables.Culture, "Clipboard{0:yyyyMMddHHmmss}", System.DateTime.Now);

			IDataObject data = Clipboard.GetDataObject();

			if (data.GetDataPresent(DataFormats.Bitmap)) {
				LoadImage((Bitmap)data.GetData(DataFormats.Bitmap, true));
			}
		}

		private void tsbBlackOnWhite_CheckedChanged(object sender, System.EventArgs e) {
			_TextSettings.IsBlackTextOnWhite = !tsbBlackOnWhite.Checked;

			_TextViewer.BackgroundColor = (_TextSettings.IsBlackTextOnWhite) ? Color.White : Color.Black;
			_TextViewer.TextColor = (_TextSettings.IsBlackTextOnWhite) ? Color.Black : Color.White;

			ApplyTextEffects();
		}

		private void cmenuTextHorizontal_Click(object sender, System.EventArgs e) {
			_TextSettings.FlipHorizontally = !_TextSettings.FlipHorizontally;
			ApplyTextEffects();
		}

		private void cmenuTextVertical_Click(object sender, System.EventArgs e) {
			_TextSettings.FlipVertically = !_TextSettings.FlipVertically;
			ApplyTextEffects();
		}

		private void ApplyTextBrightnessContrast(object sender, EventArgs e) {
			_TextSettings.Brightness = _BrightnessContrast.Brightness;
			_TextSettings.Contrast = _BrightnessContrast.Contrast;
			ApplyTextEffects();
			UpdateLevelsArray();
		}

		/// <summary>Method that fires when the levels widget value changes</summary>
		private void LevelsChanged(object sender, EventArgs e) {
			_TextSettings.MinimumLevel = _Levels.Minimum;
			_TextSettings.MedianLevel = _Levels.Median;
			_TextSettings.MaximumLevel = _Levels.Maximum;
			ApplyTextEffects();
		}

		private void DitheringChanging(object sender, EventArgs e) {
			_TextSettings.Dithering = _Dither.DitherAmount;
			ApplyTextEffects();
		}

		void DitheringRandomChanged(object sender, EventArgs e) {
			_TextSettings.DitheringRandom = _Dither.DitherRandom;
			ApplyTextEffects();
		}

		private void menuFileBatchConversion_Click(object sender, System.EventArgs e) {
			_BatchConverter.ShowDialog();
		}

		private void menuEditSpecifyCharSize_Click(object sender, EventArgs e) {
			CharacterSizeDialog characterDialog = new CharacterSizeDialog();

			characterDialog.DefaultCharacterSize = (_TextSettings.CalculateCharacterSize && _TextSettings.IsFixedWidth) ?
				_TextSettings.CharacterSize : FontFunctions.GetFixedPitchFontSize(_TextSettings.Font);

			if (!_TextSettings.IsFixedWidth) {
				characterDialog.DefaultCharacterSize = new Size(ValuesToVariableWidthTextConverter.CharacterWidth,
					FontFunctions.MeasureText("W", _TextSettings.Font).Height);
			}

			characterDialog.AutoCalculateSize = _TextSettings.CalculateCharacterSize;

			characterDialog.CharacterSize = _TextSettings.CharacterSize;

			if (characterDialog.ShowDialog() == DialogResult.OK) {
				_TextSettings.CalculateCharacterSize = characterDialog.AutoCalculateSize;

				if (!characterDialog.AutoCalculateSize) {
					_TextSettings.CharacterSize = characterDialog.CharacterSize;
				}

				UpdateOutputDimensions();
				DoConvert();
			}
		}

		private void menuEdit_Popup(object sender, System.EventArgs e) {
			menuEditInput.Enabled = menuEditOutput.Enabled = (pbxMain.Image != null);
		}

		private void menuEditOutput_Popup(object sender, System.EventArgs e) {
			menuEditStretch.Checked = _TextSettings.Stretch;
			menuEditFlipHorizontal.Checked = _TextSettings.FlipHorizontally;
			menuEditFlipVertical.Checked = _TextSettings.FlipVertically;

			menuEditOutput.DropDown.Enabled = menuEditOutput.Enabled;
		}

        private void menuEditRamps_DropDownOpening(object sender, EventArgs e) {
            menuEditRampsCopyRamp.Enabled = _TextSettings.IsFixedWidth;
        }

		private void menuEditSharpeningMethod_Popup(object sender, System.EventArgs e) {
			menuEditSharpeningMethodNone.Checked = !_TextSettings.Sharpen && !_TextSettings.Unsharp;
			menuEditSharpeningMethodSharpen.Checked = _TextSettings.Sharpen;
			menuEditSharpeningMethodUnsharp.Checked = _TextSettings.Unsharp;
		}

		private void menuEditSaveSettings_Click(object sender, System.EventArgs e) {
			WriteXML(Variables.SettingsFile);
		}

		private void cmbCharacters_DropDown(object sender, System.EventArgs e) {
			int iWidth = cmbCharacters.Width;

			foreach (string Characters in cmbCharacters.Items) {
                Size szWidth = FontFunctions.MeasureText(Characters + "  ", cmbCharacters.Font);

				if (szWidth.Width > iWidth)
					iWidth = szWidth.Width;
			}

			cmbCharacters.DropDownWidth = iWidth;
		}

		private void cmenuImageSelectionFillColor_Click(object sender, System.EventArgs e) {
			dialogSelectionColor.Color = pbxMain.SelectionFillColor;

			if (dialogSelectionColor.ShowDialog() == DialogResult.OK) {
				pbxMain.SelectionFillColor = dialogSelectionColor.Color;
			}
		}

		private void cmenuImageSelectionBorderColor_Click(object sender, System.EventArgs e) {
			dialogSelectionColor.Color = pbxMain.SelectionBorderColor;

			if (dialogSelectionColor.ShowDialog() == DialogResult.OK) {
				pbxMain.SelectionBorderColor = dialogSelectionColor.Color;
			}
		}

		private void FormConvertImage_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
			if (pbxMain.Image != null) {
				e.Cancel = !CheckCloseWithoutSaving();
			}
		}

		private void menuHelpDonate_Click(object sender, EventArgs e) {
			System.Diagnostics.Process.Start("https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=wardog1uk%40gmail%2ecom&item_name=Ascii%20Generator%20%2eNET&no_shipping=2&no_note=1&tax=0&currency_code=GBP&bn=PP%2dDonationsBF&charset=UTF%2d8");
		}

		private void menuEditEditSettings_Click(object sender, EventArgs e) {
			FormEditSettings settingsDialog = new FormEditSettings();

			settingsDialog.DefaultFont = _TextSettings.Font;

			if (settingsDialog.ShowDialog() == DialogResult.OK) {
				_InputDirectory = settingsDialog.InputDirectory;
				_OutputDirectory = settingsDialog.OutputDirectory;

				if (_TextSettings.Font != settingsDialog.DefaultFont) {
					SetFont(settingsDialog.DefaultFont);
				}

				Variables.ConfirmOnClose = settingsDialog.ConfirmOnClose;

				Variables.CheckForNewVersions = settingsDialog.CheckForNewVersions;
			}
		}

		private void menuHelpReportBug_Click(object sender, EventArgs e) {
			System.Diagnostics.Process.Start("http://sourceforge.net/tracker/?func=add&group_id=133786&atid=728164");
		}

		private void menuHelpRequestFeature_Click(object sender, EventArgs e) {
			System.Diagnostics.Process.Start("http://sourceforge.net/tracker/?func=add&group_id=133786&atid=728167");
		}

		/// <summary>
		/// Check if a new version of the program is available
		/// </summary>
		private void CheckForNewVersion() {
			CheckForIllegalCrossThreadCalls = false;

			byte[] buffer = new byte[8192];
			StringBuilder stringbuffer = new StringBuilder();

			try {
				HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://ascgen2.sourceforge.net/version.xml");
				request.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);

				using (HttpWebResponse response = (HttpWebResponse)request.GetResponse()) {
					using (Stream receiveStream = response.GetResponseStream()) {
						int numbytes = 0;

						do {
							numbytes = receiveStream.Read(buffer, 0, buffer.Length);

							if (numbytes != 0) {
								stringbuffer.Append(Encoding.ASCII.GetString(buffer, 0, numbytes));
							}
						}
						while (numbytes > 0);
					}
				}
			}
			catch (System.Net.WebException) {
				stringbuffer = new StringBuilder();
			}

			if (stringbuffer.Length > 0) {
				XmlDocument doc = new XmlDocument();

				try {
					doc.LoadXml(stringbuffer.ToString());

					int major = XmlProcessor.ReadNode(doc.SelectSingleNode("version/major"), 0, 100, 0);
					int minor = XmlProcessor.ReadNode(doc.SelectSingleNode("version/minor"), 0, 100, 0);
					int patch = XmlProcessor.ReadNode(doc.SelectSingleNode("version/patch"), 0, 100, 0);
					string suffix = XmlProcessor.ReadNode(doc.SelectSingleNode("version/suffix"), "", true);
					int suffixnum = XmlProcessor.ReadNode(doc.SelectSingleNode("version/suffixnum"), 0, 100, 0);

					bool showdialog = false;

					if (major > Variables.Version.Major) {
						showdialog = true;
					}
					else if (major == Variables.Version.Major) {
						if (minor > Variables.Version.Minor) {
							showdialog = true;
						}
						else if (minor == Variables.Version.Minor) {
							if (patch > Variables.Version.Patch ||
								(patch == Variables.Version.Patch && suffixnum > Variables.Version.SuffixNumber)) {
								showdialog = true;
							}
						}
					}

					if (showdialog) {
						NewVersionDialog(major.ToString() + "." + minor.ToString() + "." + patch.ToString() + suffix,
							"http://sourceforge.net/project/showfiles.php?group_id=133786");
					}
					else {
						if (_ShowNoNewVersionMessage) {
							MessageBox.Show(Resource.GetString("This is the latest version"),
								Variables.ProgramName, MessageBoxButtons.OK, MessageBoxIcon.Information);
						}
					}
				}
				catch (System.Xml.XmlException) {
				}
			}

			CheckForIllegalCrossThreadCalls = true;
		}

        private void NewVersionDialog(string version, string url) {
			string caption = Resource.GetString("Open the download page") + "?";
            string text = string.Format(Resource.GetString("Version {0} is available"), version);

            if (MessageBox.Show(caption, text, MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK) {
                System.Diagnostics.Process.Start(url);
            }
        }

        private void menuEditRampCopyRamp_Click(object sender, EventArgs e) {
            Clipboard.SetDataObject(_TextSettings.Ramp, true);
        }

		private void menuFilePageSetup_Click(object sender, EventArgs e) {
			try {
				pageSetupDialog.ShowDialog();
			}
			catch (System.Exception ex) {
				MessageBox.Show(Resource.GetString("Print Error") + ": " + ex.Message, Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

		}

		private void menuFilePrint_Click(object sender, EventArgs e) {
			if (printDialog.ShowDialog() == DialogResult.OK) {
				try {
					_PrintColour = false;
					printDocument.Print();
				}
				catch (System.Exception ex) {
					MessageBox.Show(Resource.GetString("Print Error") + ": " + ex.Message, Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}

		private void menuFilePrintPreview_Click(object sender, EventArgs e) {
			try {
				_PrintColour = false;
				printPreviewDialog.ShowDialog();
			}
			catch (System.Exception ex) {
				MessageBox.Show(Resource.GetString("Print Error") + ": " + ex.Message, Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void menuFilePrintColour_Click(object sender, EventArgs e) {
			if (printDialog.ShowDialog() == DialogResult.OK) {
				try {
					_PrintColour = true;
					printDocument.Print();
				}
				catch (System.Exception ex) {
					MessageBox.Show(Resource.GetString("Print Error") + ": " + ex.Message, Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}

		private void menuFilePrintPreviewColour_Click(object sender, EventArgs e) {
			try {
				_PrintColour = true;
				printPreviewDialog.ShowDialog();
			}
			catch (System.Exception ex) {
				MessageBox.Show(Resource.GetString("Print Error") + ": " + ex.Message, Resource.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void printBlackAndWhite_PrintPage(object sender, PrintPageEventArgs e) {
			if (!DoConvert()) {
				return;
			}

			if (_PrintColour) {
				Rectangle Section = (pbxMain.SelectedArea.Width == 0 || pbxMain.SelectedArea.Height == 0) ?
					new Rectangle(0, 0, pbxMain.Image.Width, pbxMain.Image.Height) : pbxMain.SelectedArea;

				Color[,] colors = ImageToColors.Convert((Bitmap)pbxMain.BCImage,
							new Size(_TextSettings.Width, _TextSettings.Height), Section, false);

				Bitmap canvas = (Bitmap)TextToColorImage.Convert(_TextViewer.Lines, _TextSettings.Font, 
					colors, _TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black, 100f);

				PrintImage(canvas, e, true);
			}
			else {
				// get the text as an image
				Bitmap canvas = TextToImage.Convert(_TextViewer.Text, _TextSettings.Font,
					(_TextSettings.IsBlackTextOnWhite ? Color.Black : Color.White),
					(_TextSettings.IsBlackTextOnWhite ? Color.White : Color.Black));

				PrintImage(canvas, e, false);
			}
		}

		private void PrintImage(Bitmap image, PrintPageEventArgs e, bool UseColour) {
			bool border = true;

			printDocument.DocumentName = "ASCII-" + Path.GetFileNameWithoutExtension(_Filename);

			Rectangle printarea = getPrintableArea(e, true, printDocument.PrintController.IsPreview);

			// calculate the area that the image will cover
			float printratio = (float)printarea.Width / (float)printarea.Height;
			float imageratio = (float)image.Width / (float)image.Height;

			Rectangle targetlocation = new Rectangle();

			if (printratio > imageratio) {
				targetlocation.Width = (int)((imageratio * (float)printarea.Height) + 0.5);
				targetlocation.Height = printarea.Height;

				targetlocation.X = printarea.X + ((printarea.Width - targetlocation.Width) / 2);
				targetlocation.Y = printarea.Y;
			}
			else {
				targetlocation.Width = printarea.Width;
				targetlocation.Height = (int)(((float)printarea.Width / imageratio) + 0.5);

				targetlocation.X = printarea.X;
				targetlocation.Y = printarea.Y + ((printarea.Height - targetlocation.Height) / 2);
			}

			e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

			ImageAttributes ia = new ImageAttributes();

			if (!UseColour) {
				// converting to greyscale to avoid cleartype colours problem
				ia.SetColorMatrix(JMSoftware.Matrices.Grayscale());
			}

			e.Graphics.DrawImage(image, targetlocation, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, ia);

			if (border) {
				e.Graphics.DrawRectangle(Pens.Black, targetlocation);
			}
		}

		/// <summary>
		/// Get a rectangle representing the total actual area printable on the page
		/// </summary>
		/// <param name="center">Make the margins equal so the area is centered on the page?</param>
		/// <param name="e">The print parameters</param>
		/// <param name="is_preview">Is this for a print preview?</param>
		/// <returns>The printable area</returns>
		public static Rectangle getPrintableArea(PrintPageEventArgs e, bool center, bool is_preview) {
			Rectangle printablearea = Rectangle.Round(e.PageSettings.PrintableArea);

			int leftmargin = printablearea.X;
			int topmargin = printablearea.Y;
			int rightmargin = e.PageBounds.Width - (e.PageSettings.Landscape ? printablearea.Bottom : printablearea.Right);
			int bottommargin = e.PageBounds.Height - (e.PageSettings.Landscape ? printablearea.Right : printablearea.Bottom);

			if (center) {
				// use the biggest values to center the image
				leftmargin = rightmargin = Math.Max(leftmargin, rightmargin);
				topmargin = bottommargin = Math.Max(topmargin, bottommargin);
			}

			Rectangle result = new Rectangle(
				leftmargin,
				topmargin,
				e.PageBounds.Width - leftmargin - rightmargin - 1,
				e.PageBounds.Height - topmargin - bottommargin - 1);

			if (!is_preview) {
				// apply physical offset for the printer
				result.Offset(-(int)e.PageSettings.HardMarginX, -(int)e.PageSettings.HardMarginY);
			}

			return result;
		}

		private void cmenuImageRotate90_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.Rotate90FlipNone);
		}

		private void cmenuImageRotate180_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.Rotate180FlipNone);
		}

		private void cmenuImageRotate270_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.Rotate270FlipNone);
		}

		private void cmenuImageFlipHorizontal_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.RotateNoneFlipX);
		}

		private void cmenuImageFlipVertical_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.RotateNoneFlipY);
		}

		private void DoRotateFlip(RotateFlipType type) {
			pbxMain.RotateImage(type);
			UpdateOutputDimensions();
			DoConvert();
		}

		private void menuEditInput_DropDownOpening(object sender, EventArgs e) {
			menuEditInput.DropDown.Enabled = menuEditInput.Enabled;
		}

		private void tsbImageVisible_Click(object sender, EventArgs e) {
			splitContainer1.Panel2Collapsed = !splitContainer1.Panel2Collapsed;
		}

		private void menuViewImage_Click(object sender, EventArgs e) {
			splitContainer1.Panel2Collapsed = !splitContainer1.Panel2Collapsed;
			tsbImageVisible.Checked = !tsbImageVisible.Checked;
		}

		private void menuHelpTutorials_Click(object sender, EventArgs e) {
			System.Diagnostics.Process.Start("http://ascgendotnet.jmsoftware.co.uk/tutorials");
		}

		private void menuHelpCheckForNewVersionToolStrip_Click(object sender, EventArgs e) {
			// fix this ugly hack
			_ShowNoNewVersionMessage = true;

			CheckForNewVersion();
		}

		private void tstripRotateAnticlockwise_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.Rotate270FlipNone);
		}

		private void tstripRotateClockwise_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.Rotate90FlipNone);
		}

		private void tsbFlipHorizontally_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.RotateNoneFlipX);
		}

		private void tsbFlipVertically_Click(object sender, EventArgs e) {
			DoRotateFlip(RotateFlipType.RotateNoneFlipY);
		}

		private void tsbColourPreview_Click(object sender, EventArgs e) {
			ShowColourPreview();
		}

		private void menuViewColourPreview_Click(object sender, EventArgs e) {
			ShowColourPreview();
		}

		private void ShowColourPreview() {
			if (!_TextSettings.IsFixedWidth) {
				throw new Exception("Cannot use colour with variable width conversions");
			}

			FormColourPreview preview = new FormColourPreview();

			preview.Image = CreateColourImage(100);

			preview.ShowDialog();
		}

		private void menuViewImagePosition_Click(object sender, EventArgs e) {
			splitContainer1.Orientation =
				(splitContainer1.Orientation == Orientation.Horizontal) ? Orientation.Vertical : Orientation.Horizontal;
		}

		#region Properties and Variables

		/// <summary>Interface to the object used to display the text</summary>
		private ITextViewer _TextViewer;

		/// <summary>Interface to the object used to get and set the brightness and contrast amounts</summary>
		private IBrightnessContrast _BrightnessContrast;

		/// <summary>Interface to the object used to get and set the levels</summary>
		private ILevels _Levels;

		/// <summary>Interface to the object used to get and set the dithering amounts</summary>
		private IDither _Dither;

		/// <summary>Interface to the object used to get and set the input images brightness and contrast</summary>
		private IBrightnessContrast _ImageBrightnessContrast;

		/// <summary>The original image converted into an array of bytes</summary>
		private byte[,] _Values;

		/// <summary>Arguments passed when the program started</summary>
		private string[] _Args;

		/// <summary>Have the input settings changed so the output needs to be recalculated?</summary>
		private bool _InputChanged;

		/// <summary>The full filename of the input image</summary>
		private string _Filename = String.Empty;

		/// <summary>Used for storing the size of the form</summary>
		private Size _ClientSize;

		/// <summary>Brightness/Contrast widget used</summary>
		private WidgetBrightnessContrast _WidgetImageBrightnessContrast = new WidgetBrightnessContrast();

		/// <summary>Text settings widget</summary>
		private WidgetTextSettings _WidgetTextSettings = new WidgetTextSettings();

		/// <summary>Used to store the settings used on the output image</summary>
		private TextProcessingSettings _TextSettings;

		private bool _SizeIsChanging;

		private bool _WidthChangedLast = true;

		private bool _Locked = true;
		/// <summary>
		/// Are the output size dimensions locked to the correct aspect ratio?
		/// </summary>
		public bool Locked {
			get {
				return _Locked;
			}

			set {
				_Locked = value;

				if (_Locked) {
					UpdateOutputDimensions();
				}
			}
		}

		/// <summary>Store the position and size of the form when going to full screen mode</summary>
		private Rectangle _PreviousFormPosition = Rectangle.Empty;

		/// <summary>Store the previous state of the window (workaround problem with maximized form</summary>
		private FormWindowState _PreviousWindowState = FormWindowState.Normal;

		/// <summary>True when changing to and from full screen mode</summary>
		private bool _FullScreenChanging;

		private FormBatchConvert _BatchConverter;

		/// <summary>Has the current image been saved?</summary>
		private bool _ImageSaved;
		
		private Thread _VersionCheckThread;

		private bool _ShowNoNewVersionMessage = false;

		private bool _PrintColour = false;

		/// <summary>
		/// Get and set the directory for the output images
		/// </summary>
		private string _OutputDirectory {
			get {
				return Variables.InitialOutputDirectory;
			}

			set {
				dialogSaveImage.InitialDirectory = dialogSaveText.InitialDirectory = dialogSaveColour.InitialDirectory =
					Variables.InitialOutputDirectory = value;
			}
		}

		/// <summary>
		/// Get and set the directory for the input images
		/// </summary>
		private string _InputDirectory {
			get {
				return Variables.InitialInputDirectory;
			}

			set {
				dialogLoadImage.InitialDirectory =
					Variables.InitialInputDirectory = value;
			}
		}

		private FormSaveAs _FormSaveAs;

		/// <summary>
		/// Get and set whether tstripAlterInputImage is enabled (while allowing it to be moved)
		/// </summary>
		private bool _AlterInputImageToolStripIsEnabled {
			get {
				return tsbRotateClockwise.Enabled;
			}

			set {
				foreach (ToolStripItem item in tstripAlterInputImage.Items) {
					item.Enabled = value;
				}
			}
		}

		#endregion

	}
}
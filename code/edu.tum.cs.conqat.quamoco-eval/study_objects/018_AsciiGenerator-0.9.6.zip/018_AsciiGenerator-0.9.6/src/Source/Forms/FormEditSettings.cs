//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: FormEditSettings.cs,v 1.10 2008/01/31 15:32:03 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Form to edit the settings
	/// </summary>
	public partial class FormEditSettings : Form
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public FormEditSettings() {
			InitializeComponent();

			UpdateUI();
		}

		private void FormEditSettings_Load(object sender, EventArgs e) {
			ResetSettings();
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		private void UpdateUI() {
			Text = Resource.GetString("Edit Settings");

			pageBasic.Text = Resource.GetString("Basic");

			btnOk.Text = Resource.GetString("&Ok");
			btnSave.Text = Resource.GetString("&Save");
			btnCancel.Text = Resource.GetString("&Cancel");

			cbxConfirmClose.Text = Resource.GetString("Confirm close if unsaved");
			cbxConfirmVersionCheck.Text = Resource.GetString("New version check");

			lblInputDirectory.Text = Resource.GetString("Input Directory") + ":";
			lblOutputDirectory.Text = Resource.GetString("Output Directory") + ":";

			btnFont.Text = Resource.GetString("Font") + "...";
		}

		private void ResetSettings() {
			tbxInputDirectory.Text = Variables.InitialInputDirectory;

			tbxOutputDirectory.Text = Variables.InitialOutputDirectory;

			cbxConfirmClose.Checked = Variables.ConfirmOnClose;

			cbxConfirmVersionCheck.Checked = Variables.CheckForNewVersions;
		}

		private void UpdateFont() {
			tbxFont.Text = _DefaultFont.Name + String.Format(Variables.Culture, " {0}pt", _DefaultFont.Size) +
				(_DefaultFont.Bold ? ", bold" : "") + (_DefaultFont.Italic ? ", italic" : "") +
				(_DefaultFont.Underline ? ", underline" : "") +
				(_DefaultFont.Strikeout ? ", strikeout" : "") + ".";
		}

		private void btnInputDirectory_Click(object sender, EventArgs e) {
			folderBrowserDialog1.Description = Resource.GetString("Input Directory");
			folderBrowserDialog1.SelectedPath = tbxInputDirectory.Text;

			if (folderBrowserDialog1.ShowDialog() == DialogResult.OK) {
				tbxInputDirectory.Text = folderBrowserDialog1.SelectedPath;
			}
		}

		private void btnOutputDirectory_Click(object sender, EventArgs e) {
			folderBrowserDialog1.Description = Resource.GetString("Output Directory");
			folderBrowserDialog1.SelectedPath = tbxOutputDirectory.Text;

			if (folderBrowserDialog1.ShowDialog() == DialogResult.OK) {
				tbxOutputDirectory.Text = folderBrowserDialog1.SelectedPath;
			}
		}

		private void btnFont_Click(object sender, EventArgs e) {
			fontDialog1.Font = DefaultFont;

			if (fontDialog1.ShowDialog() == DialogResult.OK) {
				DefaultFont = fontDialog1.Font;
			}
		}

		/// <summary>
		/// Raise the System.Windows.Forms.Form.Closing event
		/// </summary>
		/// <param name="e">CancelEventArgs containing the event data</param>
		protected override void OnClosing(CancelEventArgs e) {
			// Catch ok button press
			if (this.DialogResult == DialogResult.OK) {
				errorProvider1.Clear();

				TextBox[] Directories = new TextBox[] { tbxInputDirectory, tbxOutputDirectory };

				foreach (TextBox textbox in Directories) {
					// the directory must exist if not empty
					if (textbox.Text.Length > 0 && !System.IO.Directory.Exists(textbox.Text)) {
						errorProvider1.SetError(textbox, Resource.GetString("Invalid Directory"));
						e.Cancel = true;
					}
				}
			}

			base.OnClosing(e);
		}

		#region Properties and Variables
		/// <summary>Initial directory for loading the images</summary>
		public string InputDirectory {
			get { return tbxInputDirectory.Text; }
		}

		/// <summary>Initial directory for saving the images</summary>
		public string OutputDirectory {
			get { return tbxOutputDirectory.Text; }
		}

		/// <summary>Check for a new version on start?</summary>
		public bool ConfirmOnClose {
			get { return cbxConfirmClose.Checked; }
		}

		/// <summary>Check for a new version on start?</summary>
		public bool CheckForNewVersions {
			get { return cbxConfirmVersionCheck.Checked; }
		}

		private Font _DefaultFont;
		/// <summary>Default font</summary>
		public new Font DefaultFont {
			get {
				return _DefaultFont;
			}

			set {
				_DefaultFont = value;
				UpdateFont();
			}
		}

		#endregion
	}
}
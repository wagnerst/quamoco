﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using JMSoftware.Widgets;
using JMSoftware.Interfaces;

namespace JMSoftware.AsciiGeneratorDotNet
{
	/// <summary>
	/// Class to show a preview of the output in colour
	/// </summary>
	public partial class FormColourPreview : Form
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public FormColourPreview() {
			InitializeComponent();

			_Zoom = _Widget;

			Controls.AddRange(new Control[] { _Widget });

			_Widget.Top = 4;
			_Widget.Left = 4;
			_Widget.BringToFront();
			_Widget.CloseForm += new EventHandler(_Widget_CloseForm);
			_Widget.ZoomChanged += new EventHandler(_Widget_ZoomChanged);

			UpdateUI();
		}

		void _Widget_ZoomChanged(object sender, EventArgs e) {
			UpdateImageSize();
		}

		void _Widget_CloseForm(object sender, EventArgs e) {
			Close();
		}

		/// <summary>Get and set the displayed image</summary>
		public Image Image {
			get {
				return jmPictureBox1.Image;
			}

			set {
				jmPictureBox1.Image = value;
				UpdateImageSize();
			}
		}

		/// <summary>
		/// Update the controls for the current image size and output options
		/// </summary>
		private void UpdateImageSize() {
			jmPictureBox1.Size = new Size(
				(int)(((float)jmPictureBox1.Image.Width * _Zoom.Amount) + 0.5),
				(int)(((float)jmPictureBox1.Image.Height * _Zoom.Amount) + 0.5));

			PositionImage();
		}

		/// <summary>
		/// Move the image into the center if it is smaller then the panel, else put at 0,0
		/// </summary>
		private void PositionImage() {
			jmPictureBox1.Left = (jmPictureBox1.Width < pnlImage.Width) ?
				(pnlImage.Width - jmPictureBox1.Width) / 2 : 0;

			jmPictureBox1.Top = (jmPictureBox1.Height < pnlImage.Height) ?
				(pnlImage.Height - jmPictureBox1.Height) / 2 : 0;
		}

		private void pnlImage_SizeChanged(object sender, EventArgs e) {
			PositionImage();
		}

		/// <summary>
		/// Update the form with the text strings for the current language
		/// </summary>
		private void UpdateUI() {
			this.Text = Resource.GetString("Colour Preview");
			_Widget.CloseText = Resource.GetString("Close");
			_Widget.ZoomInText = Resource.GetString("Zoom In");
			_Widget.ZoomOutText = Resource.GetString("Zoom Out");
		}

		#region Properties and Variables

		/// <summary>Widget used to display the zoom in/out and close buttons</summary>
		private WidgetPreview _Widget = new WidgetPreview();

		/// <summary>Interface to the object that holds the current zoom level</summary>
		private IZoomLevel _Zoom;

		#endregion
	}
}
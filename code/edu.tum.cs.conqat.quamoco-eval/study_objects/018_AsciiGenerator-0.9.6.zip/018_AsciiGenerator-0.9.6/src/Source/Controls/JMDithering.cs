//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: JMDithering.cs,v 1.6 2008/02/10 14:10:26 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using JMSoftware.Interfaces;

namespace JMSoftware.Controls
{
	/// <summary>
	/// Control to handle changing the dithering levels
	/// </summary>
	public partial class JMDithering : UserControl, IDither
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public JMDithering() {
			InitializeComponent();

			udDitheringAmount.Value = trkDithering.Value = DitherAmount;
			trkRandom.Value = DitherRandom;

			lblRandom.Enabled = trkRandom.Enabled = DitherAmount > 0;
		}

		private void trkDithering_MouseDown(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Left) {
				_MouseDown = true;
			}
		}

		private void trkDithering_MouseUp(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Left) {
				_MouseDown = false;

				UpdateDitheringChanged();
			}
		}

		private void UpdateDitheringChanged() {
			if (DitheringChanged != null) {
				DitheringChanged(this, new EventArgs());
			}
		}

		private void trkDithering_ValueChanged(object sender, EventArgs e) {
			DitherAmount = trkDithering.Value;
		}

		private void trkDithering_Scroll(object sender, EventArgs e) {
			DitherAmount = trkDithering.Value;
		}

		private void trkRandom_Scroll(object sender, EventArgs e) {
			DitherRandom = trkRandom.Value;
		}

		private void trkRandom_ValueChanged(object sender, EventArgs e) {
			DitherRandom = trkRandom.Value;
		}

		private void udDitheringAmount_ValueChanged(object sender, EventArgs e) {
			DitherAmount = (int)udDitheringAmount.Value;
		}

		public void Reset() {
			DitherAmount = 5;
			DitherRandom = 3;
		}

		#region Properties and Variables

		/// <summary>Get and set the text shown on the dithering amount label</summary>
		[DefaultValue("Dithering Amount:")]
		public string DitheringLabel {
			set {
				lblDitheringAmount.Text = value;
			}

			get {
				return lblDitheringAmount.Text;
			}
		}

		/// <summary>Get and set the text shown on the random amount label</summary>
		[DefaultValue("Random:")]
		public string RandomLabel {
			set {
				lblRandom.Text = value;
			}

			get {
				return lblRandom.Text;
			}
		}

		private int _DitherAmount = 5;
		/// <summary>
		/// Level of dithering to be applied (0 to ?)
		/// </summary>
		[Browsable(true), DefaultValue(5)]
		public int DitherAmount {
			get { return _DitherAmount; }

			set {
				if (_DitherAmount != value && value > -1) {
					_DitherAmount = value;
					udDitheringAmount.Value = trkDithering.Value = _DitherAmount;

					udDitheringAmount.Refresh();

					lblRandom.Enabled = trkRandom.Enabled = trkDithering.Value > 0;

					if (_MouseDown) {
						if (DitheringChanging != null) {
							DitheringChanging(this, new EventArgs());
						}
					}
					else {
						UpdateDitheringChanged();
					}
				}
			}
		}

		private int _DitherRandom = 3;
		/// <summary>
		/// Amount of randomness to be used
		/// </summary>
		[Browsable(true), DefaultValue(3)]
		public int DitherRandom {
			get { return _DitherRandom; }

			set {
				if (_DitherRandom != value) {
					_DitherRandom = value;
					trkRandom.Value = _DitherRandom;

					if (RandomChanged != null) {
						RandomChanged(this, new EventArgs());
					}
				}
			}
		}

		private bool _MouseDown = false;

		/// <summary>Event raised when the dithering value changes</summary>
		public event EventHandler DitheringChanging = null;

		/// <summary>Event raised when the dithering value has changed</summary>
		public event EventHandler DitheringChanged = null;

		/// <summary>Event raised when the random value has changed</summary>
		public event EventHandler RandomChanged = null;

		#endregion
	}
}
//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: JMLevels.cs,v 1.17 2008/01/31 15:32:02 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace JMSoftware.CustomControl {
	/// <summary>
	/// Control for displaying and adjusting a levels histogram
	/// </summary>
	public class JMLevels : UserControl {
		private JMLevelsDisplay _LevelsDisplay;

		/// <summary>Constructor</summary>
		public JMLevels() {
			SetStyle(ControlStyles.DoubleBuffer |
				ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint, true);

			_LevelsDisplay = new JMLevelsDisplay();
			_LevelsDisplay.OnRefresh += new RefreshEventHandler(LevelsDisplay_OnRefresh);
			_LevelsDisplay.OnValueChanged += new ValueChangedEventHandler(DisplayValueChanged);
		}

		private void LevelsDisplay_OnRefresh() {
			Refresh();
		}

		/// <summary>
		/// Reset the levels to the default values
		/// </summary>
		public void Reset() {
			Suspended = true;

			Minimum = 0;
			Maximum = 255;
			Median = 0.5f;

			Suspended = false;
		}

		/// <summary>Get or set the minimum value</summary>
		[DefaultValue(0)]
		public int Minimum {
			get { return _LevelsDisplay.Minimum; }

			set {
				if (_LevelsDisplay.Minimum != value) {
					_LevelsDisplay.Minimum = value;

					Refresh();
				}
			}
		}

		/// <summary>Get or set the maximum value</summary>
		[DefaultValue(255)]
		public int Maximum {
			get { return _LevelsDisplay.Maximum; }

			set {
				if (_LevelsDisplay.Maximum != value) {
					_LevelsDisplay.Maximum = value;

					Refresh();
				}
			}
		}

		/// <summary>Get or set the median value (0.0 to 1.0)</summary>
		[DefaultValue(0.5f)]
		public float Median {
			get { return _LevelsDisplay.Median; }

			set {
				if (_LevelsDisplay.Median != value) {
					_LevelsDisplay.Median = value;

					Refresh();
				}
			}
		}

		private bool _Suspended = false;
		/// <summary>Are we drawing the control?</summary>
		public bool Suspended {
			get { return _Suspended; }

			set {
				_Suspended = value;

				if (!_Suspended) {
					Refresh();
				}
			}
		}

		/// <summary>Method called when the control is painted</summary>
		protected override void OnPaint(PaintEventArgs e) {
			if (!Suspended) {
				e.Graphics.Clear(BackColor);

				_LevelsDisplay.Paint(e);
			}
		}

		/// <summary>Event that fires when the minimum, median, or maximum value changes</summary>
		[Browsable(true), Description("Occurs when the minimum, maximum, or median value changes")]
		public event ValueChangedEventHandler ValueChanged;

		private void DisplayValueChanged() {
			if (ValueChanged != null) {
				ValueChanged();
			}
		}

		/// <summary>Method called when the control is resized</summary>
		protected override void OnResize(EventArgs e) {
			Size = new Size(Width, Height);
		}

		/// <summary>Method called when a mouse button is pressed down</summary>
		protected override void OnMouseDown(MouseEventArgs e) {
			if (!Enabled) return;

			_LevelsDisplay.MouseDown(e);

			Focus();
		}

		/// <summary>Method called when a mouse button is released</summary>
		protected override void OnMouseUp(MouseEventArgs e) {
			if (!Enabled) return;

			_LevelsDisplay.MouseUp(e);
		}

		/// <summary>Method called when the mouse moves</summary>
		protected override void OnMouseMove(MouseEventArgs e) {
			if (!Enabled) return;

			_LevelsDisplay.MouseMove(e);
		}

		private int _TopMargin = 5;
		/// <summary>Get or Set TopMargin</summary>
		[Browsable(false)]
		public int TopMargin {
			get { return _TopMargin; }
			set { _TopMargin = value; }
		}

		private int _BottomMargin = 5;
		/// <summary>Get or Set BottomMargin</summary>
		[Browsable(false)]
		public int BottomMargin {
			get { return _BottomMargin; }
			set { _BottomMargin = value; }
		}

		private int _LeftMargin = 5;
		/// <summary>Get or Set LeftMargin</summary>
		[Browsable(false)]
		public int LeftMargin {
			get { return _LeftMargin; }
			set { _LeftMargin = value; }
		}

		private int _RightMargin = 5;
		/// <summary>Get or Set RightMargin</summary>
		[Browsable(false)]
		public int RightMargin {
			get { return _RightMargin; }
			set { _RightMargin = value; }
		}

		/// <summary>Get or Set the size of the control</summary>
		public new Size Size {
			get { return base.Size; }

			set {
				base.Size = value;

				_LevelsDisplay.Size = new Size(ClientRectangle.Width - _LeftMargin - _RightMargin,
					ClientRectangle.Height - _TopMargin - _BottomMargin);

				_LevelsDisplay.Location = new Point(_LeftMargin, _TopMargin);

				Refresh();
			}
		}

		private bool _Enabled = true;
		/// <summary>Is the control enabled?</summary>
		[DefaultValue(true)]
		public new bool Enabled {
			get { return _Enabled; }

			set {
				_LevelsDisplay.Enabled = _Enabled = value;

				Refresh();
			}
		}

		/// <summary>Get or set the array of values</summary>
		[Browsable(false)]
		public int[] Array {
			get { return _LevelsDisplay.Array; }

			set {
				_LevelsDisplay.Array = value;
				Refresh();
			}
		}
	}

	/// <summary>
	/// Class used to draw the main body of the JMLevels control
	/// </summary>
	internal class JMLevelsDisplay {
		private JMLevelsGraph _LevelsGraph;
		private JMLevelsSliderContainer _Sliders;

		public JMLevelsDisplay() {
			_Sliders = new JMLevelsSliderContainer();
			_LevelsGraph = new JMLevelsGraph();

			_Sliders.OnRefresh += new RefreshEventHandler(Refresh);
			_Sliders.OnValueChanged += new ValueChangedEventHandler(SlidersValueChanged);
		}

		public void Paint(PaintEventArgs e) {
			_LevelsGraph.Paint(e);
			_Sliders.Paint(e);
		}

		/// <summary>
		/// Process mouse button being pressed down
		/// </summary>
		/// <param name="e">Mouse data for the event</param>
		public void MouseDown(MouseEventArgs e) {
			if (!Enabled) return;

			_Sliders.MouseDown(e);
		}

		/// <summary>
		/// Process mouse button being released
		/// </summary>
		/// <param name="e">Mouse data for the event</param>
		public void MouseUp(MouseEventArgs e) {
			if (!Enabled) return;

			_Sliders.MouseUp(e);
		}

		/// <summary>
		/// Process the mouse moving
		/// </summary>
		/// <param name="e">e</param>
		public void MouseMove(MouseEventArgs e) {
			if (!Enabled) return;

			_Sliders.MouseMove(e);
		}

		/// <summary>Get or set the maximum value</summary>
		public int Maximum {
			get { return _Sliders.Maximum; }
			set { _Sliders.Maximum = value; }
		}

		/// <summary>Get or set the minimum value</summary>
		public int Minimum {
			get { return _Sliders.Minimum; }
			set { _Sliders.Minimum = value; }
		}

		/// <summary>Get or set the median value (0.0 to 1.0)</summary>
		public float Median {
			get { return _Sliders.Median; }
			set { _Sliders.Median = value; }
		}

		/// <summary>Event that fires when the minimum, median, or maximum value changes</summary>
		internal event ValueChangedEventHandler OnValueChanged;

		private void SlidersValueChanged() {
			if (OnValueChanged != null) {
				OnValueChanged();
			}
		}

		private Size _Size = new Size();
		/// <summary>Get or Set Size</summary>
		public Size Size {
			get { return _Size; }

			set {
				_Size = value;

				_LevelsGraph.Size = new Size(_Size.Width,
					_Size.Height - ControlGap - JMLevelsSliderContainer.Height);

				_Sliders.Size = new Size(_Size.Width, JMLevelsSliderContainer.Height);
			}
		}

		private Point _Location;
		/// <summary>Get or Set Location</summary>
		public Point Location {
			get { return _Location; }

			set {
				_LevelsGraph.Location = _Location = value;

				_Sliders.Location = new Point(_Location.X,
					_Location.Y + Size.Height - JMLevelsSliderContainer.Height);
			}
		}

		/// <summary>Get or Set the display's rectangle</summary>
		public Rectangle Rectangle {
			get {
				return new Rectangle(Location, Size);
			}

			set {
				Size = value.Size;
				Location = value.Location;
			}
		}

		private int _ControlGap = 2;
		/// <summary>Get or Set the gap between the graph and the sliders</summary>
		public int ControlGap {
			get { return _ControlGap; }
			set { _ControlGap = value; }
		}

		/// <summary>Occurs when this class is refreshed</summary>
		public event RefreshEventHandler OnRefresh;

		/// <summary>Force a redraw of the control</summary>
		public void Refresh() {
			if (OnRefresh != null) {
				OnRefresh();
			}
		}

		private bool _Enabled = true;
		/// <summary>Is the control enabled?</summary>
		public bool Enabled {
			get { return _Enabled; }

			set {
				_LevelsGraph.Enabled = _Sliders.Enabled = _Enabled = value;
			}
		}

		/// <summary>Get or set the array of values</summary>
		public int[] Array {
			get { return _LevelsGraph.Array; }
			set { _LevelsGraph.Array = value; }
		}
	}

	/// <summary>
	/// Class used to handle drawing of the graph onto the JMLevelsDisplay
	/// </summary>
	internal class JMLevelsGraph {
		private JMLevelsGraphArea _GraphArea = new JMLevelsGraphArea();

		public JMLevelsGraph() {
		}

		public void Paint(PaintEventArgs e) {
			e.Graphics.DrawLine(Enabled ? SystemPens.ControlText : SystemPens.GrayText, Location,
				new Point(Location.X, Location.Y + Size.Height - 1));

			e.Graphics.DrawLine(Enabled ? SystemPens.ControlText : SystemPens.GrayText,
				new Point(Location.X, Location.Y + Size.Height - 1),
				new Point(Location.X + Size.Width - 1, Location.Y + Size.Height - 1));

			_GraphArea.Paint(e);
		}

		/// <summary>Get or set the color used to draw the graph</summary>
		public Color GraphColor {
			get { return _GraphArea.GraphColor; }
			set { _GraphArea.GraphColor = value; }
		}

		private Size _Size = new Size();
		/// <summary>Get or Set Size</summary>
		public Size Size {
			get { return _Size; }

			set {
				_Size = value;

				_GraphArea.Size = new Size(_Size.Width - 1, _Size.Height - 2);

				UpdateGraphAreaArray();
			}
		}

		private void UpdateGraphAreaArray() {
			if (Array == null) return;

			int GraphSize = _GraphArea.Size.Width;
			int[] NewArray;

			if (Array.Length > GraphSize) {
				NewArray = new int[GraphSize];

				float ratio = 255f / (float)GraphSize;

				float Total;
				float StartPoint;
				float EndPoint;
				float Difference;

				for (int x = 0; x < GraphSize; x++) {
					StartPoint = x * ratio;
					EndPoint = StartPoint + ratio;

					Difference = 1f - (StartPoint - (float)((int)StartPoint));
					Total = (float)Array[(int)StartPoint] * Difference;

					for (int i = (int)StartPoint + 1; i < (int)EndPoint; i++) {
						Total += (float)Array[i];
					}

					Difference = EndPoint - (float)((int)EndPoint);
					Total += (float)Array[(int)EndPoint] * Difference;

					NewArray[x] = (int)((Total / ratio) + 0.5f);
				}
			}
			else if (Array.Length < GraphSize) {
				NewArray = new int[GraphSize];

				float ratio = 255f / (float)GraphSize;

				for (int x = 0; x < GraphSize; x++) {
					float PositionInArray = ratio * x;
					int PreviousPosition = (int)PositionInArray;

					if ((float)PreviousPosition == PositionInArray) {
						NewArray[x] = Array[PreviousPosition];
					}
					else {
						float PreviousValue = (float)Array[PreviousPosition];
						float Difference = (float)Array[PreviousPosition + 1] - PreviousValue;

						NewArray[x] = (int)PreviousValue +
							(int)((Difference * (PositionInArray - PreviousPosition)) + 0.5f);
					}
				}
			}
			else {
				NewArray = Array;
			}

			int Max = 0;

			for (int x = 0; x < GraphSize; x++) {
				if (NewArray[x] > Max) Max = NewArray[x];
			}

			if (Max > 0) {
				float HeightRatio = (float)_GraphArea.Size.Height / (float)Max;

				for (int x = 0; x < GraphSize; x++) {
					NewArray[x] = (int)(((float)NewArray[x] * HeightRatio) + 0.5f);
				}
			}

			_GraphArea.Array = NewArray;
		}

		private Point _Location;
		/// <summary>Get or Set Location</summary>
		public Point Location {
			get { return _Location; }

			set {
				_Location = value;
				_GraphArea.Location = new Point(_Location.X + 1, _Location.Y);
			}
		}

		/// <summary>Get or Set the graph's rectangle</summary>
		public Rectangle Rectangle {
			get {
				return new Rectangle(Location, Size);
			}

			set {
				Size = value.Size;
				Location = value.Location;
			}
		}

		private bool _Enabled = true;
		/// <summary>Is the control enabled?</summary>
		public bool Enabled {
			get { return _Enabled; }

			set { _Enabled = value; }
		}

		private int[] _Array;
		/// <summary>Get or set the array of values</summary>
		public int[] Array {
			get { return _Array; }

			set {
				if (value != null && value.Length == 256) {
					_Array = value;

					UpdateGraphAreaArray();
				}
			}
		}
	}

	/// <summary>
	/// Class used to draw the graph lines onto the control
	/// </summary>
	internal class JMLevelsGraphArea {
		/// <summary>Constructor</summary>
		public JMLevelsGraphArea() {
		}

		public void Paint(PaintEventArgs e) {
			if (_Array != null) {
				Pen pen = new Pen(GraphColor);

				for (int x = 0; x < Array.Length; x++) {
					e.Graphics.DrawLine(pen, x + Location.X, Location.Y + Size.Height,
						x + Location.X, Location.Y + Size.Height - Array[x]);
				}
			}
		}

		private int[] _Array;
		/// <summary>Get or set the _Size.Width length array of values with maximum value of _Size.Height</summary>
		public int[] Array {
			get { return _Array; }

			set {
				if (value != null && value.Length == Size.Width) {
					_Array = value;
				}
			}
		}

		private Size _Size = new Size();
		/// <summary>Get or Set Size</summary>
		public Size Size {
			get { return _Size; }

			set {
				_Size = value;

				if (_Size.Width < 0) _Size.Width = 0;
				if (_Size.Height < 0) _Size.Height = 0;
			}
		}

		private Point _Location;
		/// <summary>Get or Set Location</summary>
		public Point Location {
			get { return _Location; }
			set { _Location = value; }
		}

		/// <summary>Get or Set the graph's rectangle</summary>
		public Rectangle Rectangle {
			get {
				return new Rectangle(Location, Size);
			}

			set {
				Size = value.Size;
				Location = value.Location;
			}
		}

		private Color _GraphColor = Color.Blue;
		/// <summary>Get or set the color used to draw the graph</summary>
		public Color GraphColor {
			get { return _GraphColor; }
			set { _GraphColor = value; }
		}
	}

	/// <summary>
	/// Class used to handle drawing of the sliders onto the JMLevelsDisplay
	/// </summary>
	internal class JMLevelsSliderContainer {
		private JMLevelsSlider _MinimumSlider;
		private JMLevelsSlider _MaximumSlider;
		private JMLevelsSlider _MedianSlider;

		/// <summary>Array of pointers to the sliders, in top-down order</summary>
		private JMLevelsSlider[] _Sliders;

		public JMLevelsSliderContainer() {
			_MinimumSlider = new JMLevelsSlider(Color.Black, 0, this);
			_MinimumSlider.MinimumValue = 0;
			_MinimumSlider.MaximumValue = 253;
			_MinimumSlider.OnRefresh += new RefreshEventHandler(Refresh);
			_MinimumSlider.OnSliderMoved +=
				new JMLevelsSlider.SliderMovedEventHandler(MinimumSliderMoved);

			_MaximumSlider = new JMLevelsSlider(Color.White, 255, this);
			_MaximumSlider.MinimumValue = 2;
			_MaximumSlider.MaximumValue = 255;
			_MaximumSlider.OnRefresh += new RefreshEventHandler(Refresh);
			_MaximumSlider.OnSliderMoved +=
				new JMLevelsSlider.SliderMovedEventHandler(MaximumSliderMoved);

			_MedianSlider = new JMLevelsSlider(Color.LightGray, 128, this);
			_MedianSlider.MinimumValue = 1;
			_MedianSlider.MaximumValue = 254;
			_MedianSlider.OnRefresh += new RefreshEventHandler(Refresh);
			_MedianSlider.OnSliderMoved +=
				new JMLevelsSlider.SliderMovedEventHandler(MedianSliderMoved);

			_Sliders = new JMLevelsSlider[] { _MinimumSlider, _MaximumSlider, _MedianSlider };
		}

		/// <summary>
		/// Bring the specified slider to the front of the array
		/// </summary>
		/// <param name="slider">slider to move</param>
		public void BringToFront(JMLevelsSlider slider) {
			JMLevelsSlider[] sliders = new JMLevelsSlider[_Sliders.Length];

			sliders[0] = slider;

			int pos = 1;

			for (int x = 0; x < _Sliders.Length; x++) {
				if (_Sliders[x] != slider) {
					sliders[pos] = _Sliders[x];
					pos++;
				}
			}

			_Sliders = sliders;
		}

		private void MinimumSliderMoved(int PreviousValue) {
			if (PreviousValue == _MinimumSlider.Value) return;

			_MaximumSlider.MinimumValue = _MinimumSlider.Value + 2;
			_MedianSlider.MinimumValue = _MinimumSlider.Value + 1;
			UpdateMedianSlider();

			if (OnValueChanged != null) {
				OnValueChanged();
			}
		}

		private void MaximumSliderMoved(int PreviousValue) {
			if (PreviousValue == _MaximumSlider.Value) return;

			_MinimumSlider.MaximumValue = _MaximumSlider.Value - 2;
			_MedianSlider.MaximumValue = _MaximumSlider.Value - 1;
			UpdateMedianSlider();

			if (OnValueChanged != null) {
				OnValueChanged();
			}
		}

		private void MedianSliderMoved(int PreviousValue) {
			if (PreviousValue == _MedianSlider.Value) return;

			Median = (float)(_MedianSlider.Value - Minimum) / (float)(Maximum - Minimum);

			if (OnValueChanged != null) {
				OnValueChanged();
			}
		}

		/// <summary>Update the position of the median slider according to _Median</summary>
		private void UpdateMedianSlider() {
			_MedianSlider.Value = (int)(((float)(_MaximumSlider.Value - _MinimumSlider.Value) * Median) + 0.5f) + _MinimumSlider.Value;
		}

		/// <summary>Event that fires when the minimum, median, or maximum value changes</summary>
		internal event ValueChangedEventHandler OnValueChanged;

		public void Paint(PaintEventArgs e) {
			e.Graphics.DrawLine(SystemPens.ControlLightLight,
				new Point(Location.X, Location.Y + Size.Height - 1),
				new Point(Location.X + Size.Width - 1, Location.Y + Size.Height - 1));

			e.Graphics.DrawLine(SystemPens.ControlLightLight,
				new Point(Location.X + Size.Width - 1, Location.Y),
				new Point(Location.X + Size.Width - 1, Location.Y + Size.Height - 1));

			e.Graphics.DrawLine(Enabled ? SystemPens.ControlDarkDark : SystemPens.GrayText,
				Location, new Point(Location.X, Location.Y + Size.Height - 1));

			e.Graphics.DrawLine(Enabled ? SystemPens.ControlDarkDark : SystemPens.GrayText,
				Location, new Point(Location.X + Size.Width - 1, Location.Y));

			for (int x = _Sliders.Length - 1; x > -1; x--) {
				_Sliders[x].Paint(e);
			}
		}

		/// <summary>
		/// Process mouse button being pressed down
		/// </summary>
		/// <param name="e">Mouse data for the event</param>
		public void MouseDown(MouseEventArgs e) {
			if (!Enabled) return;

			if (!DraggingSlider) {
				for (int x = 0; x < _Sliders.Length; x++) {
					//if (_Sliders[x].Rectangle.Contains(e.Location)) {	// .Net 2.0
					if (_Sliders[x].Rectangle.Contains(new Point(e.X, e.Y))) {
						_Sliders[x].MouseDown(e);
						break;
					}
				}
			}
		}

		/// <summary>
		/// Process mouse button being released
		/// </summary>
		/// <param name="e">Mouse data for the event</param>
		public void MouseUp(MouseEventArgs e) {
			if (!Enabled) return;

			if (DraggingSlider) {
				for (int x = 0; x < _Sliders.Length; x++) {
					_Sliders[x].MouseUp(e);
				}
			}
		}

		/// <summary>
		/// Process the mouse moving
		/// </summary>
		/// <param name="e">e</param>
		public void MouseMove(MouseEventArgs e) {
			if (!Enabled) return;

			if (DraggingSlider) {
				for (int x = 0; x < _Sliders.Length; x++) {
					_Sliders[x].MouseMove(e);
				}
			}
		}

		/// <summary>Occurs when this class is refreshed</summary>
		public event RefreshEventHandler OnRefresh;

		/// <summary>Force a redraw of the control</summary>
		public void Refresh() {
			if (OnRefresh != null) {
				OnRefresh();
			}
		}

		private Size _Size = new Size();
		/// <summary>Get or Set Size</summary>
		public Size Size {
			get { return _Size; }

			set {
				if (value.Height == Height) {
					_Size = value;
				}
				else {
					_Size = new Size(value.Width, Height);
				}
			}
		}

		private Point _Location;
		/// <summary>Get or Set Location</summary>
		public Point Location {
			get { return _Location; }
			set { _Location = value; }
		}

		/// <summary>Fixed height of the slider area</summary>
		public const int Height = 12;

		/// <summary>Get or Set the slider area rectangle</summary>
		public Rectangle Rectangle {
			get {
				return new Rectangle(Location, Size);
			}

			set {
				Size = value.Size;
				Location = value.Location;
			}
		}

		/// <summary>Get or set the minimum value</summary>
		public int Minimum {
			get {
				return _MinimumSlider.Value;
			}

			set {
				_MinimumSlider.Value = value;
			}
		}

		/// <summary>Get or set the maximum value</summary>
		public int Maximum {
			get {
				return _MaximumSlider.Value;
			}

			set {
				_MaximumSlider.Value = value;
			}
		}

		private float _Median = 0.5f;
		/// <summary>Get or set Median</summary>
		public float Median {
			get { return _Median; }

			set {
				if (value < 0f) _Median = 0f;
				else if (value > 1f) _Median = 1f;
				else _Median = value;

				UpdateMedianSlider();
			}
		}

		private bool _DraggingSlider = false;
		/// <summary>Get or set DraggingSlider</summary>
		public bool DraggingSlider {
			get { return _DraggingSlider; }
			set { _DraggingSlider = value; }
		}

		private bool _Enabled = true;
		/// <summary>Is the control enabled?</summary>
		public bool Enabled {
			get { return _Enabled; }

			set {
				_Enabled = value;

				for (int x = 0; x < _Sliders.Length; x++) {
					_Sliders[x].Enabled = value;
				}
			}
		}
	}

	/// <summary>
	/// Class used to draw a slider onto the control
	/// </summary>
	internal class JMLevelsSlider {
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="color">Color of the slider's body</param>
		/// <param name="value">Initial value of the slider</param>
		/// <param name="container">Object that contains this slider</param>
		public JMLevelsSlider(Color color, int value, JMLevelsSliderContainer container) {
			Color = color;
			Value = value;

			_Container = container;
		}

		private JMLevelsSliderContainer _Container;

		private Color _Color;
		/// <summary>Get or set the fill color</summary>
		public Color Color {
			get { return _Color; }
			set { _Color = value; }
		}

		private int _Value;
		/// <summary>Get or set the value of this slider (MinimumValue->MaximumValue)</summary>
		public int Value {
			get { return _Value; }

			set {
				if (_Value != value) {
					int oldValue = _Value;

					if (value < MinimumValue) {
						_Value = MinimumValue;
					}
					else if (value > MaximumValue) {
						_Value = MaximumValue;
					}
					else {
						_Value = value;
					}

					if (OnValueChanged != null) {
						OnValueChanged(oldValue);
					}
				}
			}
		}

		private int _MinimumValue = 0;
		/// <summary>Get or set the lowest allowed value</summary>
		public int MinimumValue {
			get { return _MinimumValue; }

			set {
				_MinimumValue = value;

				if (Value < _MinimumValue) {
					Value = _MinimumValue;
				}

				if (_MinimumValue > MaximumValue - 2) {
					_MinimumValue = MaximumValue - 2;
				}
			}
		}

		private int _MaximumValue = 255;
		/// <summary>Get or set the highest allowed value</summary>
		public int MaximumValue {
			get { return _MaximumValue; }

			set {
				_MaximumValue = value;

				if (Value > _MaximumValue) {
					Value = _MaximumValue;
				}

				if (_MaximumValue < MinimumValue + 2) {
					_MaximumValue = MinimumValue + 2;
				}
			}
		}

		/// <summary>The size of each slider</summary>
		public static Size SliderSize = new Size(11, JMLevelsSliderContainer.Height - 1);

		public void Paint(PaintEventArgs e) {
			Rectangle rect = Rectangle;

			Point[] points =
				new Point[] {
								new Point(rect.X + (rect.Width / 2), rect.Y),
								new Point(rect.X + rect.Width - 1, rect.Y + rect.Height / 2),
								new Point(rect.X + rect.Width - 1, rect.Y + rect.Height),
								new Point(rect.X, rect.Y + rect.Height),
								new Point(rect.X, rect.Y + rect.Height / 2),
								new Point(rect.X + (rect.Width / 2), rect.Y)
							};

			e.Graphics.FillPolygon(new SolidBrush(Color), points);
			e.Graphics.DrawLines(Enabled ? SystemPens.ControlText : SystemPens.GrayText, points);
		}

		/// <summary>Get the rectangle containing the slider</summary>
		public Rectangle Rectangle {
			get {
				int offset =
					(int)((((float)(_Container.Size.Width - 1) / 255f) * (float)Value) + 0.5 - ((float)SliderSize.Width / 2f));

				return new Rectangle(new Point(_Container.Location.X + offset, _Container.Location.Y), SliderSize);
			}
		}

		/// <summary>
		/// Calculate the new Value given the physical location x
		/// </summary>
		/// <param name="x">Physical x location on the control</param>
		public void UpdateValue(int x) {
			Value = (int)(((255f / (float)_Container.Size.Width) * (x - _Container.Location.X)) + 0.5);
		}

		/// <summary>Is the mouse down and moving this slider</summary>
		private bool _Dragging = false;

		/// <summary>
		/// Process mouse button being pressed down
		/// </summary>
		/// <param name="e">Mouse data for the event</param>
		public void MouseDown(MouseEventArgs e) {
			if (!Enabled) return;

			//if (Rectangle.Contains(e.Location) && e.Button == MouseButtons.Left) {	// .Net 2.0
			if (Rectangle.Contains(new Point(e.X, e.Y)) && e.Button == MouseButtons.Left && AcceptMouseInput) {
				_Container.DraggingSlider = _Dragging = true;
				_Container.BringToFront(this);
			}
		}

		/// <summary>
		/// Process mouse button being released
		/// </summary>
		/// <param name="e">Mouse data for the event</param>
		public void MouseUp(MouseEventArgs e) {
			if (!Enabled) return;

			if (_Dragging && AcceptMouseInput) {
				_Container.DraggingSlider = _Dragging = false;
			}
		}

		/// <summary>
		/// Process the mouse moving
		/// </summary>
		/// <param name="e">e</param>
		public void MouseMove(MouseEventArgs e) {
			if (!Enabled) return;

			if (_Dragging && AcceptMouseInput) {
				int previous = Value;

				UpdateValue(e.X);
				Refresh();

				if (OnSliderMoved != null) {
					OnSliderMoved(previous);
				}
			}
		}

		/// <summary>Force a redraw of the control</summary>
		public void Refresh() {
			if (OnRefresh != null) {
				OnRefresh();
			}
		}

		private bool _Enabled = true;
		/// <summary>Is the control enabled?</summary>
		public bool Enabled {
			get { return _Enabled; }
			set { _Enabled = value; }
		}

		private bool _AcceptMouseInput = true;
		/// <summary>Get or set whether this slider accepts changes from the mouse</summary>
		public bool AcceptMouseInput {
			get { return _AcceptMouseInput; }
			set { _AcceptMouseInput = value; }
		}

		/// <summary>Occurs when this class is refreshed</summary>
		public event RefreshEventHandler OnRefresh;

		/// <summary>Delegated method called when Value changes</summary>
		/// <param name="previousValue">Value before it changed</param>
		internal delegate void ValueChangedEventHandler(int previousValue);

		/// <summary>Event that occurs when Value changes</summary>
		public event ValueChangedEventHandler OnValueChanged;

		/// <summary>Delegate for the OnSliderMoved event</summary>
		/// <param name="oldValue">The previous slider value</param>
		public delegate void SliderMovedEventHandler(int oldValue);

		/// <summary>Event called when the slider has moved</summary>
		public event SliderMovedEventHandler OnSliderMoved;
	}

	/// <summary>Delegate used for OnRefresh events</summary>
	internal delegate void RefreshEventHandler();

	/// <summary>Delegate used for ValueChanged events</summary>
	public delegate void ValueChangedEventHandler();
}
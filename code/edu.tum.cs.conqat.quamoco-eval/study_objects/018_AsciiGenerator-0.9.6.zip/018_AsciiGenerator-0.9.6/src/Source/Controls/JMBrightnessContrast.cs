using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace JMSoftware.Controls
{
	public partial class JMBrightnessContrast : UserControl
	{
		/// <summary>Constructor</summary>
		public JMBrightnessContrast() {
			InitializeComponent();

			MinimumContrast = -100;
			MaximumContrast = 100;
			MinimumBrightness = -200;
			MaximumBrightness = 200;
		}

		private void trkBrightness_Scroll(object sender, EventArgs e) {
			Brightness = trkBrightness.Value;
		}

		private void trkContrast_Scroll(object sender, EventArgs e) {
			Contrast = trkContrast.Value;
		}

		private void udBrightness_ValueChanged(object sender, EventArgs e) {
			Brightness = (int)udBrightness.Value;
		}

		private void udContrast_ValueChanged(object sender, EventArgs e) {
			Contrast = (int)udContrast.Value;
		}

		private void trkBrightness_MouseDown(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Left) {
				_MouseDown = true;
			}
		}

		private void trkBrightness_MouseUp(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Left) {
				_MouseDown = false;

				UpdateBrightnessChanged();
			}
		}

		private void trkContrast_MouseDown(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Left) {
				_MouseDown = true;
			}
		}

		private void trkContrast_MouseUp(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Left) {
				_MouseDown = false;

				UpdateContrastChanged();
			}
		}

		private void UpdateBrightnessChanged() {
			if (BrightnessChanged != null) {
				BrightnessChanged(this, new EventArgs());
			}

			if (ValueChanged != null) {
				ValueChanged(this, new EventArgs());
			}
		}

		private void UpdateBrightnessChanging() {
			if (BrightnessChanging != null) {
				BrightnessChanging(this, new EventArgs());
			}

			if (ValueChanging != null) {
				ValueChanging(this, new EventArgs());
			}
		}

		private void UpdateContrastChanged() {
			if (ContrastChanged != null) {
				ContrastChanged(this, new EventArgs());
			}

			if (ValueChanged != null) {
				ValueChanged(this, new EventArgs());
			}
		}

		private void UpdateContrastChanging() {
			if (ContrastChanging != null) {
				ContrastChanging(this, new EventArgs());
			}

			if (ValueChanging != null) {
				ValueChanging(this, new EventArgs());
			}
		}

		/// <summary>
		/// Reset the brightness and contrast to their default values
		/// </summary>
		public void Reset() {
			Suspended = true;

			bool brightnessupdated = false;
			bool contrastupdated = false;

			if (Brightness != 0) {
				Brightness = 0;

				brightnessupdated = true;
			}

			if (Contrast != 0) {
				Contrast = 0;

				contrastupdated = true;
			}

			Suspended = false;

			if (brightnessupdated) {
				UpdateBrightnessChanged();
			}
			else {
				if (contrastupdated) {
					UpdateContrastChanged();
				}
			}
		}

		#region Properties and variables

		private bool _MouseDown;

		private int _Brightness = 0;
		/// <summary>Get and set the current brightness</summary>
		[DefaultValue(0)]
		public int Brightness {
			get { return _Brightness; }

			set {
				if (_Brightness != value) {
					_Brightness = Math.Max(Math.Min(value, MaximumBrightness), MinimumBrightness);

					udBrightness.Value = trkBrightness.Value = _Brightness;

					if (!Suspended) {
						udBrightness.Refresh();

						if (_MouseDown) {
							UpdateBrightnessChanging();
						}
						else {
							UpdateBrightnessChanged();
						}
					}
				}
			}
		}

		private int _Contrast = 0;
		/// <summary>Get and set the current contrast</summary>
		[DefaultValue(0)]
		public int Contrast {
			get { return _Contrast; }

			set {
				if (_Contrast != value) {
					_Contrast = Math.Max(Math.Min(value, MaximumContrast), MinimumContrast);

					udContrast.Value = trkContrast.Value = _Contrast;

					if (!Suspended) {
						udContrast.Refresh();

						if (_MouseDown) {
							UpdateContrastChanging();
						}
						else {
							UpdateContrastChanged();
						}
					}
				}
			}
		}

		/// <summary>Get and set the text shown on the brightness label</summary>
		[DefaultValue("Brightness:")]
		public string BrightnessLabel {
			set {
				lblBrightness.Text = value;
			}

			get {
				return lblBrightness.Text;
			}
		}

		/// <summary>Get and set the text shown on the contrast label</summary>
		[DefaultValue("Contrast:")]
		public string ContrastLabel {
			set {
				lblContrast.Text = value;
			}

			get {
				return lblContrast.Text;
			}
		}

		private int _MaximumBrightness = 200;
		/// <summary>Get and set the maximum brightness value</summary>
		[DefaultValue(200)]
		public int MaximumBrightness {
			get {
				return _MaximumBrightness;
			}
			set {
				udBrightness.Maximum = trkBrightness.Maximum = _MaximumBrightness = value;
				trkBrightness.TickFrequency = (_MaximumBrightness - _MinimumBrightness) / 20;
			}
		}

		private int _MinimumBrightness = -200;
		/// <summary>Get and set the minimum brightness value</summary>
		[DefaultValue(-200)]
		public int MinimumBrightness {
			get {
				return _MinimumBrightness;
			}
			set {
				udBrightness.Minimum = trkBrightness.Minimum = _MinimumBrightness = value;
				trkBrightness.TickFrequency = (_MaximumBrightness - _MinimumBrightness) / 20;
			}
		}

		private int _MaximumContrast = 100;
		/// <summary>
		/// Get and set the maximum contrast value
		/// </summary>
		[DefaultValue(100)]
		public int MaximumContrast {
			get {
				return _MaximumContrast;
			}
			set {
				udContrast.Maximum = trkContrast.Maximum = _MaximumContrast = value;
				trkContrast.TickFrequency = (_MaximumContrast - _MinimumContrast) / 20;
			}
		}

		private int _MinimumContrast = -100;
		/// <summary>
		/// Get and set the minimum contrast value
		/// </summary>
		[DefaultValue(-100)]
		public int MinimumContrast {
			get {
				return _MinimumContrast;
			}
			set {
				udContrast.Minimum = trkContrast.Minimum = _MinimumContrast = value;
				trkContrast.TickFrequency = (_MaximumContrast - _MinimumContrast) / 20;
			}
		}

		/// <summary>Event raised when the brightness value changes</summary>
		public event EventHandler BrightnessChanged = null;

		/// <summary>Event raised when the brightness value is changing</summary>
		public event EventHandler BrightnessChanging = null;

		/// <summary>Event raised when the contrast value changes</summary>
		public event EventHandler ContrastChanged = null;

		/// <summary>Event raised when the contrast value is changing</summary>
		public event EventHandler ContrastChanging = null;

		/// <summary>Event raised when a value is changing</summary>
		public event EventHandler ValueChanging = null;

		/// <summary>Event raised when a value changes</summary>
		public event EventHandler ValueChanged = null;

		private bool _Suspended = false;
		/// <summary>Are we drawing the control?</summary>
		public bool Suspended {
			get { return _Suspended; }

			set {
				_Suspended = value;

				if (!_Suspended) {
					Refresh();
				}
			}
		}

		#endregion
	}
}
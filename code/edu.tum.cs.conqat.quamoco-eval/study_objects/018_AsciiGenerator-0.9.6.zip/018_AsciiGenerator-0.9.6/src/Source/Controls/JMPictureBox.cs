//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: JMPictureBox.cs,v 1.26 2008/01/31 15:32:02 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace JMSoftware.CustomControl {
	/// <summary>
	/// Summary description for JMPictureBox.
	/// </summary>
	public class JMPictureBox : System.Windows.Forms.Label {
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Constructor
		/// </summary>
		public JMPictureBox() {
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			SetStyle(ControlStyles.ResizeRedraw, true);
			SetStyle(ControlStyles.UserPaint, true );
			SetStyle(ControlStyles.AllPaintingInWmPaint, true );
			SetStyle(ControlStyles.DoubleBuffer, true );
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) {
			if( disposing ) {
				if(components != null) {
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			components = new System.ComponentModel.Container();
		}
		#endregion


		/// <summary>
		/// Handle painting the control
		/// </summary>
		/// <param name="e">Provides data for the Paint event</param>
		protected override void OnPaint(PaintEventArgs e) {
			if (!ImageLocation.Contains(e.ClipRectangle)) {
				e.Graphics.FillRectangle(new SolidBrush(BackColor), e.ClipRectangle);
			}

			if (_Image != null) {
				if (!DrawingImage)
					return;

				if (e.ClipRectangle.IntersectsWith(ImageLocation)) {
					if (_BCResizedImage == null)
						CreateBCResizedImageFromResizedImage();

					if (ImageUpscaled) {
						e.Graphics.InterpolationMode = _InterpolationMode;

						// avoid DrawImage() bug(?) that offsets small images by -0.5 pixels in each direction
						e.Graphics.PixelOffsetMode = PixelOffsetMode.Half;

						e.Graphics.DrawImage(_BCResizedImage, ImageLocation);
					} 
					else {
						e.Graphics.DrawImageUnscaled(_BCResizedImage, ImageLocation);
					}
				}
			}
			else {
				using (Font font = new Font("Microsoft Sans Serif", 8.25f)) {					
					using (StringFormat f = new StringFormat()) {
						f.Alignment = StringAlignment.Center;
						f.LineAlignment = StringAlignment.Center;

						e.Graphics.DrawString(Text, font, Brushes.DarkGray, ClientRectangle, f);
					}
				}
			}
		}

		/// <summary>
		/// Calculate a new ImageLocation for the image
		/// </summary>
		/// <returns>Did the size of the rectangle change?</returns>
		private bool CalculateImageLocation() {
			if (Image != null) {
				// Store the previous rectangle size
				Size OldSize = ImageLocation.Size;

				Size DisplaySize = new Size(DisplayRectangle.Width - 1, DisplayRectangle.Height - 1);

				switch (_SizeMode) {
					case JMPictureBoxSizeMode.Stretch:
						ImageLocation = new Rectangle(0, 0, DisplaySize.Width, DisplaySize.Height);
						break;

					case JMPictureBoxSizeMode.FitCenter:
						ImageLocation = new Rectangle(0, 0, 0, 0);

						float fImageRatio = (float)Image.Width / (float)Image.Height;
						float fAreaRatio = (float)DisplaySize.Width / (float)DisplaySize.Height;

						// if the Control is wider then the image
						if (fAreaRatio > fImageRatio) {
							ImageLocation.Height = DisplaySize.Height;
							ImageLocation.Width = (int)((fImageRatio * (float)DisplaySize.Height) + 0.5);
							ImageLocation.X = (DisplaySize.Width - ImageLocation.Width) / 2;
						}
						else {
							ImageLocation.Width = DisplaySize.Width;
							ImageLocation.Height = (int)(((float)DisplaySize.Width / (float)fImageRatio) + 0.5);
							ImageLocation.Y = (DisplaySize.Height - ImageLocation.Height) / 2;
						}

						break;

					case JMPictureBoxSizeMode.Center:
						ImageLocation = new Rectangle((DisplaySize.Width - Image.Width) / 2, (DisplaySize.Height - Image.Height) / 2,
							Image.Width, Image.Height);
						break;

					default:
					case JMPictureBoxSizeMode.Normal:
						ImageLocation = new Rectangle(0, 0, Image.Width, Image.Height);
						break;
				}

                ImageUpscaled = _Image.Width < ImageLocation.Width || _Image.Height < ImageLocation.Height;

				return (ImageLocation.Size != OldSize);
			}
			else
				return false;
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.Resize event.
		/// </summary>
		/// <param name="e">An System.EventArgs that contains the event data.</param>
		protected override void OnResize(EventArgs e) {
			if (CalculateImageLocation()) {
				DisposeIfOnlyOneReference(_ResizedImage);
				_ResizedImage = null;

				CreateBCResizedImageFromBCImage();
			}

			base.OnResize(e);
		}

		/// <summary>
		/// Forces the control to invalidate its client area and immediately redraw itself and any child controls.
		/// </summary>
		public override void Refresh() {
			if (_DrawingImage)
				base.Refresh();
		}

		/// <summary>
		/// Create _BCResizedImage from _ResizedImage
		/// </summary>
		private void CreateBCResizedImageFromResizedImage() {
			if (_Image == null || !_DrawingImage || ImageLocation.Width == 0 || ImageLocation.Height == 0)
				return;

			if (_Image.Width < ImageLocation.Width || _Image.Height < _Image.Height) {
				DisposeIfOnlyOneReference(_ResizedImage);
				_ResizedImage = (Bitmap)_Image;
			}
			else {
				if (_ResizedImage == null) {
					_ResizedImage = new Bitmap(ImageLocation.Width, ImageLocation.Height, PixelFormat.Format24bppRgb);

					using (Graphics g = Graphics.FromImage(_ResizedImage)) {
						g.InterpolationMode = _InterpolationMode;

						g.DrawImage(_Image, 0, 0, ImageLocation.Width, ImageLocation.Height);
					}
				}
			}

			DisposeIfOnlyOneReference(_BCResizedImage);
			_BCResizedImage = new Bitmap(_ResizedImage.Width, _ResizedImage.Height, PixelFormat.Format24bppRgb);

			using (Graphics g = Graphics.FromImage(_BCResizedImage)) {
				using (ImageAttributes ia = new ImageAttributes()) {
					ia.SetColorMatrix(JMSoftware.Matrices.BrightnessContrast(_fBrightness, _fContrast));

					g.DrawImage(_ResizedImage, new Rectangle(0, 0, _ResizedImage.Width, _ResizedImage.Height),
						0, 0, _ResizedImage.Width, _ResizedImage.Height, GraphicsUnit.Pixel, ia);
				}
			}
		}

		/// <summary>
		/// Create _BCResizedImage from _BCImage
		/// </summary>
		private void CreateBCResizedImageFromBCImage() {
			if (_Image == null || !_DrawingImage || ImageLocation.Width == 0 || ImageLocation.Height == 0)
				return;

			if (_BCImage == null) {
				_BCImage = new Bitmap(_Image.Width, _Image.Height, PixelFormat.Format24bppRgb);

				using (Graphics g = Graphics.FromImage(_BCImage)) {
					using (ImageAttributes ia = new ImageAttributes()) {
						ia.SetColorMatrix(JMSoftware.Matrices.BrightnessContrast(_fBrightness, _fContrast));

						g.DrawImage(_Image, new Rectangle(0, 0, _Image.Width, _Image.Height),
							0, 0, _Image.Width, _Image.Height, GraphicsUnit.Pixel, ia);
					}
				}
			}

			DisposeIfOnlyOneReference(_BCResizedImage);

			if (_BCImage.Width < ImageLocation.Width || _BCImage.Height < ImageLocation.Height) {
				_BCResizedImage = _BCImage;
			}
			else {
				_BCResizedImage = new Bitmap(ImageLocation.Width, ImageLocation.Height, PixelFormat.Format24bppRgb);

				using (Graphics g = Graphics.FromImage(_BCResizedImage)) {
					g.InterpolationMode = _InterpolationMode;

					g.DrawImage(_BCImage, 0, 0, ImageLocation.Width, ImageLocation.Height);
				}
			}
		}

		/// <summary>
		/// Dispose the bitmap in memory if it is only referenced once
		/// </summary>
		/// <param name="bitmap">The bitmap to possibly dispose</param>
		private void DisposeIfOnlyOneReference(Bitmap bitmap) {
			if (bitmap == null)
				return;

			int iCount = 0;

			if (bitmap == (Bitmap)_Image)
				iCount++;

			if (bitmap == _BCImage)
				iCount++;

			if (bitmap == _ResizedImage)
				iCount++;

			if (bitmap == _BCResizedImage)
				iCount++;

			if (iCount == 1)
				bitmap.Dispose();
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.MouseDown event.
		/// </summary>
		/// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
		protected override void OnMouseDown(MouseEventArgs e) {
			this.Focus();

			base.OnMouseDown (e);
		}

		/// <summary>
		/// Rotate the image
		/// </summary>
		public virtual void RotateImage(RotateFlipType type) {
			// create a new image
			Image NewImage = new Bitmap(Image);

			NewImage.RotateFlip(type);

			Image = NewImage;
		}

		#region Properties and Variables
		/// <summary>The size and position of the image on the control</summary>
		protected Rectangle ImageLocation;

		private Bitmap _BCImage;
        /// <summary>_Image with Brightness/Contrast applied</summary>
        public Image BCImage {
            get {
                if (_BCImage == null) {
                    CreateBCResizedImageFromBCImage();
                }

                return _BCImage;
            }
        }

        /// <summary>_Image resized to ImageLocation.Width and ImageLocation.Height</summary>
		private Bitmap _ResizedImage;

		/// <summary>_Image with Brightness/Contrast applied, size less then or equal to ImageLocation</summary>
		/// <remarks>This is the finished image that is drawn onto the control</remarks>
		private Bitmap _BCResizedImage;

		/// <summary>The original image</summary>
		private Image _Image;

        /// <summary>Has the image has been stretched to fit the area?</summary>
        protected bool ImageUpscaled;

		/// <summary>Get and set the unaltered image</summary>
		[DefaultValue(null), Category("Appearance"), Description("Image to be Displayed")]
		public new Image Image {
			get {
				return _Image;
			}
			set {
				DisposeIfOnlyOneReference((Bitmap)_Image);
				_Image = value;

				DisposeIfOnlyOneReference(_ResizedImage);
				_ResizedImage = null;

				DisposeIfOnlyOneReference(_BCImage);
				_BCImage = null;

				DisposeIfOnlyOneReference(_BCResizedImage);
				_BCResizedImage = null;

				CalculateImageLocation();

				Refresh();
			}
		}

		// TODO: Add options ResizeToFit, ???
		/// <summary>New SizeMode enumerator</summary>
		public enum JMPictureBoxSizeMode {
			/// <summary>Picture displayed at the top left corner without any stretching</summary>
			Normal,
			/// <summary>Stretch the image to fit the control</summary>
			Stretch,
			/// <summary>Center the image in the control without resizing</summary>
			Center,
			/// <summary>Center and stretch the image to the control, keeping its aspect ratio</summary>
			FitCenter
		}

		/// <summary>Mode to use when drawing the image onto the control</summary>
		private JMPictureBoxSizeMode _SizeMode = JMPictureBoxSizeMode.Normal;
		/// <summary>
		/// Get and set how the image is displayed in the control
		/// </summary>
		[DefaultValue(JMPictureBoxSizeMode.Normal), Category("Appearance"), Description("Method used to draw the image on the control")]
		public JMPictureBoxSizeMode SizeMode {
			get {
				return _SizeMode;
			}
			set {
				if (_SizeMode != value) {
					_SizeMode = value;

					if (CalculateImageLocation()) {
						DisposeIfOnlyOneReference(_ResizedImage);
						_ResizedImage = null;

						DisposeIfOnlyOneReference(_BCResizedImage);
						_BCResizedImage = null;
					}

					Refresh();
				}
			}
		}

		/// <summary>InterpolationMode to use when drawing the image</summary>
		private InterpolationMode _InterpolationMode = InterpolationMode.Default;
		/// <summary>
		/// Get and set the InterpolationMode used to draw the image
		/// </summary>
		[DefaultValue(InterpolationMode.Default), Category("Appearance"), Description("InterpolationMode for drawing the image.")]
		public InterpolationMode InterpolationMode {			
			get {
				return _InterpolationMode;
			}
			set {
				// don't allow the Invalid value
				// TODO: Remove InterpolationMode and replace with a new enum that doesn't contain Invalid
				_InterpolationMode = (value != InterpolationMode.Invalid) ? value : InterpolationMode.Default;

				// repaint the control
				Refresh();
			}
		}

		/// <summary>Level of brightness to apply to the image, 0.0f = no change</summary>
		private float _fBrightness;
		/// <summary>
		/// Level of brightness to apply to the image.
		/// </summary>
		[DefaultValue(0.0f), Category("Appearance"), Description("Level of brightness to apply to the image.")]
		public float Brightness {
			get {
				return _fBrightness;
			}
			set {
				_fBrightness = value;

				DisposeIfOnlyOneReference(_BCImage);
				_BCImage = null;


				DisposeIfOnlyOneReference((Bitmap)_BCResizedImage);
				_BCResizedImage = null;

				Refresh();
			}
		}

		/// <summary>Level of contrast to apply to the image, 1.0f = no change</summary>
		private float _fContrast = 1.0f;
		/// <summary>
		/// Level of contrast to apply to the image.
		/// </summary>
		[DefaultValue(1.0f), Category("Appearance"), Description("Level of contrast to apply to the image.")]
		public float Contrast {
			get {
				return _fContrast;
			}
			set {
				_fContrast = value;

				DisposeIfOnlyOneReference(_BCImage);
				_BCImage = null;

				DisposeIfOnlyOneReference(_BCResizedImage);
				_BCResizedImage = null;

				Refresh();
			}
		}

		private bool _DrawingImage = true;
		/// <summary>
		/// Get and set boolean - should the image be drawn?
		/// </summary>
		public bool DrawingImage {
			get {
				return _DrawingImage;
			}

			set {
				_DrawingImage = value;

				if (_DrawingImage)
					Refresh();
			}
		}

		#endregion
	}
}
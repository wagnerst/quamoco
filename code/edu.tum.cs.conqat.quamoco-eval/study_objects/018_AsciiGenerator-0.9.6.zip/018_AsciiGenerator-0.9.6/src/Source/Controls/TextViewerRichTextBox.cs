﻿//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: TextViewerRichTextBox.cs,v 1.2 2008/02/10 14:10:26 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Windows.Forms;
using JMSoftware.Interfaces;

namespace JMSoftware.CustomControl
{
	/// <summary>
	/// Class to give an ITextViewer interface to a RichTextBox
	/// </summary>
	public class TextViewerRichTextBox : RichTextBox, ITextViewer
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public TextViewerRichTextBox() {
		}

		/// <summary>Select all of the text</summary>
		public new void SelectAll() {
			base.SelectAll();

			// Give the control focus to avoid "not looking selected" problem
			base.Select();
		}

		/// <summary>Stop selecting the text</summary>
		public void SelectNone() {
			base.Select(base.SelectionStart + base.SelectionLength, 0);
		}

		/// <summary>Is the text empty?</summary>
		public bool IsEmpty {
			get {
				return Text.Length == 0;
			}
		}

		/// <summary>Get and set the lines of text</summary>
		public new string[] Lines {
			get {
				return base.Lines;
			}

			set {
				base.Lines = value;

				Update();
			}
		}

		/// <summary>Get and set the Background colour</summary>
		public Color BackgroundColor {
			get {
				return BackColor;
			}

			set {
				BackColor = value;
			}
		}

		/// <summary>Get and set the colour of the text</summary>
		public Color TextColor {
			get {
				return ForeColor;
			}

			set {
				ForeColor = value;
			}
		}
	}
}
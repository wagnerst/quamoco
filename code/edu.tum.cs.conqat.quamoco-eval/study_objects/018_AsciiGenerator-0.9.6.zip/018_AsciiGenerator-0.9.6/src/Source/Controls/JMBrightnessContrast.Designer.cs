namespace JMSoftware.Controls
{
	/// <summary>
	/// Control to receive user input for brightness and contrast levels
	/// </summary>
	partial class JMBrightnessContrast
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.lblContrast = new System.Windows.Forms.Label();
			this.lblBrightness = new System.Windows.Forms.Label();
			this.trkBrightness = new System.Windows.Forms.TrackBar();
			this.trkContrast = new System.Windows.Forms.TrackBar();
			this.udBrightness = new System.Windows.Forms.NumericUpDown();
			this.udContrast = new System.Windows.Forms.NumericUpDown();
			((System.ComponentModel.ISupportInitialize)(this.trkBrightness)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trkContrast)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.udBrightness)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.udContrast)).BeginInit();
			this.SuspendLayout();
			// 
			// lblContrast
			// 
			this.lblContrast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblContrast.Location = new System.Drawing.Point(3, 46);
			this.lblContrast.Name = "lblContrast";
			this.lblContrast.Size = new System.Drawing.Size(64, 16);
			this.lblContrast.TabIndex = 21;
			this.lblContrast.Text = "Contrast:";
			this.lblContrast.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblBrightness
			// 
			this.lblBrightness.Location = new System.Drawing.Point(3, 2);
			this.lblBrightness.Name = "lblBrightness";
			this.lblBrightness.Size = new System.Drawing.Size(64, 16);
			this.lblBrightness.TabIndex = 18;
			this.lblBrightness.Text = "Brightness:";
			this.lblBrightness.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// trkBrightness
			// 
			this.trkBrightness.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.trkBrightness.AutoSize = false;
			this.trkBrightness.LargeChange = 10;
			this.trkBrightness.Location = new System.Drawing.Point(-5, 19);
			this.trkBrightness.Maximum = 150;
			this.trkBrightness.Minimum = -150;
			this.trkBrightness.Name = "trkBrightness";
			this.trkBrightness.Size = new System.Drawing.Size(131, 24);
			this.trkBrightness.TabIndex = 20;
			this.trkBrightness.TickFrequency = 15;
			this.trkBrightness.MouseDown += new System.Windows.Forms.MouseEventHandler(this.trkBrightness_MouseDown);
			this.trkBrightness.Scroll += new System.EventHandler(this.trkBrightness_Scroll);
			this.trkBrightness.MouseUp += new System.Windows.Forms.MouseEventHandler(this.trkBrightness_MouseUp);
			// 
			// trkContrast
			// 
			this.trkContrast.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.trkContrast.AutoSize = false;
			this.trkContrast.LargeChange = 10;
			this.trkContrast.Location = new System.Drawing.Point(-5, 63);
			this.trkContrast.Maximum = 100;
			this.trkContrast.Minimum = -100;
			this.trkContrast.Name = "trkContrast";
			this.trkContrast.Size = new System.Drawing.Size(131, 24);
			this.trkContrast.TabIndex = 23;
			this.trkContrast.TickFrequency = 10;
			this.trkContrast.MouseDown += new System.Windows.Forms.MouseEventHandler(this.trkContrast_MouseDown);
			this.trkContrast.Scroll += new System.EventHandler(this.trkContrast_Scroll);
			this.trkContrast.MouseUp += new System.Windows.Forms.MouseEventHandler(this.trkContrast_MouseUp);
			// 
			// udBrightness
			// 
			this.udBrightness.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.udBrightness.Location = new System.Drawing.Point(64, 2);
			this.udBrightness.Name = "udBrightness";
			this.udBrightness.Size = new System.Drawing.Size(50, 20);
			this.udBrightness.TabIndex = 24;
			this.udBrightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.udBrightness.ValueChanged += new System.EventHandler(this.udBrightness_ValueChanged);
			// 
			// udContrast
			// 
			this.udContrast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.udContrast.Location = new System.Drawing.Point(64, 46);
			this.udContrast.Name = "udContrast";
			this.udContrast.Size = new System.Drawing.Size(50, 20);
			this.udContrast.TabIndex = 25;
			this.udContrast.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.udContrast.ValueChanged += new System.EventHandler(this.udContrast_ValueChanged);
			// 
			// JMBrightnessContrast
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.udContrast);
			this.Controls.Add(this.udBrightness);
			this.Controls.Add(this.lblContrast);
			this.Controls.Add(this.lblBrightness);
			this.Controls.Add(this.trkBrightness);
			this.Controls.Add(this.trkContrast);
			this.MinimumSize = new System.Drawing.Size(120, 86);
			this.Name = "JMBrightnessContrast";
			this.Size = new System.Drawing.Size(120, 86);
			((System.ComponentModel.ISupportInitialize)(this.trkBrightness)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trkContrast)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.udBrightness)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.udContrast)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label lblContrast;
		private System.Windows.Forms.Label lblBrightness;
		private System.Windows.Forms.TrackBar trkBrightness;
		private System.Windows.Forms.TrackBar trkContrast;
		private System.Windows.Forms.NumericUpDown udBrightness;
		private System.Windows.Forms.NumericUpDown udContrast;
	}
}

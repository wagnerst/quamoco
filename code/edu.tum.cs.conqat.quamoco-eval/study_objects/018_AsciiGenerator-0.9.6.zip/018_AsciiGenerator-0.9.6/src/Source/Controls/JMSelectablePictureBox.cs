//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: JMSelectablePictureBox.cs,v 1.37 2008/01/31 15:32:02 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace JMSoftware.CustomControl
{
	/// <summary>
	/// JMPictureBox with added area selection function
	/// </summary>
	public class JMSelectablePictureBox : JMSoftware.CustomControl.JMPictureBox {
		/// <summary>
		/// Constructor
		/// </summary>
		public JMSelectablePictureBox() {
			SelectionFillColor = Color.LightBlue;
			SelectionBorderColor = Color.DarkBlue;
		}

		/// <summary>
		/// Handle painting the control
		/// </summary>
		/// <param name="e">Provides data for the Paint event</param>
		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e) {
			base.OnPaint(e);

			if (DrawingImage) {
				if (SelectedArea.Width > 0 || SelectedArea.Height > 0) {
					Rectangle DrawRect = ConvertToPictureBoxCoordinates(_SelectedArea);

					// avoid problem caused by the DrawImage bug fix in parent's OnPaint
					if (ImageLocation.Width > Image.Width || ImageLocation.Width > Image.Width) {
						DrawRect.Offset(1, 1);
						DrawRect.Width -= 1;
						DrawRect.Height -= 1;
					}

					if (_FillSelectionRectangle)
						e.Graphics.FillRectangle(new SolidBrush(_SelectionFillColor), DrawRect);

					e.Graphics.DrawRectangle(new Pen(_SelectionBorderColor, 1), DrawRect);
                    Pen BorderPen = new Pen(_SelectionBorderColor, 1);

					if (_MovingRectangle) {
                        // Draw the "+" in the center of the selected area
                        int left = (DrawRect.Width / 2) + DrawRect.Left;
                        int top = (DrawRect.Height / 2) + DrawRect.Top;

                        e.Graphics.DrawLine(BorderPen, left - 2 - (ImageUpscaled ? 1 : 0), top, left + 2, top);
                        e.Graphics.DrawLine(BorderPen, left, top - 2 - (ImageUpscaled ? 1 : 0), left, top + 2);
                    }
                    else {
						if (SelectionLocked) {
							DrawRect.Inflate(-1, -1);
							e.Graphics.DrawRectangle(new Pen(Color.White, 1), DrawRect);
						}
						else {
							e.Graphics.FillRectangles(Brushes.White, _Modifiers);
                            e.Graphics.DrawRectangles(BorderPen, _Modifiers);
						}
					}
				}
			}
		}

		/// <summary>
		/// Take a point in the current picturebox and convert it to a point in Image
		/// </summary>
		/// <param name="p">A point on the picturebox</param>
		/// <returns>p converted to a point in Image</returns>
		private Point ConvertToImageCoordinates(Point p) {
			return ConvertToImageCoordinates(p.X, p.Y);
		}

		/// <summary>
		/// Take a point in the current picturebox and convert it to a point in Image
		/// </summary>
		/// <param name="x">The x coordinate of the point on the picturebox</param>
		/// <param name="y">The y coordinate of the point on the picturebox</param>
		/// <returns>(x, y) converted to a point in Image</returns>
		private Point ConvertToImageCoordinates(int x, int y) {
			float fXRatio = (float)Image.Width / (float)ImageLocation.Width;
			float fYRatio = (float)Image.Height / (float)ImageLocation.Height;

			return new Point((int)(((float)(x - ImageLocation.X) * fXRatio) + 0.5),
				(int)(((float)(y - ImageLocation.Y) * fYRatio) + 0.5));
		}

		/// <summary>
		/// Take a point in the current Image and convert it to a point in the picturebox
		/// </summary>
		/// <param name="p">A point on the Image</param>
		/// <returns>p converted to a point in the PictureBox</returns>
		private Point ConvertToPictureBoxCoordinates(Point p) {
			return ConvertToPictureBoxCoordinates(p.X, p.Y);
		}

		/// <summary>
		/// Take a point in the current Image and convert it to a point in the picturebox
		/// </summary>
		/// <param name="x">The x coordinate of the point on the Image</param>
		/// <param name="y">The y coordinate of the point on the Image</param>
		/// <returns>(x, y) converted to a point in the picturebox</returns>
		private Point ConvertToPictureBoxCoordinates(int x, int y) {
			float fXRatio = (float)ImageLocation.Width / (float)Image.Width;
			float fYRatio = (float)ImageLocation.Height / (float)Image.Height;

			return new Point((int)(((float)x * fXRatio) + 0.5) + ImageLocation.X,
				(int)(((float)y * fYRatio) + 0.5) + ImageLocation.Y);
		}

		/// <summary>
		/// Take a rectangle in the current Image and convert it to a rectangle in the picturebox
		/// </summary>
		/// <param name="r">A rectangle in Image</param>
		/// <returns>r converted to a Rectangle in the picturebox</returns>
		private Rectangle ConvertToPictureBoxCoordinates(Rectangle r) {
			Point start = ConvertToPictureBoxCoordinates(r.Location);
			Point end = ConvertToPictureBoxCoordinates(r.Right, r.Bottom);

			return new Rectangle(start, new Size(end.X - start.X, end.Y - start.Y));
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.MouseDown event.
		/// </summary>
		/// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
		protected override void OnMouseDown(System.Windows.Forms.MouseEventArgs e) {
			if (e.Button == MouseButtons.Left && Image != null && !SelectionLocked) {
				_PreviousSelectedArea = _SelectedArea;

				_Selecting = true;
				_XLocked = false;
				_YLocked = false;

				_StartPoint = new Point(e.X, e.Y);

				Point position = ConvertToImageCoordinates(_StartPoint);

				if (_Modifiers[0].Contains(_StartPoint)) {
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Right, _SelectedArea.Bottom);
				}
				else if (_Modifiers[1].Contains(_StartPoint)) {
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Left, _SelectedArea.Bottom);
				}
				else if (_Modifiers[2].Contains(_StartPoint)) {
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Right, _SelectedArea.Y);
				}
				else if (_Modifiers[3].Contains(_StartPoint)) {
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.X, _SelectedArea.Y);
				}
				else if (_Modifiers[4].Contains(_StartPoint)) {
					_XLocked = true;
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Left, _SelectedArea.Bottom);
				}
				else if (_Modifiers[5].Contains(_StartPoint)) {
					_XLocked = true;
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.X, _SelectedArea.Y);
				}
				else if (_Modifiers[6].Contains(_StartPoint)) {
					_YLocked = true;
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.Right, _SelectedArea.Y);
				}
				else if (_Modifiers[7].Contains(_StartPoint)) {
					_YLocked = true;
					_StartPoint = ConvertToPictureBoxCoordinates(_SelectedArea.X, _SelectedArea.Y);
				}
				else if (_SelectedArea.Contains(position)) {
					_MovingRectangle = true;
					_MovingOffset = new Point(position.X - _SelectedArea.X, position.Y - _SelectedArea.Y);
					_Selecting = false;
				}
			}

			Refresh();

			base.OnMouseDown (e);
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.MouseUp event.
		/// </summary>
		/// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
		protected override void OnMouseUp(System.Windows.Forms.MouseEventArgs e) {
			if (e.Button == MouseButtons.Left && Image != null) {
				ReleaseMouseButton(e.Location);
			}

			Refresh();

			base.OnMouseUp (e);
		}

		/// <summary>
		/// Handle mouse released
		/// </summary>
		/// <param name="location">The point at which the button is released</param>
		private void ReleaseMouseButton(Point location) {
			bool NotifyChange = false;

			if (_MovingRectangle) {
				_MovingRectangle = false;

				NotifyChange = true;
			}
			else {
				_Selecting = false;

				// if the button was released at the point it was clicked
				if (_StartPoint.X == location.X && _StartPoint.Y == location.Y) {
					// clear the selection if clicked on the image but outside the current selection
					if (ImageLocation.Contains(_StartPoint) && !_SelectedArea.Contains(ConvertToImageCoordinates(_StartPoint))) {
						SelectNothing();
					}
				}
				else {
					NotifyChange = true;
				}
			}

			if (NotifyChange && SelectedArea != _PreviousSelectedArea) {
				NotifySelectionChange();
			}
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.MouseMove event.
		/// </summary>
		/// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
		protected override void OnMouseMove(System.Windows.Forms.MouseEventArgs e) {
			if (Image != null) {
				if (_MovingRectangle) {
					MovingChange(e.Location);
				}
				else if (_Selecting) {
					SelectionChange(e.Location);
				}
				else {	// not selecting or moving
					UpdateMouseCursor(e.Location);
				}
			}

			base.OnMouseMove (e);
		}

		/// <summary>
		/// Update the area being selected as _StartPoint to the passed end point
		/// </summary>
		/// <param name="location">New end point for the selection in picturebox coordinates</param>
		private void SelectionChange(Point location) {
			_EndPoint = location;
			SelectionChange();
		}

		/// <summary>
		/// Update the area being selected as _StartPoint to _EndPoint
		/// </summary>
		private void SelectionChange() {
			Point start = ConvertToImageCoordinates(_StartPoint);
			start.X = Math.Max(Math.Min(start.X, Image.Width), 0);
			start.Y = Math.Max(Math.Min(start.Y, Image.Height), 0);

			Point current = ConvertToImageCoordinates(_EndPoint);
			current.X = Math.Max(Math.Min(current.X, Image.Width), 0);
			current.Y = Math.Max(Math.Min(current.Y, Image.Height), 0);

			if (_ShiftIsDown && !_XLocked && !_YLocked) {
				int width = Math.Abs(current.X - start.X);
				int height = Math.Abs(current.Y - start.Y);

				if (width < height) {
					// make height = width
					current.Y = (current.Y > start.Y) ? start.Y + width : start.Y - width;
				}
				else {
					// make width = height
					current.X = (current.X > start.X) ? start.X + height : start.X - height;
				}
			}

			Point topleft = new Point(Math.Min(start.X, current.X), Math.Min(start.Y, current.Y));
			Point bottomright = new Point(Math.Max(start.X, current.X), Math.Max(start.Y, current.Y));

			if (_XLocked) {
				topleft.X = SelectedArea.X;
				bottomright.X = SelectedArea.Right;
			}
			else if (_YLocked) {
				topleft.Y = SelectedArea.Y;
				bottomright.Y = SelectedArea.Bottom;
			}

			SelectedArea = new Rectangle(topleft, new Size(bottomright.X - topleft.X, bottomright.Y - topleft.Y));
		}

		/// <summary>
		/// Moving the selected area
		/// </summary>
		/// <param name="location">The new mouse position</param>
		private void MovingChange(Point location) {
			Point position = ConvertToImageCoordinates(location.X, location.Y);

			_SelectedArea.X = Math.Max(position.X - _MovingOffset.X, 0);
			_SelectedArea.Y = Math.Max(position.Y - _MovingOffset.Y, 0);

			if (_SelectedArea.Right > Image.Width) {
				_SelectedArea.X = Image.Width - _SelectedArea.Width;
			}

			if (_SelectedArea.Bottom > Image.Height) {
				_SelectedArea.Y = Image.Height - _SelectedArea.Height;
			}

			NotifySelectionChange();

			UpdateSelectionHandles();
			Refresh();
		}

		/// <summary>
		/// Update the mouse cursor for the current position
		/// </summary>
		/// <param name="location">The current position</param>
		private void UpdateMouseCursor(Point location) {
			if (_SelectionLocked || _SelectedArea.Width < 1 || _SelectedArea.Height < 1) {
				return;
			}

			int position = -1;

			for (int i = 0; i < 8; i++) {
				if (_Modifiers[i].Contains(location)) {
					position = i;
					break;
				}
			}

			switch (position) {
				case 0:
				case 3:
					Cursor = Cursors.SizeNWSE;
					break;

				case 1:
				case 2:
					Cursor = Cursors.SizeNESW;
					break;

				case 4:
				case 5:
					Cursor = Cursors.SizeNS;
					break;

				case 6:
				case 7:
					Cursor = Cursors.SizeWE;
					break;

				default:
					if (_SelectedArea.Contains(ConvertToImageCoordinates(location))) {
						Cursor = Cursors.Hand;
					}
					else {
						Cursor = Cursors.Default;
					}

					break;
			}

			Refresh();
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.KeyDown event.
		/// </summary>
		/// <param name="e"></param>
		protected override void OnKeyDown(KeyEventArgs e) {
			if (_Selecting || _MovingRectangle) {
				if (e.KeyCode == Keys.Escape) {
					SelectedArea = _PreviousSelectedArea;
					ReleaseMouseButton(new Point(0, 0));
					Refresh();
				}
				else if (e.KeyCode == Keys.ShiftKey && !_MovingRectangle) {
					_ShiftIsDown = true;
					SelectionChange();
				}
			}

			base.OnKeyDown(e);
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.KeyUp event.
		/// </summary>
		/// <param name="e"></param>
		protected override void OnKeyUp(KeyEventArgs e) {
			_ShiftIsDown = false;

			if (_Selecting) {
				SelectionChange();
			}

			base.OnKeyUp(e);
		}

		/// <summary>
		/// Set the selected area to nothing selected
		/// </summary>
		public void SelectNothing() {
			SelectedArea = new Rectangle(0, 0, 0, 0);
			SelectionLocked = false;
		}

		/// <summary>
		/// Move the selection modifier squares into the correct positions
		/// </summary>
		private void UpdateSelectionHandles() {
			Rectangle Selected = ConvertToPictureBoxCoordinates(_SelectedArea);

			_Modifiers[0].X = Selected.X - 4;
			_Modifiers[0].Y = Selected.Y - 4;

			_Modifiers[1].X = Selected.Right - 4;
			_Modifiers[1].Y = Selected.Y - 4;

			_Modifiers[2].X = Selected.X - 4;
			_Modifiers[2].Y = Selected.Bottom - 4;

			_Modifiers[3].X = Selected.Right - 4;
			_Modifiers[3].Y = Selected.Bottom - 4;

			_Modifiers[4].X = Selected.X + ((Selected.Right - Selected.X) / 2) - 3;
			_Modifiers[4].Y = Selected.Y - 3;

			_Modifiers[5].X = Selected.X + ((Selected.Right - Selected.X) / 2) - 3;
			_Modifiers[5].Y = Selected.Bottom - 3;

			_Modifiers[6].X = Selected.X - 3;
			_Modifiers[6].Y = Selected.Y + ((Selected.Bottom - Selected.Y) / 2) - 3;

			_Modifiers[7].X = Selected.Right - 3;
			_Modifiers[7].Y = Selected.Y + ((Selected.Bottom - Selected.Y) / 2) - 3;
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.Resize event.
		/// </summary>
		/// <param name="e">An System.EventArgs that contains the event data.</param>
		protected override void OnResize(EventArgs e) {
			base.OnResize (e);

			if (Image != null)
				UpdateSelectionHandles();
		}

		/// <summary>
		/// Raises the System.Windows.Forms.Control.LostFocus event.
		/// </summary>
		/// <param name="e">An System.EventArgs that contains the event data.</param>
		protected override void OnLostFocus(EventArgs e) {
			base.OnLostFocus (e);

			if (_MovingRectangle) Invalidate();

			_Selecting = false;
			_MovingRectangle = false;
		}

		/// <summary>
		/// Handle notifing functions of a selection changed/changing event
		/// </summary>
		private void NotifySelectionChange() {
			if (_Selecting || _MovingRectangle) {
				if (SelectionChanging != null) {
					SelectionChanging(this, EventArgs.Empty);
				}
			}
			else {
				if (SelectionChanged != null) {
					SelectionChanged(this, EventArgs.Empty);
				}
			}
		}

		/// <summary>
		/// Rotate the image
		/// </summary>
		public override void RotateImage(RotateFlipType type) {
			base.RotateImage(type);

			SelectNothing();
		}

		#region Properties and Variables
		/// <summary>Get and set the image</summary>
		[DefaultValue(null), Category("Appearance"), Description("Image to be Displayed")]
		public new Image Image {
			get {
				return base.Image;
			}
			set {
				SelectionLocked = false;
				SelectNothing();

				base.Image = value;
			}
		}

		private Rectangle _SelectedArea;
		/// <summary>Get and set the selected area of the Image</summary>
		[Browsable(false)]
		public Rectangle SelectedArea {
			get {
				return _SelectedArea;
			}

			set {
				if (_SelectedArea != value) {
					_SelectedArea = value;

					NotifySelectionChange();

					UpdateSelectionHandles();

					Refresh();
				}
			}
		}

		/// <summary>The last selected area</summary>
		private Rectangle _PreviousSelectedArea;

		/// <summary>Has the left shift key been pressed down?</summary>
		private bool _ShiftIsDown = false;

		private Color _SelectionFillColor;
		/// <summary>
		/// Get and set the color used for filling the selection rectangle
		/// </summary>
		[Browsable(true), Category("Appearance"), Description("The color used to fill the selection rectangle")]
		public Color SelectionFillColor {
			get {
				return _SelectionFillColor;
			}

			set {
				if (value.A < 255) {
					_SelectionFillColor = value;
				}
				else {
					_SelectionFillColor = Color.FromArgb(128, value.R, value.G, value.B);
				}

				Refresh();
			}
		}

		private bool _FillSelectionRectangle;
		/// <summary>
		/// Should we fill the selected area with SelectionFillColor?
		/// </summary>
		[Browsable(true), Category("Appearance"), Description("The color used to fill the selection rectangle")]
		public bool FillSelectionRectangle {
			get {
				return _FillSelectionRectangle;
			}

			set {
				_FillSelectionRectangle = value;

				Refresh();
			}
		}


		/// <summary>The point at which the left mouse button was pressed down in picturebox coordinates</summary>
		private Point _StartPoint;

		/// <summary>The end point of the selection in picturebox coordinates</summary>
		private Point _EndPoint;

		/// <summary>Are we in the middle of selecting an area of the image?</summary>
		private bool _Selecting;

		private Color _SelectionBorderColor;
		/// <summary>
		/// Get and set the color used for filling the selection rectangle
		/// </summary>
		[DefaultValue(true), Browsable(true), Category("Appearance"), Description("The color used for the selection rectangle's border")]
		public Color SelectionBorderColor {
			get {
				return _SelectionBorderColor;
			}

			set {
				_SelectionBorderColor = value;
				Refresh();
			}
		}

		/// <summary>
		/// Describes the signature of the function for the SelectionChanged event
		/// </summary>
		public delegate void SelectionChangedEventHandler(object sender, EventArgs e);

		/// <summary>
		/// Event fired when the selected area has changed
		/// </summary>
		[Browsable(true), Description("Event raised when the selected area has changed")]
		public event SelectionChangedEventHandler SelectionChanged;

		/// <summary>
		/// Describes the signature of the function for the SelectionChanging event
		/// </summary>
		public delegate void SelectionChangingEventHandler(object sender, EventArgs e);

		/// <summary>
		/// Event fired when the selected area is changing
		/// </summary>
		[Browsable(true), Description("Event raised when the selected area is changing")]
		public event SelectionChangingEventHandler SelectionChanging;

		/// <summary>Are we dragging the selection rectangle?</summary>
		private bool _MovingRectangle;

		/// <summary>Offset of the cursor postion to _SelectedArea top left corner when moving</summary>
		private Point _MovingOffset;

		/// <summary>Size and positions of the selection area modifying handles in picturebox coordinates</summary>
		private Rectangle[] _Modifiers = {new Rectangle(0, 0, 9, 9),		// Top Left
										   new Rectangle(0, 0, 9, 9),	// Top Right
										   new Rectangle(0, 0, 9, 9),	// Bottom Left
										   new Rectangle(0, 0, 9, 9),	// Bottom Right
										   new Rectangle(0, 0, 7, 7),	// Top Middle
										   new Rectangle(0, 0, 7, 7),	// Bottom Middle
										   new Rectangle(0, 0, 7, 7),	// Left Middle
										   new Rectangle(0, 0, 7, 7)};	// Right Middle

		/// <summary>Is the X dimension protected from changing?</summary>
		private bool _XLocked;

		/// <summary>Is the X dimension protected from changing?</summary>
		private bool _YLocked;

		private bool _SelectionLocked;
		/// <summary>
		/// Is the selection area locked from changing?
		/// </summary>
		public bool SelectionLocked {
			get {
				return _SelectionLocked;
			}
			set {
				_SelectionLocked = value;
				Refresh();
			}
		}

		#endregion
	}
}
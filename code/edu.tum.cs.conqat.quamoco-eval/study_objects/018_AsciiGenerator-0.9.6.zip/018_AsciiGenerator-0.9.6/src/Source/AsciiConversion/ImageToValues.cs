//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: ImageToValues.cs,v 1.2 2008/01/31 15:32:01 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace JMSoftware.AsciiConversion
{
	/// <summary>
	/// Class to handle converting the image into an array of values
	/// </summary>
	class ImageToValues
	{
		/// <summary>
		/// Empty private constructor
		/// </summary>
		private ImageToValues() {
		}

		/// <summary>
		/// Convert an Image to an OutputSize array of Byte values
		/// </summary>
		/// <param name="image">Image to convert</param>
		/// <param name="outputSize">Size of the array to be returned</param>
		/// <returns>2d array of bytes of size [OutputSize.Width, OutputSize.Height]</returns>
		public static byte[,] Convert(Image image, Size outputSize) {
			if (image == null) {
				return null;
			}
			else {
				return Convert(image, outputSize, JMSoftware.Matrices.Identity());
			}
		}

		/// <summary>
		/// Modify and convert an Image to an OutputSize array of Byte values
		/// </summary>
		/// <param name="image">Image to convert</param>
		/// <param name="outputSize">Size of the array to be returned</param>
		/// <param name="matrix">ColorMatrix to be applied to the image</param>
		/// <returns>2d array of bytes of size [OutputSize.Width, OutputSize.Height]</returns>
		public static byte[,] Convert(Image image, Size outputSize, ColorMatrix matrix) {
			if (image == null || matrix == null) {
				return null;
			}
			else {
				return Convert(image, outputSize, matrix, new Rectangle(0, 0, image.Width, image.Height));
			}
		}

		/// <summary>
		/// Modify and convert an Image to an OutputSize array of Byte values
		/// </summary>
		/// <param name="image">Image to convert</param>
		/// <param name="outputSize">Size of the array to be returned</param>
		/// <param name="matrix">ColorMatrix to be applied to the image</param>
		/// <param name="section">The part of the image to be used</param>
		/// <returns>2d array of bytes of size [OutputSize.Width, OutputSize.Height]</returns>
		public static byte[,] Convert(Image image, Size outputSize, ColorMatrix matrix, Rectangle section) {
			if (image == null || matrix == null) {
				return null;
			}

			byte[,] OutputArray;

			try {
				OutputArray = new byte[outputSize.Width, outputSize.Height];
			}
			catch (System.OutOfMemoryException) {
				return null;
			}

			using (Bitmap Resized = new Bitmap(outputSize.Width, outputSize.Height)) {
				// draw a resized version onto the new bitmap
				using (Graphics g = Graphics.FromImage(Resized)) {
					g.InterpolationMode = InterpolationMode.HighQualityBicubic;

					g.DrawImage(image, new Rectangle(0, 0, outputSize.Width, outputSize.Height),
						section.X, section.Y, section.Width, section.Height,
						GraphicsUnit.Pixel);
				}

				// copy the resized version onto a new bitmap, applying the matrix
				using (Bitmap Target = new Bitmap(outputSize.Width, outputSize.Height)) {
					// create the image attributes and pass it the matrix
					using (ImageAttributes ia = new ImageAttributes()) {
						// merge the passed matrix with the matrix for converting to greyscale
						ColorMatrix cm = JMSoftware.Matrices.Multiply(JMSoftware.Matrices.Grayscale(), matrix);

						ia.SetColorMatrix(cm);

						using (Graphics grap = Graphics.FromImage(Target)) {
							grap.DrawImage(Resized, new Rectangle(0, 0, outputSize.Width, outputSize.Height),
								0, 0, outputSize.Width, outputSize.Height,
								GraphicsUnit.Pixel, ia);
						}
					}

					// loop for all rows
					for (int y = 0; y < outputSize.Height; y++) {
						// loop for all pixels in the row
						for (int x = 0; x < outputSize.Width; x++) {
							// TODO: Check overhead, use unsafe code?
							// get and store the R component of the pixel (R=G=B)
							OutputArray[x, y] = Target.GetPixel(x, y).R;
						}
					}
				}
			}

			// return the array
			return OutputArray;
		}
	}
}
//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: UnsharpMask.cs,v 1.5 2008/01/31 15:32:02 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;

namespace JMSoftware.AsciiConversion.Filters
{
	/// <summary>
	/// Filter to run a unsharp mask over the values
	/// </summary>
	class UnsharpMask : IAscgenFilter
	{
		/// <summary>
		/// Default Constructor
		/// </summary>
		public UnsharpMask() : this(2) {
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="number_of_blurs">The number of blurs to use when applying the filter</param>
		public UnsharpMask(int number_of_blurs) {
			_NumberOfBlurs = number_of_blurs;
		}

		/// <summary>
        /// Implementation of the apply function
        /// </summary>
        /// <param name="values">Input values</param>
        /// <returns>Output values</returns>
		public byte[,] Apply(byte[,] values) {
			if (values == null) {
				return null;
			}

			byte[,] Result = (byte[,])values.Clone();

			for (int i = 0; i < _NumberOfBlurs; i++) {
				Result = blur.Apply(Result);
			}

			int ArrayWidth = values.GetLength(0);
			int ArrayHeight = values.GetLength(1);

			for (int y = 0; y < ArrayHeight; y++) {
				for (int x = 0; x < ArrayWidth; x++) {
					// subtract the blurred value from the current value * 2
					int newvalue = (values[x, y] * 2) - Result[x, y];

					// make sure value is between 0 and 255
					Result[x, y] = (byte)Math.Max(Math.Min(newvalue, 255), 0);
				}
			}

			return Result;
		}

		private int _NumberOfBlurs;
		/// <summary>Number of times the image should be blurred when applying the filter</summary>
		public int NumberOfBlurs {
			get { return _NumberOfBlurs; }
			set { _NumberOfBlurs = value; }
		}

		/// <summary>Blur filter used during the unsharp process</summary>
		private Blur blur = new Blur();
	}
}
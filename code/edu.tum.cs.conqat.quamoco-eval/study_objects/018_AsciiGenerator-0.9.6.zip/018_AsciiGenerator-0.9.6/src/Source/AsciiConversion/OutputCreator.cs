//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: OutputCreator.cs,v 1.5 2008/01/31 15:32:01 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.IO;
using JMSoftware.AsciiGeneratorDotNet;
using JMSoftware.AsciiConversion;

namespace JMSoftware
{
	/// <summary>
	/// 
	/// </summary>
	public abstract class OutputCreator
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="strings"></param>
		/// <param name="colors"></param>
		/// <param name="TextSettings"></param>
		/// <returns></returns>
		public static string CreateRTF(string[] strings, Color[,] colors, TextProcessingSettings TextSettings) {
			if (!TextSettings.IsFixedWidth) return null;

			//--
			// Create the unique color array, and the array of int pointers
			//--
			int[,] CharToColor = new int[colors.GetLength(0), colors.GetLength(1)];

			ArrayList UniqueColors = new ArrayList();
			int colorid;
			int previous = -1;

			for (int y = 0; y < colors.GetLength(1); y++) {
				for (int x = 0; x < colors.GetLength(0); x++) {
					colorid = UniqueColors.IndexOf(colors[x, y]);
					CharToColor[x, y] = (colorid == -1) ? UniqueColors.Add(colors[x, y]) : colorid;

					if (CharToColor[x, y] == previous) {
						CharToColor[x, y] = -1;
					}
					else {
						previous = CharToColor[x, y];
					}
				}
			}

			//--
			// create and output the text
			//--

			System.Text.StringBuilder builder = new System.Text.StringBuilder();

			// the rtf header
			builder.Append(@"{\rtf1\ansi\ansicpg1252\deff0{\fonttbl{\f0\fnil\fcharset0 ");
			builder.Append(TextSettings.Font.Name);
			builder.Append(";}}");
			builder.Append(Environment.NewLine);

			// the rtf colortbl
			builder.Append(@"{\colortbl ;");

			foreach (Color c in UniqueColors) {
				builder.Append(@"\red");
				builder.Append(c.R);
				builder.Append(@"\green");
				builder.Append(c.G);
				builder.Append(@"\blue");
				builder.Append(c.B);
				builder.Append(";");
			}

			builder.Append("}");
			builder.Append(Environment.NewLine);
			builder.Append(@"{\*\generator Ascgen dotNET ");
			builder.Append(Variables.Version.GetVersion());
			builder.Append(";}");

			// the font settings
			builder.Append(@"\viewkind4\uc1\pard\lang2057\f0");
			if (TextSettings.Font.Bold) builder.Append(@"\b");
			if (TextSettings.Font.Italic) builder.Append(@"\i");
			if (TextSettings.Font.Underline) builder.Append(@"\ul");
			if (TextSettings.Font.Strikeout) builder.Append(@"\strike");
			builder.Append(@"\fs");
			builder.Append((int)(TextSettings.Font.Size * 2));

			// the text
			for (int y = 0; y < TextSettings.Height; y++) {
				for (int x = 0; x < TextSettings.Width; x++) {
					if (CharToColor[x, y] != -1) {
						builder.Append(@"\cf");
						builder.Append(CharToColor[x, y] + 1);
						builder.Append(" ");
					}

					builder.Append(strings[y][x]);
				}

				builder.Append(@"\par");
				builder.Append(Environment.NewLine);
			}

			builder.Append("}");

			return builder.ToString();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="strings"></param>
		/// <param name="colors"></param>
		/// <param name="backgroundcolor"></param>
		/// <param name="textSettings"></param>
		/// <param name="title"></param>
		/// <returns></returns>
		public static string CreateHTML(string[] strings, Color[,] colors, Color backgroundcolor, TextProcessingSettings textSettings, string title) {
			bool UseColor = (colors != null) && textSettings.IsFixedWidth;

			//--
			// Create the unique color array, and the array of int pointers
			//--
			int[,] CharToColor = null;

			ArrayList UniqueColors = new ArrayList();

			if (UseColor) {
				CharToColor = new int[colors.GetLength(0), colors.GetLength(1)];
				int colorid;
				int previous = -1;

				for (int y = 0; y < colors.GetLength(1); y++) {
					for (int x = 0; x < colors.GetLength(0); x++) {
						colorid = UniqueColors.IndexOf(colors[x, y]);
						CharToColor[x, y] = (colorid == -1) ? UniqueColors.Add(colors[x, y]) : colorid;

						if (CharToColor[x, y] == previous) {
							CharToColor[x, y] = -1;
						}
						else {
							previous = CharToColor[x, y];
						}
					}
				}
			}

			System.Text.StringBuilder builder = new System.Text.StringBuilder();

			builder.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			builder.AppendLine("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">");
			builder.AppendLine("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\">");
			builder.AppendLine("");
			builder.AppendLine("<head>");
			builder.AppendLine("");

			builder.Append("<title>");
			builder.Append(title);
			builder.Append("</title>");
			builder.Append(Environment.NewLine);

			builder.AppendLine("");

			builder.Append("<meta name=\"generator\" content=\"Ascgen dotNET ");
			builder.Append(Variables.Version.GetVersion());
			builder.Append("\" />");
			builder.Append(Environment.NewLine);

			builder.AppendLine("");

			builder.AppendLine("<style type=\"text/css\">");
			builder.AppendLine("<!--");

			builder.AppendLine("#ascgen-image pre {");
			builder.Append("	font-family: \"");
			builder.Append(textSettings.Font.Name);
			builder.Append("\", monospace;");
			builder.Append(Environment.NewLine);

			builder.Append("	font-size: ");
			builder.Append(textSettings.Font.Size);
			builder.Append("pt;");
			builder.Append(Environment.NewLine);

			builder.Append("	background-color: #");
			builder.Append(backgroundcolor.R.ToString("X2", null));
			builder.Append(backgroundcolor.G.ToString("X2", null));
			builder.Append(backgroundcolor.B.ToString("X2", null));
			builder.Append(";");
			builder.Append(Environment.NewLine);

			Color forecolor = Color.FromArgb((byte)~(backgroundcolor.R), (byte)~(backgroundcolor.G), (byte)~(backgroundcolor.B));
			builder.Append("	color: #");
			builder.Append(forecolor.R.ToString("X2", null));
			builder.Append(forecolor.G.ToString("X2", null));
			builder.Append(forecolor.B.ToString("X2", null));
			builder.Append(";");
			builder.Append(Environment.NewLine);

			builder.AppendLine("	float: left;");     // avoids firefox problem with scrolling horizontally
			builder.Append("	line-height: ");  // fixes firefox problem with extra space between lines
			builder.Append(textSettings.CharacterSize.Height);
			builder.Append("px;");
			builder.Append(Environment.NewLine);

			builder.AppendLine("	border: 1px solid #000000;");

			builder.AppendLine("}");

			if (UseColor) {
				builder.Append(Environment.NewLine);

				int count = 0;

				foreach (Color c in UniqueColors) {
					builder.Append(".c");
					builder.Append(count++);
					builder.Append(" { color: #");
					builder.Append(c.R.ToString("X2", null));
					builder.Append(c.G.ToString("X2", null));
					builder.Append(c.B.ToString("X2", null));
					builder.Append("; }");
					builder.Append(Environment.NewLine);
				}
			}

			builder.AppendLine("-->");
			builder.AppendLine("</style>");
			builder.AppendLine("");
			builder.AppendLine("</head>");
			builder.AppendLine("");
			builder.AppendLine("<body>");
			builder.AppendLine("");
			builder.AppendLine("<div id=\"ascgen-image\">");
			builder.Append("<pre>");

			bool spanopen = false;

			// the text
			if (textSettings.IsFixedWidth) {
				for (int y = 0; y < textSettings.Height; y++) {
					for (int x = 0; x < textSettings.Width; x++) {
						if (UseColor && CharToColor[x, y] != -1) {
							if (spanopen) {
								builder.Append("</span>");
								spanopen = false;
							}

							builder.Append("<span class=\"c");
							builder.Append(CharToColor[x, y]);
							builder.Append("\">");
							spanopen = true;
						}

						builder.Append(strings[y][x]);
					}

					if (y < textSettings.Height - 1) builder.Append(Environment.NewLine);
				}
			}
			else {
				foreach (string s in strings) {
					builder.Append(s);
					builder.Append(Environment.NewLine);
				}
			}

			if (UseColor) {
				builder.Append("</span>");
			}

			builder.Append("</pre>");
			builder.Append(Environment.NewLine);
			builder.AppendLine("</div>");
			builder.AppendLine("");
			builder.AppendLine("</body>");
			builder.AppendLine("");
			builder.Append("</html>");

			return builder.ToString();
		}
	}
}
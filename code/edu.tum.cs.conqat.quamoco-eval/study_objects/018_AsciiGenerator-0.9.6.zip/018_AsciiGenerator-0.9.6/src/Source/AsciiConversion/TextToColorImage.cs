//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: TextToColorImage.cs,v 1.2 2008/01/31 15:32:01 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace JMSoftware.AsciiConversion
{
	/// <summary>
	/// Class to handle text to color image conversions
	/// </summary>
	class TextToColorImage
	{
		private TextToColorImage() {
		}

		/// <summary>
		/// Draw the text onto a new bitmap with the specified font and colours
		/// </summary>
		/// <param name="text">The text to be drawn</param>
		/// <param name="font">Font to use</param>
		/// <param name="textcolors">2d array of colours to use (must have one for each character)</param>
		/// <param name="backgroundcolor">Color to use behind the text</param>
		/// <param name="scale">Percentage scale of the image, 1.0-100.0</param>
		/// <returns>Image containing the coloured text</returns>
		public static Image Convert(string[] text, Font font, Color[,] textcolors, Color backgroundcolor, float scale) {
			if (!FontFunctions.IsFixedWidth(font)) {
				return null;
			}

			// size the output image must be to fit the text
			Size size = FontFunctions.MeasureText(FontFunctions.StringArrayToString(text), font);

			// size of one character in the font
			Size charactersize = FontFunctions.GetFixedPitchFontSize(font);

			Bitmap fullsize = new Bitmap(size.Width, size.Height);

			using (Graphics g = Graphics.FromImage(fullsize)) {
				g.Clear(backgroundcolor);

				int width = textcolors.GetLength(0);
				int height = textcolors.GetLength(1);

				for (int y = 0; y < height; y++) {
					string line = text[y];

					for (int x = 0; x < width; x++) {
						Point offset = new Point(x * charactersize.Width, y * charactersize.Height);

						if (textcolors[x, y] != backgroundcolor) {
							g.DrawString(line[x].ToString(), font, new SolidBrush(textcolors[x, y]), offset, StringFormat.GenericTypographic);
						}
					}
				}
			}

			if (scale < 100f) {
				float fMagnification = scale / 100f;

				Size newSize = new Size((int)((fullsize.Width * fMagnification) + 0.5),
					(int)((fullsize.Height * fMagnification) + 0.5));

				newSize.Width = Math.Max(newSize.Width, 1);
				newSize.Height = Math.Max(newSize.Height, 1);

				Bitmap resized = new Bitmap(newSize.Width, newSize.Height);

				using (Graphics g = Graphics.FromImage(resized)) {
					g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

					g.DrawImage(fullsize, new Rectangle(0, 0, newSize.Width, newSize.Height));
				}

				return resized;
			}
			else {
				return fullsize;
			}
		}
	}
}
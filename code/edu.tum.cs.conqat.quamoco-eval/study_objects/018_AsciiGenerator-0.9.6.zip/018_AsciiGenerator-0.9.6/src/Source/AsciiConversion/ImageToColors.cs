//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: ImageToColors.cs,v 1.3 2008/01/31 15:32:01 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace JMSoftware.AsciiConversion
{
	/// <summary>
	/// Class to handle converting an image into an array of Colors
	/// </summary>
	class ImageToColors
	{
		/// <summary>
		/// Empty private constructor
		/// </summary>
		private ImageToColors() {
		}

		/// <summary>
		/// Process the passed image into an outputSize array of Colors
		/// </summary>
		/// <param name="image">Source image</param>
		/// <param name="outputSize">Size of the output array</param>
		/// <param name="reducecolors">Reduce the number of colors to no more then 256?</param>
		/// <returns>An outputSize array of Colors</returns>
		public static Color[,] Convert(Image image, Size outputSize, bool reducecolors) {
			return Convert(image, outputSize, new Rectangle(0, 0, image.Width, image.Height), reducecolors);
		}

		/// <summary>
		/// Process the specified section of the passed image into an outputSize array of Colors
		/// </summary>
		/// <param name="image">Source image</param>
		/// <param name="outputSize">Size of the output array</param>
		/// <param name="section">Section of the image to use</param>
		/// <param name="reducecolors">Reduce the number of colors to no more then 256?</param>
		/// <returns>An outputSize array of Colors</returns>
		public static Color[,] Convert(Image image, Size outputSize, Rectangle section, bool reducecolors) {
			Color[,] OutputArray;

			try {
				OutputArray = new Color[outputSize.Width, outputSize.Height];
			}
			catch (System.OutOfMemoryException) {
				return null;
			}

			string tempfilename = System.IO.Path.GetTempFileName();

			// create the resized and cropped image
			using (Bitmap Resized = new Bitmap(outputSize.Width, outputSize.Height)) {
				using (Graphics g = Graphics.FromImage(Resized)) {
					g.InterpolationMode = InterpolationMode.HighQualityBicubic;

					g.DrawImage(image, new Rectangle(0, 0, outputSize.Width, outputSize.Height),
						section.X, section.Y, section.Width, section.Height,
						GraphicsUnit.Pixel);
				}

				if (reducecolors) {
					// save as gif
					Resized.Save(tempfilename, System.Drawing.Imaging.ImageFormat.Gif);
				}
				else {
					for (int y = 0; y < outputSize.Height; y++) {
						for (int x = 0; x < outputSize.Width; x++) {
							OutputArray[x, y] = Resized.GetPixel(x, y);
						}
					}
				}
			}

			if (reducecolors) {
				// load into an image
				using (Image gif = Image.FromFile(tempfilename)) {
					// fill the output array with the Colors
					for (int y = 0; y < outputSize.Height; y++) {
						for (int x = 0; x < outputSize.Width; x++) {
							OutputArray[x, y] = ((Bitmap)gif).GetPixel(x, y);
						}
					}
				}

				try {
					// cleanup the temp file
					System.IO.File.Delete(tempfilename);
				}
				catch {
				}
			}

			return OutputArray;
		}
	}
}

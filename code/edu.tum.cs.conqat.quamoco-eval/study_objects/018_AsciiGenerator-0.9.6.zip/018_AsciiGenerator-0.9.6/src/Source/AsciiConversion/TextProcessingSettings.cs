//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: TextProcessingSettings.cs,v 1.16 2008/01/31 15:32:01 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections;
using System.Drawing;
using JMSoftware.AsciiGeneratorDotNet;
using JMSoftware.AsciiConversion.Filters;

namespace JMSoftware.AsciiConversion
{
	/// <summary>
	/// Summary description for ConversionSettings.
	/// </summary>
	public class TextProcessingSettings
	{
		/// <summary>
		/// Default Constructor
		/// </summary>
		public TextProcessingSettings()
			: this(new Size(Variables.DefaultWidth, Variables.DefaultHeight)) {
		}

		/// <summary>
		/// Constructor with size parameter
		/// </summary>
		/// <param name="size">The initial output size</param>
		public TextProcessingSettings(Size size)
			: this(size, Variables.DefaultFont) {
		}

		/// <summary>
		/// Constructor with size and font parameters
		/// </summary>
		/// <param name="size">The initial output size</param>
		/// <param name="font">The initial font</param>
		public TextProcessingSettings(Size size, Font font) {
			Size = size;
			Font = font;
		}

		#region Properties and Variables

		private ArrayList _FilterList;
		/// <summary>List of filters for the current settings</summary>
		public ArrayList FilterList {
			get {
				if (_FilterChanged) {
					_FilterList = new System.Collections.ArrayList();

					// only apply brightness and contrast if necessary
					if (Brightness != 0 || Contrast != 0) {
						_FilterList.Add(new BrightnessContrast(IsBlackTextOnWhite ? Brightness : -Brightness,
							IsBlackTextOnWhite ? Contrast : -Contrast));
					}

					if (Stretch) {
						_FilterList.Add(_StretchFilter);
					}

					if (MinimumLevel != 0 || MaximumLevel != 255 || MedianLevel != 0.5f) {
						_FilterList.Add(new Levels(MinimumLevel, MaximumLevel, MedianLevel));
					}

					if (Sharpen) {
						_FilterList.Add(_SharpenFilter);
					}

					if (Unsharp) {
						_FilterList.Add(_UnsharpFilter);
					}

					if (FlipHorizontally || FlipVertically) {
						_FilterList.Add(new Flip(FlipHorizontally, FlipVertically));
					}

					if (Dithering > 0) {
					    _FilterList.Add(new Dither(Dithering, DitheringRandom));
					}

					_FilterChanged = false;
				}

				return _FilterList;
			}
		}

		/// <summary>Filters that do not change</summary>
		private Sharpen _SharpenFilter = new Sharpen();
		private Stretch _StretchFilter = new Stretch();
		private UnsharpMask _UnsharpFilter = new UnsharpMask(3);

		private bool _FilterChanged = true;

		private ValuesToTextConverter _ValuesToText;
		/// <summary>The current Values To Text conversion class</summary>
		public ValuesToTextConverter ValuesToText {
			get { return _ValuesToText; }
			set { _ValuesToText = value; }
		}


		private int _Width = Variables.DefaultWidth;
		/// <summary>Width of the output image</summary>
		public int Width {
			get {
				return _Width;
			}

			set {
				_Width = value;
				_FilterChanged = true;
			}
		}

		private int _Height = Variables.DefaultHeight;
		/// <summary>Height of the output image</summary>
		public int Height {
			get {
				return _Height;
			}

			set {
				_Height = value;
				_FilterChanged = true;
			}
		}

		/// <summary>Size of the output image (accesses Width and Height values)</summary>
		public Size Size {
			get {
				return new Size(Width, Height);
			}

			set {
				Width = value.Width;
				Height = value.Height;
				_FilterChanged = true;
			}
		}

		private int _Brightness = Variables.DefaultTextBrightness;
		/// <summary>Brightness of the text image</summary>
		public int Brightness {
			get {
				return _Brightness;
			}

			set {
				_Brightness = value;
				_FilterChanged = true;
			}
		}

		private int _Contrast = Variables.DefaultTextContrast;
		/// <summary>Contrast of the text image</summary>
		public int Contrast {
			get {
				return _Contrast;
			}

			set {
				_Contrast = value;
				_FilterChanged = true;
			}
		}

		private int _MinimumLevel = Variables.DefaultMinLevel;
		/// <summary>Minimum level of the text image</summary>
		public int MinimumLevel {
			get {
				return _MinimumLevel;
			}

			set {
				_MinimumLevel = value;
				_FilterChanged = true;
			}
		}

		private int _MaximumLevel = Variables.DefaultMaxLevel;
		/// <summary>Minimum level of the text image</summary>
		public int MaximumLevel {
			get {
				return _MaximumLevel;
			}

			set {
				_MaximumLevel = value;
				_FilterChanged = true;
			}
		}

		private float _MedianLevel = Variables.DefaultMedianLevel;
		/// <summary>Median level of the text image</summary>
		public float MedianLevel {
			get {
				return _MedianLevel;
			}

			set {
				_MedianLevel = value;
				_FilterChanged = true;
			}
		}

		private int _Dithering = Variables.DefaultDitheringLevel;
		/// <summary>Level of dithering to apply to the text image</summary>
		public int Dithering {
			get { return _Dithering; }

			set {
				_Dithering = value;
				_FilterChanged = true;
			}
		}

		private int _DitheringRandom = Variables.DefaultDitheringRandom;
		/// <summary>Level of randomness to use in the dithering</summary>
		public int DitheringRandom {
			get { return _DitheringRandom; }

			set {
				_DitheringRandom = value;
				_FilterChanged = true;
			}
		}

		private bool _Stretch = Variables.Stretch;
		/// <summary>Stretch the image?</summary>
		public bool Stretch {
			get {
				return _Stretch;
			}

			set {
				_Stretch = value;
				_FilterChanged = true;
			}
		}

		private bool _Sharpen = Variables.Sharpen;
		/// <summary>Sharpen the image?</summary>
		public bool Sharpen {
			get {
				return _Sharpen;
			}

			set {
				_Sharpen = value;
				_FilterChanged = true;
			}
		}

		private bool _Unsharp = Variables.UnsharpMask;
		/// <summary>Use an unsharpening mask on the image?</summary>
		public bool Unsharp {
			get {
				return _Unsharp;
			}

			set {
				_Unsharp = value;
				_FilterChanged = true;
			}
		}

		private Font _Font;
		/// <summary>The current font</summary>
		public Font Font {
			get {
				return _Font;
			}

			set {
				_Font = value;

				IsFixedWidth = FontFunctions.IsFixedWidth(_Font);

				if (CalculateCharacterSize) {
					CalculateCharacterSize = true;
				}
			}
		}

		private string _Ramp = "MMMMMMM@@@@@@@WWWWWWWWWBBBBBBBB000000008888888ZZZZZZZZZaZaaaaaa2222222" +
				"SSSSSSSXXXXXXXXXXX7777777rrrrrrr;;;;;;;;iiiiiiiii:::::::,:,,,,,,.........       ";
		/// <summary>The ASCII ramp used for the image (black->white)</summary>
		public string Ramp {
			get {
				return _Ramp;
			}

			set {
				if (value.Length > 0) {
					_Ramp = value;

					if (_ValuesToText.GetType() == typeof(ValuesToFixedWidthTextConverter)) {
						((ValuesToFixedWidthTextConverter)_ValuesToText).Ramp =
							IsBlackTextOnWhite ? _Ramp  : FontFunctions.Reverse(_Ramp);
					}
				}
			}
		}

		private bool _IsGeneratedRamp = Variables.UseGeneratedRamp;
		/// <summary>Has the ramp be automatically generated?</summary>
		public bool IsGeneratedRamp {
			get {
				return _IsGeneratedRamp;
			}

			set {
				_IsGeneratedRamp = value;
			}
		}

		private string _ValidCharacters = Variables.CurrentSelectedValidCharacters > -1 ?
			(string)Variables.DefaultValidCharacters[Variables.CurrentSelectedValidCharacters] :
			Variables.CurrentCharacters;
		/// <summary>The characters used to create the ASCII ramp</summary>
		public string ValidCharacters {
			get {
				return _ValidCharacters;
			}

			set {
				_ValidCharacters = value;

				if (_ValuesToText.GetType() == typeof(ValuesToVariableWidthTextConverter)) {
					((ValuesToVariableWidthTextConverter)_ValuesToText).ValidCharacters = _ValidCharacters;
				}
				else {
					if (IsGeneratedRamp) {
						Ramp = AsciiRampCreator.CreateRamp(Font, ValidCharacters);
					}
				}
			}
		}

		private bool _IsFixedWidth = true;
		/// <summary>Get or set if the current font is fixed width</summary>
		public bool IsFixedWidth {
			get { return _IsFixedWidth; }

			set {
				_IsFixedWidth = value;

				if (_IsFixedWidth) {
					_ValuesToText = new ValuesToFixedWidthTextConverter(Ramp);
				}
				else {
					_ValuesToText = new ValuesToVariableWidthTextConverter(ValidCharacters, Font);

					if (!IsBlackTextOnWhite) {
						((ValuesToVariableWidthTextConverter)_ValuesToText).InvertOutput = true;
					}
				}
			}
		}

		private bool _IsBlackTextOnWhite = Variables.BlackTextOnWhite;
		/// <summary>Is the image black text on a white background?</summary>
		public bool IsBlackTextOnWhite {
			get {
				return _IsBlackTextOnWhite;
			}

			set {
				if (_IsBlackTextOnWhite != value) {
					_IsBlackTextOnWhite = value;

					if (_ValuesToText.GetType() == typeof(ValuesToFixedWidthTextConverter)) {
						((ValuesToFixedWidthTextConverter)_ValuesToText).Ramp =
							IsBlackTextOnWhite ? Ramp : FontFunctions.Reverse(Ramp);
					}
					else if (_ValuesToText.GetType() == typeof(ValuesToVariableWidthTextConverter)) {
						((ValuesToVariableWidthTextConverter)_ValuesToText).InvertOutput = !_IsBlackTextOnWhite;
					}
				}
			}
		}

		private bool _FlipHorizontally = Variables.FlipHorizontally;
		/// <summary>Should the image be flipped horizontally?</summary>
		public bool FlipHorizontally {
			get {
				return _FlipHorizontally;
			}

			set {
				_FlipHorizontally = value;
				_FilterChanged = true;
			}
		}

		private bool _FlipVertically = Variables.FlipVertically;
		/// <summary>Should the image be flipped vertically?</summary>
		public bool FlipVertically {
			get {
				return _FlipVertically;
			}

			set {
				_FlipVertically = value;
				_FilterChanged = true;
			}
		}

		private bool _CalculateCharacterSize = true;
		/// <summary>Should the character size be automatically calculated?</summary>
		public bool CalculateCharacterSize {
			get {
				return _CalculateCharacterSize;
			}

			set {
				_CalculateCharacterSize = value;

				Size size = FontFunctions.MeasureText("W", Font);

				if (_CalculateCharacterSize) {
					if (!IsFixedWidth) {
						size.Width = ValuesToVariableWidthTextConverter.CharacterWidth;
					}

					_CharacterSize = size;
				}
			}
		}

		private Size _CharacterSize;
		/// <summary>Size of one character in the font</summary>
		public Size CharacterSize {
			get {
				return _CharacterSize;
			}

			set {
				_CharacterSize = value;
				CalculateCharacterSize = false;
			}
		}

		#endregion
	}
}
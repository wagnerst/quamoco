//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: Interfaces.cs,v 1.6 2008/02/10 14:10:26 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;

namespace JMSoftware.Interfaces
{
	/// <summary>
	/// Interface to an object that will display text
	/// </summary>
	public interface ITextViewer
	{
		/// <summary>Remove all of the text</summary>
		void Clear();

		/// <summary>Copy the currently selected text to the clipboard</summary>
		void Copy();

		/// <summary>Select all of the text</summary>
		void SelectAll();

		/// <summary>Stop selecting the text</summary>
		void SelectNone();

		/// <summary>Get the number of characters selected</summary>
		int SelectionLength { get; }

		/// <summary>Is the text empty?</summary>
		bool IsEmpty { get; }

		/// <summary>Get and set the text</summary>
		string Text { get; set; }

		/// <summary>Get and set the lines of text</summary>
		string[] Lines { get; set; }

		/// <summary>Get and set the text</summary>
		System.Drawing.Font Font { get; set; }

		/// <summary>Get and set the Background colour</summary>
		System.Drawing.Color BackgroundColor { get; set; }

		/// <summary>Get and set the colour of the text</summary>
		System.Drawing.Color TextColor { get; set; }
	}

	/// <summary>
	/// Brightness and contrast interface
	/// </summary>
	public interface IBrightnessContrast
	{
		/// <summary>Get or set Brightness</summary>
		int Brightness { get; set; }

		/// <summary>Get or set Contrast</summary>
		int Contrast { get;	set; }
	}

	/// <summary>
	/// Levels interface
	/// </summary>
	public interface ILevels
	{
		/// <summary>Get or set Maximum</summary>
		int Maximum { get; set; }

		/// <summary>Get or set Minimum</summary>
		int Minimum { get; set; }

		/// <summary>Get or set Median</summary>
		float Median { get; set; }
	}

	/// <summary>
	/// Dithering interface
	/// </summary>
	public interface IDither
	{
		/// <summary>Level of dithering to perform</summary>
		int DitherAmount { get; set; }

		/// <summary>Level of randomness to use in the dither</summary>
		int DitherRandom { get; set; }
	}

	/// <summary>
	/// Interface for levels of zoom
	/// </summary>
	public interface IZoomLevel
	{
		/// <summary>Level of zoom to use (1.0 = no zoom, 0.5 = 50%, 2.0 = 200% etc)</summary>
		float Amount { get; set; }
	}
}
//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: Dither.cs,v 1.9 2008/02/10 14:10:25 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using JMSoftware.Interfaces;

namespace JMSoftware.AsciiConversion.Filters
{
	/// <summary>
	/// Filter to apply a dithering pattern to the values
	/// </summary>
	public class Dither : IDither, IAscgenFilter
	{
		/// <summary>
		/// Default constructor
		/// </summary>
		public Dither() : this(5, 3) {
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="amount">Level of dithering</param>
		/// <param name="randomness">Level of randomness in the dither</param>
		public Dither(int amount, int randomness) {
			DitherAmount = amount;
			DitherRandom = randomness;
		}

		/// <summary>
		/// Implementation of the apply function
		/// </summary>
		/// <param name="values">Input values</param>
		/// <returns>Output values</returns>
		public byte[,] Apply(byte[,] values) {
			if (values == null) {
				return null;
			}

			int ArrayWidth = values.GetLength(0);
			int ArrayHeight = values.GetLength(1);

			byte[,] Result = new byte[ArrayWidth, ArrayHeight];

			Random rand = new Random();

			for (int y = 0; y < ArrayHeight; y++) {
				for (int x = 0; x < ArrayWidth; x++) {
					int randomvalue = rand.Next(-DitherRandom, DitherRandom);

					int newvalue = values[x, y] + 
						((x + y) % 2 == 1 ? DitherAmount + randomvalue : -DitherAmount - randomvalue);

					// limit the new value to between 0 and 255
					if ((newvalue & 255) == newvalue) {
						Result[x, y] = (byte)newvalue;
					}
					else if (newvalue > 255) {
						Result[x, y] = 255;
					}
					else {
						Result[x, y] = 0;
					}
				}
			}

			return Result;
		}

		private int _DitherAmount;
		/// <summary>Level of dithering to perform (0 = none)</summary>
		public int DitherAmount {
			get { return _DitherAmount; }
			set { _DitherAmount = value; }
		}

		private int _DitherRandom;
		/// <summary>Level of randomness to use in the dither (0 = none)</summary>
		public int DitherRandom {
			get { return _DitherRandom; }
			set { _DitherRandom = value; }
		}
	}
}
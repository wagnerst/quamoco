//----------------------------------------------------------------------------
// ASCII Generator dotNET - Image to ASCII Art Conversion Program
// Copyright (C) 2008 Jonathan Mathews
//----------------------------------------------------------------------------
// This file is part of ASCII Generator dotNET.
//
// ASCII Generator dotNET is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//----------------------------------------------------------------------------
// http://www.jmsoftware.co.uk/                http://ascgen2.sourceforge.net/
// <info@jmsoftware.co.uk>                              <jmsoftware@gmail.com>
//----------------------------------------------------------------------------
// $Id: TextToImage.cs,v 1.5 2008/01/31 15:32:02 wardog_uk Exp $
//----------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.IO;

namespace JMSoftware.AsciiConversion
{
	/// <summary>
	/// Class to handle text to image conversion
	/// </summary>
	class TextToImage
	{
		private TextToImage() {
		}

		/// <summary>
		/// Draw the text onto a new bitmap, with the specified font
		/// </summary>
		/// <param name="text">The text to be drawn</param>
		/// <param name="font">The font to use</param>
		/// <returns>A new bitmap containing the text</returns>
		public static Bitmap Convert(string text, Font font) {
			return Convert(text, font, Color.Black, Color.White);
		}

		/// <summary>
		/// Draw the text onto a new bitmap, with the specified font and text colours
		/// </summary>
		/// <param name="text">The text to be drawn</param>
		/// <param name="font">The font to use</param>
		/// <param name="textcolor">The colour of the text</param>
		/// <param name="backgroundcolor">The colour of the background</param>
		/// <returns>A new bitmap containing the text</returns>
		public static Bitmap Convert(string text, Font font, Color textcolor, Color backgroundcolor) {
			return Convert(text, font, textcolor, backgroundcolor, new Point(0, 0));
		}

		/// <summary>
		/// Draw the text onto a new bitmap at the specified point, with the specified font and text colours
		/// </summary>
		/// <param name="text">The text to be drawn</param>
		/// <param name="font">The font to use</param>
		/// <param name="textcolor">The colour of the text</param>
		/// <param name="backgroundcolor">The colour of the background</param>
		/// <param name="offset">The amount by which to offset the text</param>
		/// <returns>A new bitmap containing the text</returns>
		public static Bitmap Convert(string text, Font font, Color textcolor, Color backgroundcolor, Point offset) {
			Size size = FontFunctions.MeasureText(text, font);

			Bitmap result = new Bitmap(size.Width, size.Height);

			using (Graphics g = Graphics.FromImage(result)) {
				g.Clear(backgroundcolor);
				TextRenderer.DrawText(g, text, font, offset, textcolor, backgroundcolor, TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
			}

			return result;
		}

		/// <summary>
		/// Save the text as an image file, will overwrite it if the file already exists
		/// </summary>
		/// <param name="text">The text to save</param>
		/// <param name="filename">Filename to save</param>
		/// <param name="font">Font to use for the text</param>
		/// <param name="textcolor">Color of the text</param>
		/// <param name="backgroundcolor">Color of the background</param>
		/// <param name="scale">Percentage scale of the image, 1.0-100.0</param>
		/// <param name="greyscale">Save the image as greyscale?</param>
		/// <returns>did the file save without errors?</returns>
		public static bool Save(string text, string filename, Font font, Color textcolor, Color backgroundcolor, float scale, bool greyscale) {
			using (Bitmap bmpFullSize = Convert(text, font, textcolor, backgroundcolor)) {
				if (scale < 100f) {
					float fMagnification = scale / 100f;

					Size newSize = new Size((int)((bmpFullSize.Width * fMagnification) + 0.5),
						(int)((bmpFullSize.Height * fMagnification) + 0.5));

					newSize.Width = Math.Max(newSize.Width, 1);
					newSize.Height = Math.Max(newSize.Height, 1);

					using (Bitmap bmpOutput = new Bitmap(newSize.Width, newSize.Height)) {
						using (ImageAttributes ia = new ImageAttributes()) {
							ia.SetColorMatrix(greyscale ? JMSoftware.Matrices.Grayscale() : JMSoftware.Matrices.Identity());

							using (Graphics g = Graphics.FromImage(bmpOutput)) {
								g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

								g.DrawImage(bmpFullSize, new Rectangle(0, 0, newSize.Width, newSize.Height),
									0, 0, bmpFullSize.Width, bmpFullSize.Height,
									GraphicsUnit.Pixel, ia);
							}
						}

						bmpOutput.Save(filename, ImageFunctions.GetImageFormat(Path.GetExtension(filename).ToLower()));
					}
				}
				else {
					bmpFullSize.Save(filename, ImageFunctions.GetImageFormat(Path.GetExtension(filename).ToLower()));
				}
			}

			return true;
		}
	}
}
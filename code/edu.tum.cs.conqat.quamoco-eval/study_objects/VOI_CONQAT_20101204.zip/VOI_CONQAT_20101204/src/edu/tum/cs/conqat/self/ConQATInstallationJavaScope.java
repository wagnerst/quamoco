/*--------------------------------------------------------------------------+
$Id: ConQATInstallationJavaScope.java 31716 2010-11-26 15:33:02Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.self;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.conqat.java.resource.IJavaElement;
import org.conqat.java.resource.IJavaResource;
import org.conqat.java.resource.JavaContainer;
import org.conqat.java.resource.JavaElementFactory;
import org.conqat.resource.IContentAccessor;
import org.conqat.resource.scope.filesystem.FileContentAccessor;
import org.conqat.resource.util.ConQATDirectoryScanner;
import org.conqat.resource.util.ConQATFileUtils;

import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.filesystem.FileExtensionFilter;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.bundle.BundleInfo;
import edu.tum.cs.conqat.commons.util.ConQATInputProcessorBase;
import edu.tum.cs.conqat.core.AConQATFieldParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.self.scope.ConQATBundleNode;
import edu.tum.cs.conqat.self.scope.ConQATInstallationRoot;

/**
 * {@ConQAT.Doc}
 * 
 * @author Benjamin Hummel
 * @author $Author: heineman $
 * @version $Rev: 31716 $
 * @levd.rating GREEN Hash: 3D73E69E15247E79AC081C791529C089
 */
@AConQATProcessor(description = "This processor creates a JavaRootElement from the "
		+ "given ConQATInstallationRoot including ConQAT and all its bundles.")
public class ConQATInstallationJavaScope extends
		ConQATInputProcessorBase<ConQATInstallationRoot> {

	/** The name of the ConQAT project itself. */
	private static final String CONQAT = "ConQAT";

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "test-src", attribute = "include", optional = true, description = ""
			+ "Decide whether to also include the test sources. Default is false.")
	public boolean includeTests = false;

	/** Factory used for creating byte-code. */
	private final JavaElementFactory factory = new JavaElementFactory();

	/** The accessors used for Java files. */
	private final List<IContentAccessor> javaAccessors = new ArrayList<IContentAccessor>();

	/** The accessors used for class files. */
	private final List<IContentAccessor> classAccessors = new ArrayList<IContentAccessor>();

	/** {@inheritDoc} */
	public IJavaResource process() throws ConQATException {
		factory.init(getProcessorInfo());

		addConQAT();
		for (ConQATBundleNode bundleNode : input.getChildren()) {
			addBundle(bundleNode);
		}

		factory.addByteCodeAccessors(classAccessors
				.toArray(new IContentAccessor[classAccessors.size()]));
		factory.process();

		JavaContainer rootPackage = new JavaContainer(StringUtils.EMPTY_STRING);
		for (IContentAccessor javaAccessor : javaAccessors) {
			insert(factory.create(javaAccessor),
					rootPackage);
		}
		return rootPackage;
	}

	/** Inserts the given java element into the hierarchy. */
	private void insert(IJavaElement javaElement, JavaContainer container) {
		String[] segments = javaElement.getClassName().split("[.]");
		for (int i = 0; i < segments.length - 1; ++i) {
			IJavaResource child = container.getNamedChild(segments[i]);
			if (!(child instanceof JavaContainer)) {
				child = new JavaContainer(segments[i]);
				container.addChild(child);
			}
			container = (JavaContainer) child;
		}
		container.addChild(javaElement);
	}
	
	/** Adds the ConQAT directory. */
	private void addConQAT() throws ConQATException {
		scanForJava(new File(input.getConQATDirectory(), "src"), CONQAT);
		if (includeTests) {
			scanForJava(new File(input.getConQATDirectory(), "test-src"),
					CONQAT);
		}

		scanForClass(new File(input.getConQATDirectory(), "build"), CONQAT);

		for (File lib : new File(input.getConQATDirectory(), "lib")
				.listFiles(new FileExtensionFilter("jar"))) {
			getLogger().info("Added class path element " + lib.getPath());
			factory.addClasspathElement(lib.getPath());
		}
	}

	/** Adds a bundle. */
	private void addBundle(ConQATBundleNode bundleNode) throws ConQATException {
		BundleInfo bundleInfo = bundleNode.getBundleInfo();
		File srcDir = new File(bundleInfo.getLocation(), "src");
		File testsrcDir = new File(bundleInfo.getLocation(), "test-src");
		File classesDir = bundleInfo.getClassesDirectory();

		if (srcDir.isDirectory()) {
			scanForJava(srcDir, bundleNode.getId());
		}
		if (includeTests && testsrcDir.isDirectory()) {
			scanForJava(testsrcDir, bundleNode.getId());
		}
		if (classesDir.isDirectory()) {
			scanForClass(classesDir, bundleNode.getId());
		}
		for (File lib : bundleInfo.getLibraries()) {
			getLogger().info("Added class path element " + lib.getPath());
			factory.addClasspathElement(lib.getPath());
		}
	}

	/** Scans for Java files in the given directory. */
	private void scanForJava(File dir, String projectName)
			throws ConQATException {
		scanForFiles(dir, projectName, "source code", "java", javaAccessors);
	}

	/** Scans for class files in the given directory. */
	private void scanForClass(File dir, String projectName)
			throws ConQATException {
		scanForFiles(dir, projectName, "byte code", "class", classAccessors);
	}

	/** Scans for files with given extensions and adds them to the target list. */
	private void scanForFiles(File dir, String projectName, String fileType,
			String extension, List<IContentAccessor> target)
			throws ConQATException {
		if (!dir.isDirectory()) {
			throw new ConQATException("Expected " + dir + " to be a directory!");
		}

		getLogger().info("Added " + fileType + " directory " + dir);

		String[] filenames = ConQATDirectoryScanner.scan(dir.getAbsolutePath(),
				true, new String[] { "**/*." + extension }, new String[] {
						"**/.svn/**", "**/*$*" });

		CanonicalFile root = ConQATFileUtils.createCanonicalFile(dir
				.getParentFile());

		for (int i = 0; i < filenames.length; ++i) {
			target.add(new FileContentAccessor(ConQATFileUtils
					.createCanonicalFile(new File(dir, filenames[i])), root,
					projectName));
		}
	}
}
/*--------------------------------------------------------------------------+
$Id: ArchitectureAssessmentAggregator.java 27885 2010-05-21 12:41:16Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.aggregation;

import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 27885 $
 * @levd.rating GREEN Hash: FC554716DBD65712E9226E4C92246292
 */
@AConQATProcessor(description = "This processor aggregates assessments along the "
		+ "hierarchy defined by the architecture in a bottom-up manner.")
public class ArchitectureAssessmentAggregator extends
		ArchitectureAggregatorBase<Assessment> {

	/** Aggregate assessments. */
	@Override
	protected Assessment aggregate(List<Assessment> values) {
		return Assessment.aggregate(values);
	}

	/**
	 * Returns assessment or <code>null</code> if no value or value of incorrect
	 * type was found.
	 */
	@Override
	protected Assessment obtainValue(IConQATNode node, String key) {
		return NodeUtils.getValue(node, key, Assessment.class, null);
	}
}

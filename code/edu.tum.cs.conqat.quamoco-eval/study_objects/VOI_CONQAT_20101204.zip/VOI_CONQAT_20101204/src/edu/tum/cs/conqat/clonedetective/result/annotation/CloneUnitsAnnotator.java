/*--------------------------------------------------------------------------+
$Id: CloneUnitsAnnotator.java 31740 2010-11-26 16:23:19Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result.annotation;

import java.util.List;

import org.conqat.resource.text.ITextElement;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.region.Region;
import edu.tum.cs.commons.region.RegionSet;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Revision: 31740 $
 * @levd.rating GREEN Hash: 6F8540EB0FA56EB05898C5032BF92488
 */
@AConQATProcessor(description = "Computes the number of units of a class that are part of at "
		+ "least one clone.")
public class CloneUnitsAnnotator extends CloneAnnotatorBase {

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Key that stores Clone units", type = "java.lang.Integer")
	public final static String CLONE_UNITS_KEY = "Clone Units";

	/** {@inheritDoc} */
	@Override
	protected String[] getKeys() {
		return new String[] { CLONE_UNITS_KEY };
	}

	/** {@inheritDoc} */
	@Override
	protected void annotateClones(ITextElement element,
			UnmodifiableList<Clone> clonesList) {
		element.setValue(CLONE_UNITS_KEY, calcCloneUnits(clonesList));
	}

	/**
	 * Computes the number of units of an element that are covered by at least
	 * one clone. This corresponds to the non-overlapping sum of the length of
	 * the clones annotated to this class, measured in units.
	 */
	private int calcCloneUnits(List<Clone> clones) {
		RegionSet regions = new RegionSet("clones");

		for (Clone clone : clones) {
			Region region = new Region(clone.getStartUnitIndexInElement(),
					clone.getStartUnitIndexInElement()
							+ clone.getLengthInUnits() - 1, "clone");
			regions.add(region);
		}

		return regions.getPositionCount();
	}

}
/*--------------------------------------------------------------------------+
$Id: SimulinkBlockTypeAssessor.java 27748 2010-05-17 15:40:16Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import java.util.HashSet;

import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * {@ConQAT.Doc}
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 27748 $
 * @levd.rating GREEN Hash: E2A61E83C5D59C7B0DDBD8FCFF3A3830
 */
@AConQATProcessor(description = "This processor attaches findings to blocks of specified types.")
public class SimulinkBlockTypeAssessor extends
		FindingsBlockTraversingProcessorBase {

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "Block Type Assessment Findings", type = ConQATParamDoc.FINDING_LIST_TYPE)
	public static final String KEY = "BlockTypeFindings";

	/** Set of prohibited types. */
	private final HashSet<String> prohibitedTypes = new HashSet<String>();

	/** Add prohibited type. */
	@AConQATParameter(name = "prohibit", description = "Add prohibited type", minOccurrences = 1)
	public void addProhibitedType(
			@AConQATAttribute(name = "type", description = "Name of of prohibited "
					+ "type. Use 'Reference.<type>' for library types.") String blockType) {
		prohibitedTypes.add(blockType);
	}

	/** Check if block has prohibited type. */
	@Override
	protected void visitBlock(SimulinkBlock block,
			SimulinkModelElement modelNode) {

		String type = block.getResolvedType();

		if (prohibitedTypes.contains(type)) {
			String message = "Prohibited type '" + type + "'.";
			String id = block.getId();
			attachFinding(message, modelNode, id);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected String getKey() {
		return KEY;
	}
}
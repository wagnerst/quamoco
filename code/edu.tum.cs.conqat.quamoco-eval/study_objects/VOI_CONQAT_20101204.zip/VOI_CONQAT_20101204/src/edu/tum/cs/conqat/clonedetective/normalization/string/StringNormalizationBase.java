/*--------------------------------------------------------------------------+
$Id: StringNormalizationBase.java 31478 2010-11-25 14:41:50Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.string;

import java.io.Serializable;

import org.conqat.resource.text.ITextElement;
import org.conqat.resource.text.ITextResource;

import edu.tum.cs.commons.string.LineSplitter;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.lazyscope.IElementProvider;
import edu.tum.cs.conqat.clonedetective.normalization.UnitProviderBase;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.commons.pattern.PatternTransformationList;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Base class for String based normalizations
 * 
 * @author $Author: heineman $
 * @version $Rev: 31478 $
 * @levd.rating GREEN Hash: E168E56F2AEBF77BB047131A4C6840AA
 */
/* package */abstract class StringNormalizationBase extends
		UnitProviderBase<ITextResource, StringUnit> implements Serializable {

	/** The input component used to access elements. */
	private final IElementProvider<ITextResource, ITextElement> inputProvider;

	/** Processor that performs layout preserving removals during normalization */
	private final LayoutPreservingPatternReplacer removals;

	/** List of replacement transformations performed during normalization */
	private final PatternTransformationList replacements;

	/** The current source element. */
	private transient ITextElement currentElement;

	/** The current position within a file (line number) */
	private int currentLineNumber = -1;

	/** The current unit index within a file */
	private int currentUnitIndex = -1;

	/** Flag that determines whether empty lines are filtered out */
	protected final boolean ignoreEmptyLines;

	/** Flag that determines whether lines are trimmed */
	protected final boolean trimLines;

	/**
	 * Flag that determines whether all whitespace is removed from the string
	 * unit
	 */
	protected final boolean removeAllWhitespace;

	/** This is used to split lines. */
	private transient LineSplitter splitter;

	/** Constructor */
	public StringNormalizationBase(
			IElementProvider<ITextResource, ITextElement> inputProvider,
			PatternList removeConfig, PatternTransformationList replacements,
			boolean trimLines, boolean ignoreEmptyLines,
			boolean removeAllWhitespace) {
		this.inputProvider = inputProvider;
		removals = new LayoutPreservingPatternReplacer(removeConfig);
		this.replacements = replacements;
		this.ignoreEmptyLines = ignoreEmptyLines;
		this.trimLines = trimLines;
		this.removeAllWhitespace = removeAllWhitespace;

		// setting the splitter's input to the empty string makes it return null
		// on first call to splitter.getNextLine()
		assertSplitterInitialized();
		splitter.setContent(StringUtils.EMPTY_STRING);
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ITextResource root) {
		assertSplitterInitialized();
		inputProvider.init(root, getLogger());
	}

	/**
	 * Initializes the splitter if necessary. Necessary, since splitter is
	 * transient.
	 */
	private void assertSplitterInitialized() {
		if (splitter == null) {
			splitter = new LineSplitter();
		}
	}

	/**
	 * Obtain next input line.
	 * 
	 * @return the next line or <code>null</code> if all lines have been
	 *         returned
	 * @throws CloneDetectionException
	 *             only thrown if the input component throws an exception. This
	 *             component itself <i>does not</i> throw any exceptions.
	 */
	@Override
	protected StringUnit provideNext() throws CloneDetectionException {
		// determine next line that is not ignored
		String content = null;
		while (content == null) {
			content = findNextUnignoredInFile();
			if (content == null && !moveToNextFileSucceeded()) {
				// no more lines found
				return null;
			}
		}

		currentUnitIndex++;
		int indexInFile = currentUnitIndex;
		return new StringUnit(normalize(content), currentElement
				.getUniformPath(), currentLineNumber, indexInFile);
	}

	/**
	 * Template method that allows deriving classes to perform normalization of
	 * the content
	 */
	protected abstract String normalize(String content);

	/** Retrieves next line from line splitter */
	protected String getNextLine() {
		currentLineNumber += 1;
		return splitter.getNextLine();
	}

	/**
	 * Template method that deriving classes override to provide the next string
	 * for unit creation
	 */
	protected abstract String findNextUnignoredInFile();

	/**
	 * Sets normalization to next input file.
	 * 
	 * @return true, if a new input file was found, false
	 */
	private boolean moveToNextFileSucceeded() throws CloneDetectionException {
		currentElement = inputProvider.getNext();

		// check if there are more source files
		if (currentElement == null) {
			// no more source files
			getLogger().debug("no more source files.");
			return false;
		}

		getLogger().debug("Processing source element: " + currentElement);

		// set new splitter content and reset line number
		String content;
		try {
			content = normalizeCurrentFileContent();
		} catch (ConQATException e) {
			throw new CloneDetectionException(
					"Could not read content of element "
							+ currentElement.getLocation(), e);
		}
		splitter.setContent(content);
		currentLineNumber = -1;
		currentUnitIndex = -1;

		return true;
	}

	/**
	 * Reads content of current source element and applies normalizations.
	 * <p>
	 * Performs a check whether the normalization changed the number of lines.
	 * 
	 * @throws ConQATException
	 */
	private String normalizeCurrentFileContent() throws ConQATException {
		// read content
		String content = currentElement.getTextContent();
		int lineNumberCountBefore = StringUtils.splitLines(content).length;

		// perform normalization
		content = removals.process(content);
		content = replacements.applyTransformation(content);

		// Check whether transformations have been layout preserving
		int lineNumberCountAfter = StringUtils.splitLines(content).length;
		if (lineNumberCountBefore != lineNumberCountAfter) {
			getLogger().warn(
					"Normalization of element '" + currentElement.getLocation()
							+ "' changed number of lines!");
		}

		// return normalized content
		return content;
	}

}
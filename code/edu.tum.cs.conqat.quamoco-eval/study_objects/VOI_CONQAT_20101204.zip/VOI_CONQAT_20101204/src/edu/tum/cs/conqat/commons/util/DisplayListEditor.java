/*--------------------------------------------------------------------------+
$Id: DisplayListEditor.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.util;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * A processor for editing the display list of an {@link IConQATNode}.
 * 
 * @author Benjamin Hummel
 * @author Elmar Juergens
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 0DF46FE5C0B6CDC904A1DF1DC2D3CD7E
 */
@AConQATProcessor(description = "This processor can be used for modifying the display list of a ConQAT node.")
public class DisplayListEditor extends ConQATPipelineProcessorBase<IConQATNode> {

	/** Determines whether all keys are removed from the display list */
	private boolean removeAll = false;

	/** Determines whether the Assessment summary at the root node is removed */
	private boolean removeAssessmentSummary = false;

	/** Names of keys to remove. */
	private final List<String> removeKeys = new ArrayList<String>();

	/** Names of keys to add (at the end). */
	private final List<String> addKeys = new ArrayList<String>();

	/** Names of keys to insert (at the beginning). */
	private final List<String> insertKeys = new ArrayList<String>();

	/**
	 * Flag to indicate if root should be hidden or not. We use the
	 * non-primitive to here to use the third state (<code>null</code>) to
	 * encode the default value that does not change the root hiding.
	 */
	private Boolean hideRoot = null;

	/** ConQAT Parameter */
	@AConQATParameter(name = "clear", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Removes all keys")
	public void setClearAll(
			@AConQATAttribute(name = "all", description = "Default is false") boolean removeAll) {
		this.removeAll = removeAll;
	}

	/** ConQAT Parameter */
	@AConQATParameter(name = "assessment-summary", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Remove assessment summary")
	public void setRemoveAssessmentSummary(
			@AConQATAttribute(name = "remove", description = "Default is false") boolean removeAssessmentSummary) {
		this.removeAssessmentSummary = removeAssessmentSummary;
	}

	/** Add a key. */
	@AConQATParameter(name = "add", description = "Add a key to the end of the display list.")
	public void addKey(
			@AConQATAttribute(name = "key", description = "The name of the key") String key) {
		addKeys.add(key);
	}

	/** Insert a key. */
	@AConQATParameter(name = "insert", description = "Add a key to the beginning of the display list.")
	public void insertKey(
			@AConQATAttribute(name = "key", description = "The name of the key") String key) {
		insertKeys.add(key);
	}

	/** Delete a key. */
	@AConQATParameter(name = "remove", description = "Remove a key from the display list.")
	public void removeKey(
			@AConQATAttribute(name = "key", description = "The name of the key") String key) {
		removeKeys.add(key);
	}

	/** Hide root. */
	@AConQATParameter(name = "hide", minOccurrences = 0, maxOccurrences = 1, description = "Hide/unhide root. Default is to leave unchanged.")
	public void hideRoot(
			@AConQATAttribute(name = "root", description = "Rrue to hide root. False to unhide root.") boolean hideRoot) {
		this.hideRoot = hideRoot;
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(IConQATNode input) {
		if (removeAssessmentSummary) {
			input.setValue(NodeConstants.SUMMARY, null);
		}

		if (hideRoot != null) {
			input.setValue(NodeConstants.HIDE_ROOT, hideRoot);
		}

		List<String> displayList = NodeUtils.getDisplayList(input);
		if (removeAll) {
			displayList.clear();
		} else {
			displayList.removeAll(removeKeys);
		}
		displayList.addAll(0, insertKeys);
		displayList.addAll(addKeys);
	}
}
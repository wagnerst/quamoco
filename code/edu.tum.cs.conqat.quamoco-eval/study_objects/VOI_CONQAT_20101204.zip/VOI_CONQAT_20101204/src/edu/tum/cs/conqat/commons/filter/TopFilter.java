/*--------------------------------------------------------------------------+
$Id: TopFilter.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.filter;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author Florian Deissenboeck
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: B354728DF7EFCECF5344A808382F5761
 */
@AConQATProcessor(description = "This filter works like the SQL 'TOP' directive. "
		+ " For every tree node it includes the specified number of children and "
		+ "removes all others. Hence, filtering is defined by the assigned sorter. "
		+ "If not sorter is assigned, the filtering mechanism is undefined.")
public class TopFilter extends
		ConQATPipelineProcessorBase<IRemovableConQATNode> {

	/** Number of children to include. */
	private int numOfChildren;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "top", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "The maximal number of children to include.")
	public void setMaxDepth(
			@AConQATAttribute(name = "value", description = "The number of children.") int numOfChildren) {

		this.numOfChildren = numOfChildren;
	}

	/** {@inheritDoc} */
	@Override
	protected void processInput(IRemovableConQATNode input) {
		filterNodes(input);
	}

	/**
	 * This method traverses the a node tree and filters children.
	 */
	private void filterNodes(IRemovableConQATNode element) {
		if (element.hasChildren()) {

			int childCount = 0;
			for (IRemovableConQATNode child : NodeUtils
					.getRemovableSortedChildren(element)) {
				if (childCount < numOfChildren) {
					filterNodes(child);
				} else {
					child.remove();
				}
				childCount++;
			}
		}
	}

}
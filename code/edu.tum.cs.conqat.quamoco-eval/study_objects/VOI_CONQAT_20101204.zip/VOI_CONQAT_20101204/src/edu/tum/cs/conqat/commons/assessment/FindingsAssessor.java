/*--------------------------------------------------------------------------+
$Id: FindingsAssessor.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.assessment;

import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.conqat.commons.findings.FindingsList;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.ETargetNodes;
import edu.tum.cs.conqat.commons.traversal.TargetExposedNodeTraversingProcessorBase;
import edu.tum.cs.conqat.core.AConQATKey;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 542DE8A667224244E85661D35A394A3D
 */
@AConQATProcessor(description = ""
		+ "This processor rates leaf nodes based on findings found. "
		+ "For this all keys mentioned in the display list are inspected.")
public class FindingsAssessor extends
		TargetExposedNodeTraversingProcessorBase<IConQATNode> {

	/** {@ConQAT.Doc} */
	@AConQATKey(description = "The assessment based on findings for the node.", type = "edu.tum.cs.commons.assessment.Assessment")
	public static final String KEY = "FindingsAssessment";

	/** The display list. */
	private List<String> displayList;

	/** {@inheritDoc} */
	@Override
	protected ETargetNodes getDefaultTargetNodes() {
		return ETargetNodes.LEAVES;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);
		NodeUtils.addToDisplayList(root, KEY);
		displayList = NodeUtils.getDisplayList(root);
	}

	/** {@inheritDoc} */
	public void visit(IConQATNode node) {
		ETrafficLightColor color = ETrafficLightColor.GREEN;
		for (String key : displayList) {
			Object o = node.getValue(key);
			if (o instanceof FindingsList && !((FindingsList) o).isEmpty()) {
				color = ETrafficLightColor.RED;
				break;
			}
		}
		node.setValue(KEY, new Assessment(color));
	}
}
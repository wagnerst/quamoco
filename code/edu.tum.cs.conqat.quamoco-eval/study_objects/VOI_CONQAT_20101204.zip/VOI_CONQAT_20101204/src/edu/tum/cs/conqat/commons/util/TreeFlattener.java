/*--------------------------------------------------------------------------+
$Id: TreeFlattener.java 29865 2010-08-24 09:24:36Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.util;

import java.util.List;

import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.ListNode;
import edu.tum.cs.conqat.commons.node.NodeConstants;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.commons.traversal.INodeVisitor;
import edu.tum.cs.conqat.commons.traversal.TraversalUtils;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * This processor flattens tree structures by adding all leaves directly to a
 * dummy root node.
 * 
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 29865 $
 * @levd.rating GREEN Hash: 92B4609CC77FC0FD2A16E571048BF3DE
 */
@AConQATProcessor(description = "This processor flattens tree structures by "
		+ "adding all leaves directly to a dummy root node. Only values included "
		+ "in the display list will be copied to the flat result structure.")
public class TreeFlattener extends ConQATInputProcessorBase<IConQATNode>
		implements INodeVisitor<IConQATNode, NeverThrownRuntimeException> {

	/** Result node. */
	private ListNode result;

	/** The display list of the key being copied. */
	private List<String> displayList;

	/** {@inheritDoc} */
	public ListNode process() {
		result = new ListNode(input.getId(), input.getName());
		displayList = NodeUtils.getDisplayList(input);
		result.setValue(NodeConstants.DISPLAY_LIST, displayList);
		result.setValue(NodeConstants.HIDE_ROOT, true);

		TraversalUtils.visitLeavesDepthFirst(this, input);
		return result;
	}

	/** Create child node, copy values and add to result root. */
	public void visit(IConQATNode node) {
		ListNode child = new ListNode(node.getId(), node.getName());
		for (String key : displayList) {
			child.setValue(key, node.getValue(key));
		}
		result.addChild(child);
	}

}
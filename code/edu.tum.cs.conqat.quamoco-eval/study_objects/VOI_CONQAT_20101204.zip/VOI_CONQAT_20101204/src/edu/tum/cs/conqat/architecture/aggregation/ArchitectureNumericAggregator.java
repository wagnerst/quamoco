/*--------------------------------------------------------------------------+
$Id: ArchitectureNumericAggregator.java 28103 2010-06-09 13:30:23Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.architecture.aggregation;

import java.util.List;

import edu.tum.cs.commons.math.EAggregationStrategy;
import edu.tum.cs.commons.math.MathUtils;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * {@ConQAT.Doc}
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 28103 $
 * @levd.rating GREEN Hash: FE26147BC7AA4DDE9F26EE6B6BBB95AC
 */
@AConQATProcessor(description = "This processor aggregates values along the "
		+ "hierarchy defined by the architecture in a bottom-up manner. The"
		+ "aggregation strategy is specified via a parameter. However, not all"
		+ "strategies, e.g. mean, can be applied in a bottom-up manner. ")
public class ArchitectureNumericAggregator extends
		ArchitectureAggregatorBase<Double> {

	/** Aggregation strategy. */
	private EAggregationStrategy strategy = EAggregationStrategy.SUM;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "aggregation", maxOccurrences = 1, description = ""
			+ "Defines aggregation strategy [summation is the default strategy]")
	public void setStrategy(
			@AConQATAttribute(name = "strategy", description = "The strategy") EAggregationStrategy strategy) {
		this.strategy = strategy;
	}

	/** Aggregate with aggregation strategy. */
	@Override
	protected Double aggregate(List<Double> values) throws ConQATException {
		double result = MathUtils.aggregate(values, strategy);
		if (!MathUtils.isNormal(result)) {
			throw new ConQATException(
					"Could not aggregate values. "
							+ "Probably, the aggregation was carried out on an emtpy value list.");
		}
		return result;
	}

	/**
	 * Returns numeric value or <code>null</code> if no value or value of
	 * incorrect type was found.
	 */
	@Override
	protected Double obtainValue(IConQATNode child, String readKey) {
		try {
			return NodeUtils.getDoubleValue(child, readKey);
		} catch (ConQATException e) {
			return null;
		}
	}
}

/*--------------------------------------------------------------------------+
$Id: StateflowAnalyzerBase.java 27748 2010-05-17 15:40:16Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.analyzers;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.simulink.scope.SimulinkModelElement;
import edu.tum.cs.simulink.model.SimulinkBlock;
import edu.tum.cs.simulink.model.stateflow.StateflowBlock;
import edu.tum.cs.simulink.model.stateflow.StateflowChart;
import edu.tum.cs.simulink.model.stateflow.StateflowJunction;
import edu.tum.cs.simulink.model.stateflow.StateflowNodeBase;
import edu.tum.cs.simulink.model.stateflow.StateflowState;
import edu.tum.cs.simulink.model.stateflow.StateflowTransition;

/**
 * Base class for Stateflow analyzers.
 * 
 * @author Florian Deissenboeck
 * @author $Author: hummelb $
 * @version $Rev: 27748 $
 * @levd.rating GREEN Hash: 580C9ED88AA7C7E42F4948FC59D3B173
 */
public abstract class StateflowAnalyzerBase extends
		FindingsBlockTraversingProcessorBase {

	/**
	 * Checks if block is a Stateflow block and calls
	 * {@link #visitChart(StateflowChart, SimulinkModelElement)} if it is.
	 * 
	 * @throws ConQATException
	 *             if analysis threw an exception
	 */
	@Override
	protected void visitBlock(SimulinkBlock block,
			SimulinkModelElement modelNode) throws ConQATException {

		if (block instanceof StateflowBlock) {
			visitChart(((StateflowBlock) block).getChart(), modelNode);
		}
	}

	/**
	 * Recursively visits Stateflow model and calls the appropriate
	 * <code>analyze*()</code>-methods.
	 * 
	 * @throws ConQATException
	 *             if any of the <code>analyze*()</code>-methods throws an
	 *             exception
	 */
	private void visitChart(StateflowChart chart, SimulinkModelElement modelNode)
			throws ConQATException {
		analyzeChart(chart, modelNode);
		for (StateflowNodeBase node : chart.getNodes()) {
			visitNode(node, modelNode);
		}
	}

	/**
	 * Recursively visits Stateflow model and calls the appropriate
	 * <code>analyze*()</code>-methods.
	 * 
	 * @throws ConQATException
	 *             if any of the <code>analyze*()</code>-methods throws an
	 *             exception
	 */
	private void visitNode(StateflowNodeBase node,
			SimulinkModelElement modelNode) throws ConQATException {

		for (StateflowTransition transition : node.getOutTransitions()) {
			analyzeTransition(transition, modelNode);
		}

		if (node instanceof StateflowJunction) {
			analyzeJunction((StateflowJunction) node, modelNode);
			return;
		}

		if (node instanceof StateflowState) {
			StateflowState state = (StateflowState) node;
			analyzeState(state, modelNode);
			for (StateflowNodeBase child : state.getNodes()) {
				visitNode(child, modelNode);
			}
			return;
		}

		CCSMAssert.fail("Unkown subclass :" + node.getClass().getName());
	}

	/** Override to analyze a transition. This implementation is empty. */
	@SuppressWarnings("unused")
	protected void analyzeTransition(StateflowTransition transition,
			SimulinkModelElement modelNode) throws ConQATException {
		// do nothing
	}

	/** Override to analyze a state. This implementation is empty. */
	@SuppressWarnings("unused")
	protected void analyzeState(StateflowState state,
			SimulinkModelElement modelNode) throws ConQATException {
		// do nothing
	}

	/** Override to analyze a junction. This implementation is empty. */
	@SuppressWarnings("unused")
	protected void analyzeJunction(StateflowJunction junction,
			SimulinkModelElement modelNode) throws ConQATException {
		// do nothing
	}

	/** Override to analyze a chart. This implementation is empty. */
	@SuppressWarnings("unused")
	protected void analyzeChart(StateflowChart chart,
			SimulinkModelElement modelNode) throws ConQATException {
		// do nothing
	}

}
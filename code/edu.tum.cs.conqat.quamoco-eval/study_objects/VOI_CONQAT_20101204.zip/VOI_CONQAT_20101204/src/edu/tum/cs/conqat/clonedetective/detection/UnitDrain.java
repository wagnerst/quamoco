/*--------------------------------------------------------------------------+
$Id: UnitDrain.java 31668 2010-11-26 12:52:27Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.detection;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.conqat.resource.IElement;
import org.conqat.resource.text.ITextElement;
import org.conqat.resource.text.ITextResource;
import org.conqat.resource.util.ResourceTraversalUtils;
import org.conqat.resource.util.ResourceUtils;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.filesystem.CanonicalFile;
import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IUnitProvider;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * Drains units from an {@link IUnitProvider} into a list.
 * 
 * @author juergens
 * @author $Author: heineman $
 * @version $Rev: 31668 $
 * @levd.rating GREEN Hash: EA574CAD7741E2500D9A011802448B01
 */
/* package */class UnitDrain {

	/** Logger used to issue status messages */
	private final IConQATLogger logger;

	/**
	 * If this string is set to a non-empty value, a debug file (containing the
	 * normalized units) is written for each input file.
	 */
	private final String debugFileExtension;

	/**
	 * Key that contains flag that determines whether file gets ignored.
	 * Influences log message generation, but not unit draining.
	 */
	private final String ignoreKey;

	/**
	 * Constructor
	 * 
	 * @param logger
	 *            logger of the processor that executes the {@link UnitDrain}.
	 */
	/* package */UnitDrain(IConQATLogger logger, String debugFileExtension,
			String ignoreKey) {
		this.logger = logger;
		this.debugFileExtension = debugFileExtension;
		this.ignoreKey = ignoreKey;
	}

	/**
	 * Determines all units used for clone detection.
	 * 
	 * @param units
	 *            List to add units to. If null, units are discarded.
	 * */
	public void drainUnits(ITextResource input,
			IUnitProvider<ITextResource, Unit> unitProvider, List<Unit> units)
			throws ConQATException {
		// include sentinelizer
		unitProvider = new Sentinelizer(unitProvider);

		// read units from unit provider
		logger.debug("Before unit drain...");
		int unitCount = drainUnitProvider(input, unitProvider, units);
		logger.debug("Units drained:" + unitCount);

		// write debug files
		if (!StringUtils.isEmpty(debugFileExtension)) {
			writeDebugFiles(units, input);
		}

		// mark files without units
		logEmptyFiles(input);
	}

	/**
	 * Writes a debug file for each input file. The debug file contains the
	 * units after normalization (in the same line numbers as in the original
	 * file). The name of the debug file is the name of the original file with
	 * the debugFileExtension.
	 */
	private void writeDebugFiles(List<Unit> units, ITextResource input)
			throws ConQATException {
		HashedListMap<String, Unit> pathUnits = new HashedListMap<String, Unit>();
		for (Unit unit : units) {
			pathUnits.add(unit.getElementUniformPath(), unit);
		}

		Map<String, IElement> map = ResourceTraversalUtils
				.createUniformPathToElementMap(input, IElement.class);

		for (String path : pathUnits.getKeys()) {
			IElement element = map.get(path);
			CCSMAssert.isNotNull(element,
					"May not be null due to same input root used!");

			List<Unit> unitsInFile = pathUnits.getList(path);
			CanonicalFile originalFile = ResourceUtils.getFile(element);
			if (originalFile == null) {
				throw new ConQATException(
						"Writing of debug files only works for elements in the file system!");
			}

			File debugFile = new File(originalFile.getCanonicalPath()
					+ debugFileExtension);
			writeDebugFile(debugFile, unitsInFile);
		}
	}

	/**
	 * Writes a single debug file.
	 * 
	 * @param debugFile
	 *            Debug file to write
	 * @param unitsInFile
	 *            List of units that gets written into the file
	 */
	private void writeDebugFile(File debugFile, List<Unit> unitsInFile) {
		int line = 0;
		StringBuilder content = new StringBuilder();
		for (Unit unit : unitsInFile) {
			while (unit.getStartLineInElement() > line) {
				content.append(StringUtils.CR);
				line++;
			}
			content.append(unit.getContent());
		}

		try {
			FileSystemUtils.writeFile(debugFile, content.toString());
		} catch (IOException e) {
			logger.warn("Could not write debug file: " + debugFile + ": "
					+ e.getMessage());
		}
	}

	/**
	 * Searches for files with 0 units used for clone detection and creates log
	 * messages accordingly. The underlying assumption is that a file that is
	 * included in clone detection, yet does not contain a single unit that gets
	 * used for clone detection, can potentially indicate a configuration
	 * problem.
	 * <p>
	 * If a file is marked as ignore, no warning is created
	 */
	private void logEmptyFiles(ITextResource input) {
		List<ITextElement> elements = ResourceTraversalUtils
				.listTextElements(input);

		for (ITextElement element : elements) {
			if (element.getValue(UnitProcessorBase.UNITS_KEY) == null) {
				element.setValue(UnitProcessorBase.UNITS_KEY, 0);

				if (!NodeUtils.isIgnored(element, ignoreKey)) {
					logger.debug("File " + element.getLocation()
							+ " has 0 non-ignored units.");
				}
			}
		}
	}

	/**
	 * Retrieves all units from the unitProvider and stores them in a list
	 * <p>
	 * Additionally, the number of units encountered in a file is stored at the
	 * corresponding element. However, no unit count value is stored at file
	 * elements that don't contain a single unit.
	 * 
	 * @param units
	 *            List to add units to. If null, units are discarded.
	 * 
	 * @return Number of units drained
	 */
	private int drainUnitProvider(ITextResource input,
			IUnitProvider<ITextResource, Unit> unitProvider, List<Unit> units)
			throws ConQATException {

		List<ITextElement> elements = ResourceTraversalUtils
				.listNonIgnoredElements(input, ignoreKey, ITextElement.class);

		int unitsInElementsCount = 0;
		for (ITextElement fileElement : elements) {
			// initialize lazy pipeline with leaf
			unitProvider.init(fileElement, logger);

			// drain units into list
			unitsInElementsCount += drainUnitsFromElement(fileElement,
					unitProvider, units);
		}

		return unitsInElementsCount;
	}

	/** Drain units from element */
	private int drainUnitsFromElement(ITextElement input,
			IUnitProvider<ITextResource, Unit> unitProvider, List<Unit> units)
			throws CloneDetectionException, ConQATException {
		int unitsInFileCount = 0;
		Unit unit = unitProvider.getNext();
		while (unit != null) {
			if (units != null) {
				units.add(unit);
			}
			// ignore synthetic units, since they are not part of the file
			if (!unit.isSynthetic()) {
				unitsInFileCount++;
			}

			Unit nextUnit = unitProvider.getNext();
			if (lastUnitInFile(unit, nextUnit)) {
				input.setValue(UnitProcessorBase.UNITS_KEY, unitsInFileCount);
				unitsInFileCount = 0;
			}

			unit = nextUnit;
		}

		return unitsInFileCount;
	}

	/** Checks whether a unit is the last unit from its file */
	private boolean lastUnitInFile(Unit unit, Unit nextUnit) {
		return nextUnit == null || !unit.inSameElement(nextUnit);
	}

}
/*--------------------------------------------------------------------------+
$Id: LogManager.java 27287 2010-03-30 13:34:34Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.logging;

import java.util.List;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.collections.UnmodifiableSet;
import edu.tum.cs.conqat.driver.ConQATInstrumentation;

/**
 * A Log4J appender that collects log messages and stores them. This allows
 * processors like the HTML presentation to display log messages.
 * 
 * @author Benjamin Hummel
 * @author Lukas Kuhn
 * @author Florian Deissenboeck
 * @author $Author: juergens $
 * 
 * @version $Rev: 27287 $
 * @levd.rating GREEN Hash: 3145E0A7805B0CF25C18373887A846DC
 */
public class LogManager extends AppenderSkeleton {

	/** Maps from processor names to list of logging events. */
	private final HashedListMap<String, ConQATLoggingEvent> conqatLogMessages = new HashedListMap<String, ConQATLoggingEvent>();

	/** The instrumentation used. */
	private final ConQATInstrumentation instrumentation;

	/** Constructor. */
	public LogManager(ConQATInstrumentation instrumentation) {
		this.instrumentation = instrumentation;
	}

	/** {@inheritDoc} */
	@Override
	public void close() {
		// nothing to do
	}

	/**
	 * Get the names of all processor that created log events.
	 */
	public UnmodifiableSet<String> getLoggingProcessors() {
		return CollectionUtils.asUnmodifiable(conqatLogMessages.getKeys());
	}

	/**
	 * Get all logging events.
	 * 
	 * @return the events, or an empty list if no events occurred.
	 */
	public UnmodifiableList<ConQATLoggingEvent> getLoggingEvents() {
		List<ConQATLoggingEvent> events = conqatLogMessages.getValues();

		if (events == null) {
			return CollectionUtils.emptyList();
		}

		return CollectionUtils.asUnmodifiable(events);
	}

	/**
	 * Get all logging events created by a specific processor.
	 * 
	 * @param processorName
	 *            name of the processor
	 * @return the events, or an empty list if no events occurred.
	 */
	public UnmodifiableList<ConQATLoggingEvent> getLogMessages(
			String processorName) {
		List<ConQATLoggingEvent> logMessages = conqatLogMessages
				.getList(processorName);

		if (logMessages == null) {
			return CollectionUtils.emptyList();
		}

		return CollectionUtils.asUnmodifiable(logMessages);
	}

	/** {@inheritDoc} */
	@Override
	public boolean requiresLayout() {
		// we want layout
		return true;
	}

	/** {@inheritDoc} */
	@Override
	protected void append(LoggingEvent event) {
		ConQATLoggingEvent conqatLoggingEvent = new ConQATLoggingEvent(event);

		conqatLogMessages.add(conqatLoggingEvent.getProcessorName(),
				conqatLoggingEvent);

		instrumentation.eventLogged(conqatLoggingEvent);
	}
}
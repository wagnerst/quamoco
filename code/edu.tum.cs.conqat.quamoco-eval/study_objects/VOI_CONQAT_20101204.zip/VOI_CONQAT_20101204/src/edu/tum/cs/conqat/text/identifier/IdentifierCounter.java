/*--------------------------------------------------------------------------+
$Id: IdentifierCounter.java 31764 2010-11-26 17:18:06Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.identifier;

import edu.tum.cs.commons.collections.CounterSet;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: hummelb $
 * @version $Revision: 31764 $
 * @levd.rating GREEN Hash: BC76F0558E54D09CA0A1751C0AE05295
 */
@AConQATProcessor(description = "This processor counts the "
		+ "occurrences of identifiers from a source code tree. The result is a counterset that stores "
		+ "the frequency of each identifier")
public class IdentifierCounter extends
		IdentifierProcessorBase<CounterSet<String>> {

	/** Maps the identifier text to the number of occurrences. */
	private final CounterSet<String> counter = new CounterSet<String>();

	/** {@inheritDoc} */
	@Override
	protected CounterSet<String> obtainResult() {
		return counter;
	}

	/** {@inheritDoc} */
	@Override
	protected void processIdentifier(String identifier) {
		counter.inc(identifier);
	}
}

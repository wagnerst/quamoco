/*--------------------------------------------------------------------------+
$Id: BasicBlockShaper.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.shapers;

import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.scanner.ETokenType;
import edu.tum.cs.scanner.IToken;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 26282 $
 * @levd.rating GREEN Hash: D9EFBF8B23C3512DECDE8EED7FB778F9
 */
@AConQATProcessor(description = ""
		+ "Inserts sentinels after each '{' or '}' character. Clones thus cannot cross block boundaries.")
public class BasicBlockShaper extends ShaperBase {

	/** Determines whether a token represents a boundary */
	@Override
	protected boolean isBoundary(IToken token) {
		return token.getType() == ETokenType.RBRACE
				|| token.getType() == ETokenType.LBRACE;
	}

}
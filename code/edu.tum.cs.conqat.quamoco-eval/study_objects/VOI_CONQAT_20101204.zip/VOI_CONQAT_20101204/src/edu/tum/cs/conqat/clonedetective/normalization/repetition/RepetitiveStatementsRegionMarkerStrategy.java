/*--------------------------------------------------------------------------+
$Id: RepetitiveStatementsRegionMarkerStrategy.java 31491 2010-11-25 15:38:31Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.repetition;

import java.io.Serializable;
import java.util.List;

import org.conqat.sourcecode.resource.ITokenElement;

import edu.tum.cs.commons.region.RegionSet;
import edu.tum.cs.conqat.clonedetective.core.StatementUnit;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.sourcecode.analysis.SourceCodeElementRegionMarkerStrategyBase;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: heineman $
 * @version $Rev: 31491 $
 * @levd.rating GREEN Hash: 558A907CAF9AFB4E9C3620DD61CDCBFD
 */
@AConQATProcessor(description = ""
		+ "Marks regions of repetitive statements for context sensitive normalization")
public class RepetitiveStatementsRegionMarkerStrategy extends
		SourceCodeElementRegionMarkerStrategyBase implements Serializable {

	/** Repetition detection parameters */
	private RepetitionParameters repetitionParameters = null;

	/** ConQAT Parameter */
	@AConQATParameter(name = "min", description = "Minimal size of repetition", minOccurrences = 1, maxOccurrences = 1)
	public void setMinLength(
			@AConQATAttribute(name = ConQATParamDoc.REPETITION_MIN_LENGTH_NAME, description = ConQATParamDoc.REPETITION_MIN_LENGTH_DESC) int minLength,
			@AConQATAttribute(name = ConQATParamDoc.REPETITION_MIN_INSTANCES_NAME, description = ConQATParamDoc.REPETITION_MIN_INSTANCES_DESC) int minMotifInstances,
			@AConQATAttribute(name = ConQATParamDoc.REPETITION_MIN_MOTIF_LENGTH_NAME, description = ConQATParamDoc.REPETITION_MIN_MOTIF_LENGTH_DESC) int minMotifLength,
			@AConQATAttribute(name = ConQATParamDoc.REPETITION_MAX_MOTIF_LENGTH_NAME, description = ConQATParamDoc.REPETITION_MAX_MOTIF_LENGTH_DESC) int maxMotifLength)
			throws ConQATException {
		repetitionParameters = new RepetitionParameters(minLength,
				minMotifLength, maxMotifLength, minMotifInstances);
	}

	/** Sets {@link RepetitionParameters} for programmatic use of the strategy. */
	/* package */void setRepetitionParameters(
			RepetitionParameters repetitionParameters) {
		this.repetitionParameters = repetitionParameters;
	}

	/**
	 * Creates regions marking repetitions with motifs of length between 1 and
	 * max motif length
	 */
	@Override
	protected void findRegionsForElement(ITokenElement element, RegionSet result)
			throws ConQATException {
		StatementUnit[] sequence = RepetitionUtils.getStatements(element,
				getLogger());

		RepetitionFinder<StatementUnit> detector = new RepetitionFinder<StatementUnit>(
				sequence, new StatementEquator(), repetitionParameters
						.getMinLength(), repetitionParameters
						.getMinMotifInstances());
		List<Repetition<StatementUnit>> repetitions = detector.findRepetitions(
				repetitionParameters.getMinMotifLength(), repetitionParameters
						.getMaxMotifLength());

		for (Repetition<StatementUnit> repetition : repetitions) {
			result.add(RepetitionUtils.regionFor(repetition));
		}
	}

}
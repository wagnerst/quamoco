/*--------------------------------------------------------------------------+
$Id: ILAssemblyDependenciesImporterProcessor.java 31638 2010-11-26 11:18:58Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.dotnet.ila;

import org.conqat.resource.text.ITextElement;

import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.dotnet.ila.xml.IlaAssembliesXmlReader;
import edu.tum.cs.conqat.dotnet.ila.xml.IlaXmlReaderBase;

/**
 * {@ConQAT.Doc}
 * 
 * @see ILAnalyzerRunnerProcessor
 * 
 * @author $Author: hummelb $
 * @version $Revision: 31638 $
 * @levd.rating GREEN Hash: 562EAEF655EDA70B0C8423FA0AE373A9
 */
@AConQATProcessor(description = "Reads dependency information stored in XML produced by the Intermediate "
		+ "Language Analyzer files into a representation that can be used to create an dependency graph of the "
		+ "assemblies contained in a solution.")
public class ILAssemblyDependenciesImporterProcessor extends
		ILImporterProcessorBase {

	/** {@inheritDoc} */
	@Override
	protected IlaXmlReaderBase<?> createXmlReader(ITextElement element)
			throws ConQATException {
		return new IlaAssembliesXmlReader(element.getTextContent(), outputRoot,
				excludePatterns, includePatterns, includedDependencies,
				excludedDependencies);
	}
}
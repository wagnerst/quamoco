/*--------------------------------------------------------------------------+
$Id: Unit.java 31677 2010-11-26 13:03:55Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core;

import edu.tum.cs.conqat.driver.instance.ConQATStringPool;

/**
 * Base class for units.
 * <p>
 * We have observed that in large code bases, the number of different units
 * after normalization is significantly smaller than the total number of units.
 * We exploit this observation in order to reduce the memory footprint of the
 * units by pooling unit content strings. This way, each unit content string is
 * only kept in memory once, independent of how often it occurs in the source
 * code. For pooling, we use Java's {@link String#intern()} facility in the
 * constructor {@link Unit}.
 * <p>
 * <b>Note:</b> The implementation of {@link #hashCode()} and
 * {@link #equals(Object)} are crucial for the detection algorithm.
 * 
 * @author $Author: heineman $
 * @version $Rev: 31677 $
 * @levd.rating GREEN Hash: 0A9B601289F6B4440B8C90A72FE8934A
 */
public abstract class Unit {

	/** The position in the element */
	private final int startLineInElement;

	/** The uniform path of the element this unit stems from. */
	private final String elementUniformPath;

	/** The number of lines covered by this unit */
	private final int coveredLines;

	/** The number of lines covered by this unit */
	private final int indexInElement;

	/** The content of this unit. */
	private final String content;

	/** The content of this unit without normalization */
	private final String unnormalizedContent;

	/** Create a new unit with identical normalized and unnormalized content */
	protected Unit(int startLineInElement, String elementUniformPath,
			String content, int coveredLines, int indexInElement) {
		this(startLineInElement, elementUniformPath, content, content,
				coveredLines, indexInElement);
	}

	/** Create new unit */
	protected Unit(int startLineInElement, String elementUniformPath,
			String content, String unnormalizedContent, int coveredLines,
			int indexInElement) {
		this.startLineInElement = startLineInElement;
		this.elementUniformPath = elementUniformPath;
		this.content = ConQATStringPool.intern(content);
		this.unnormalizedContent = ConQATStringPool.intern(unnormalizedContent);
		this.coveredLines = coveredLines;
		this.indexInElement = indexInElement;
	}

	/** Uniform path of the element this unit stems from. */
	public String getElementUniformPath() {
		return elementUniformPath;
	}

	/** Gets the line number of the start of the unit in the source element. */
	public int getStartLineInElement() {
		return startLineInElement;
	}

	/** Gets the index of the unit in the source element */
	public int getIndexInElement() {
		return indexInElement;
	}

	/** Returns the number of lines this unit covers in the source element */
	public int getCoveredLines() {
		return coveredLines;
	}

	/** Textual content of the unit. */
	public String getContent() {
		return content;
	}

	/** Unnormalized textual content of this unit */
	public String getUnnormalizedContent() {
		return unnormalizedContent;
	}

	/**
	 * The hash code of a unit object is identical to the hash code of its
	 * content string.
	 * 
	 * @see #getContent()
	 */
	@Override
	public int hashCode() {
		return content.hashCode();
	}

	/** Two unit objects are equal if there content strings are equal. */
	@Override
	public boolean equals(Object other) {
		// contrary to the myths on the net this is not slower than catching
		// the class cast exception
		if (!(other instanceof Unit)) {
			return false;
		}

		// we use equals(), which is fast for the same string (i.e. same
		// reference) but still can cope with different references (if there are
		// non-interned strings).
		return content.equals(((Unit) other).content);
	}

	/** Default implementation returns false. Override for synthetic units */
	public boolean isSynthetic() {
		return false;
	}

	/** Checks whether other unit stems from same element */
	public boolean inSameElement(Unit other) {
		return getElementUniformPath().equals(other.getElementUniformPath());
	}
}
/*--------------------------------------------------------------------------+
$Id: SimulinkClonesToFindingsConverter.java 27354 2010-04-02 13:10:39Z klenkm $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.output;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.commons.findings.EFindingKeys;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingCategory;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.FindingReport;
import edu.tum.cs.conqat.commons.findings.location.QualifiedNameLocation;
import edu.tum.cs.conqat.commons.findings.typespec.EFindingTypeSpecType;
import edu.tum.cs.conqat.commons.findings.typespec.FindingTypeSpec;
import edu.tum.cs.conqat.commons.findings.typespec.FindingTypeSpecEntry;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.simulink.clones.result.SimulinkClone;
import edu.tum.cs.conqat.simulink.clones.result.SimulinkCloneResultNode;
import edu.tum.cs.simulink.model.SimulinkBlock;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: klenkm $
 * @version $Rev: 27354 $
 * @levd.rating GREEN Hash: 16B9A7252ECA9F84ECC7337601B16003
 */
@AConQATProcessor(description = "Processor for converting a Simulink clone result to a finding report.")
public class SimulinkClonesToFindingsConverter extends ConQATProcessorBase {

	/** The clones */
	private SimulinkCloneResultNode cloneResult;

	/** The category to add to. */
	private FindingCategory category;

	/** Counter for the clone groups. */
	private int numGroups = 0;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = ConQATParamDoc.INPUT_NAME, minOccurrences = 1, maxOccurrences = 1, description = "The simulink clone result.")
	public void setCloneResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) SimulinkCloneResultNode cloneResult) {
		this.cloneResult = cloneResult;
	}

	/** {@inheritDoc} */
	public FindingReport process() {
		FindingReport report = new FindingReport();
		category = report.getOrCreateCategory("Simulink Clones");
		for (SimulinkClone clone : cloneResult.getChildren()) {
			convertClone(clone);
		}
		return report;
	}

	/** Converts a clone to a finding group. */
	private void convertClone(SimulinkClone clone) {
		FindingGroup group = category.createFindingGroup("Clone Group "
				+ ++numGroups);
		for (UnmodifiableList<SimulinkBlock> blocks : clone.getBlockLists()) {
			Finding finding = group
					.createFinding("ConQAT Model Clone Detective");
			for (SimulinkBlock block : blocks) {
				finding.addLocation(new QualifiedNameLocation(block.getId()));
			}
		}

		FindingTypeSpec format = new FindingTypeSpec();
		// just copy everything looking numeric
		for (String key : NodeUtils.getDisplayList(cloneResult)) {
			Object value = clone.getValue(key);
			if (value instanceof Number) {
				group.setValue(key, value);
				format.addEntry(new FindingTypeSpecEntry(key,
						EFindingTypeSpecType.DOUBLE));
			} else {
				System.err.println("ignored " + key);
			}
		}

		group.setValue(EFindingKeys.TYPESPEC.name(), format);
	}
}
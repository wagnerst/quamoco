/*--------------------------------------------------------------------------+
$Id: ListBasedTokenProvider.java 30652 2010-10-18 15:52:53Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.provider;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import org.conqat.sourcecode.resource.ITokenResource;

import edu.tum.cs.conqat.clonedetective.normalization.token.TokenProviderBase;
import edu.tum.cs.scanner.IToken;

/**
 * Provides tokens from a list.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30652 $
 * @levd.rating GREEN Hash: 78B7242B629A3C5DD9A8F237280E4D9F
 */
public class ListBasedTokenProvider extends TokenProviderBase implements
		Serializable {
	/** Iterator that keeps track of position in tokens list */
	private Iterator<IToken> tokenIterator;

	/** Constructor */
	public ListBasedTokenProvider(List<IToken> tokens) {
		tokenIterator = tokens.iterator();
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ITokenResource root) {
		// Do nothing
	}

	/** {@inheritDoc} */
	@Override
	protected IToken provideNext() {
		if (tokenIterator != null && tokenIterator.hasNext()) {
			return tokenIterator.next();
		}

		tokenIterator = null;
		return null;
	}
}
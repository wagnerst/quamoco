/*--------------------------------------------------------------------------+
$Id: InMemoryStore.java 28591 2010-06-22 15:31:32Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database.store.mem;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.Map.Entry;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.database.store.IKeyValueCallback;
import edu.tum.cs.conqat.database.store.StorageException;
import edu.tum.cs.conqat.database.store.base.ByteArrayComparator;
import edu.tum.cs.conqat.database.store.base.StoreBase;

/**
 * Store implementation that keeps all data in main memory. Very simple
 * persistence is possible, but all data must fit into main memory.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 28591 $
 * @levd.rating GREEN Hash: EAE7FE2AE807D7D31FC3FFA4AFC34D0B
 */
/* package */class InMemoryStore extends StoreBase {

	/** Data store. */
	private final NavigableMap<byte[], byte[]> data = new TreeMap<byte[], byte[]>(
			ByteArrayComparator.INSTANCE);

	/** {@inheritDoc} */
	@Override
	public byte[] get(byte[] key) {
		byte[] value = data.get(key);
		if (value == null) {
			return null;
		}
		return value.clone();
	}

	/** {@inheritDoc} */
	@Override
	public void put(byte[] key, byte[] value) {
		data.put(key.clone(), value.clone());
	}

	/** {@inheritDoc} */
	@Override
	public void remove(byte[] key) {
		data.remove(key);
	}

	/** {@inheritDoc} */
	@Override
	public void scan(byte[] beginKey, byte[] endKey, IKeyValueCallback callback) {
		for (Entry<byte[], byte[]> entry : data.subMap(beginKey, endKey)
				.entrySet()) {
			callback.callback(entry.getKey().clone(), entry.getValue().clone());
		}
	}

	/** {@inheritDoc} */
	@Override
	public void close() {
		// nothing to do
	}

	/**
	 * Serializes this store to the given file. The contents of this file will
	 * be overwritten.
	 */
	public void dumpToFile(File file) throws StorageException {
		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(new BufferedOutputStream(
					new FileOutputStream(file)));
			out.writeObject(data);
		} catch (IOException e) {
			throw new StorageException("Could not persist store: "
					+ e.getMessage(), e);
		} finally {
			FileSystemUtils.close(out);
		}
	}

	/** Loads all entries from a map which was serialized to the given file. */
	@SuppressWarnings("unchecked")
	public void loadFromFile(File file) throws StorageException {
		ObjectInputStream in = null;
		try {
			in = new ObjectInputStream(new BufferedInputStream(
					new FileInputStream(file)));
			Map<byte[], byte[]> m = (Map<byte[], byte[]>) in.readObject();
			data.putAll(m);
		} catch (ClassNotFoundException e) {
			// we map this to IOException as it is an unlikely case and
			// indicates data corruption
			throw new StorageException("Invalid file contents: "
					+ e.getMessage(), e);
		} catch (IOException e) {
			throw new StorageException("Could not load store: "
					+ e.getMessage(), e);
		} finally {
			FileSystemUtils.close(in);
		}
	}
}

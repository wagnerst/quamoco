/*--------------------------------------------------------------------------+
$Id: CloneReportWriterProcessor.java 31701 2010-11-26 14:21:42Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.conqat.resource.text.ITextElement;
import org.conqat.resource.text.ITextResource;
import org.conqat.resource.text.TextElementUtils;
import org.conqat.resource.util.ResourceTraversalUtils;

import edu.tum.cs.commons.digest.Digester;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.report.CloneReportWriter;
import edu.tum.cs.conqat.clonedetective.core.report.SourceElementDescriptor;
import edu.tum.cs.conqat.clonedetective.core.utils.CloneUtils;
import edu.tum.cs.conqat.clonedetective.detection.CloneDetectionResultElement;
import edu.tum.cs.conqat.commons.ConQATParamDoc;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.logging.IConQATLogger;

/**
 * {@ConQAT.Doc}
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * @version $Revision: 31701 $
 * @levd.rating GREEN Hash: 15C543D4A9CEBF27ACF17F84A7959031
 */
@AConQATProcessor(description = "Processor that writes a clone detection result file in xml format."
		+ "The actual xml processing is performed in class {@link CloneReportWriter}."
		+ "The main job of this class is to make {@link CloneReportWriter} accessible in"
		+ "a ConQAT clone detection configuration. This separation allows for the use of"
		+ "{@link CloneReportWriter} outside of ConQAT.")
public class CloneReportWriterProcessor extends CloneReportWriterProcessorBase {

	/** Clone detection result for which report gets written */
	private CloneDetectionResultElement detectionResult;

	/** ConQAT Parameter */
	@AConQATParameter(name = "detection-result", description = ConQATParamDoc.INPUT_DESC, minOccurrences = 1, maxOccurrences = 1)
	public void setDetectionResult(
			@AConQATAttribute(name = ConQATParamDoc.INPUT_REF_NAME, description = ConQATParamDoc.INPUT_REF_DESC) CloneDetectionResultElement detectionResult) {
		this.detectionResult = detectionResult;
	}

	/** {@inheritDoc} */
	@Override
	protected void doWriteReport() throws ConQATException {
		List<CloneClass> cloneClasses = detectionResult.getList();
		writeReport(cloneClasses, detectionResult.getRoot(), detectionResult
				.getSystemDate(), targetFile, getLogger());

		getLogger().info("Clone classes: " + cloneClasses.size());
		getLogger().info("Clones: " + CloneUtils.countClones(cloneClasses));
	}

	/**
	 * Writes a clone report file using a {@link CloneReportWriter}.
	 * 
	 * @param cloneClasses
	 *            Result clone classes that get written to the report
	 * @param root
	 *            Root of the resource tree on which detection has been
	 *            performed
	 * @param systemDate
	 *            Date denoting the system version on which clone detection was
	 *            performed.
	 * @param targetFile
	 *            File into which report gets written
	 * @param logger
	 *            Logger used to log errors occurring during report writing
	 * 
	 * @throws ConQATException
	 *             If report creation fails.
	 */
	public static void writeReport(List<CloneClass> cloneClasses,
			ITextResource root, Date systemDate, File targetFile,
			IConQATLogger logger) throws ConQATException {
		CloneReportWriter.writeReport(cloneClasses,
				createSourceElementDescriptors(root, logger), systemDate,
				targetFile);
	}

	/** Creates a Map from clone uniform paths to {@link SourceElementDescriptor}s. */
	private static Map<String, SourceElementDescriptor> createSourceElementDescriptors(
			ITextResource root, IConQATLogger logger) {
		Map<String, SourceElementDescriptor> sourceElementInfos = new HashMap<String, SourceElementDescriptor>();

		int sourceElementIdCounter = 0;
		for (ITextElement element : ResourceTraversalUtils
				.listTextElements(root)) {
			int length = -1;
			String fingerprint = StringUtils.EMPTY_STRING;
			try {
				length = TextElementUtils.countLOC(element);
				fingerprint = Digester
						.createMD5Digest(element.getTextContent());
			} catch (ConQATException e) {
				logger.warn("Could not read element " + element.getLocation()
						+ " in order to compute length and fingerprint: "
						+ e.getMessage());
			}

			sourceElementInfos.put(element.getUniformPath(),
					new SourceElementDescriptor(sourceElementIdCounter++, element
							.getLocation(), element.getUniformPath(), length,
							fingerprint));
		}
		return sourceElementInfos;
	}

}
/*--------------------------------------------------------------------------+
$Id: RangeBasedAssessorBase.java 30050 2010-09-03 11:27:17Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.commons.assessment;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.assessment.Assessment;
import edu.tum.cs.commons.assessment.ETrafficLightColor;
import edu.tum.cs.commons.math.Range;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * An assessor based on given ranges.
 * 
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 30050 $
 * @levd.rating GREEN Hash: F7EAF5EB2D9F5C456F185C3FFE819001
 */
public abstract class RangeBasedAssessorBase<E> extends LocalAssessorBase<E> {

	/** The ranges used in the assessment. */
	private final List<AssessedRange> ranges = new ArrayList<AssessedRange>();

	/** Color used, if no range matches. */
	private ETrafficLightColor defaultColor = ETrafficLightColor.RED;

	/** Add a new assessment range. */
	@AConQATParameter(name = "range", description = "Adds an assessment range. The ranges defined may not overlap.")
	public void addRange(
			@AConQATAttribute(name = "lower", description = "lower bound of the range (exclusive).") double lower,
			@AConQATAttribute(name = "upper", description = "upper bound of the range (inclusive).") double upper,
			@AConQATAttribute(name = "color", description = "color to use if the value is in this range") ETrafficLightColor color)
			throws ConQATException {
		ranges.add(new AssessedRange(lower, upper, color));
	}

	/** Set the color used if no range matches. */
	@AConQATParameter(name = "default", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Set the assessment color returned if no range contained the value. Default is RED.")
	public void setDefaultColor(
			@AConQATAttribute(name = "color", description = "traffic light color") ETrafficLightColor color) {
		defaultColor = color;
	}

	/** {@inheritDoc} */
	@Override
	protected void setUp(IConQATNode root) throws ConQATException {
		super.setUp(root);

		checkRanges();
	}

	/**
	 * Checks if there are overlapping ranges. The algorithm checks for each
	 * pair of ranges, whether the upper bound of one range is contained in the
	 * other one. This works, as for each possible overlapping configuration of
	 * ranges this holds for at least one pair.
	 */
	private void checkRanges() throws ConQATException {
		for (AssessedRange r1 : ranges) {
			for (AssessedRange r2 : ranges) {
				if (r1 != r2 && r1.contains(r2.getUpper())) {
					throw new ConQATException(
							"May not use overlapping ranges: " + r1 + " and "
									+ r2);
				}
			}
		}
	}

	/** {@inheritDoc} */
	@Override
	protected final Assessment assessValue(E e) {
		double value = obtainDouble(e);
		for (AssessedRange r : ranges) {
			if (r.contains(value)) {
				return new Assessment(r.color);
			}
		}
		return new Assessment(defaultColor);
	}

	/** Obtains a double from the value which should be assessed. */
	protected abstract double obtainDouble(E value);

	/** Helper class to store ranges and their assigned colors. */
	private static class AssessedRange extends Range {

		/** assigned color. */
		public final ETrafficLightColor color;

		/** Constructor. */
		public AssessedRange(double lower, double upper,
				ETrafficLightColor color) throws ConQATException {
			super(lower, false, upper, true);
			if (isEmpty()) {
				throw new ConQATException(
						"Invalid/empty range (lower >= upper): " + lower
								+ " and " + upper);
			}
			this.color = color;
		}
	}
}
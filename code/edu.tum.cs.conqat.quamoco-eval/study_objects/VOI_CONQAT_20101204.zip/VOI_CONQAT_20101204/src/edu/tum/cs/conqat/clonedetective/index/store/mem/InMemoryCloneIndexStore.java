/*--------------------------------------------------------------------------+
$Id: InMemoryCloneIndexStore.java 30291 2010-10-04 12:49:54Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index.store.mem;

import java.util.List;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.digest.MD5Digest;
import edu.tum.cs.conqat.clonedetective.index.Chunk;

/**
 * A clone index store that keeps all data in memory.
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 30291 $
 * @levd.rating GREEN Hash: AFC39EFB76A16836BFEAE01DD05A439D
 */
public class InMemoryCloneIndexStore extends MemoryStoreBase {

	/** Map for storing {@link Chunk}s by originId. */
	protected final HashedListMap<String, Chunk> byOrigin = new HashedListMap<String, Chunk>();

	/** Map for storing {@link Chunk}s by hash. */
	protected final HashedListMap<MD5Digest, Chunk> byHash = new HashedListMap<MD5Digest, Chunk>();

	/** {@inheritDoc} */
	@Override
	public void batchInsertChunks(List<Chunk> chunks) {
		for (Chunk chunk : chunks) {
			byOrigin.add(chunk.getOriginId(), chunk);
			byHash.add(chunk.getChunkHash(), chunk);
		}
	}

	/** {@inheritDoc} */
	@Override
	public void removeChunks(String originId) {
		List<Chunk> chunks = byOrigin.getList(originId);
		byOrigin.removeList(originId);

		for (Chunk chunk : chunks) {
			List<Chunk> list = byHash.getList(chunk.getChunkHash());
			list.remove(chunk);
		}
	}

	/** {@inheritDoc} */
	@Override
	public List<Chunk> getChunksByOrigin(String originId) {
		return byOrigin.getList(originId);
	}

	/** {@inheritDoc} */
	@Override
	public UnmodifiableList<Chunk> getChunksByHash(MD5Digest chunkHash) {
		return CollectionUtils.asUnmodifiable(byHash.getList(chunkHash));
	}
}

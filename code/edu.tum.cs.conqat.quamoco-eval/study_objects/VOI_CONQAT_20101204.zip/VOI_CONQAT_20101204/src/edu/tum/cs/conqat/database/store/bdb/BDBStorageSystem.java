/*--------------------------------------------------------------------------+
$Id: BDBStorageSystem.java 29797 2010-08-19 09:38:31Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database.store.bdb;

import java.io.File;
import java.io.IOException;

import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;

import edu.tum.cs.commons.filesystem.FileSystemUtils;
import edu.tum.cs.conqat.database.store.IStorageSystem;
import edu.tum.cs.conqat.database.store.IStore;
import edu.tum.cs.conqat.database.store.StorageException;

/**
 * Storage system based on Berkeley DB.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29797 $
 * @levd.rating GREEN Hash: 1CC6C222B5EE2117226C141BCCF720E5
 */
public class BDBStorageSystem implements IStorageSystem {

	/** The environment. */
	private final Environment environment;

	/**
	 * Constructor.
	 * 
	 * @param cacheMemoryInMB
	 *            the size of the memory cache in MB. If this is 0 or negative,
	 *            BDBs default size is used (which is not recommended).
	 */
	public BDBStorageSystem(File baseDirectory, int cacheMemoryInMB)
			throws StorageException {
		try {
			FileSystemUtils.ensureDirectoryExists(baseDirectory);
		} catch (IOException e) {
			throw new StorageException("Could not create store location: "
					+ baseDirectory, e);
		}

		try {
			EnvironmentConfig envConfig = new EnvironmentConfig();
			envConfig.setAllowCreate(true);
			if (cacheMemoryInMB > 0) {
				envConfig.setCacheSize(cacheMemoryInMB * 1024 * 1024);
			}
			environment = new Environment(baseDirectory, envConfig);
		} catch (DatabaseException e) {
			throw new StorageException("Could not initialize BDB store!", e);
		}
	}

	/** {@inheritDoc} */
	@Override
	public IStore openStore(String name) throws StorageException {
		try {
			DatabaseConfig dbConfig = new DatabaseConfig();
			dbConfig.setAllowCreate(true);
			dbConfig.setDeferredWrite(true);
			Database database = environment.openDatabase(null, name, dbConfig);
			return new BDBStore(database);
		} catch (DatabaseException e) {
			throw new StorageException("Could not access BDB database called "
					+ name + "!", e);
		}
	}

	/** {@inheritDoc} */
	@Override
	public void removeStore(String storeName) throws StorageException {
		try {
			if (environment.getDatabaseNames().contains(storeName)) {
				environment.removeDatabase(null, storeName);
			}
		} catch (DatabaseException e) {
			throw new StorageException("Could not delete store " + storeName
					+ "!", e);
		}
	}

	/** {@inheritDoc} */
	@Override
	public void close() throws StorageException {
		try {
			environment.close();
		} catch (DatabaseException e) {
			throw new StorageException("Could not close!", e);
		}
	}
}

/*--------------------------------------------------------------------------+
$Id: ISimulinkNormalizer.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.clones.normalize;

import edu.tum.cs.commons.clone.IDeepCloneable;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.simulink.model.SimulinkBlock;
import edu.tum.cs.simulink.model.SimulinkLine;

/**
 * Interface for a Simulink normalization which maps both blocks and lines to
 * plain strings. It is also responsible for determining the weight of a block.
 * 
 * @author hummelb
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: A383E4CFA82A5197AE51F5A9F040A47B
 */
public interface ISimulinkNormalizer extends IDeepCloneable {

	/** Returns a normalized representation of the block. */
	public String normalizeBlock(SimulinkBlock block) throws ConQATException;

	/** Returns the weight for the given block. */
	public int determineWeight(SimulinkBlock block) throws ConQATException;

	/** Returns a normalized representation of the line. */
	public String normalizeLine(SimulinkLine line) throws ConQATException;
}
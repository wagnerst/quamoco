/*--------------------------------------------------------------------------+
$Id: NonOverlappingConstraint.java 31737 2010-11-26 16:20:03Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.constraint;

import java.util.List;

import edu.tum.cs.commons.collections.HashedListMap;
import edu.tum.cs.commons.region.Region;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author juergens
 * @author $Author: hummelb $
 * @version $Rev: 31737 $
 * @levd.rating GREEN Hash: 7F94DD4AD62AB013C0CFE194E3C2856A
 */
@AConQATProcessor(description = ""
		+ "Constraint that is satisfied if none of the clones of the CloneClass overlapp")
public class NonOverlappingConstraint extends ConstraintBase {

	/** {@inheritDoc} */
	public boolean satisfied(CloneClass cloneClass) {
		HashedListMap<String, Region> cloneRegions = new HashedListMap<String, Region>();

		// look for overlaps
		for (Clone clone : cloneClass.getClones()) {
			String uniformPath = clone.getUniformPath();
			Region cloneRegion = createCloneRegion(clone);

			if (overlaps(cloneRegion, cloneRegions.getList(uniformPath))) {
				return false;
			}
			cloneRegions.add(uniformPath, cloneRegion);
		}

		// if code reaches here, no overlap was found
		return true;
	}

	/** Creates a region for a clone */
	private Region createCloneRegion(Clone clone) {
		int start = clone.getStartLineInElement();
		int end = start + clone.getLengthInElement() - 1;
		return new Region(start, end);
	}

	/** Checks whether a region overlaps with any region in a list of regions */
	private boolean overlaps(Region cloneRegion, List<Region> regionsInSameFile) {
		if (regionsInSameFile == null) {
			return false;
		}

		for (Region region : regionsInSameFile) {
			if (region.overlaps(cloneRegion)) {
				return true;
			}
		}
		return false;
	}

}
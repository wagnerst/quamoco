/*--------------------------------------------------------------------------+
$Id: CloneNode.java 31740 2010-11-26 16:23:19Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.result;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.utils.EBooleanStoredValue;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * This class represents a single clone. It works as an adapter between
 * {@link Clone}s and {@link edu.tum.cs.conqat.commons.node.IConQATNode}s.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 31740 $
 * @levd.rating GREEN Hash: 0C45AE34196D6A2424437F9C3E4ECF8F
 */
public class CloneNode extends ConQATNodeBase {

	/** Clone represented by this CloneNode */
	private final Clone clone;

	/**
	 * Path prefix of clone element that gets pruned, since it is the same for
	 * all clones.
	 */
	private final String rootPath;

	/** The parent for this node. */
	private CloneClassNode parent = null;

	/** Create clone node from clone. */
	public CloneNode(Clone clone, String rootPath) {
		this.clone = clone;
		this.rootPath = rootPath;

		setValue(CloneListBuilderBase.CLONE_START_LINE, clone
				.getStartLineInElement());
		setValue(CloneListBuilderBase.CLONE_LENGTH_IN_LINES, clone
				.getLengthInElement());
		setValue(CloneListBuilderBase.GAP_COUNT, clone.getGapPositions().size());
		setValue(CloneListBuilderBase.COVERED, EBooleanStoredValue.COVERED
				.getValue(clone));
		setValue(CloneListBuilderBase.BIRTH, clone.getBirth());
	}

	/** Copy constructor. */
	private CloneNode(CloneNode node) throws DeepCloneException {
		super(node);
		clone = node.clone;
		rootPath = node.rootPath;
	}

	/** {@inheritDoc} */
	public String getId() {
		return clone.getUniformPath() + ":" + clone.getStartLineInElement()
				+ ":" + clone.getLengthInElement();
	}

	/** {@inheritDoc} */
	public String getName() {
		return clone.getUniformPath();
	}

	/** {@inheritDoc} */
	public CloneNode deepClone() throws DeepCloneException {
		return new CloneNode(this);
	}

	/** {@inheritDoc} */
	public IRemovableConQATNode[] getChildren() {
		return null;
	}

	/** {@inheritDoc} */
	public CloneClassNode getParent() {
		return parent;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return false;
	}

	/** Set the parent. */
	/* package */void setParent(CloneClassNode node) {
		parent = node;
	}
}
/*--------------------------------------------------------------------------+
$Id: PairReportGeneratorBase.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.tum.cs.commons.collections.CollectionUtils;
import edu.tum.cs.commons.collections.ImmutablePair;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.IdProvider;

/**
 * Base class for classes that generate reports containing clone pairs.
 * 
 * @author juergens
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 67898DCAB3DA7E1927ADA8C4FC9F3F69
 */
public abstract class PairReportGeneratorBase {

	/** Id provider used to create new clone class ids */
	protected final IdProvider idProvider = new IdProvider();

	/** Create paired {@link CloneClass}es */
	public List<CloneClass> createDetectionResult(List<CloneClass> cloneClasses) {
		List<CloneClass> pairClasses = new ArrayList<CloneClass>();

		for (CloneClass cloneClass : cloneClasses) {
			createPairClasses(cloneClass, pairClasses);
		}

		return pairClasses;
	}

	/** Create pair clone classes for all clones in a clone class */
	private void createPairClasses(CloneClass cloneClass,
			List<CloneClass> pairClasses) {
		for (ImmutablePair<Clone, Clone> clonePair : CollectionUtils
				.computeUnorderedPairs(cloneClass.getClones())) {
			pairClasses.addAll(createPairClasses(clonePair));
		}
	}

	/**
	 * Template method that deriving classes override to implement pair creation
	 */
	protected abstract Collection<? extends CloneClass> createPairClasses(
			ImmutablePair<Clone, Clone> clonePair);

}
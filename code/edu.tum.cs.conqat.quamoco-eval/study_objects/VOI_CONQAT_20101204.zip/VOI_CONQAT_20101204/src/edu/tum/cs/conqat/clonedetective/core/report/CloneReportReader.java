/*--------------------------------------------------------------------------+
$Id: CloneReportReader.java 31593 2010-11-26 10:43:42Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.core.report;

import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportAttribute.systemdate;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportElement.clone;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportElement.cloneClass;
import static edu.tum.cs.conqat.clonedetective.core.report.ECloneReportElement.sourceFile;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import edu.tum.cs.commons.assertion.CCSMAssert;
import edu.tum.cs.commons.reflect.TypeConversionException;
import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.commons.xml.XMLUtils;
import edu.tum.cs.conqat.clonedetective.core.Clone;
import edu.tum.cs.conqat.clonedetective.core.CloneClass;
import edu.tum.cs.conqat.clonedetective.core.KeyValueStoreBase;
import edu.tum.cs.conqat.core.ConQATException;

/**
 * Reads clone reports. This reader is used both by ConQAT and by
 * CloneInspector.
 * 
 * @author Elmar Juergens
 * @author $Author: hummelb $
 * @version $Rev: 31593 $
 * @levd.rating GREEN Hash: 5F02613307A4E52C5547B63ACA27B6D2
 */
public class CloneReportReader {

	/** Name of schema file. */
	private static final String CLONEREPORT_SCHEMA_NAME = "clonereport.xsd";

	/** Descriptors for all source files on which detection was performed */
	private final List<SourceElementDescriptor> sourceFileDescriptors = new ArrayList<SourceElementDescriptor>();

	/** List of the clone classes in the report */
	private final List<CloneClass> cloneClasses = new ArrayList<CloneClass>();

	/**
	 * Maps source file ids to {@link SourceElementDescriptor}s in order to resolve
	 * source files of clones
	 */
	private final Map<Integer, SourceElementDescriptor> sourceFileDescriptorsById = new HashMap<Integer, SourceElementDescriptor>();

	/** Date denoting the system version on which clone detection was performed */
	private Date systemDate;

	/**
	 * Reads the clone report.
	 * 
	 * @throws ConQATException
	 *             if report could not be parsed
	 */
	public CloneReportReader(File report) throws ConQATException {
		try {
			URL schema = CloneReportReader.class
					.getResource(CLONEREPORT_SCHEMA_NAME);
			CCSMAssert.isFalse(schema == null, "Schema not found.");

			Element root = XMLUtils.parse(report, schema).getDocumentElement();

			systemDate = dateAttribute(systemdate, root);
			parseSourceFilesDescriptors(root);
			parseCloneClasses(root);
		} catch (SAXException e) {
			throw new ConQATException("Could not parse file '" + report + ": "
					+ e.getMessage(), e);
		} catch (IOException e) {
			throw new ConQATException("Could not read file: " + e.getMessage(),
					e);
		}
	}

	/** Get list of {@link SourceElementDescriptor}s contained in report */
	public List<SourceElementDescriptor> getSourceFileDescriptors() {
		return sourceFileDescriptors;
	}

	/** Get list of clone classes contained in report */
	public List<CloneClass> getCloneClasses() {
		return cloneClasses;
	}

	/**
	 * Get the date denoting the system version on which clone detection was
	 * performed
	 */
	public Date getSystemDate() {
		return systemDate;
	}

	/** Reads source file information from the clone report. */
	private void parseSourceFilesDescriptors(Element rootElement) {
		for (Element sourceFileElement : childElements(rootElement, sourceFile)) {
			SourceElementDescriptor descriptor = parseSourceFileDescriptor(sourceFileElement);
			sourceFileDescriptorsById.put(descriptor.getId(), descriptor);
			sourceFileDescriptors.add(descriptor);
		}
	}

	/**
	 * Parses an {@link ECloneReportElement#sourceFile} into a
	 * {@link SourceElementDescriptor}
	 */
	private SourceElementDescriptor parseSourceFileDescriptor(
			Element sourceFileElement) {
		int id = intAttribute(ECloneReportAttribute.id, sourceFileElement);
		String uniformPath = stringAttribute(ECloneReportAttribute.path,
				sourceFileElement);

		// read (optional) location
		String location = stringAttribute(ECloneReportAttribute.location,
				sourceFileElement);
		if (StringUtils.isEmpty(location)) {
			location = uniformPath;
		}

		int length = intAttribute(ECloneReportAttribute.length,
				sourceFileElement);
		String fingerprint = stringAttribute(ECloneReportAttribute.fingerprint,
				sourceFileElement);

		return new SourceElementDescriptor(id, location, uniformPath, length,
				fingerprint);
	}

	/** Reads clone class information from the clone report */
	private void parseCloneClasses(Element rootElement) throws ConQATException {
		for (Element cloneClassElement : childElements(rootElement, cloneClass)) {
			CloneClass cloneClass = parseCloneClass(cloneClassElement);
			cloneClasses.add(cloneClass);
		}
	}

	/**
	 * Parses an {@link ECloneReportElement#cloneClass} into a
	 * {@link CloneClass}
	 */
	private CloneClass parseCloneClass(Element cloneClassElement)
			throws ConQATException {
		// create clone class
		int normalizedLength = intAttribute(
				ECloneReportAttribute.normalizedLength, cloneClassElement);
		int id = intAttribute(ECloneReportAttribute.id, cloneClassElement);
		CloneClass cloneClass = new CloneClass(normalizedLength, id);

		// add values
		parseValues(cloneClassElement, cloneClass);

		// add clones
		for (Element cloneElement : childElements(cloneClassElement, clone)) {
			Clone clone = parseClone(cloneElement, cloneClass);
			cloneClass.add(clone);
		}

		return cloneClass;
	}

	/**
	 * Parses the clone class values from a class element and stores them in the
	 * clone class
	 */
	private void parseValues(Element parentElement, KeyValueStoreBase store)
			throws ConQATException {
		try {
			List<Element> childElements = childElements(parentElement,
					ECloneReportElement.values);
			if (childElements.size() == 0) {
				// no value element found
				return;
			}

			Element valuesElement = childElements.get(0);
			for (Element valueElement : childElements(valuesElement,
					ECloneReportElement.value)) {
				String key = stringAttribute(ECloneReportAttribute.key,
						valueElement);
				String typeString = stringAttribute(ECloneReportAttribute.type,
						valueElement);
				String valueString = stringAttribute(
						ECloneReportAttribute.value, valueElement);

				store.setValue(key, valueString, typeString);
			}
		} catch (TypeConversionException e) {
			throw new ConQATException("Could not parse clone class value", e);
		} catch (ClassNotFoundException e) {
			throw new ConQATException("Could not parse clone class value", e);
		}
	}

	/**
	 * Parses an {@link ECloneReportElement#clone} into a {@link Clone}.
	 * 
	 * @param cloneClass
	 *            clone class this clone belongs to
	 */
	private Clone parseClone(Element cloneElement, CloneClass cloneClass)
			throws ConQATException {
		// read attributes
		int id = intAttribute(ECloneReportAttribute.id, cloneElement);
		int lineCount = intAttribute(ECloneReportAttribute.lineCount,
				cloneElement);
		int startLine = intAttribute(ECloneReportAttribute.startLine,
				cloneElement);
		int sourceFileId = intAttribute(ECloneReportAttribute.sourceFileId,
				cloneElement);
		String gaps = stringAttribute(ECloneReportAttribute.gaps, cloneElement);
		String fingerprint = stringAttribute(ECloneReportAttribute.fingerprint,
				cloneElement);
		int startUnitIndexInFile = intAttribute(
				ECloneReportAttribute.startUnitIndexInFile, cloneElement);
		int lengthInUnits = intAttribute(ECloneReportAttribute.lengthInUnits,
				cloneElement);
		int deltaInUnits = intAttribute(ECloneReportAttribute.deltaInUnits,
				cloneElement);

		// resolve clone origin
		CCSMAssert.isFalse(sourceFileDescriptorsById.get(sourceFileId) == null,
				"Inconsistent clone report: source file id unknown");
		SourceElementDescriptor fileDescriptor = sourceFileDescriptorsById
				.get(sourceFileId);

		// create clone
		Clone clone = new Clone(id, cloneClass, fileDescriptor.getLocation(),
				fileDescriptor.getUniformPath(), startLine, lineCount,
				startUnitIndexInFile, lengthInUnits, fingerprint, deltaInUnits);
		ReportUtils.parseGapOffsetString(clone, gaps);

		// add values
		parseValues(cloneElement, clone);

		// return clone
		return clone;
	}

	/**
	 * Return list of child elements with specified tag name from parent element
	 */
	private List<Element> childElements(Element parentElement,
			ECloneReportElement childElement) {
		return XMLUtils.getNamedChildren(parentElement, childElement.name());
	}

	/** Read int attribute from element */
	private int intAttribute(ECloneReportAttribute attribute, Element element) {
		return Integer.valueOf(element.getAttribute(attribute.name()));
	}

	/** Read string attribute from element */
	private String stringAttribute(ECloneReportAttribute attribute,
			Element element) {
		return element.getAttribute(attribute.name());
	}

	/**
	 * Read date attribute from element. Returns null, if the attribute could
	 * not be found.
	 */
	private Date dateAttribute(ECloneReportAttribute attribute, Element element)
			throws ConQATException {
		try {
			String dateString = stringAttribute(attribute, element);
			if (StringUtils.isEmpty(dateString)) {
				return null;
			}
			return new SimpleDateFormat(CloneReportWriter.DATE_PATTERN)
					.parse(dateString);
		} catch (ParseException e) {
			throw new ConQATException("Problems reading date attribute.", e);
		}
	}

}
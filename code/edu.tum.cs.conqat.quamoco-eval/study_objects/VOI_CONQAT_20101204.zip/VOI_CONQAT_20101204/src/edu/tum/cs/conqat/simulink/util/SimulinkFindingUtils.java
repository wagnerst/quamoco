/*--------------------------------------------------------------------------+
$Id: SimulinkFindingUtils.java 30490 2010-10-07 17:20:05Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.util;

import edu.tum.cs.conqat.commons.findings.EFindingKeys;
import edu.tum.cs.conqat.commons.findings.Finding;
import edu.tum.cs.conqat.commons.findings.FindingGroup;
import edu.tum.cs.conqat.commons.findings.location.FileLocation;
import edu.tum.cs.conqat.commons.findings.location.QualifiedNameLocation;
import edu.tum.cs.conqat.commons.node.NodeUtils;
import edu.tum.cs.conqat.simulink.scope.ISimulinkElement;

/**
 * Utility method for the Simulink bundle.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30490 $
 * @levd.rating GREEN Hash: E8C35F2FB8940D59C2BDF5D186E69E44
 */
public class SimulinkFindingUtils {

	/**
	 * Create a finding and attach it to a model element.
	 * 
	 * @param group
	 *            the finding group the finding belongs to
	 * @param originTool
	 *            the class that best describes the creating tool.
	 * @param message
	 *            the message
	 * @param element
	 *            the affected model element
	 * @param id
	 *            the qualified name of the affected element, e.g. a Simulink
	 *            block
	 * @param key
	 *            the key used to store the finding
	 * @return the created finding
	 */
	public static Finding createAndAttachFinding(FindingGroup group,
			Class<?> originTool, String message, ISimulinkElement element,
			String id, String key) {

		Finding finding = group.createFinding(originTool.getSimpleName());
		finding.setValue(EFindingKeys.MESSAGE.toString(), message);
		finding.addLocation(new QualifiedNameLocation(id));

		finding.addLocation(new FileLocation(element.getLocation(), element
				.getUniformPath()));
		NodeUtils.getOrCreateFindingsList(element, key).add(finding);

		return finding;
	}
}
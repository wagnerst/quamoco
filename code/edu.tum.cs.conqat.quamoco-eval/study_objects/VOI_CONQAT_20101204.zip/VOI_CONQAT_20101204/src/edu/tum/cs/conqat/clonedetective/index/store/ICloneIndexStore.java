/*--------------------------------------------------------------------------+
$Id: ICloneIndexStore.java 29795 2010-08-19 09:38:28Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index.store;

import java.io.Serializable;
import java.util.List;

import edu.tum.cs.commons.collections.UnmodifiableList;
import edu.tum.cs.commons.digest.MD5Digest;
import edu.tum.cs.conqat.clonedetective.index.Chunk;
import edu.tum.cs.conqat.database.store.StorageException;

/**
 * Interface for a clone index store. A clone index store is used to persist
 * chunk information collected and used during index-based clone detection.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29795 $
 * @levd.rating GREEN Hash: 6DB6C4B2DEBA58964B2DD831E9A04E99
 */
public interface ICloneIndexStore {

	/**
	 * Returns the object stored under the given key. If no object is stored,
	 * <code>null</code> should be returned.
	 */
	Serializable getOption(String key) throws StorageException;

	/**
	 * Stores an object under the given key. This is used to store certain clone
	 * detection options which have to be reused when updating data in the
	 * store.
	 */
	void setOption(String key, Serializable value)
			throws StorageException;

	/**
	 * Returns all stored {@link Chunk} objects for the given
	 * originId. Returns <code>null</code> if the file was not found.
	 */
	List<Chunk> getChunksByOrigin(String originId)
			throws StorageException;

	/**
	 * Returns the list of {@link Chunk}s stored for the given chunk
	 * hash. 
	 */
	UnmodifiableList<Chunk> getChunksByHash(MD5Digest chunkHash)
			throws StorageException;

	/**
	 * Inserts a batch of {@link Chunk}s. All chunks must belong to the same origin.
	 */
	void batchInsertChunks(List<Chunk> chunks)
			throws StorageException;

	/** Removes all chunks from the store which belong to the given originId name. */
	void removeChunks(String originId) throws StorageException;

	/**
	 * Closes this store. No operations should be performed on the store after
	 * calling this method.
	 */
	void close() throws StorageException;
}

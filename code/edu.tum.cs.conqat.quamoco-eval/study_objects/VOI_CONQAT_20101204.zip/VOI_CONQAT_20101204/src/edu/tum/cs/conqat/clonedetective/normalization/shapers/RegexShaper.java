/*--------------------------------------------------------------------------+
$Id: RegexShaper.java 31482 2010-11-25 14:49:34Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.shapers;

import java.io.Serializable;

import org.conqat.resource.text.ITextResource;

import edu.tum.cs.conqat.clonedetective.core.CloneDetectionException;
import edu.tum.cs.conqat.clonedetective.core.Unit;
import edu.tum.cs.conqat.clonedetective.detection.SentinelUnit;
import edu.tum.cs.conqat.clonedetective.normalization.UnitProviderBase;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IUnitProvider;
import edu.tum.cs.conqat.commons.pattern.PatternList;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.IConQATProcessor;
import edu.tum.cs.conqat.core.IConQATProcessorInfo;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: heineman $
 * @version $Rev: 31482 $
 * @levd.rating GREEN Hash: 0EF300AC9F90B117AE3BD99BD2D1061C
 */
@AConQATProcessor(description = ""
		+ "Inserts sentinels before units that match one of a set of regular expressions. "
		+ "Matching is performed on the textual representation of the units.")
public class RegexShaper extends UnitProviderBase<ITextResource, Unit>
		implements IConQATProcessor, Serializable {

	/** Underlying provider. */
	private IUnitProvider<ITextResource, Unit> provider;

	/** Patterns. Initialize to empty list in case it does not get set. */
	private final PatternList patterns = new PatternList();

	/** Flag that indicates that the last returned unit was a sentinel */
	private boolean lastWasSentinel = false;

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "unit", minOccurrences = 1, maxOccurrences = 1, description = ""
			+ "Unit provider")
	public void setUnitProvider(
			@AConQATAttribute(name = "provider", description = "Unit provider") IUnitProvider<ITextResource, Unit> provider) {
		this.provider = provider;
	}

	/** {@ConQAT.Doc} */
	@AConQATParameter(name = "patterns", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Patterns matching units before which sentinels are inserted")
	public void setPatterns(
			@AConQATAttribute(name = "ref", description = "Reference to pattern producer") PatternList patterns) {
		this.patterns.addAll(patterns);
	}

	/** {@inheritDoc} */
	@Override
	protected void init(ITextResource root) throws CloneDetectionException {
		provider.init(root, getLogger());
	}

	/** {@inheritDoc} */
	@Override
	protected Unit provideNext() throws CloneDetectionException {
		Unit nextUnit = provider.lookahead(1);
		if (nextUnit == null) {
			return null;
		}

		if (!lastWasSentinel && patterns.matchesAny(nextUnit.getContent())) {
			lastWasSentinel = true;
			return new SentinelUnit(nextUnit.getElementUniformPath());
		}

		lastWasSentinel = false;
		return provider.getNext();
	}

	/** {@inheritDoc} */
	public void init(IConQATProcessorInfo processorInfo) {
		// nothing to do
	}

	/** {@inheritDoc} */
	public IUnitProvider<ITextResource, Unit> process() {
		return this;
	}

}
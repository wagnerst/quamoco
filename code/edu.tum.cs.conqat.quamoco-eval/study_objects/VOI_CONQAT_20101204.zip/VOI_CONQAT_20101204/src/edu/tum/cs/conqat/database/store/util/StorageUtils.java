/*--------------------------------------------------------------------------+
$Id: StorageUtils.java 29797 2010-08-19 09:38:31Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database.store.util;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.string.StringUtils;
import edu.tum.cs.conqat.database.store.IKeyValueCallback;
import edu.tum.cs.conqat.database.store.IStore;
import edu.tum.cs.conqat.database.store.StorageException;

/**
 * Utility methods used for dealing with the storage system.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29797 $
 * @levd.rating GREEN Hash: C037D5B86BA20A5462430A1ED2D9A6D7
 */
public class StorageUtils {

	/** Returns the list of all keys as strings for the given store. */
	public static List<String> listStringKeys(IStore store)
			throws StorageException {
		final List<String> result = new ArrayList<String>();
		store.scan(new byte[0], new IKeyValueCallback() {
			@Override
			public void callback(byte[] key, byte[] value) {
				synchronized (result) {
					result.add(StringUtils.bytesToString(key));
				}
			}
		});
		return result;
	}

	/**
	 * Inserts an int value to the given position in the byte array. The storage
	 * will require 4 bytes in big endian byte order.
	 * 
	 * @throws ArrayIndexOutOfBoundsException
	 *             is the array is not large enough
	 */
	public static void insertInt(int i, byte[] bytes, int position) {
		bytes[position++] = (byte) ((i >> 24) & 0xff);
		bytes[position++] = (byte) ((i >> 16) & 0xff);
		bytes[position++] = (byte) ((i >> 8) & 0xff);
		bytes[position] = (byte) (i & 0xff);
	}

	/**
	 * Extracts an int value from the given array position (4 bytes in big
	 * endian). This is the counter part to {@link #insertInt(int, byte[], int)}
	 * .
	 * 
	 * @throws ArrayIndexOutOfBoundsException
	 *             is the array is not large enough
	 */
	public static int extractInt(byte[] bytes, int position) {
		int result = bytes[position++] & 0xff;
		result <<= 8;
		result |= bytes[position++] & 0xff;
		result <<= 8;
		result |= bytes[position++] & 0xff;
		result <<= 8;
		result |= bytes[position++] & 0xff;
		return result;
	}
}

/*--------------------------------------------------------------------------+
$Id: TokenNormalizationFactory.java 31530 2010-11-26 09:02:26Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization;

import org.conqat.sourcecode.resource.ITokenResource;

import edu.tum.cs.conqat.clonedetective.core.TokenUnit;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IUnitProvider;
import edu.tum.cs.conqat.clonedetective.normalization.token.TokenNormalization;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Creates a {@link TokenNormalization}.
 * <p>
 * Sentinels are inserted between tokens from different elements.
 * 
 * @author $Author: heineman $
 * @version $Revision: 31530 $
 * @levd.rating GREEN Hash: EB08E79763C6FA398582299D487BC3EA
 */
@AConQATProcessor(description = "Creates a TokenNormalization")
public class TokenNormalizationFactory extends
		TokenBasedNormalizationFactoryBase {

	/** {@inheritDoc} */
	public IUnitProvider<ITokenResource, TokenUnit> process() {
		return new TokenNormalization(tokenProvider, configurationList,
				defaultConfiguration, debugFileExtension);
	}
}
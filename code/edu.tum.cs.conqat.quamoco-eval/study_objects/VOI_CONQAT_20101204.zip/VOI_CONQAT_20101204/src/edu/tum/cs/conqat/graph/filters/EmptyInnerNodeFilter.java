/*--------------------------------------------------------------------------+
$Id: EmptyInnerNodeFilter.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.filters;

import java.util.ArrayList;

import edu.tum.cs.conqat.commons.ConQATPipelineProcessorBase;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.graph.nodes.ConQATGraph;
import edu.tum.cs.conqat.graph.nodes.ConQATGraphInnerNode;

/**
 * This filter removes inner nodes which are not needed anymore as they carry no
 * vertices.
 * 
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: F1F9FF90CCBF266432508782680A7BB0
 */
@AConQATProcessor(description = "This filter removes inner nodes having no children.")
public class EmptyInnerNodeFilter extends
		ConQATPipelineProcessorBase<ConQATGraph> {

	/** {@inheritDoc} */
	@Override
	protected void processInput(ConQATGraph graph) {
		for (ConQATGraphInnerNode child : new ArrayList<ConQATGraphInnerNode>(
				graph.getInnerNodes())) {
			checkNode(child);
		}
	}

	/** Checks the node and removes it if required. */
	private void checkNode(ConQATGraphInnerNode node) {
		// copy the list as we remove
		for (ConQATGraphInnerNode child : new ArrayList<ConQATGraphInnerNode>(
				node.getInnerNodes())) {
			checkNode(child);
		}
		if (!node.hasChildren()) {
			node.remove();
		}
	}
}
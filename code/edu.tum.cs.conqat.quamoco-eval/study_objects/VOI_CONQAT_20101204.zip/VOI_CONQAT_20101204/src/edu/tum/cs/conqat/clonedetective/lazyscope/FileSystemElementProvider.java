/*--------------------------------------------------------------------------+
$Id: FileSystemElementProvider.java 31494 2010-11-25 15:47:22Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import java.util.List;

import org.conqat.resource.text.ITextElement;
import org.conqat.resource.text.ITextResource;

import edu.tum.cs.conqat.filesystem.regions.RegionMarkerStrategyBase;

/**
 * Provider for {@link ITextResource}s.
 * <p>
 * Remark on implementation: this class only sets the generic parameter its base
 * class to {@link ITextResource}. This way, the ConQAT load time type checking
 * mechanism does not have to deal with generic types (which it cannot).
 * 
 * @author $Author: heineman $
 * @version $Rev: 31494 $
 * @levd.rating GREEN Hash: A6200318BBE1FB7FD06C6EF9C0E1FA93
 */
public class FileSystemElementProvider extends
		ElementProviderBase<ITextResource, ITextElement> {

	/** Constructor. */
	public FileSystemElementProvider() {
		// nothing to do
	}

	/** Constructor. */
	public FileSystemElementProvider(
			List<RegionMarkerStrategyBase<ITextElement>> strategies) {
		super(strategies);
	}

	/** {@inheritDoc} */
	@Override
	protected Class<ITextElement> getElementClass() {
		return ITextElement.class;
	}
}
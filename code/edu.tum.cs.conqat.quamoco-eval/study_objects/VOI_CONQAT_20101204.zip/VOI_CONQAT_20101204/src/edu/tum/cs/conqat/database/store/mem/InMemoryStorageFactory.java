/*--------------------------------------------------------------------------+
$Id: InMemoryStorageFactory.java 28964 2010-07-01 10:27:26Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.database.store.mem;

import java.io.File;

import edu.tum.cs.conqat.commons.ConQATProcessorBase;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;
import edu.tum.cs.conqat.core.ConQATException;
import edu.tum.cs.conqat.core.IShutdownHook;
import edu.tum.cs.conqat.database.store.IStorageSystem;

/**
 * {@ConQAT.Doc}
 * 
 * @author hummelb
 * @author $Author: hummelb $
 * @version $Rev: 28964 $
 * @levd.rating GREEN Hash: 956755D0766A36F6E082A96EA168B37A
 */
@AConQATProcessor(description = "A simple in-memory implementation of a storage system. "
		+ "It also supports disk-based persistence, but the entire store must fit into main memory.")
public class InMemoryStorageFactory extends ConQATProcessorBase {

	/** The name of the base directory to store the data in. */
	private File baseDirectory;

	/**
	 * {@ConQAT.Doc}
	 * <p>
	 * 
	 * Note that in this processor, the directory is optional! So it can not be
	 * merged with other disk-based stores in a common super class.
	 */
	@AConQATParameter(name = "storage", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "The directory where the data is stored in. "
			+ "If this is not provided, no persistence across individual runs will occur.")
	public void setBaseDirectory(
			@AConQATAttribute(name = "dir", description = "Name of the directory.") String baseDirectory) {
		this.baseDirectory = new File(baseDirectory);
	}

	/** {@inheritDoc} */
	@Override
	public IStorageSystem process() throws ConQATException {
		final InMemoryStorageSystem storageSystem = new InMemoryStorageSystem(
				baseDirectory);
		getProcessorInfo().registerShutdownHook(new IShutdownHook() {
			@Override
			public void performShutdown() throws ConQATException {
				storageSystem.close();
			}
		}, false);
		return storageSystem;
	}
}

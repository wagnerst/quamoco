/*--------------------------------------------------------------------------+
$Id: MSWordTextElementFactory.java 31811 2010-11-30 16:56:04Z juergens $
|                                                                          |
| Copyright 2005-2010 by the ConQAT Project                                |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.text.msword;

import org.conqat.resource.IContentAccessor;
import org.conqat.resource.IElement;
import org.conqat.resource.text.TextFilterAwareElementFactoryBase;

import edu.tum.cs.conqat.core.AConQATFieldParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * {@ConQAT.Doc}
 * 
 * @author $Author: juergens $
 * @version $Rev: 31811 $
 * @levd.rating GREEN Hash: E7CFCF2AC087800585EB7219C006D4F5
 */
@AConQATProcessor(description = "Factory for treating MS Word files as text files.")
public class MSWordTextElementFactory extends TextFilterAwareElementFactoryBase {

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "wrap-at-dot", attribute = "value", optional = true, description = ""
			+ "If set to true, a newline is inserted after each dot (default is false).")
	private final boolean wrapAtDot = false;

	/** {@ConQAT.Doc} */
	@AConQATFieldParameter(parameter = "wrap-at-whitespace", attribute = "value", optional = true, description = ""
			+ "If set to true, a newline is inserted after each whitespace block (default is false).")
	private final boolean wrapAtWhitespace = false;

	/** {@inheritDoc} */
	@Override
	public IElement create(IContentAccessor accessor) {
		return new MSWordTextElement(accessor, getFilters(), wrapAtDot,
				wrapAtWhitespace);
	}
}

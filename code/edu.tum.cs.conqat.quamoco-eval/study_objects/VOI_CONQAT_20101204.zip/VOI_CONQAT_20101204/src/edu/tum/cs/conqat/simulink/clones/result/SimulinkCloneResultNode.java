/*--------------------------------------------------------------------------+
$Id: SimulinkCloneResultNode.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.simulink.clones.result;

import java.util.ArrayList;
import java.util.List;

import edu.tum.cs.commons.clone.DeepCloneException;
import edu.tum.cs.conqat.commons.node.ConQATNodeBase;
import edu.tum.cs.conqat.commons.node.IConQATNode;
import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * Result of a simulink clone detection. Basically this is just a list of
 * clones.
 * 
 * @author hummelb
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: 682984DDCDBB6372B00DB853776D6DD2
 */
public class SimulinkCloneResultNode extends ConQATNodeBase implements
		IRemovableConQATNode {

	/** The children of this node. */
	private final List<SimulinkClone> clones = new ArrayList<SimulinkClone>();

	/** Constructor. */
	public SimulinkCloneResultNode() {
		// nothing to do.
	}

	/** Copy constructor. */
	private SimulinkCloneResultNode(SimulinkCloneResultNode node)
			throws DeepCloneException {
		super(node);
		for (SimulinkClone clone : node.clones) {
			addChild(clone.deepClone());
		}
	}

	/** Add a clone to the list. */
	public void addChild(SimulinkClone clone) {
		clones.add(clone);
		clone.setParent(this);
	}

	/** {@inheritDoc} */
	public SimulinkClone[] getChildren() {
		return clones.toArray(new SimulinkClone[clones.size()]);
	}

	/** {@inheritDoc} */
	public void remove() {
		// nothing to do; this is root
	}

	/** {@inheritDoc} */
	public String getId() {
		return "Simulink Clone Result";
	}

	/** {@inheritDoc} */
	public String getName() {
		return getId();
	}

	/** {@inheritDoc} */
	public IConQATNode getParent() {
		return null;
	}

	/** {@inheritDoc} */
	public boolean hasChildren() {
		return !clones.isEmpty();
	}

	/** {@inheritDoc} */
	public SimulinkCloneResultNode deepClone() throws DeepCloneException {
		return new SimulinkCloneResultNode(this);
	}

	/** Remove the given child node. */
	/* package */void removeChild(SimulinkClone clone) {
		clones.remove(clone);
	}
}
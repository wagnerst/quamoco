/*--------------------------------------------------------------------------+
$Id: SourceCodeElementProviderFactory.java 31494 2010-11-25 15:47:22Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import org.conqat.sourcecode.resource.ITokenElement;

import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Creates a {@link SourceCodeElementProvider}.
 * <p>
 * This class could be unified with {@link FileSystemElementProvider} using
 * generics. However, since the ConQAT load time type checking mechanism cannot
 * deal with generics, this was deliberately not done.
 * 
 * @author $Author: heineman $
 * @version $Revision: 31494 $
 * @levd.rating GREEN Hash: 692CB4EFE27532E23AC06CB1F36452B7
 */
@AConQATProcessor(description = "Creates a SourceCodeElementProvider")
public class SourceCodeElementProviderFactory extends
		ElementProviderFactoryBase<ITokenElement> {

	/** Creates a {@link SourceCodeElementProvider} */
	public SourceCodeElementProvider process() {
		return new SourceCodeElementProvider(strategies);
	}
}
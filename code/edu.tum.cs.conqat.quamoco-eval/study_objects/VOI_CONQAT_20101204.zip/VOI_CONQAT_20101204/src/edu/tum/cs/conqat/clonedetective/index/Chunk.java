/*--------------------------------------------------------------------------+
$Id: Chunk.java 29795 2010-08-19 09:38:28Z deissenb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.index;

import edu.tum.cs.commons.digest.MD5Digest;

/**
 * Class for describing basic information for a chunk of units. This class is
 * immutable.
 * 
 * @author hummelb
 * @author $Author: deissenb $
 * @version $Rev: 29795 $
 * @levd.rating GREEN Hash: DFC5B837F84BB4F1B193ECB937D7ACC9
 */
public class Chunk {

	/** The origin of the chunk (e.g. a filename). */
	private final String originId;

	/** Hash value of the chunk. */
	private final MD5Digest chunkHash;

	/** Index of first unit in the chunk. */
	private final int firstUnitIndex;

	/** First line of the chunk. */
	private final int firstLineNumber;

	/** Last line of the chunk. */
	private final int lastLineNumber;

	/** Constructor. */
	public Chunk(String originId, MD5Digest chunkHash,
			int firstUnitIndex, int firstLineNumber, int lastLineNumber) {
		this.originId = originId;
		this.chunkHash = chunkHash;
		this.firstUnitIndex = firstUnitIndex;
		this.firstLineNumber = firstLineNumber;
		this.lastLineNumber = lastLineNumber;
	}

	/** Returns the origin of the chunk (for example the name of the file). */
	public String getOriginId() {
		return originId;
	}

	/** Returns the hash value of the chunk. */
	public MD5Digest getChunkHash() {
		return chunkHash;
	}

	/** Returns the index of first unit in the chunk. */
	public int getFirstUnitIndex() {
		return firstUnitIndex;
	}

	/** Returns the first line of the chunk. */
	public int getFirstLineNumber() {
		return firstLineNumber;
	}

	/** Returns the last line of the chunk. */
	public int getLastLineNumber() {
		return lastLineNumber;
	}

	/** {@inheritDoc} */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Chunk)) {
			return false;
		}
		Chunk other = (Chunk) obj;
		return other.originId.equals(originId)
				&& other.chunkHash.equals(chunkHash)
				&& other.firstUnitIndex == firstUnitIndex
				&& other.firstLineNumber == firstLineNumber
				&& other.lastLineNumber == lastLineNumber;
	}

	/**
	 * Hash code is only based on originId, chunk hash and first unit, as
	 * remaining fields typically should depend on these fields.
	 */
	@Override
	public int hashCode() {
		return originId.hashCode() + 13 * chunkHash.hashCode() + 413
				* firstUnitIndex;
	}
}

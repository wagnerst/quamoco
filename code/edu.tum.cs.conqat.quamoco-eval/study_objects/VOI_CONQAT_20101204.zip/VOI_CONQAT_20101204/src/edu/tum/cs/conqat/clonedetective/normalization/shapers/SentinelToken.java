/*--------------------------------------------------------------------------+
$Id: SentinelToken.java 30655 2010-10-18 15:56:27Z hummelb $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization.shapers;

import edu.tum.cs.scanner.ELanguage;
import edu.tum.cs.scanner.ETokenType;
import edu.tum.cs.scanner.IToken;
import edu.tum.cs.scanner.Token;

/**
 * Sentinel Token. Sentinels tokens have a unique textual content and are thus
 * unequal to any other tokens.
 * 
 * @author $Author: hummelb $
 * @version $Rev: 30655 $
 * @levd.rating GREEN Hash: 88E29D6D30657BEFD2F0024CBEAE6BCA
 */
/* package */class SentinelToken extends Token {

	/**
	 * Creates a sentinel token whose origin information is copied from the
	 * token after which the sentinel is to be inserted
	 */
	public static SentinelToken createSentinelAfter(IToken token) {
		return new SentinelToken(ETokenType.SENTINEL, token.getOffset(), token
				.getLineNumber(), "\u00A7" + counter++, token.getOriginId(),
				token.getLanguage());
	}

	/** Counter used to create unique sentinel texts */
	private static int counter = 0;

	/** Stores language */
	private final ELanguage language;

	/** Constructor */
	protected SentinelToken(ETokenType type, int offset, int lineNumber,
			String text, String originId, ELanguage language) {
		super(type, offset, lineNumber, text, originId);
		this.language = language;
	}

	/** {@inheritDoc} */
	public ELanguage getLanguage() {
		return language;
	}

	/** {@inheritDoc} */
	public IToken newToken(ETokenType type, int offset, int lineNumber,
			String text, String originId) {
		return new SentinelToken(type, offset, lineNumber, text, originId,
				language);
	}

}
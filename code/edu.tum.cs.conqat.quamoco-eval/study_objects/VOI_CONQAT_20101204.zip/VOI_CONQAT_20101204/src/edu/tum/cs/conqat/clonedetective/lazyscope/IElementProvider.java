/*--------------------------------------------------------------------------+
$Id: IElementProvider.java 31494 2010-11-25 15:47:22Z heineman $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.lazyscope;

import org.conqat.resource.text.ITextElement;
import org.conqat.resource.text.ITextResource;

import edu.tum.cs.commons.error.NeverThrownRuntimeException;
import edu.tum.cs.conqat.clonedetective.normalization.provider.IProvider;

/**
 * Interface for {@link ITextResource} providing components.
 * 
 * @author $Author: heineman $
 * @version $Revision: 31494 $
 * @levd.rating GREEN Hash: A0D212349BF7A216B7A800F55BCCDC57
 */
public interface IElementProvider<R extends ITextResource, E extends ITextElement>
		extends IProvider<R, E, NeverThrownRuntimeException> {
	// Nothing to do
}
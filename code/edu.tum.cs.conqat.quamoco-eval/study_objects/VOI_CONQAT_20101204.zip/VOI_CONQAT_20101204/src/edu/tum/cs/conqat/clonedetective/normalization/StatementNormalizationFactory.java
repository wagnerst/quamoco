/*--------------------------------------------------------------------------+
$Id: StatementNormalizationFactory.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.clonedetective.normalization;

import edu.tum.cs.conqat.clonedetective.normalization.statement.StatementNormalization;
import edu.tum.cs.conqat.core.AConQATAttribute;
import edu.tum.cs.conqat.core.AConQATParameter;
import edu.tum.cs.conqat.core.AConQATProcessor;

/**
 * Creates a {@link StatementNormalization}.
 * 
 * @author Elmar Juergens
 * @author $Author: juergens $
 * 
 * @version $Revision: 26282 $
 * @levd.rating GREEN Hash: 30F77B92FEF38E2A7D3A19B717754DEF
 */
@AConQATProcessor(description = "Creates a StatementNormalization")
public class StatementNormalizationFactory extends
		TokenBasedNormalizationFactoryBase {

	/** Flag that determines whether underlying tokens are stored */
	private boolean storeTokens = false;

	/** ConQAT Parameter */
	@AConQATParameter(name = "store", minOccurrences = 0, maxOccurrences = 1, description = ""
			+ "Flag that determines whether underlying tokens are stored")
	public void setStoreTokens(
			@AConQATAttribute(name = "tokens", description = "Default is false")
			boolean storeTokens) {
		this.storeTokens = storeTokens;
	}

	/** {@inheritDoc} */
	public StatementNormalization process() {
		return new StatementNormalization(tokenProvider, configurationList,
				defaultConfiguration, storeTokens, debugFileExtension);
	}

}
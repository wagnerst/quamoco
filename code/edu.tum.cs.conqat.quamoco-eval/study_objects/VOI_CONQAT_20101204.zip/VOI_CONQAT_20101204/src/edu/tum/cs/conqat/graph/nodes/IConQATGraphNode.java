/*--------------------------------------------------------------------------+
$Id: IConQATGraphNode.java 26282 2010-02-18 11:13:33Z juergens $
|                                                                          |
| Copyright 2005-2010 Technische Universitaet Muenchen                     |
|                                                                          |
| Licensed under the Apache License, Version 2.0 (the "License");          |
| you may not use this file except in compliance with the License.         |
| You may obtain a copy of the License at                                  |
|                                                                          |
|    http://www.apache.org/licenses/LICENSE-2.0                            |
|                                                                          |
| Unless required by applicable law or agreed to in writing, software      |
| distributed under the License is distributed on an "AS IS" BASIS,        |
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. |
| See the License for the specific language governing permissions and      |
| limitations under the License.                                           |
+--------------------------------------------------------------------------*/
package edu.tum.cs.conqat.graph.nodes;

import edu.tum.cs.conqat.commons.node.IRemovableConQATNode;

/**
 * This is the most general interface for ConQATNodes in the hierarchy of the
 * ConQAT graph. A {@link IConQATGraphNode} is either a
 * {@link IConQATGraphInnerNode} or an {@link IConQATGraphVertex}.
 * <p>
 * This does not introduce new methods but only makes some return values more
 * concrete.
 * 
 * @author Benjamin Hummel
 * @author $Author: juergens $
 * @version $Rev: 26282 $
 * @levd.rating GREEN Hash: A879F5B943528FC218C2FB4BAA8E4434
 */
public interface IConQATGraphNode extends IRemovableConQATNode {

	/** {@inheritDoc} */
	public IConQATGraphNode[] getChildren();

	/** {@inheritDoc} */
	public IConQATGraphInnerNode getParent();
}